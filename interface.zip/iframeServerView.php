<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("./config/config.php");
	require_once("./lang/lang.php");
	require_once("./php/functions/functions.php");
	require_once("./php/functions/functionsSql.php");
	require_once('./php/functions/functionsTeamspeak.php');
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/** 
		Could not load all settings
	*/
	if(!$settings['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
?>

<html>
	<head>
		<link rel="stylesheet" type="text/css" href="./css/other/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="./css/bootstrap/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="./css/style.css" />
	</head>
	<body class="iframe" style="color:#<?php echo htmlentities($_GET['color']); ?>;background-color:<?php echo htmlentities($_GET['bodybgcolor']); ?>;font-size:<?php echo htmlentities($_GET['fontsize']); ?>">
		<div id="newTree" class="tree">
			<div class="treeLoading" style="background-color:<?php echo htmlentities($_GET['spinbgcolor']); ?>;">
				<div>
					<h3><?php echo $language['tree_loading']; ?></h3>
					<i class="fas fa-spinner fa-spin fa-2x"></i>
				</div>
			</div>
		</div>
	</body>
	
	<script src="./js/jquery/jquery.min.js"></script>
	<script src="js/other/functions.js"></script>
	<script src="js/webinterface/teamspeak.js"></script>
	<script language="JavaScript">
		var instance = '<?php echo htmlentities($_GET['instanz']); ?>',
			port = '<?php echo htmlentities($_GET['port']); ?>',
			treeInterval = <?php echo ($settings['data']['ts_tree_intervall'] / 1000); ?>,
			jsonLang = '<?php echo str_replace('\"', "", json_encode($language)); ?>',
			lang = JSON.parse(jsonLang);
		
		new TeamspeakTree({
			id: 'newTree',
			instance: instance,
			port: port,
			interval: treeInterval
		});
		
		/**
			Extend obj function
		*/
		function extend(a, b) {
			for(var key in b) {
				if(b.hasOwnProperty(key)) {
					a[key] = b[key];
				};
			};
			
			return a;
		};
	</script>
</html>