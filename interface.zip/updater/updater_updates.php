<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("../lang/lang.php");
	require_once("../config/instance.php");
	require_once("../config/instance-bot.php");
	require_once("../php/functions/functions.php");
	require_once("../php/functions/functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success'] || !$settings['success']) {
		if($user_right['data']['perm_admin_settings_main'] != $mysql_keys['perm_admin_settings_main']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_settings_main missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Soap loading
	*/
	$team[] = array('name' => 'L.Gmann', 'job' => 'Manager and Developer', 'skills' => array('PHP', 'JavaScript', 'C#', 'C', 'CSS3', 'Shell'), 'rname' => 'Lukas G.', 'mail' => 'admin@first-coder.de', 'member_since' => '2012');
	$team[] = array('name' => 'SoulofSorrow', 'job' => 'Manager and Sponsor', 'skills' => array('Shell', 'Nginx', 'Apache'), 'rname' => 'Julian S.', 'mail' => 'admin@ts-3.io', 'member_since' => '2015');
	$error = null;
	
	try {
		$client = new SoapClient(null, array(
			'location' => 'http://wiki.first-coder.de/soap/soap_server_version_two.php',
			'uri' => 'https://wiki.first-coder.de/soap/soap_server_version_two.php'
		));
		
		$versionList = array_reverse(json_decode($client->getVersionList($settings['data']['donator'], false)));
		$tmpVersionNumber = $tmpVersionNumber2 = count($versionList)-1;
		
		// Changelogs
		for($i = 0;$i <= $tmpVersionNumber;$i++) {
			$log = $client->getChangelog($i);
			
			if(empty($log)) {
				continue;
			};
			
			$split = explode('-', $log[0]);
			echo	'<div class="modal fade" id="modal-'.$i.'" tabindex="-1" aria-hidden="true">
						<div class="modal-dialog modal-dialog-centered modal-lg">
							<div class="modal-content modal-custom">
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									&times;
								</button>
								<div class="modal-body pb-0 form">
									<div class="header">
										<h1>'.$split[0].'</h1>
										<h2>';
										for($a = 1;$a < count($split);$a++) {
											if($a != 1) {
												echo '-';
											};
											echo $split[$a];
										};
			echo						'</h2>
									</div>
									<hr/>
									<ul class="changelog_tmtimeline">
										<li>
											<time class="changelog_tmtime"><span>'.$log[1].'</span></time>
											<div class="changelog_tmicon changelog_tmicon-pc"></div>
											<div class="changelog_tmlabel"
												<p class="mb-0">';
													for($entry = 2;$entry < count($log);$entry++) {
														if($log[$entry][0] == "-" && $log[$entry][1] == "-") {
															echo "<i class=\"fas fa-bug\"></i> ".substr($log[$entry], 3)."<br/>";
														} else {
															switch($log[$entry][0]) {
																case "+":
																	echo "<font class=\"text-success\"><i class=\"fas fa-plus\"></i> ".substr($log[$entry], 1)."</font><br/>";
																	break;
																case "-":
																	echo "<font class=\"text-danger\"><i class=\"fas fa-minus\"></i> ".substr($log[$entry], 1)."</font><br/>";
																	break;
																default:
																	echo $log[$entry]."<br/>";
																	break;
															};
														};
														
													};
			echo 								'</p>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>';
		};
	} catch(Exception $e) {
		$error = $e;
	};
?>

<div class="content-header color-header">Updates</div>

<div class="row shadow-default-content mb-3">
	<div class="col-lg7 border-right widget col-lg in-sm bottom table-search-100">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-history"></i> <?php echo $language['history']; ?></h4>
			<h6 class="sub-title text-muted">First-Coder TS Webinterface Version 2.X.X</h6>
		</div>
		<table id="table" data-card-view="false" data-classes="table-no-bordered table-hover table" data-striped="true" data-pagination="true" data-search="true">
			<thead>
				<tr>
					<th data-field="version"><?php echo $language['version']; ?></th>
					<th data-field="type"><?php echo $language['type']; ?></th>
					<th data-field="status"><?php echo $language['status']; ?></th>
					<th data-field="actions"></th>
				</tr>
			</thead>
			<tbody>
				<?php if(!empty($versionList)) {
					$updatePossible = -1;
					foreach($versionList AS $version)
					{
						if($version == INTERFACE_VERSION)
						{
							$tmpVersion = true;
						};
						
						if(!$tmpVersion)
						{
							$updatePossible = $tmpVersionNumber2;
						};
						
						$tmpVersionNumber2--;
					};
					$tmpVersion = false;
					
					foreach($versionList AS $version) {
						$split = explode('-', $version);
						
						echo 	'<tr>
									<td>'.$split[0].'</td>
									<td>';
										for($i = 1;$i < count($split);$i++) {
											if($i != 1) {
												echo '-';
											};
											echo $split[$i];
										};
						echo		'</td>
									<td>';
										if($version == INTERFACE_VERSION) {
											$tmpVersion = true;
											echo $language['current_version'];
										} else if(!$tmpVersion) {
											echo '<span class="text-success">'.$language['new_version'].'</span>';
										} else {
											echo '<span class="text-danger">'.$language['old_version'].'</span>';
										};
						echo		'</td>
									<td>';
										if($updatePossible == $tmpVersionNumber) {
											echo '<button data-toggle="modal" data-target="#modal-'.$tmpVersionNumber.'" data-update="true" data-number="'.$tmpVersionNumber.'" class="btn btn-custom btn-blue">'.$language['changelog'].'</button>';
										} else {
											echo '<button data-toggle="modal" data-target="#modal-'.$tmpVersionNumber.'" data-update="false" data-number="'.$tmpVersionNumber.'" class="btn btn-custom btn-blue">'.$language['changelog'].'</button>';
										};
						echo		'</td>
								</tr>';
						
						$tmpVersionNumber--;
					};
				}; ?>
			</tbody>
		</table>
	</div>
	<div id="process" class="col-lg-5 widget col-lg in-sm top">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-server"></i> <?php echo $language['connection']; ?></h4>
			<h6 class="sub-title text-muted">First-Coder.de SOAP Server</h6>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col text-center" id="start-update">
				<div class="updater-icon icon-success <?php echo ($updatePossible > 0) ? 'icon-button' : ''; ?>" style="margin: auto;display: inline-block;">
					<i class="fas fa-check-double"></i>
				</div>
				<div class="text-success ml-2" style="display: inline-block;">
					<?php echo ($updatePossible > 0) ? '<b>'.$language['update_start'].'</b>' : $language['no_updates']; ?>
				</div>
			</div>
		</div>
		<?php if($e === null) { ?>
			<hr class="hr-headline mb-3"/>
			<div class="row mb-3">
				<div class="col">
					<i class="fas fa-code-branch w-20"></i> <?php echo $language['newest_version']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-success"><?php echo checkNewVersion(); ?></span>
				</div>
			</div>
			<div class="row mb-3">
				<div class="col">
					<i class="fas fa-info w-20"></i> <?php echo $language['current_version']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-primary"><?php echo INTERFACE_VERSION; ?></span>
				</div>
			</div>
			<hr class="hr-headline mb-3"/>
		<?php }; ?>
	</div>
</div>

<script src="../js/bootstrap/bootstrap-table.js"></script>
<script>
	/**
		Start updater
	*/
	$('#start-update').on('click', '.icon-button, .btn-red', function() {
		var $this = $(this).closest('#start-update');
		var el = '<div class="row mb-3">\
					<div class="col-8 text-left">\
						<i class="fas fa-folder w-20"></i> Check Permissions\
					</div>\
					<div class="col text-right">\
						<span class="badge badge-text badge-danger" data-process="permissions">0%</span>\
					</div>\
				</div>\
				<div class="row mb-3">\
					<div class="col-8 text-left">\
						<i class="fas fa-download w-20"></i> Download update\
					</div>\
					<div class="col text-right">\
						<span class="badge badge-text badge-danger" data-process="download">0%</span>\
					</div>\
				</div>\
				<div class="row mb-3">\
					<div class="col-8 text-left">\
						<i class="fas fa-terminal w-20"></i> Execute updater.php\
					</div>\
					<div class="col text-right">\
						<span class="badge badge-text badge-danger" data-process="execute">0%</span>\
					</div>\
				</div>\
				<div class="row mb-3">\
					<div class="col-8 text-left">\
						<i class="fas fa-file w-20"></i> Override files\
					</div>\
					<div class="col text-right">\
						<span class="badge badge-text badge-danger" data-process="override">0%</span>\
					</div>\
				</div>\
				<div id="error-update"></div>\
				<button class="btn btn-red btn-custom disabled" disabled>Updating...</button>';
		$this.html(el);
		
		$.ajax({
			type: "POST",
			url: "./functionsUpdate.php",
			data: {
				id: $('#table button[data-update="true"]').attr('data-number')
			},
			success: function(data) {
				var json = JSON.parse(data);
				console.log(json);
				for(var d in json.data) {
					if(json.data[d]) {
						$('#process span.badge[data-process="'+d+'"]').removeClass('badge-danger').addClass('badge-success').text('100%');
					};
				};
				
				if(json.success) {
					$('#process button').removeClass('disabled').removeClass('btn-red').prop('disabled', false).addClass('btn-green').attr('id', '').attr('onClick', 'changeContent(\'updater_updates\', false);').text(lang.done);
				} else {
					$('#error-update').html(
						'<hr class="hr-headline mb-3"/>\
						<div class="row mb-3">\
							<div class="col text-left text-danger">\
								<i class="fas fa-exclamation w-20"></i> '+lang.failed+'<p class="mb-0">'+json.error+'</p>\
							</div>\
						</div>\
						<hr class="hr-headline mb-3"/>'
					);
					$('#process button').removeClass('disabled').prop('disabled', false).text(lang.retry);
				};
			}
		});
	});
	
	/**
		History table
	*/
	$('#table').bootstrapTable({
		formatNoMatches: function () {
			return lang.no_entrys;
		}
	});
</script>