<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once("../config/config.php");
	require_once("../lang/lang.php");
	require_once("../php/functions/functions.php");
	require_once("../php/functions/functionsSql.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	$hasRights			=	true;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		$hasRights		=	false;
	};
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_hp_main']['key'] != $mysql_keys['right_hp_main'])
	{
		$hasRights		=	false;
	};
?>

<!doctype html>
<html lang="en" class="custom-bg">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
		<meta name="viewport" content="width=700, initial-scale=0.5"> 
		
		<title><?php echo xssSafe(HEADING)." -- Teamspeak3 Control Panel -- Updater"; ?></title>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="author" content="First Coder: L.Gmann" />
		
		<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
		
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Courgette|Kreon">
		
		<link rel="stylesheet" type="text/css" href="../css/other/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="../css/other/toastr.css" />
		<link rel="stylesheet" type="text/css" href="../css/other/sweetalert2.css" />
		<link rel="stylesheet" type="text/css" href="../css/other/dropzone.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap-table.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap-material-datetimepicker.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap-colorpicker.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap-editable.css" />
		<link rel="stylesheet" type="text/css" href="../css/mail/codemirror.css" />
		<link rel="stylesheet" type="text/css" href="../editor/contents.css" />
		<link rel="stylesheet" type="text/css" href="../css/style.css" />
		
		<script src="../js/jquery/jquery.min.js"></script>
		<script src="../js/jquery/jquery.bootstrap.js"></script>
		<script src="../js/other/tether.js"></script>
		<script src="../js/other/functions.js"></script>
		<script src="../js/other/navigation.js"></script>
		<script src="../js/other/arrive.js"></script>
		<script src="../js/other/approve.js"></script>
		<script src="../js/other/toastr.js"></script>
		<script src="../js/other/sweetalert2.js"></script>
		<script src="../js/other/draggabilly.pkgd.js"></script>
		<script src="../js/bootstrap/bootstrap-material-design.iife.js"></script>
		<script src="../js/bootstrap/bootstrap-table.js"></script>
		<script>
			var OverlayButton = new OverlayButton();
		</script>
	</head>
	<body>
		<!-- Header -->
		<nav class="navbar">
			<span class="navbar-brand nav-title"><?php xssEcho(HEADING); ?> Updater</span>
			<ul class="nav nav-inline navbar-left" style="text-align: right;">
				<li class="nav-item">
					<a class="nav-link" href="../index.php">
						<i class="material-icons">keyboard_arrow_left</i> <span class="hidden-sm-down nav-linktext"><?php echo $language['back']; ?></span>
					</a>
				</li>
			</ul>
		</nav>
		
		<div class="jumbotron-main">
			<div class="jumbotron jumbotron-fluid">
				<div class="container-fluid">
					<ol class="breadcrumb icon-home icon-angle-right no-bg breadline">
						<li><a href="#" onClick="return false;">Updater</a></li>
					</ol>
				</div>
			</div>
		</div>
		
		<!-- Hidden Boxes -->
		<div class="backdrop">
			<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>
		</div>
		
		<div id="OverlayButton" class="btn bmd-btn-fab bmd-fixed" style="display: none;" data-toggle="tooltip" data-placement="left">
			<i class="fa" aria-hidden="true"></i>
		</div>
		
		<!-- Content -->
		<div id="myContent">
			<div class="col-xs-12 main">
				<div class="page-on-top">
					<div class="row m-b-40">
						<div class="col-xs-12 col-sm-12 col-xl-12">
							<div class="card-block-header">
								<h4 class="card-title"><?php echo (!$hasRights) ? '<i class="fa fa-ban"></i> '.$language['no_access'] : '<i class="fa fa-random"></i> '.$language['updater_welcome']; ?>
							</div>
							<hr class="hr-headline"/>
							<?php if(!$hasRights) { ?>
								<p style="text-align: center;"><?php echo $language['no_access_info']; ?></p>
							<?php } else { ?>
								<div class="step-1">
									<?php
										try
										{
											$updater 			= 	new SoapClient(null, array(
												'location' => 'http://wiki.first-coder.de/soap/soap_server_version_two.php',
												'uri' => 'https://wiki.first-coder.de/soap/soap_server_version_two.php'
											));
											
											$versionList		=	array();
											$versionList		=	array_reverse(json_decode($updater->getVersionList(DONATOR_MAIL)));
											$tmpVersion			=	false;
											$tmpVersionNumber	=	count($versionList)-1;
											$tmpVersionNumber2	=	count($versionList)-1;
										}
										catch(Exception $e)
										{ ?>
											<div class="alert alert-danger">
												<b><i class="fa fa-warning"></i> Connection to Updateserver failed:</b><br /><?php echo $language['message'].": ".$e->getMessage(); ?>
											</div>
										<?php exit(); };
									?>
									
									<div class="alert alert-info">
										<b><i class="fa fa-info" aria-hidden="true"></i> FAQ / Help <i class="fa fa-question" aria-hidden="true"></i></b><br/>
										<?php echo $language['faq_help_info1']; ?><br/><br/><?php echo $language['faq_help_info2']; ?>
									</div>
									
									<table class="table table-hover">
										<thead>
											<th colspan="3">
												<?php echo $language['version']; ?>
											</th>
										</thead>
										<tbody>
											<?php
												$updatePossible					=	-1;
												foreach($versionList AS $version)
												{
													if($version == INTERFACE_VERSION)
													{
														$tmpVersion				=	true;
													};
													
													if(!$tmpVersion)
													{
														$updatePossible			=	$tmpVersionNumber2;
													};
													
													$tmpVersionNumber2--;
												};
												$tmpVersion						=	false;
												foreach($versionList AS $version)
												{
													if($version == INTERFACE_VERSION)
													{
														$tmpVersion				=	true;
														echo "<tr class=\"text-warning\"><td>".$version."</td><td>".$language['current_version']."</td><td><button onClick=\"ShowChangelog('".$tmpVersionNumber."', false)\" class=\"btn btn-sm btn-secondary\">".$language['changelog']."</button></td></tr>";
													}
													else if(!$tmpVersion)
													{
														if($updatePossible == $tmpVersionNumber)
														{
															echo "<tr class=\"text-success\"><td>".$version."</td><td>".$language['new_version']."</td><td><button class=\"btn btn-sm btn-success\" onClick=\"ShowChangelog('".$tmpVersionNumber."')\"><i class\"fa fa-check\" aria-hidden=\"true\"> ".$language['download']."</button></td></tr>";
														}
														else
														{
															echo "<tr class=\"text-success\"><td>".$version."</td><td>".$language['new_version']."</td><td></td></tr>";
														};
													}
													else
													{
														echo "<tr class=\"text-danger-no-cursor\"><td>".$version."</td><td>".$language['old_version']."</td><td><button  onClick=\"ShowChangelog('".$tmpVersionNumber."', false)\"class=\"btn btn-sm btn-secondary\">".$language['changelog']."</button></td></tr>";
													};
													
													$tmpVersionNumber--;
												};
											?>
										</tbody>
									</table>
								</div>
								<div class="step-2" style="display: none;">
									<div class="alert alert-outline-info alert-updater mb-3">
										<h1 class="changelogHeadline pull-xs-left mb-3" style="font-size: 22px;"></h1>
										<h6 class="changelogTime pull-xs-right mb-3"></h6>
										<div style="clear: both;" class="mb-3 mt-3" id="changelogContent"></div>
									</div>
									<button id="updateAction" class="btn btn-success" style="width: 100%;"><i class="fa fa-plug" aria-hidden="true"></i> Update</button>
									<button onClick="backToMainMenu();" class="btn btn-secondary small-top-bottom-margin" style="width: 100%;"><i class="fa fa-close" aria-hidden="true"></i> <?php echo $language['abort']; ?></button>
								</div>
								<div class="step-3" style="display: none;text-align: center;">
									<i style="font-size:100px;" class="fa fa-cogs fa-spin"></i>
									<h1 style="font-size: 22px;margin-top: 20px;">Install... Please wait...</h1>
								</div>
								<div class="step-4" style="display: none;">
									<div id="changeOutput"></div>
									<button onClick="backToMainMenu();" class="btn btn-info"><i class="fa fa-arrow-left" aria-hidden="true"></i> <?php echo $language['back']; ?></button>
								</div>
							<?php }; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Footer -->
		<div id="footer" class="jumbotron-main">
			<div class="jumbotron jumbotron-fluid">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-4">
							<div class="footer-background">
								<ul class="list-group footer-color-light">
									<li class="list-group-item">
										<p class="list-group-item-heading footer-headline"><i class="fa fa-thumbs-up" aria-hidden="true"></i> <?php echo "Speziellen Dank"; ?></p>
									</li>
									<div class="footer-border ml-2 mr-2"></div>
									<li class="list-group-item">
										ghostrider
										<span class="tag tag-secondary tag-pill pull-xs-right">Projektmanager</span>
									</li>
									<li class="list-group-item">
										L. Gmann
										<span class="tag tag-secondary tag-pill pull-xs-right">Entwickler</span>
									</li>
									<li class="list-group-item">
										angeloccrr
										<span class="tag tag-secondary tag-pill pull-xs-right">Designer</span>
									</li>
									<li class="list-group-item">
										Splamy
										<span class="tag tag-secondary tag-pill pull-xs-right">Bot Entwickler</span>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-md-4"></div>
						<!-- Copyright! Do not remove this lines! -->
						<div class="col-md-4">
							<div id="copyright" class="footer-logo">
								<img style="width:300px;" src="https://first-coder.de/images/fcLogo.png"/>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Lanugage -->
		<script>
			var weiter		=	'<?php echo $language['next']; ?>';
		</script>
		<script src="updater.js"></script>
	</body>
</html>