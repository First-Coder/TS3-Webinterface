<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("../lang/lang.php");
	require_once("../config/instance.php");
	require_once("../config/instance-bot.php");
	require_once("../php/functions/functions.php");
	require_once("../php/functions/functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success'] || !$settings['success']) {
		if($user_right['data']['perm_admin_settings_main'] != $mysql_keys['perm_admin_settings_main']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_settings_main missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
?>

<!doctype html>
<html lang="en">
	<head>
		<title><?php echo xssSafe($settings['data']['title'])." -- Teamspeak3 Control Panel -- Updater"; ?></title>
		
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=0.6, minimum-scale=0.6, maximum-scale=0.6, shrink-to-fit=no" />
		<meta name="theme-color" content="#2f7207" />
		<meta name="author" content="First Coder: L.Gmann" />
		
		<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon" />
		
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Courgette|Kreon|Poppins|Roboto">
		
		<link rel="stylesheet" type="text/css" href="../css/other/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap/bootstrap-table.css" />
		<link rel="stylesheet" type="text/css" href="../css/style.css" />
		
		<script>
			var jsonLang = '<?php echo str_replace('\"', "", json_encode($language)); ?>', lang = JSON.parse(jsonLang);
		</script>
		
		<script src="../js/jquery/jquery.min.js"></script>
		<script src="../js/jquery/jquery.bootstrap.js"></script>
		<script src="../js/other/tether.js"></script>
		<script src="../js/other/popper.js"></script>
		<script src="../js/other/functions.js"></script>
		<script src="../js/other/navigation.js"></script>
		<script src="../js/other/arrive.js"></script>
		<script src="../js/other/approve.js"></script>
		<script src="../js/other/sweetalert2.js"></script>
		<script src="../js/bootstrap/bootstrap-material-design.iife.js"></script>
		<script src="../js/bootstrap/bootstrap-table.js"></script>
	</head>
	<body>
		<!-- Header -->
		<nav class="navbar">
			<span class="navbar-brand nav-title"><?php xssEcho($settings['data']['title']); ?> Updater</span>
			<div class="nav"></div>
		</nav>
		
		<div class="jumbotron-main">
			<div class="jumbotron-content">
				<ul>
					<li>
						<a href="../index.php" class="no-after"><i class="fas fa-arrow-left mr-2"></i><?php echo $language['back']; ?></a>
					</li>
					<li>
						<a href="#" onClick="changeContent('updater_information', false);return false;" class="no-after"><i class="fas fa-info mr-2"></i><?php echo $language['informations']; ?></a>
					</li>
					<li>
						<a href="#" onClick="changeContent('updater_updates', false);return false;" class="no-after"><i class="fas fa-code-branch mr-2"></i>Updates</a>
					</li>
				</ul>
				<ol class="breadcrumb icon-home icon-angle-right no-bg breadline">
					<li><a href="#" onClick="return false;">Updater</a></li>
				</ol>
			</div>
		</div>
		
		<!-- Spinner -->
		<span class="spinner">
			<span class="spinner-bar"></span>
		</span>
		
		<!-- Content -->
		<div id="myContent">
			<?php include_once('./updater_information.php'); ?>
		</div>
		
		<div id="footer">
			<div class="footer-row">
				<div class="copyright">
					2019 <i class="far fa-copyright"></i> First-Coder by <a href="https://first-coder.de/" target="_blank">L.Gmann</a>
				</div>
				<div class="links">
					<a href="https://github.com/First-Coder/" target="_blank"><i class="fab fa-github mr-2"></i>Github</a>
					<a href="https://forum.first-coder.de/" target="_blank"><i class="fas fa-hands-helping mr-2"></i>Forum</a>
					<a href="#" onClick="changeContent('web_main_impressum');return false;"><i class="far fa-handshake mr-2"></i>Impressum</a>
				</div>
			</div>
		</div>
		
		<script>
			/**
				Meterial init
			*/
			$('body').bootstrapMaterialDesign();
			
			/**
				Dropwdown events for the login area
			*/
			$('.dropdown-menu.dropdown-no-event').on('click', function(event){
				// The event won't be propagated up to the document NODE and 
				// therefore delegated events won't be fired
				event.stopPropagation();
			});
		</script>
		<script src="../js/bootstrap/bootstrap-tooltip.js"></script>
	</body>
</html>