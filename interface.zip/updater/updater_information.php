<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("../lang/lang.php");
	require_once("../config/instance.php");
	require_once("../config/instance-bot.php");
	require_once("../php/functions/functions.php");
	require_once("../php/functions/functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success'] || !$settings['success']) {
		if($user_right['data']['perm_admin_settings_main'] != $mysql_keys['perm_admin_settings_main']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_settings_main missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Soap loading
	*/
	$team[] = array('name' => 'L.Gmann', 'job' => 'Manager and Developer', 'skills' => array('PHP', 'JavaScript', 'C#', 'C', 'CSS3', 'Shell'), 'rname' => 'Lukas G.', 'mail' => 'admin@first-coder.de', 'member_since' => '2012');
	$team[] = array('name' => 'SoulofSorrow', 'job' => 'Manager and Sponsor', 'skills' => array('Shell', 'Nginx', 'Apache'), 'rname' => 'Julian S.', 'mail' => 'admin@ts-3.io', 'member_since' => '2015');
	$error = null;
	
	try {
		$client = new SoapClient(null, array(
			'location' => 'http://wiki.first-coder.de/soap/soap_server_version_two.php',
			'uri' => 'https://wiki.first-coder.de/soap/soap_server_version_two.php'
		));
		
		$team = $client->getTeam();
		$donator = $client->hasUserDonationStatus($settings['data']['donator']);
	} catch(Exception $e) {
		$error = $e;
	};
?>

<div class="content-header color-header"><?php echo $language['informations']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-7 border-right widget in-sm bottom">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-users"></i> <?php echo $language['the_team']; ?></h4>
			<h6 class="sub-title text-muted">First-Coder Team</h6>
		</div>
		<?php foreach($team AS $member) { ?>
			<hr class="hr-headline mb-3"/>
			<ul class="list-group">
				<a class="list-group-item">
					<i class="fas fa-user"></i>
					<?php echo $language['member'].': '.$member['name']; ?>
				</a>
				<a class="list-group-item">
					<i class="fas fa-sitemap"></i>
					<?php echo $language['position'].': '.$member['job']; ?>
				</a>
				<?php if(!empty($member['skills'])) { ?>
					<a class="list-group-item">
						<i class="fas fa-code"></i>
						<?php echo $language['skills'].': '.join(', ', $member['skills']);?>
					</a>
				<?php }; ?>
				<a class="list-group-item">
					<i class="fas fa-envelope"></i>
					<?php echo $language['mail'].': '.$member['mail']; ?>
				</a>
				<a class="list-group-item">
					<i class="fas fa-clock"></i>
					<?php echo $language['member_since'].': '.$member['member_since']; ?>
				</a>
			</ul>
		<?php }; ?>
	</div>
	<div class="col-md-5 widget in-sm top">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-server"></i> <?php echo $language['connection']; ?></h4>
			<h6 class="sub-title text-muted">First-Coder.de SOAP Server</h6>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col-4 text-center">
				<div class="updater-icon icon-<?php echo ($e === null) ? 'success' : 'danger'; ?>" style="margin: auto;">
					<i class="fas <?php echo ($e === null) ? 'fa-check-double' : 'fa-times'; ?>"></i>
				</div>
			</div>
			<div class="col-8 <?php echo ($e === null) ? 'text-success' : 'text-danger'; ?>" style="margin: auto;">
				<?php echo ($e === null) ? $language['connection_successfull'] : $language['failed'].'<br/>'.$e->getMessage(); ?>
			</div>
		</div>
		<?php if($e === null) { ?>
			<hr class="hr-headline mb-3"/>
			<div class="row mb-3">
				<div class="col">
					<i class="fab fa-paypal w-20"></i> <?php echo $language['donator']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-<?php echo ($donator) ? 'success' : 'danger'; ?>"><?php echo ($donator) ? $language['yes'] : $language['no']; ?></span>
				</div>
			</div>
			<div class="row mb-3">
				<div class="col">
					<i class="fas fa-code-branch w-20"></i> <?php echo $language['newest_version']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-success"><?php echo checkNewVersion(); ?></span>
				</div>
			</div>
			<div class="row mb-3">
				<div class="col">
					<i class="fas fa-info w-20"></i> <?php echo $language['current_version']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-primary"><?php echo INTERFACE_VERSION; ?></span>
				</div>
			</div>
			<hr class="hr-headline mb-3"/>
		<?php }; ?>
	</div>
</div>