<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	require_once(__dir__."/../config/config.php");
	require_once(__dir__."/../php/functions/functions.php");
	require_once(__dir__."/../php/functions/functionsSql.php");
	
	/**
		Update the Webinterface
	*/
	$pid = './startUpdate.pid';
	$update = 'First-Coder-TS3-Webinterface-'.$_POST['id'].'.update.zip';
	$settings = getSqlHomepagesettings();
	$json = array(
		'permissions' => false,
		'download' => false,
		'execute' => false,
		'override' => false
	);
	
	if(file_exists($pid)) {
		die(json_encode(generateOutput(false, 'Update file already exist!', null)));
	};
	
	if(!$settings['success']) {
		die(json_encode(generateOutput(false, 'Database connection failed!', null)));
	};
	
	if(is_file('./'.$update)) {
		die(json_encode(generateOutput(false, 'Update file already exists!', null)));
	};
	
	//file_put_contents($pid, json_encode($json));
	
	/**
		Permissions Check
	*/
	if(($data = scanFolder('../')) !== true) {
		die(json_encode(generateOutput(false, 'File permissions ('.$data.') not writeable!', $json)));
	};
	$json['permissions'] = true;
	
	/**
		Download file
	*/
	$newUpdate = file_get_contents('https://teamspeak.first-coder.de/getUpdateV2.php?mail='.$settings['data']['donator'].'&version='.$_POST['id']);
	$dlHandler = fopen($update, 'w');
	if(!fwrite($dlHandler, $newUpdate)) {
		@unlink($update);
		die(json_encode(generateOutput(false, 'Could not save new update. Operation aborted!', $json)));
	};
	fclose($dlHandler);
	$json['download'] = true;
	
	/**
		Execute updater.php
	*/
	$zipHandle = zip_open($update);
	while($aF = zip_read($zipHandle)) {
		$afFile = zip_entry_name($aF);
		
		if($afFile == 'upgrade.php') {
			$contents = zip_entry_read($aF, zip_entry_filesize($aF));
			$upgradeExec = fopen('./upgrade.php','w');
			fwrite($upgradeExec, $contents);
			fclose($upgradeExec);
			
			if(file_exists('./upgrade.php')) {
				if(!is_executable($afFile) && !chmod($afFile, 0666)) {
					@unlink($update);
					die(json_encode(generateOutput(false, 'Could not execute updater.php. Operation aborted!', $json)));
				} else {
					if(!($upgrade = include('upgrade.php'))) {
						@unlink($update);
						@unlink('upgrade.php');
						die(json_encode(generateOutput(false, 'upgrade.php: '.$upgrade.'. Operation aborted!', $json)));
					};
					@unlink('upgrade.php');
				};
			} else {
				@unlink($update);
				die(json_encode(generateOutput(false, 'Could not extract file!', $json)));
			};
		};
	};
	$json['execute'] = true;
	
	/**
		Override files
	*/
	$zipHandle = zip_open($update);
	while($aF = zip_read($zipHandle)) {
		$afFile = zip_entry_name($aF);
		$afDir = dirname($afFile);
		
		if(substr($afFile,-1,1) == '/') {
			continue;
		};
		
		$tmpFolder = "";
		foreach(explode("/", $afDir) AS $folder) {
			$tmpFolder .= $folder;
			if(!is_dir('../'.$tmpFolder)) {
				if(!@mkdir ('../'.$tmpFolder)) {
					@unlink($update);
					@unlink('upgrade.php');
					die(json_encode(generateOutput(false, 'Folder '.$tmpFolder.' could not be created!', $json)));
				};
			};
			$tmpFolder .= "/";
		};
	};
	
	$zipHandle = zip_open($update);
	while($aF = zip_read($zipHandle)) {
		$afFile = zip_entry_name($aF);
		$afDir = dirname($afFile);
		
		if(substr($afFile,-1,1) == '/') {
			continue;
		};
		
		if(!is_dir('../'.$afFile) && $afFile !== 'upgrade.php') {
			$contents = zip_entry_read($aF, zip_entry_filesize($aF));
			$updateThis = fopen('../'.$afFile, 'w');
			fwrite($updateThis, $contents);
			fclose($updateThis);
			unset($contents);
		};
	};
	$json['override'] = true;
	
	@unlink($update);
	die(json_encode(generateOutput(true, null, $json)));
	
	/**
		Function to scan the interface_exists
	*/
	function scanFolder($dir) {
		$directory = opendir($dir);
		while($file = readdir($directory)) {
			if($file != "." && $file != "..") {
				if(is_dir($dir.'/'.$file)) {
					if(!scanFolder($dir.'/'.$file)) {
						return $dir.'/'.$file;
					};
				} else {
					if(!is_executable('../'.$file) || !is_writable('../'.$file)) {
						return $file;
					};
				};
			};
		};
		closedir($directory);
		return true;
	};
?>