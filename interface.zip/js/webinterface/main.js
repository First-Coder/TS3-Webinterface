/**
	First-Coder Teamspeak 3 Webinterface for everyone
	Copyright (C) 2018 by L.Gmann

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
	for help look http://first-coder.de/
*/

/**
	Function to delete news form the database
	@param {int} id
*/
	function deleteNews(id) {
		new AreUSure({
			label: lang.delete_news.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'deleteNews',
						id: id
					},
					success: function(data){
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, lang.succeeded_info, 'success');
							$('#'+id+"-box").remove();
						} else {
							swal(lang.aborted, info.error, 'error');
						};
					}
				});
			}
		});
	};

/**
	Function to create a news and save them into the database
*/
	function writeNews()
	{
		var title = escapeText($('#newsTitle').val()),
			subtitle = escapeText($('#newsSubTitle').val()),
			publish = new Date().getTime();
			content = $('#create-editor').summernote('code');
		
		if($('#newsPublish').val() != '') {
			publish = $('#newsPublish').val().split(".");
			publish = publish[1]+'.'+publish[0]+'.'+publish[2];
			publish = new Date(publish).getTime();
		};
		
		
		if(isDataValid('newsTitle'))
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action: 'createNews',
					title: encodeURIComponent(title),
					subtitle: encodeURIComponent(subtitle),
					content: encodeURIComponent(content),
					time: publish
				},
				success: function(data){
					var news = JSON.parse(data);
					
					if(news.success) {
						$('#create-editor').summernote('code', '');
						$('#newsTitle').val('');
						$('#newsSubTitle').val('');
						$('#newsPublish').val('');
						
						new Notification({
							message : lang.news_created,
							type : 'success'
						}).show();
						
						slideToTop();
					} else {
						new Notification({
							message : news.error,
							type : 'danger'
						}).show();
					};
				}
			});
		};
	};

/*
	Server Application
*/
	function checkWantServer()
	{
		if(typeof(wantServer['0']) == 'undefined')
		{
			var wantServerUser, wantServerPw;
			var regex_check_mail	=	true;
			var regex_check_pw		=	true;
			
			if($('#radioAccount').prop("checked") && isDataValid('wantServerLoginUser'))
			{
				wantServerUser		=	$('#wantServerLoginUser').val();
				wantServerPw		=	'';
			}
			else if(!$('#radioAccount').prop("checked") && (isDataValid('wantServerLoginCreateUser') && isDataValid('wantServerLoginCreatePw')))
			{
				wantServerUser		=	$('#wantServerLoginCreateUser').val();
				wantServerPw		=	$('#wantServerLoginCreatePw').val();
			}
			else
			{
				return;
			};
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action	:	'checkUser',
					name	:	wantServerUser
				},
				success: function(data){
					if($('#radioAccount').prop("checked") && data == 'error' || !$('#radioAccount').prop("checked") && data == 'done')
					{
						wantServer['0']			=	wantServerUser;
						wantServer['1']			=	wantServerPw;
						
						$('#wantServerStep1').slideUp("slow", function ()
						{
							$('#wantServerStep2').slideDown("slow");
						});
					}
					else if($('#radioAccount').prop("checked") && data == 'done')
					{
						setNotifyFailed(lang.user_does_not_exist);
					}
					else
					{
						setNotifyFailed(lang.user_already_exists);
					};
				}
			});
		}
		else if(typeof(wantServer['4']) == 'undefined')
		{
			wantServerValue					=	2;
			checkValues						=	true;
			
			if(!setWantServerValues(wantServerValue++, "serverCreateCause")) { checkValues = false; };
			if(!setWantServerValues(wantServerValue++, "serverCreateWhy")) { checkValues = false; };
			if(!setWantServerValues(wantServerValue++, "serverCreateNeededSlots", true)) { checkValues = false; };
			
			if(checkValues)
			{
				$('#wantServerStep2').slideUp("slow", function ()
				{
					$('#wantServerStep3').slideDown("slow");
				});
			};
		}
		else
		{
			var port		=	$('#serverCreatePort').val();
			
			if(isDataValid('serverCreatePort') && isDataValid('serverCreateServername'))
			{
				$('#wantServerBttn').prop("disabled", true);
				
				wantServerValue					=	5;
				checkValues						=	true;
				
				setWantServerValues(wantServerValue++, "serverCreateServername", false, "servername");			// Servername wird gespeichert
				setWantServerValues(wantServerValue++, "serverCreatePort", false, "");							// Der Teamspeakport wird gespeichert
				setWantServerValues(wantServerValue++, "serverCreateSlots", true, "slots");						// Die Max. Teamspeakclients werden gespeichert
				setWantServerValues(wantServerValue++, "serverCreateReservedSlots", true, "reserved_slots");	// Anzahl reservierter Slots wird gespeichert
				setWantServerValues(wantServerValue++, "serverCreatePassword", false, "password");				// Das Teamspeakpassword wird gespeichert
				setWantServerValues(wantServerValue++, "serverCreateWelcomeMessage", false, "welcome_message");	// Die Willkommensnachricht wird gespeichert
				
				wantServer['11'] 				= 	'../../files/wantServer/';
				
				var jsonString = JSON.stringify(wantServer);
				$.ajax({
					url: "./php/functions/funtionsCreateServerRequest.php",
					type: "post",
					data: {
						wantServerPost: jsonString
					},
					success: function(data){
						if(data == 'done')
						{
							setNotifySuccess(lang.server_request_requested);
						}
						else
						{
							setNotifyFailed(data);
							$('#wantServerBttn').prop("disabled", false);
						};
					}
				});
			};
		};
	};
	
	function setWantServerValues(arrayNumber, id, isNumber = false, defaultValue = "")
	{
		if(defaultValue == "")
		{
			if (isDataValid(id))
			{
				wantServer[arrayNumber] 			= 		$('#'+id).val();
				return true;
			}
			else
			{
				return false;
			};
		}
		else
		{
			if ($('#'+id).val() != '' && (isNumber && $('#'+id).val() > 0) || !isNumber)
			{
				wantServer[arrayNumber] 			= 		$('#'+id).val();
			}
			else
			{
				wantServer[arrayNumber] 			= 		ts3_server_create_default[defaultValue];
			};
		};
	};