/*
	First-Coder Teamspeak 3 Webinterface for everyone
	Copyright (C) 2017 by L.Gmann

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
	for help look http://first-coder.de/
*/
	
/*
	If someone push ENTER
*/
	$('#loginUser').keypress(function(e)
	{
		if (e.which == 13)
		{
			loginUser();
			e.preventDefault();
		};
	});
	
	$('#loginPw').keypress(function(e)
	{
		if (e.which == 13) 
		{
			loginUser();
			e.preventDefault();
		};
	});
	
/*
	Forgot password
*/
	function forgotPassword()
	{
		if(isDataValid('loginUser'))
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action:		'forgotPassword',
					username:	$('#loginUser').val()
				},
				success: function(data){
					if(data == "done")
					{
						setNotifySuccess(lang.password_reset_success);
					}
					else
					{
						setNotifyFailed(lang.password_reset_failed);
					};
				}
			});
		};
	};
	
	
/*
	Login
*/
	function loginUser()
	{
		sessionStorage.setItem("login_try", "1");
		if(sessionStorage.getItem("login_try") < 3)
		{
			var username	=	$("#loginUser").val();
			var password	=	$("#loginPw").val();
			
			if(isDataValid('loginUser') && isDataValid('loginPw'))
			{
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action:		'loginUser',
						username:	username,
						password:	password
					},
					success: function(data)
					{
						session_logintry	=	sessionStorage.getItem("login_try");
						if(typeof session_logintry == 'object')
						{
							sessionStorage.setItem("login_try", "1");
						};
						
						switch(data)
						{
							case "failed":
								switch(session_logintry)
								{
									case '0':		sessionStorage.setItem("login_try", "1");break;
									case '1':		sessionStorage.setItem("login_try", "2");break;
									case '2':		sessionStorage.setItem("login_try", "3");break;
								};
								session_logintry	=	sessionStorage.getItem("login_try");
								
								setNotifyFailed(lang.user_or_pw_wrong+"<br /><font size=2px>"+session_logintry+"/3 "+lang.trys+"</font>");
								break;
							case "blocked":
								setNotifyFailed(lang.user_is_blocked+"<br /><font size=2px>"+lang.user_blocked_info+"</font>");
								break;
							default:
								$('.showOnLogged').css("display", "inline");
								$('.showOnUnlogged').css("display", "none");
								
								$('.badge-40>img').attr("src", data);
								
								changeContent('web_profil_dashboard');
								changeNavigation();
								logged = "true";
								break;
						}
					}
				});
			}
			else
			{
				setNotifyFailed(lang.write_user_and_pw);
			};
		}
		else
		{
			setNotifyFailed(lang.user_session_blocked+"<br /><font size=2px>"+lang.user_session_blocked_info+"</font>");
		};
	};