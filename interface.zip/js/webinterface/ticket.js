/**
	First-Coder Teamspeak 3 Webinterface for everyone
	Copyright (C) 2018 by L.Gmann

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
	for help look http://first-coder.de/
*/

/**
	Function to load a ticket information
	@param {string} id
*/
	function showTicket(id) {
		if(setLoading(true)) {
			$('#myContent').load('./php/ticket/web_ticket_info.php', { "id" : id }, function() {
				$("html, body").animate({
					scrollTop: 0
				},
				600,
				function() {
					setLoading(false);
				});
				
				$('[data-toggle="tooltip"]').tooltip();
			});
		};
	};
	
/**
	Answer a ticket
	@param {string} id
	@param {string} mail
*/
	function answerTicket(id, mail) {
		var editor = $('#answer-editor');
		var text = editor.summernote('code');
		
		if(editor.summernote('isEmpty')) {
			new Notification({
				message : lang.instanz_add_empty,
				icon: 'fas fa-pencil-alt',
				type : 'danger'
			}).show();
			return;
		};
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTicketPost.php",
			data: {
				action: 'answerTicket',
				id: id,
				msg: encodeURIComponent(text)
			},
			success: function(data){
				var info = JSON.parse(data);
				
				if(info.success) {
					var newElement = '<div class="message-wrapper me">';
					newElement += '<div class="text-wrapper">';
					newElement += '<b>'+mail+'</b><br/>';
					newElement += '<p>'+text+'</p>';
					newElement += '<p class="mb-0 text-wrapper-date">Now</p>';
					newElement += '</div>';
					newElement += '</div>';
					$( ".message-wrapper" ).last().after(newElement);
					$(".chat-frame").animate({ scrollTop: $(document).height() }, "fast");
					editor.summernote('code', '');
					
					new Notification({
						message : lang.ticket_answered,
						icon: 'fas fa-pencil-alt',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : info.error,
						icon: 'fas fa-pencil-alt',
						type : 'danger'
					}).show();
				};
			}
		});
	};

/*
	Add Moderator
*/
	function addModerator()
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTicketPost.php",
			data: {
				action:		'addModerator',
				value:		encodeURIComponent($("#ticketAddRoleText").val())
			},
			success: function(data){
				if(data == 'done')
				{
					setNotifySuccess(lang.ticket_add_moderator);
					ticketInit();
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};

/*
	Moderator edit
*/
	function editModerator(id)
	{
		var value 		=	$("#ticketEditRoleText"+id).val(),
			oldValue	=	$("#ticketEditRoleText"+id).attr("oldValue");
		
		if(value == "")
		{
			deleteModerator(id);
		}
		else
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTicketPost.php",
				data: {
					action:		'editModerator',
					value:		encodeURIComponent(value),
					oldValue:	encodeURIComponent(oldValue)
				},
				success: function(data){
					if(data == 'done')
					{
						setNotifySuccess(lang.ticket_edit_moderator);
						$("#ticketEditRoleText"+id).attr("oldValue", value);
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};

/*
	Delete Moderator
*/
	function deleteModerator(id)
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTicketPost.php",
			data: {
				action:		'deleteModerator',
				oldValue:	encodeURIComponent($("#ticketEditRoleText"+id).attr("oldValue"))
			},
			success: function(data){
				if(data == 'done')
				{
					setNotifySuccess(lang.ticket_delete_moderator);
					$(".ticketEditRoleBox"+id).remove();
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	
/*
	Ticket erstellen
*/
	function createTicket()
	{
		if(!isDataValid('ticketBetreff') || !isDataValid('ticketMessage'))
		{
			setNotifyFailed(lang.ticket_fill_all);
		}
		else
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTicketPost.php",
				data: {
					action:			'addTicket',
					subject:		encodeURIComponent($('#ticketBetreff').val()),
					message:		encodeURIComponent($('#ticketMessage').val()),
					department:		encodeURIComponent($('#ticketBereich').val())
				},
				success: function(data){
					if(data == lang.ticket_create)
					{
						setNotifySuccess(data);
						changeContent('web_ticket');
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};
	
/*
	Delete a ticket
	@param {int, sting} id
*/
	function deleteTicket(id) {
		new AreUSure({
			label: lang.delete_ticket.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTicketPost.php",
					data: {
						action: 'deleteTicket',
						id: id
					},
					success: function(data){
						var info = JSON.parse(data);
						
						if(info.success) {
							$('div#ticket-'+id).remove();
							swal(lang.succeeded, lang.ticket_deleted.replace("&ouml;", "\u00f6"), 'success');
						} else {
							swal(lang.aborted, info.error, 'error');
						};
					}
				});
			}
		});
	};
	
/**
	Close a ticket
	@param {int, string} id
*/
	function closeTicket(id) {
		new AreUSure({
			label: lang.close_ticket.replace("&szlig;", "\u00df"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTicketPost.php",
					data: {
						action: 'closeTicket',
						id: id
					},
					success: function(data){
						var info = JSON.parse(data);
						
						if(info.success) {
							var el = $('.qr-code > button.btn-success');
							var main = $('div#ticket-'+id);
							var header = $('header', main);
							el.removeClass("btn-success").addClass("btn-danger");
							el.attr('onclick', 'deleteTicket(\''+id+'\');');
							main.removeClass("ticket-danger").addClass("ticket-success");
							$('p', header).text('CLOSED');
							$('i', el).removeClass("fa-times").addClass("fa-trash-alt");
							$('span', el).text(lang.delete.replace('&ouml;', '\u00f6'));
							swal(lang.succeeded, lang.ticket_close, 'success');
						} else {
							swal(lang.aborted, info.error, 'error');
						};
					}
				});
			}
		});
	};
	
