/*
	First-Coder Teamspeak 3 Webinterface for everyone
	Copyright (C) 2019 by L.Gmann

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
	for help look http://first-coder.de/
*/

/**
	Teamspeak tree object
*/
;(function(window) {
	'use strict';
	
	/**
		Constructor
	*/
	function TeamspeakTree(options) {
		this.options = extend({ }, this.options);
		extend(this.options, options);
		this._init();
	};
	
	/**
		Options from outside
	*/
	TeamspeakTree.prototype.options = {
		id: null,
		instance: null,
		port: null,
		getIcons: true,
		interval: -1,
		channelInfo: true,
		clientInfo: true,
		channelInfoAfterContent: '',
		clientInfoAfterContent: '',
		draggable: false,
		dropbox: '.dropbox',
		onDrop: function() { return false; },
		onRemoveAll: function() { return false; }
	}
	
	/**
		Constructor initial
	*/
	TeamspeakTree.prototype._init = function() {
		if(this.options.id == null) {
			console.error('TeamspeakTree: id of the element not found!');
			return;
		} else if(this.options.instance == null || this.options.port == null) {
			console.error('TeamspeakTree: instance or port is not set!');
			return;
		};
		
		var $this = this;
		
		$('#'+this.options.id).contextmenu(function(e) {
			e.preventDefault();
		});
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getTeamspeakBaum',
				instanz: this.options.instance,
				port: this.options.port,
				getIcons: this.options.getIcons
			},
			success: function(data) {
				var tree = JSON.parse(data);
				
				if(!tree['success']) {
					console.error('TeamspeakTree: Could not create teamspeak tree.');
					console.error(tree['error']);
				} else {
					var data = tree['data'];
					
					if(data.servericon === false) {
						data.servericon = '';
					};
					
					// create basic teamspeak tree
					var el = '<div class="treeContent">';
					el += '<div class="treeHeader">';
					el += '<i class="fab fa-teamspeak"></i>';
					el += '<p>'+data.servername+'</p>';
					el += '<span>';
					el += '<img width="20" src="'+data.servericon+'"/>';
					el += '</span>';
					el += '</div>';
					// Main Channels
					for(var channel of data.channels) {
						el += $this._addChannel(channel);
					};
					el += '</div>';
					$('#'+$this.options.id).append(el);
					
					// Add subchannels to the basic teamspeak tree
					for(var schannel of data.subChannels) {
						$($this._addSubChannel(schannel)).insertAfter(getLatestSubChannel($this.options.id, schannel.pid));
					};
					
					// Add clients to the basic teamspeak tree
					for(var client of data.clients) {
						var channel = '#'+$this.options.id+' div[cid="'+client.nick_cid+'"]';
						$($this._addClient(client)).insertAfter(channel);
					};
				};
				
				// Let the tree show
				$('#'+$this.options.id+' > .treeLoading').css('display', 'none');
				$('#'+$this.options.id+' > .treeContent').slideDown('slow', function() {
					if($this.options.draggable) {
						$this._initDropbox();
					};
					if($this.options.channelInfo || $this.options.clientInfo) {
						$this._initTreeInfo();
					};
				});
				
				// Set interval
				if($this.options.interval > 0) {
					if($this.options.interval < 3) {
						console.error('TeamspeakTree: Interval must be 3 seconds or higher. Invalid argument!');
					} else {
						setTimeout($this._update, ($this.options.interval * 1000), $this);
					};
				};
			}
		});
	}
	
	/**
		Channel- and Clientinfo constructor initial
	*/
	TeamspeakTree.prototype._initTreeInfo = function() {
		var selector = $('#'+this.options.id+' > .treeContent');
		var el = null;
		
		if(this.options.channelInfo) {
			selector.on('click', '.treeSubChannel > .treeTable, .treeSpacer > .treeTable, .treeChannel > .treeTable', function() {
				var $this = $(this).closest('.treeSpacer, .treeSubChannel, .treeChannel');
				
				if(el !== null) {
					$('.treeChannelInfo, .treeClientInfo', el).slideUp(500);
					el.removeClass('active');
					
					if(el.is($this)) {
						el = null;
						return;
					};
					
					el = null;
				};
				
				$('.treeChannelInfo', $this).slideDown(500);
				$this.addClass('active');
				el = $this;
			});
		};
		
		if(this.options.clientInfo) {
			selector.on('click', '.treeClient > .treeTable', function() {
				var $this = $(this).closest('.treeClient');
				
				if(el !== null) {
					$('.treeClientInfo, .treeChannelInfo', el).slideUp(500);
					el.removeClass('active');
					
					if(el.is($this)) {
						el = null;
						return;
					};
					
					el = null;
				};
				
				$('.treeClientInfo', $this).slideDown(500);
				$this.addClass('active');
				el = $this;
			});
		};
	};
	
	/**
		Dropbox constructor initial
	*/
	TeamspeakTree.prototype._initDropbox = function() {
		var dragElement = false;
		var dropbox = $(this.options.dropbox);
		var $this = this;
		
		if(!dropbox.length) {
			console.error('Could not find dropbox element');
			return;
		};
		
		/**
			Events handling
		*/
		dropbox.on('dragover', function(ev) {
			ev.preventDefault();
		});
		dropbox.on('drop', function(ev) {
			ev.preventDefault();
			
			if(dragElement === false) {
				return;
			};
			
			var clid = dragElement.attr('clid');
			if($('div[clid="'+clid+'"]', dropbox).length) {
				return;
			};
			
			var newEl = '<div class="dropbox-table" clid="'+clid+'">';
			newEl += '<p><button class="btn mr-2"><i class="fas fa-trash"></i></button>';
			newEl += $('p', dragElement).text()+'</p>';
			newEl += $('span.after-country', dragElement).html();
			newEl += '</div>';
			
			dropbox.append(newEl);
			$this.options.onDrop();
		});
		
		$('#'+this.options.id).on('dragstart', '.treeContent > div', function(ev) {
			dragElement = $(this);
		});
		
		/**
			Click handling
		*/
		dropbox.on('click', '.dropbox-table button', function (ev) {
			$(this).closest('div.dropbox-table').remove();
			if(!$('div', dropbox).length) {
				$this.options.onRemoveAll();
			};
		});
	}
	
	function getPrevChannel(el) {
		var channel = null;
		var found = false;
		while(!found) {
			channel = el.prev();
			if((!channel.hasClass('treeChannel') && !channel.hasClass('treeSpacer') && !channel.hasClass('treeSubChannel'))) {
				el = channel;
			} else {
				found = true;
			};
		};
		return channel;
	}
	
	/**
		Update teamspeaktree
	*/
	TeamspeakTree.prototype._update = function($this) {
		if(!document.getElementById($this.options.id)) {
			return;
		};
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getTeamspeakBaum',
				instanz: $this.options.instance,
				port: $this.options.port,
				getIcons: false
			},
			success: function(data) {
				var tree = JSON.parse(data);
				
				if(!tree['success']) {
					console.error('TeamspeakTree: Could not update teamspeak tree.');
					console.error(tree['error']);
				} else {
					var data = tree['data'];
					
					// Serverinfo
					$('#'+$this.options.id+' > .treeContent > .treeHeader > p').text(data.servername);
					if(data.servericon !== false) {
						$('#'+$this.options.id+' > .treeContent > .treeHeader > span > img').attr('src', data.servericon);
					};
					$('.serverpassword').html(data.serverpassword);
					$('.serverclients').html(data.serverclients - data.serverqclients+' / '+data.servermaxclients+' ('+round((data.serverclients - data.serverqclients)/data.servermaxclients, 2)+'%)');
					if(data.serverstatus !== 'online') {
						$('.servertimeup').removeClass('badge-success').addClass('badge-danger');
						$('.servertimeup').html(lang.offline);
					} else {
						$('.servertimeup').removeClass('badge-danger').addClass('badge-success');
						$('.servertimeup').html(data.servertimeup);
					};
					
					// Channelupdate
					$('#'+$this.options.id+' > .treeContent > .treeSpacer, #'+$this.options.id+' > .treeContent > .treeChannel').each(function() {
						var el = $(this);
						var num = checkArrayForKey(data.channels, 'clid', el.attr('clid'));
						
						if(num !== false) {
							var channel = data.channels[num];
							
							// set channel class and values
							if(channel.spacer && !el.hasClass('treeSpacer')) {
								el.removeClass('treeChannel');
								el.removeClass('treeSubChannel');
								el.addClass('treeSpacer');
							};
							if(!channel.spacer && !el.hasClass('treeChannel')) {
								el.removeClass('treeSpacer');
								el.removeClass('treeSubChannel');
								el.addClass('treeChannel');
								el.removeAttribute('text-align');
							};
							
							// set values
							el.attr('pid', channel.pid);
							if(el.hasClass('treeSpacer')) {
								$('p', this).html(channel.channelname);
								$('p', this).css('text-align', channel.align);
							} else {
								if(channel.channel_icon_id !== false) {
									if($('span.after-id > img', this).length == false) {
										$('span.after-id', this).append('<img width="15" src="'+channel.channel_icon_id+'"/>');
									} else {
										$('span.after-id > img', this).attr('src', channel.channel_icon_id);
									};
								} else {
									$('span.after-id > img', this).remove();
								};
								if(channel.channel_needed_talk_power != '0') {
									if($('span.after-talk-power > img', this).length == false) {
										$('span.after-talk-power', this).append('<img width="15" src="images/ts_viewer/moderated.png"/>');
									};
								} else {
									$('span.after-talk-power > img', this).remove();
								};
								$('span.before > img', this).attr('src', channel.img_before);
								$('p', this).html(channel.channelname);
							};
							
							// move channel if it�s not in the correct position
							var currentPos = $('#'+$this.options.id+' > .treeContent > .treeSpacer, #'+$this.options.id+' > .treeContent > .treeChannel').index($(this));
							if(currentPos != num) {
								var channel = $('#'+$this.options.id+' > .treeContent > .treeSpacer, #'+$this.options.id+' > .treeContent > .treeChannel').get(num);
								$(this).insertBefore(channel);
							};
							
							// update channelInfo
							var channelInfo = $('.treeChannelInfo', el);
							if(channelInfo.length) {
								$('.channel_topic', channelInfo).html(channel.channel_topic);
								$('.channel_codec', channelInfo).html(channel.channel_codec);
								$('.channel_type', channelInfo).html(channel.channel_type);
								$('.channel_needed_talk_power', channelInfo).html(channel.channel_needed_talk_power);
								$('.channel_maxclients', channelInfo).html((channel.channel_maxclients == '-1') ? lang.unlimited : channel.channel_maxclients);
								$('.cid', channelInfo).html(channel.cid);
							};
							
							delete data.channels[num];
						} else {
							el.remove();
						};
					});
					
					for(var channel of data.channels) {
						if(channel == undefined) {
							continue;
						};
						$('#'+$this.options.id+' > .treeContent').append($this._addChannel(channel));
					};
					
					// Subchannelupdate
					$('#'+$this.options.id+' > .treeContent > .treeSubChannel').each(function() {
						var el = $(this);
						var num = checkArrayForKey(data.subChannels, 'cid', el.attr('cid'));
						var mainPos = $('#'+$this.options.id+' > .treeContent > div').index(el);
						var mainChannelPos = $('#'+$this.options.id+' > .treeContent > div').index($('#'+$this.options.id+' > .treeContent > div[cid="'+el.attr('pid')+'"]'));

						if(num !== false && mainPos > mainChannelPos) {
							var channel = data.subChannels[num];
							var currentPos = $('#'+$this.options.id+' > .treeContent > .treeSubChannel').index($(this));
							
							if(channel.pid != el.attr('pid') || currentPos != num) {
								el.remove();
							} else {
								if(channel.sub_channel_icon_id !== false) {
									if($('span.after-id > img', this).length == false) {
										$('span.after-id', this).append('<img width="15" src="'+channel.sub_channel_icon_id+'"/>');
									} else {
										$('span.after-id > img', this).attr('src', channel.sub_channel_icon_id);
									};
								} else {
									$('span.after-id > img', this).remove();
								};
								if(channel.channel_needed_talk_power != '0') {
									if($('span.after-talk-power > img', this).length == false) {
										$('span.after-talk-power', this).append('<img width="15" src="images/ts_viewer/moderated.png"/>');
									};
								} else {
									$('span.after-talk-power > img', this).remove();
								};
								$('span.before > img', this).attr('src', channel.sub_img_before);
								$('p', this).html(channel.channelname);
								
								// update channelInfo
								var channelInfo = $('.treeChannelInfo', el);
								if(channelInfo.length) {
									$('.channel_topic', channelInfo).html(channel.channel_topic);
									$('.channel_codec', channelInfo).html(channel.channel_codec);
									$('.channel_type', channelInfo).html(channel.channel_type);
									$('.channel_needed_talk_power', channelInfo).html(channel.channel_needed_talk_power);
									$('.channel_maxclients', channelInfo).html((channel.channel_maxclients == '-1') ? lang.unlimited : channel.channel_maxclients);
									$('.cid', channelInfo).html(channel.cid);
								};
								
								delete data.subChannels[num];
							};
						} else {
							el.remove();
						};
					});
					
					for(var channel of data.subChannels) {
						if(channel == undefined) {
							continue;
						};
						$($this._addSubChannel(channel)).insertAfter(getLatestSubChannel($this.options.id, channel.pid));
					};
					
					// Clientupdate
					$('#'+$this.options.id+' > .treeContent > .treeClient').each(function() {
						var el = $(this);
						var num = checkArrayForKey(data.clients, 'nick_clid', el.attr('clid'));
						var channel = getPrevChannel(el);
						var steps = (parseInt($(channel).attr('tabs')) * 25);
						
						if(num !== false) {
							var client = data.clients[num];
							
							if(channel.attr('cid') != client.nick_cid) {
								el.remove();
							} else {
								var name = (client.nick_away_message != '') ? client.nickname+' ('+client.nick_away_message+')' : client.nickname;
								var status = '';
								switch(client.nick_status) {
									case 'away':
										status = 'away';
										break;
									case 'hwhead':
										status = 'hwhead';
										break;
									case 'hwmic':
										status = 'hwmic';
										break;
									case 'head':
										status = 'head';
										break;
									case 'mic':
										status = 'mic';
										break;
									case 'player_command_on':
										status = 'player_commander_on';
										break;
									case 'player_command':
										status = 'player_commander';
										break;
									case 'player_on':
										status = 'player_on';
										break;
									default:
										status = 'player';
										break;
								};
								
								$('.treeTabs', this).css('width', steps+'px');
								$('.after-country > img', this).attr('src', (client.nick_country == '') ? '' : 'images/ts_countries/'+client.nick_country+'.png');
								$('.before > img', this).attr('src', 'images/ts_viewer/'+status+'.png');
								$('p', this).html(name);
								(client.is_herself) ? $('p', this).addClass('is-herself') : $('p', this).removeClass('is-herself');
								
								if(client.cgroup.length) {
									if(!$('.after-cgroup > img', this).length) {
										$('<span class="after after-cgroup"><img width="15" src="'+client.cgroup[0]+'"/></span>').insertBefore('.after-country', this);
									};
								} else {
									$('.after-cgroup', this).remove();
								};
								
								if(client.sgroup.length) {
									for(var sgroup in client.sgroup) {
										if($('.after-sgroup[data-id="'+sgroup+'"]', this).length) {
											$('.after-sgroup[data-id="'+sgroup+'"] > img', this).attr('src', client.sgroup[sgroup]);
										} else {
											$('<span class="after after-sgroup" data-id="'+sgroup+'"><img width="15" src="'+client.sgroup[sgroup]+'"/></span>').insertBefore('.after-country', this);
										};
									};
									
									var sgroupNum = client.sgroup.length;
									while(sgroupNum != -1) {
										if($('.after-sgroup[data-id="'+sgroupNum+'"]', this).length) {
											$('.after-sgroup[data-id="'+sgroupNum+'"]', this).remove();
											sgroupNum++;
										} else {
											sgroupNum = -1;
										};
									};
								} else {
									$('.after-sgroup', this).remove();
								};

								// update clientInfo
								var clientlInfo = $('.treeClientInfo', el);
								if(clientlInfo.length) {
									$('.nick_cid', clientlInfo).html(client.nick_cid);
									$('.nick_clid', clientlInfo).html(client.nick_clid);

									if(client.cgroup.length) {
										$('.channel_type', clientlInfo).html('<img width="15" src="'+client.cgroup[0]+'"/>');
									} else {
										$('.channel_type > img', clientlInfo).remove();
									};
									
									for(var sgroup in client.sgroup) {
										if($('img[data-sgroup="'+sgroup+'"]', clientlInfo).length) {
											$('img[data-sgroup="'+sgroup+'"]', clientlInfo).attr('src', client.sgroup[sgroup]);
										} else {
											$('.channel_sgroups', clientlInfo).append('<img class="mr-1" data-sgroup="'+sgroup+'" src="'+client.sgroup[sgroup]+'"/>');
										};
									};

									var sgroupNum = client.sgroup.length;
									while(sgroupNum != -1) {
										if($('img[data-sgroup="'+sgroupNum+'"]', clientlInfo).length) {
											$('img[data-sgroup="'+sgroupNum+'"]', clientlInfo).remove();
											sgroupNum++;
										} else {
											sgroupNum = -1;
										};
									};
								};
								delete data.clients[num];
							};
						} else {
							el.remove();
						};
					});
					
					// clients add that are missing now
					for(var client of data.clients) {
						if(client == undefined) {
							continue;
						};
						var channel = '#'+$this.options.id+' div[cid="'+client.nick_cid+'"]';
						$($this._addClient(client)).insertAfter(channel);
					};
				};
				setTimeout($this._update, ($this.options.interval * 1000), $this);
			}
		});
	}
	
	/**
		Create a client element
		@param {Object} client
		@return {string}
	*/
	TeamspeakTree.prototype._addClient = function(client) {
		var _draggable = (this.options.draggable) ? ' draggable="true" ' : ' ';
		var channel = '#'+this.options.id+' div[cid="'+client.nick_cid+'"]';
		var steps = (parseInt($(channel).attr('tabs')) * 25);
		var el = '<div class="treeClient" clid="'+client.nick_clid+'" cldbid="'+client.nick_cldbid+'">';
		el += '<div class="treeTable"'+_draggable+'>';
		el += '<span class="treeTabs" style="width:'+steps+'px;"></span>';
		switch(client.nick_status) {
			case 'away':
				el += '<span class="before"><img width="15" src="images/ts_viewer/away.png"/></span>';
				break;
			case 'hwhead':
				el += '<span class="before"><img width="15" src="images/ts_viewer/hwhead.png"/></span>';
				break;
			case 'hwmic':
				el += '<span class="before"><img width="15" src="images/ts_viewer/hwmic.png"/></span>';
				break;
			case 'head':
				el += '<span class="before"><img width="15" src="images/ts_viewer/head.png"/></span>';
				break;
			case 'mic':
				el += '<span class="before"><img width="15" src="images/ts_viewer/mic.png"/></span>';
				break;
			case 'player_command_on':
				el += '<span class="before"><img width="15" src="images/ts_viewer/player_commander_on.png"/></span>';
				break;
			case 'player_command':
				el += '<span class="before"><img width="15" src="images/ts_viewer/player_commander.png"/></span>';
				break;
			case 'player_on':
				el += '<span class="before"><img width="15" src="images/ts_viewer/player_on.png"/></span>';
				break;
			default:
				el += '<span class="before"><img width="15" src="images/ts_viewer/player.png"/></span>';
				break;
		};
		if(client.is_herself) {
			el += '<p class="is-herself">'+client.nickname;
		} else {
			el += '<p>'+client.nickname;
		};
		if(client.nick_away_message != '') {
			el += ' ('+client.nick_away_message+')';
		};
		el += '</p>';
		for(var sgroup in client.sgroup) {
			el += '<span class="after after-sgroup" data-id="'+sgroup+'"><img width="15" src="'+client.sgroup[sgroup]+'"/></span>';
		};
		for(var cgroup of client.cgroup) {
			el += '<span class="after after-cgroup"><img width="15" src="'+cgroup+'"/></span>';
		};
		el += '<span class="after after-country">'
		if(client.nick_country != '') {
			el += '<img width="15" src="images/ts_countries/'+client.nick_country+'.png"/>';
		};
		el += '</span>';
		el += '</div>';
		
		if(this.options.clientInfo) {
			el += this._addClientInfo(client);
		};
		
		el += '</div>';
		return el;
	}
	
	/**
		Add client information into a client string
		@param {Object} client
		@return {string}
	*/
	TeamspeakTree.prototype._addClientInfo = function(client) {
		var el = '<div class="treeClientInfo" style="display: none;">';
		el += '<div class="row">';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.channel_id
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right nick_cid">';
		el += client.nick_cid;
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.client_id;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right nick_clid">';
		el += client.nick_clid;
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.cgroup;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right channel_type">';
		if(client.cgroup.length) {
			el += '<img width="15" src="'+client.cgroup[0]+'"/>';
		};
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.sgroups;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right channel_sgroups">';
		for(var s in client.sgroup) {
			el += '<img class="mr-1" data-sgroup="'+s+'" src="'+client.sgroup[s]+'" />';
		};
		el += '</div>';
		
		el += this.options.clientInfoAfterContent;
	
		el += '</div>';
		el += '</div>';
		
		return el;
	}
	
	/**
		Create a channel element
		@param {Object} channel
		@return {string}
	*/
	TeamspeakTree.prototype._addChannel = function(channel) {
		var el = '';
		if(channel.spacer) {
			el += '<div class="treeSpacer" style="text-align:'+channel.align+';" cid="'+channel.cid+'" pid="'+channel.pid+'" tabs="1">';
			el += '<div class="treeTable">';
			el += '<p>'+channel.channelname+'</p>';
			el += '</div>';
			if(this.options.channelInfo) {
				el += this._addChannelInfo(channel);
			};
			el += '</div>';
		} else {
			el += '<div class="treeChannel" cid="'+channel.cid+'" pid="'+channel.pid+'" tabs="1">';
			el += '<div class="treeTable">';
			el += '<span class="before"><img width="20" src="'+channel.img_before+'"/></span>';
			el += '<p>'+channel.channelname+'</p>';
			el += '<span class="after-talk-power">';
			if(channel.channel_needed_talk_power != '0') {
				el += '<img width="15" src="images/ts_viewer/moderated.png"/>';
			};
			el += '</span>';
			el += '<span class="after-id">';
			if(channel.channel_icon_id) {
				el += '<img width="15" src="'+channel.channel_icon_id+'"/>';
			};
			el += '</span>';
			el += '</div>';
			
			if(this.options.channelInfo) {
				el += this._addChannelInfo(channel);
			};
			
			el += '</div>';
		};
		return el;
	}
	
	/**
		Create a subchannel element
		@param {Object} schannel
		@return {string}
	*/
	TeamspeakTree.prototype._addSubChannel = function(schannel) {
		var channel = '#'+this.options.id+' div[cid="'+schannel.pid+'"]';
		var steps = (parseInt($(channel).attr('tabs')) * 25);
		var el = '<div class="treeSubChannel" cid="'+schannel.cid+'" pid="'+schannel.pid+'" tabs="'+(parseInt($(channel).attr('tabs')) + 1)+'">';
		el += '<div class="treeTable">';
		el += '<span class="treeTabs" style="width:'+steps+'px;"></span>';
		el += '<span class="before"><img width="20" src="'+schannel.sub_img_before+'"/></span>';
		el += '<p>'+schannel.channelname+'</p>';
		el += '<span class="after after-talk-power">';
		if(schannel.channel_needed_talk_power != '0') {
			el += '<img width="15" src="images/ts_viewer/moderated.png"/>';
		};
		el += '</span>';
		el += '<span class="after after-id">';
		if(schannel.sub_channel_icon_id) {
			el += '<img width="15" src="'+schannel.sub_channel_icon_id+'"/>';
		};
		el += '</span>';
		el += '</div>';
		if(this.options.channelInfo) {
			el += this._addChannelInfo(schannel);
		};
		el += '</div>';
		return el;
	}
	
	/**
		Add channel information into a channel string
		@param {Object} channel
		@return {string}
	*/
	TeamspeakTree.prototype._addChannelInfo = function(channel) {
		var el = '<div class="treeChannelInfo" style="display: none;">';
		el += '<div class="row">';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.topic
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right channel_topic">';
		el += channel.channel_topic;
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.ts3_channel_codec;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right channel_codec">';
		el += channel.channel_codec;
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.ts3_channel_type;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right channel_type">';
		el += channel.channel_type;
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.ts3_channel_talk_power;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right channel_needed_talk_power">';
		el += channel.channel_needed_talk_power;
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.ts3_max_clients;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right channel_maxclients">';
		el += (channel.channel_maxclients == '-1') ? lang.unlimited : channel.channel_maxclients;
		el += '</div>';
		
		el += '<div class="col-6 col-xl-3 text-left">';
		el += lang.channel_id;
		el += '</div>';
		el += '<div class="col-6 col-xl-3 text-right cid">';
		el += channel.cid;
		el += '</div>';
		
		el += this.options.channelInfoAfterContent;
	
		el += '</div>';
		el += '</div>';
		
		return el;
	}
	
	/**
		Function to return the number of the channel or subchannel element. False if no match found
		@param {Array} array
		@param {int} key
		@param {int} val
		@return {int}
	*/
	function checkArrayForKey(array, key, val) {
		for(var object in array) {
			if(array[object][key] == val) {
				return object;
			};
		};
		return false;
	}
	
	/**
		Local funktion to get the last semilar subchannel
		@param {string} id
		@param {int} pid
		@return {Object} el
	*/
	function getLatestSubChannel(id, pid) {
		var el = $('#'+id+' div[pid="'+pid+'"]').last();
		if(el.length) {
			var foundLastElement = false;
			var newCid = el.attr('cid');
			while(!foundLastElement) {
				var newEl = $('#'+id+' div[pid="'+newCid+'"]').last();
				if(newEl.length) {
					newCid = newEl.attr('cid');
				} else {
					el = $('#'+id+' div[cid="'+newCid+'"]');
					foundLastElement = true;
				};
			};
			return el;
		} else { // No subchannels
			return $('#'+id+' div[cid="'+pid+'"]');
		};
	}
	
	/**
		global namespaces
	*/
	window.TeamspeakTree = TeamspeakTree;
})(window);

/**
	Create a channel
*/
	function createChannel() {
		if(!isDataValid('channel_name')) {
			return;
		};
		
		var channeldata = {};
		
		$('#modalChannelCreate .modal-body input, #modalChannelCreate .modal-body select').each(function() {
			var el = $(this);
			var id = el.attr('id');
			
			if(id == 'channel_typ') {
				switch(el.val()) {
					case "1":
						channeldata.channel_flag_permanent = "1";
						channeldata.channel_flag_semi_permanent = "0";
						break;
					case "2":
						channeldata.channel_flag_permanent = "0";
						channeldata.channel_flag_semi_permanent = "1";
						break;
					case "3":
						channeldata.channel_flag_permanent = "1";
						channeldata.channel_flag_semi_permanent = "0";
						channeldata.channel_flag_default = "1";
						break;
				};
			} else if(id == 'cpid') {
				var attr = $('#modalChannelCreate .modal-footer > button').attr('cpid');
				if (typeof attr !== typeof undefined && attr !== false) {
					channeldata[id] = attr;
				} else {
					channeldata[id] = el.val();
				};
			} else {
				channeldata[id] = el.val();
			};
		});
		
		$.ajax({
			url: "./php/functions/functionsTeamspeakPost.php",
			type: "post",
			data: {
				action: 'createChannel',
				instance: instance,
				sid: sid,
				data: JSON.stringify(channeldata)
			},
			success: function(data){
				var info = JSON.parse(data);
				
				if(info.success) {
					$('#modalChannelCreate').modal('hide')
					swal(lang.succeeded, lang.channel_created, 'success');
				} else {
					swal(lang.aborted, info.errors.join(), 'error');
				};
			}
		});
	};
	
/**
	Delete Icons from server
	@param {int, string} id
*/
	function deleteIcon(id) {
		new AreUSure({
			label: lang.delete_icon.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'deleteIcon',
						instance: instance,
						port: port,
						id: id
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, lang.icon_successful_deleted.replace("&ouml;", "\u00f6"), 'success');
							deleteRow = Array(id);
							$('#fileTable').bootstrapTable('remove', {
								field: 'id',
								values: deleteRow
							});
						} else {
							swal(lang.aborted, info.errors.join(), 'error');
						};
					}
				});
			}
		});
	};
	
/**
	Delete Ban from server
	@param {int, string} banid
*/
	function deleteBan(banid) {
		new AreUSure({
			label: lang.delete_ban.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'deleteBan',
						instance: instance,
						port: port,
						id: banid
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, lang.ban_successful_deleted.replace("&ouml;", "\u00f6"), 'success');
							deleteRow = Array(banid);
							$('#banTable').bootstrapTable('remove', {
								field: 'id',
								values: deleteRow
							});
						} else {
							swal(lang.aborted, info.errors.join(), 'error');
						};
					}
				});
			}
		});
	};
	
/**
	Delete Token from server
	@param {string} token
*/
	function deleteToken(token) {
		new AreUSure({
			label: lang.delete_token.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'deleteToken',
						instance: instance,
						port: port,
						token: encodeURIComponent(token)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, lang.token_successful_deleted.replace("&ouml;", "\u00f6"), 'success');
							deleteRow = Array(token);
							$('#channelTokenTable').bootstrapTable('remove', {
								field: 'token',
								values: deleteRow
							});
						} else {
							swal(lang.aborted, info.errors.join(), 'error');
						};
					}
				});
			}
		});
	};
	
/**
	Create Ban into a server
*/
	function createBan() {
		var data = {
			input: escapeText($('#banInput').val()),
			reason: escapeText($('#banReason').val()),
			time: $('#banTime').val(),
			type: $('#banType').val()
		};
		
		if(!isDataValid('banInput') || !isDataValid('banTime')) {
			return;
		};
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'createBan',
				instance: instance,
				port: port,
				data: JSON.stringify(data)
			},
			success: function(data) {
				var info = JSON.parse(data);
				
				if(info.success) {
					changeContent('web_teamspeak_serverbans', true, false, String(instance), String(port));
					
					new Notification({
						message : lang.ban_successfull_added,
						icon: 'fas fa-ban',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : info.errors.join(),
						icon: 'fas fa-ban',
						type : 'danger'
					}).show();
				};
			}
		});
	};
	
/**
	Create tokens into a server
*/
	function createToken() {
		if(!isDataValid('tokenChooseCount')) {
			return;
		};
		
		var token = {
			num: $('#tokenChooseCount').val(),
			description: escapeText($('#tokenChooseDescription').val()),
			kind: $('#tokenChooseKindOfGroup').val(),
			group: $('#tokenChooseGroup').val(),
			channel: $('#tokenChooseChannel').val()
		};
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'createToken',
				instance: instance,
				port: port,
				data: JSON.stringify(token)
			},
			success: function(data) {
				var info = JSON.parse(data);
				
				if(info.success) {
					var newRow = [];
					for(var t of info.data) {
						newRow.push({
							'type': (parseInt(token.kind) == 0) ? lang.sgroup : lang.cgroup,
							'groupname': $('#tokenChooseGroup option:selected').text(),
							'channel': (parseInt(token.kind) != 0) ? $('#tokenChooseChannel option:selected').text() : "",
							'create_on': new Date(Date.now()).format('d.m.Y - H:i:s'),
							'token': t.token,
							'description': $('#tokenChooseDescription').val(),
							'actions': '<button class="btn btn-red btn-sm" onClick="deleteToken(\''+t.token+'\');"><i class="fa fa-fw fa-trash mr-2"></i>'+lang.delete+'</button>'
						});
					};
					$('#channelTokenTable').bootstrapTable('prepend', newRow);
					
					new Notification({
						message : lang.token_successful_created,
						icon: 'fas fa-plus',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : info.errors.join(),
						icon: 'fas fa-plus',
						type : 'danger'
					}).show();
				};
			}
		});
	};
	
/**
	Reset a server (not a instance)
*/
	function resetServer() {
		new AreUSure({
			label: lang.reset_server.replace('&uuml;', '\u00fc'),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'resetServer',
						instance: instance,
						port: port
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							var el = $('#resetToken');
							el.removeClass('d-none');
							$('span', el).text(info.data.token);
							
							swal(lang.succeeded, lang.reset_server_success.replace('&uuml;', '\u00fc'), 'success');
						} else {
							swal(lang.aborted, info.errors.join(), 'error');
						};
					}
				});
			}
		});
	};
	
/**
	Create a backup from a teamspeak server
*/
	function createBackup() {
		if(!isDataValid('backupName')) {
			return;
		};
		
		var backup = {
			type: $('input[name="type"]:checked').val(),
			kind: $('input[name="kind"]:checked').val(),
			name: $('#backupName').val()
		};
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'createBackup',
				instance: instance,
				port: port,
				backup: JSON.stringify(backup)
			},
			success: function(data) {
				var info = JSON.parse(data);
				
				if(info.success) {
					var isChannel = backup.type === 'channel';
					var table = (isChannel) ? 'channelTable' : 'serverTable';
					var bttnActions = (permUse) ? '<button class="activate-backup btn btn-green btn-sm" data-file="'+info.data+'"><i class="fas fa-check mr-2"></i>'+lang.activate+'</button>' : '';
					var bttnDelete = (permDelete) ? '<button class="btn btn-red btn-sm" onClick="deleteBackup(\''+table+'\', \''+info.data+'\')"><i class="fas fa-trash mr-2"></i>'+lang.delete+'</button>' : '';
					addRow = [{
						id: String(info.data).trim(),
						name: escapeHtml(backup.name),
						alias: 'Instance: '+instance,
						port: port,
						kind: (isChannel) ? (backup.kind === 'all') ? lang.channelname_and_settings : lang.just_channelname : (backup.kind === 'all') ? lang.server_and_attachment : lang.snapshot,
						created: new Date(info.data * 1000).format('d.m.Y - H:i:s'),
						actions:
							bttnActions+'\
							<a href="./php/functions/functionsDownload.php?action=downloadBackup&port='+port+'&instance='+instance+'&name='+info.data+'.fcBackup">\
							<button class="btn btn-blue btn-sm"><i class="fas fa-download mr-2"></i>'+lang.download+'</button>\
							</a>\
							'+bttnDelete
					}];
					$((isChannel) ? '#channelTable' : '#serverTable').bootstrapTable('append', addRow);
					
					new Notification({
						message : lang.backup_created,
						icon: 'fas fa-download',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : info.errors.join(),
						icon: 'fas fa-download',
						type : 'danger'
					}).show();
				};
			}
		});
	};
	
/**
	Delete a backup from the server
*/
	function deleteBackup(table, id) {
		new AreUSure({
			label: lang.delete_backup.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'deleteBackup',
						instance: instance,
						port: port,
						backup: id
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, lang.file_delete_success.replace("&ouml;", "\u00f6"), 'success');
							deleteRow = Array(id);
							$('#'+table).bootstrapTable('remove', {
								field: 'id',
								values: deleteRow
							});
						} else {
							swal(lang.aborted, lang.file_could_not_deleted.replace("&ouml;", "\u00f6"), 'error');
						};
					}
				});
			}
		});
	};
	
/**
	Delete a file from a server channel
	@param {string} path
	@param {int, sting} cid
	@param {string} id
*/
	function deleteFile(path, cid, id) {
		new AreUSure({
			label: lang.delete_file.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'deleteFile',
						instance: instance,
						port: port,
						cid: cid,
						path: encodeURIComponent(path)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, lang.file_delete_success.replace("&ouml;", "\u00f6"), 'success');
							deleteRow = Array(id);
							$('#fileTable').bootstrapTable('remove', {
								field: 'id',
								values: deleteRow
							});
						} else {
							swal(lang.aborted, info.errors.join(), 'error');
						};
					}
				});
			}
		});
	};
	
/**
	Delete a client from the teamspeak database
	@param {int, string} cldbid
*/
	function deleteDBClient(cldbid = '') {
		if(cldbid == '' && $('#datepickerInactiveClients').val() == '') {
			return;
		};

		var sgroups = ($('#datepickerInactiveClients').length) ? JSON.stringify($('#sgroupInactiveClients').val()) : '';
		var datapickerValue = $('#datepickerInactiveClients').val().split(".");
		datapickerValue = datapickerValue[1]+'.'+datapickerValue[0]+'.'+datapickerValue[2];
		datapickerValue = new Date(datapickerValue).getTime() / 1000;
		
		new AreUSure({
			label: lang.user_delete.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'deleteDBClient',
						instance: instance,
						port: port,
						cldbid: cldbid,
						sgroups: sgroups,
						time: datapickerValue
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, lang.client_successfull_deleted.replace("&ouml;", "\u00f6"), 'success');
							if(cldbid == '') {
								$('#clientsTable').bootstrapTable('remove', {
									field: 'id',
									values: info.data
								});
							} else {
								$('#clientsTable').bootstrapTable('remove', {
									field: 'id',
									values: info.data
								});
							};
						} else {
							swal(lang.aborted, info.errors.join(), 'error');
						};
					}
				});
			}
		});
	};

	
/*
	web_teamspeakbackups: slide
*/
	function slideBackups(direction)
	{
		if(direction == "up")
		{
			$('#slideBackups').slideUp("slow");
		}
		else
		{
			$('#slideBackups').slideDown("slow");
		};
	};
	
/*
	Server Message / Poke
*/
	function serverMessage()
	{
		var message 	=	$('#serverMessageContent').val();
		
		if(message != '')
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action:		'serverMessage',
					instanz:	instanz,
					port:		port,
					mode:		'3',
					message:	encodeURIComponent(message),
					serverid:	serverId
				},
				success: function(data)
				{
					if(data == "done")
					{
						setNotifySuccess(lang.servermessage_done);
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};
	
	function serverPoke()
	{
		var message 	=	$('#serverMessageContent').val();
		
		if(message != '')
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action:		'serverPoke',
					instanz:	instanz,
					port:		port,
					message:	encodeURIComponent(message),
					serverid:	serverId
				},
				success: function(data)
				{
					if(data == "done")
					{
						setNotifySuccess(lang.serverpoke_done);
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};

/*
	Server Start / Stop
*/
	function toggleStartStopTeamspeakserver(id, instanz, serverPort)
	{
		if(tsStatus == 'online')
		{
			stopTeamspeakserver(id, instanz, serverPort);
			tsStatus = "offline";
		}
		else
		{
			startTeamspeakserver(id, instanz, serverPort);
			tsStatus = "online";
		};
	};
	
	function stopTeamspeakserver(id, instanz, serverPort)
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'serverStop',
				instanz:	instanz,
				port:		serverPort,
				serverid:	id
			},
			success: function(data)
			{
				if(data == 'done')
				{
					// Serverstatus �ndern
					var objectUptime					=	document.getElementById('uptime-'+instanz+'-'+id),
						objectOnline					=	document.getElementById('online-'+instanz+'-'+id),
						objectClients					=	document.getElementById('progress-bar-'+instanz+'-'+id),
						objectTable						=	document.getElementById('serverlist-'+instanz+'-'+id),
						objectTableSlots				=	document.getElementById('serverlist-slots-'+instanz+'-'+id);
					
					if(objectUptime && objectOnline && objectClients)
					{
						objectUptime.removeAttribute('uptime-timestamp');
						objectUptime.innerHTML			=	lang.online_since+": -";
						objectOnline.innerHTML			=	lang.offline;
						objectClients.style.display		=	"none";
					};
					
					if(objectTable && objectTableSlots)
					{
						objectTable.classList.remove("text-success");
						objectTable.classList.add("text-danger");
						objectTableSlots.innerHTML		=	"-";
					};
					
					// Dashboard
					if(document.getElementById("clients-"+instanz+"-"+id))
					{
						document.getElementById("clients-"+instanz+"-"+id).innerHTML		=	'-';
						document.getElementById("status-"+instanz+"-"+id).innerHTML			=	'offline';
						
						$('#status-'+instanz+'-'+id).removeClass("text-success");
						$('#status-'+instanz+'-'+id).addClass("text-danger");
					};
					
					setNotifySuccess(lang.server_stoped);
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	
	function startTeamspeakserver(id, instanz, serverPort)
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'serverStart',
				instanz:	instanz,
				port:		serverPort,
				serverid:	id
			},
			success: function(data)
			{
				if(data == 'done')
				{
					var	objectUptime		=	document.getElementById('uptime-'+instanz+'-'+id),
						objectOnline		=	document.getElementById('online-'+instanz+'-'+id),
						objectClients		=	document.getElementById('progress-bar-'+instanz+'-'+id),
						objectTable			=	document.getElementById('serverlist-'+instanz+'-'+id),
						objectTableSlots	=	document.getElementById('serverlist-slots-'+instanz+'-'+id);
					
					if((objectTable && objectTableSlots) || (objectUptime && objectOnline && objectClients) || document.getElementById("clients-"+instanz+"-"+id))
					{
						$.ajax({
							type: "POST",
							url: "./php/functions/functionsTeamspeakPost.php",
							data: {
								action:		'getInstanzServerlistInformations'
							},
							success: function(data)
							{
								var informations 														=	JSON.parse(data);
								
								// Serverstatus �ndern
								if(objectUptime && objectOnline && objectClients)
								{
									objectUptime.setAttribute('uptime-timestamp', '1');
									objectOnline.innerHTML												=	lang.online;
									objectClients.style.display											=	"inline";
									objectClients.innerHTML												=	informations[instanz][id].clients+" / "+informations[instanz][id].maxclients;
									objectClients.style.width											=	(informations[instanz][id].clients/informations[instanz][id].maxclients) * 100+"%";
								};
								
								if(objectTable && objectTableSlots)
								{
									objectTable.classList.remove("text-danger");
									objectTable.classList.add("text-success");
									objectTableSlots.innerHTML											=	informations[instanz][id].clients+" / "+informations[instanz][id].maxclients;
								};
								
								// Dashboard
								if(document.getElementById("clients-"+instanz+"-"+id))
								{
									document.getElementById("clients-"+instanz+"-"+id).innerHTML		=	informations[instanz][id].clients+'&nbsp;/&nbsp;'+informations[instanz][id].maxclients;
									document.getElementById("status-"+instanz+"-"+id).innerHTML			=	'online';
									
									$('#status-'+instanz+'-'+id).removeClass("text-danger");
									$('#status-'+instanz+'-'+id).addClass("text-success");
								};
							}
						});
					};
					
					setNotifySuccess(lang.server_started);
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	
/*
	Delete a Teamspeakserver
*/
	function deleteTeamspeakserver(serverId, instanz, port)
	{
		var returnValue		=	"done";
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'serverDelete',
				serverid:	serverId,
				instanz:	instanz,
				port:		port
			},
			async: false,
			success: function(data)
			{
				if(data == 'done')
				{
					if(serverCount > 8)
					{
						deleteRow			=	Array(serverId);
						$('#serverTable_'+instanz).bootstrapTable('remove', {
							field: 'id',
							values: deleteRow
						});
					}
					else
					{
						$('#serverbox_'+instanz+'_'+port).remove();
					};
					
					setNotifySuccess(lang.server_deleted);
				}
				else
				{
					setNotifyFailed(lang.server_could_be_not_deleted);
					returnValue				=	lang.server_could_be_not_deleted;
				};
			}
		});
		return returnValue;
	};
	
/*
	Go back to Main menu
*/
	function goBackToMain()
	{
		if ('replaceState' in history)
		{
			history.replaceState(null, document.title, "index.php?web_teamspeak_server");
		};
		
		$(".preloader").fadeIn("fast", function()
		{
			$("#hp").load("./php/main/web_main.php");
		});
	};

/*
	Show Teamspeakinformations
*/
	function showTeamspeakserver(id, instanz)
	{
		if ('replaceState' in history)
		{
			history.replaceState(null, document.title, "index.php?web_teamspeak_serverview?"+instanz+"?"+id);
		};
		
		$(".preloader").fadeIn("fast", function()
		{
			$("#hp").load("./php/main/web_main.php?temp?"+instanz+"?"+id);
		});
	};

/*
	Serverview: Server Edit
*/
	function serverEdit(right, newValue, instanz, serverId, serverPort)
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'serverEdit',
				instanz:	instanz,
				port:		serverPort,
				right:		right,
				value:		newValue,
				serverid:	serverId
			},
			success: function(data)
			{
				if(data == "done")
				{
					setNotifySuccess(lang.server_successfull_edit);
					
					if(right == 'virtualserver_port')
					{
						goBackToMain();
						stopTeamspeakserver(serverId, instanz, serverPort);
						startTeamspeakserver(serverId, instanz, serverPort);
					};
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	

	



	

	

	

	
/*
	Serverview: Backup: Activate Channelbackup
*/
	function activateBackup(file, subaction)
	{
		alert("This can take a while.... Dont get panic ;)");
		
		var returnVal 			=	"done";
		$.ajax({
			url: "./php/functions/functionsBackupPost.php",
			type: "post",
			data: {
				action:		'activateBackup',
				subaction:	subaction,
				instanz:	instanz,
				port:		port,
				file:		file
			},
			async: false,
			success: function(data){
				if(data == "done")
				{
					setNotifySuccess(lang.backup_activation_successfull);
				}
				else
				{
					returnVal	=	data;
					setNotifyFailed(data);
				};
			}
		});
		return returnVal;
	};



/*
	Serverview: Serverhome: Client Message / Poke 
*/
	function clientMsg(clid)
	{
		var message		=	escapeText($('#inputMessagePoke').val()),
			mode		=	$('#selectMessagePoke').val(),
			action		=	(mode == 1) ? "clientMsg" : "clientPoke";
		
		if(message != '')
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action:		action,
					message:	encodeURIComponent(message),
					instanz:	instanz,
					port:		port,
					clid:		clid
				},
				success: function(data)
				{
					if(data == "done")
					{
						setNotifySuccess((mode == 1) ? lang.client_message_success : lang.client_poke_success);
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};
	
/*
	Serverview: Serverhome: Client Move
*/
	function clientMove(clid)
	{
		var cid			=	$('#selectMoveInChannel').val();
		
		if(cid != '')
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action:		'clientMove',
					message:	'',
					instanz:	instanz,
					port:		port,
					clid:		clid,
					cid:		cid
				},
				success: function(data)
				{
					if(data == 'done')
					{
						setNotifySuccess(lang.client_move_success);
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};
	
/*
	Serverview: Serverhome: Client Kick
*/
	function clientKick(clid)
	{
		var mode		=	$('#selectKickStyle').val(),
			message		=	escapeText($('#inputMessageKick').val());
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'clientKick',
				message:	encodeURIComponent(message),
				instanz:	instanz,
				port:		port,
				clid:		clid,
				kickmode:	mode
			},
			success: function(data)
			{
				if(data == 'done')
				{
					setNotifySuccess(lang.client_kick_success);
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};

/*
	Serverview: Serverhome: Client Ban
*/
	function clientBan(clid)
	{
		var time		=	($('#inputBanTime').val() == "") ? 0 : $('#inputBanTime').val(),
			message		=	escapeText($('#inputMessageBan').val());
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'clientBan',
				message:	encodeURIComponent(message),
				instanz:	instanz,
				port:		port,
				clid:		clid,
				bantime:	time
			},
			success: function(data)
			{
				if(data == 'done' && document.getElementById("infoBan"))
				{
					setNotifySuccess(lang.client_ban_success);
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	
/*
	Serverview: Serverhome: Add / Remove Serverpermissions
*/
	function addRemoveSRights(clid, sgid, id)
	{
		var hasRight	=	$('#'+id).hasClass("btn-success");
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'clientAddRemoveServerGroup',
				sgid:		sgid,
				instanz:	instanz,
				port:		port,
				clid:		clid,
				permission:	!hasRight
			},
			success: function(data)
			{
				if(data == 'done')
				{
					if(hasRight)
					{
						$('#'+id).removeClass("btn-success");
						$('#'+id+'_icon').removeClass("fa-check");
						$('#'+id).addClass("btn-danger");
						$('#'+id+'_icon').addClass("fa-ban");
						
						document.getElementById(id+'_text').innerHTML	=	' '+lang.blocked;
					}
					else
					{
						$('#'+id).removeClass("btn-danger");
						$('#'+id+'_icon').removeClass("fa-ban");
						$('#'+id).addClass("btn-success");
						$('#'+id+'_icon').addClass("fa-check");
						
						document.getElementById(id+'_text').innerHTML	=	' '+lang.unblocked;
					};
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	
/*
	Serverview: Serverhome Add / Remove Channelgroup
*/
	function addRemoveCRights(cid, oldCgid, clid, cgid, id)
	{
		if(clientChannelGroupId != -1)
		{
			oldCgid		=	clientChannelGroupId;
		};
		
		var hasRight	=	$('#'+id).hasClass("btn-success");
		
		if(!hasRight)
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action:		'clientChangeChannelGroup',
					cid:		cid,
					cgid:		cgid,
					instanz:	instanz,
					port:		port,
					clid:		clid
				},
				success: function(data)
				{
					if(data == 'done')
					{
						clientChannelGroupId	=	cgid;
						
						$('#'+id).removeClass("btn-danger");
						$('#'+id+'_icon').removeClass("fa-ban");
						$('#'+id).addClass("btn-success");
						$('#'+id+'_icon').addClass("fa-check");
						
						document.getElementById(id+'_text').innerHTML	=	' '+lang.unblocked;
						
						$('#cgroup_'+oldCgid).removeClass("btn-success");
						$('#cgroup_'+oldCgid+'_icon').removeClass("fa-check");
						$('#cgroup_'+oldCgid).addClass("btn-danger");
						$('#cgroup_'+oldCgid+'_icon').addClass("fa-ban");
						
						document.getElementById('cgroup_'+oldCgid+'_text').innerHTML	=	' '+lang.blocked;
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};
	
/*
	Serverview: Massenactions: Message / Poke
*/
	function massactionsChangeMessagePoke(action = 0)
	{
		var who					=	$("#selectMessagePokeGroup").find(':selected').attr('group'),
			channel				=	$('#selectMessagePokeChannel').val(),
			group				=	$('#selectMessagePokeGroup').val();
		
		massactionsMassInfo(who, group, channel, 'msg', action);
	};

/*
	Serverview: Massenactions: Move
*/
	function massactionsChangeMove(action = 0)
	{
		var whichChannel	= 	$('#selectMoveFromChannel').val(),
			toChannel		= 	$('#selectMoveInChannel').val();
		
		if(whichChannel != '' && toChannel != '')
		{
			var who					=	$("#selectMoveGroup").find(':selected').attr('group'),
				group				=	$('#selectMoveGroup').val();
			
			massactionsMassInfo(who, group, whichChannel, 'move', action);
		};
	};

/*
	Serverview: Massenactions: Kick
*/
	function massactionsChangeKick(action = 0)
	{
		var who					=	$("#selectKickGroup").find(':selected').attr('group'),
			channel				=	$('#selectKickChannel').val(),
			group				=	$('#selectKickGroup').val();
		
		massactionsMassInfo(who, group, channel, 'kick', action);
	};

/*
	Serverview: Massenactions: Ban
*/
	function massactionsChangeBan(action = 0)
	{
		var who					=	$("#selectBanGroup").find(':selected').attr('group'),
			channel				=	$('#selectBanChannel').val(),
			group				=	$('#selectBanGroup').val();
		
		massactionsMassInfo(who, group, channel, 'ban', action);
	};
	
/*
	Serverview: Massenactions: Massinfo & Massaction
*/
	function massactionsMassInfo(who, group, channel, action, id = 0)
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:			'getUsersMassActions',
				ts3_server:		instanz,
				ts3_port:		port,
				who:			who,
				group:			group,
				channel:		channel,
				mass_action:	action,
				just_id:		id
			},
			success: function(data)
			{
				var informations		= 	JSON.parse(data);
				
				if(id == 0)
				{
					if(informations.length <= 1)
					{
						if(informations[0] == 'move' && document.getElementById("infoMove"))
						{
							document.getElementById("infoMove").innerHTML = lang.catched_clients;
						};
						
						if(informations[0] == 'kick' && document.getElementById("infoKick"))
						{
							document.getElementById("infoKick").innerHTML = lang.catched_clients;
						};
						
						if(informations[0] == 'ban' && document.getElementById("infoBan"))
						{
							document.getElementById("infoBan").innerHTML = lang.catched_clients;
						};
						
						if(informations[0] == 'msg' && document.getElementById("infoMessagePoke"))
						{
							document.getElementById("infoMessagePoke").innerHTML = lang.catched_clients;
						};
					}
					else
					{
						var clients		=	'';
						for($i=1; $i<informations.length; $i++)
						{
							if($i == 0 || $i == informations.length -1)
							{
								clients	+=	informations[$i];
							}
							else 
							{
								clients	+=	informations[$i]+', ';
							};
						};
						
						if(informations[0] == 'move' && document.getElementById("infoMove"))
						{
							document.getElementById("infoMove").innerHTML = clients;
						};
						
						if(informations[0] == 'kick' && document.getElementById("infoKick"))
						{
							document.getElementById("infoKick").innerHTML = clients;
						};
						
						if(informations[0] == 'ban' && document.getElementById("infoBan"))
						{
							document.getElementById("infoBan").innerHTML = clients;
						};
						
						if(informations[0] == 'msg' && document.getElementById("infoMessagePoke"))
						{
							document.getElementById("infoMessagePoke").innerHTML = clients;
						};
					};
				}
				else
				{
					var succeeded					=	0;
					if(informations.length > 1)
					{
						for($i=1; $i<informations.length; $i++)											
						{
							switch(informations[0])
							{
								case "msg":
									var message		=	escapeText($('#inputMessagePoke').val()),
										mode		=	$('#selectMessagePoke').val();
									
									if(message != '')
									{
										action		=	(mode == 1) ? "clientMsg" : "clientPoke";
										$.ajax({
											type: "POST",
											url: "./php/functions/functionsTeamspeakPost.php",
											data: {
												action:		action,
												message:	encodeURIComponent(message),
												instanz:	instanz,
												port:		port,
												clid:		informations[$i]
											},
											async: false,
											success: function(data)
											{
												if(data == "done")
												{
													succeeded++;
												};
											}
										});
									};
									break;
								case "move":
									var cid			=	$('#selectMoveInChannel').val();
									
									if(cid != '')
									{
										$.ajax({
											type: "POST",
											url: "./php/functions/functionsTeamspeakPost.php",
											data: {
												action:		'clientMove',
												message:	'',
												instanz:	instanz,
												port:		port,
												clid:		informations[$i],
												cid:		cid
											},
											async: false,
											success: function(data)
											{
												if(data == 'done' && document.getElementById("infoMove"))
												{
													document.getElementById("infoMove").innerHTML = lang.catched_clients;
													succeeded++;
												};
											}
										});
									};
									break;
								case "kick":
									var mode		=	$('#selectKickStyle').val(),
										message		=	escapeText($('#inputMessageKick').val());
									
									$.ajax({
										type: "POST",
										url: "./php/functions/functionsTeamspeakPost.php",
										data: {
											action:		'clientKick',
											message:	encodeURIComponent(message),
											instanz:	instanz,
											port:		port,
											clid:		informations[$i],
											kickmode:	mode
										},
										async: false,
										success: function(data)
										{
											if(data == 'done' && document.getElementById("infoKick"))
											{
												document.getElementById("infoKick").innerHTML = lang.catched_clients;
												succeeded++;
											};
										}
									});
									break;
								case "ban":
									var time		=	$('#inputBanTime').val(),
										message		=	escapeText($('#inputMessageBan').val());
									
									$.ajax({
										type: "POST",
										url: "./php/functions/functionsTeamspeakPost.php",
										data: {
											action:		'clientBan',
											message:	encodeURIComponent(message),
											instanz:	instanz,
											port:		port,
											clid:		informations[$i],
											bantime:	time
										},
										async: false,
										success: function(data)
										{
											if(data == 'done' && document.getElementById("infoBan"))
											{
												document.getElementById("infoBan").innerHTML = lang.catched_clients;
												succeeded++;
											};
										}
									});
									break;
							};
						};
						
						if((informations.length -1) == succeeded)
						{
							setNotifySuccess(lang.massaction_success);
						}
						else
						{
							setNotifyFailed(lang.massaction_failed);
						};
					};
				};
			}
		});
	};
	


/*
	Serverview: Server Create: Checkport
*/
	$(function() {
		$('#serverCreatePort').focusout(function() {
			if($(this).val() == "")
			{
				$(this).removeClass("text-danger-no-cursor");
				$(this).removeClass("text-success");
			}
			else
			{
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action:		'checkTeamspeakPort',
						port:		$(this).val(),
						instanz:	$("#serverCreateWhichInstanz").val()
					},
					success: function(data){
						if(data == "done")
						{
							$("#serverCreatePort").addClass("text-danger-no-cursor");
							$("#serverCreatePort").removeClass("text-success");
						}
						else
						{
							$("#serverCreatePort").addClass("text-success");
							$("#serverCreatePort").removeClass("text-danger-no-cursor");
						};
					}
				});
			};
		});
	});
	
/*
	Serverview: Server Create: Server Create
*/
	function createServer(requestName = "", requestPw = "", filename, isRequest = false)
	{
		$('#createServer').addClass("disabled");
		$('#createServer').prop('disabled', true);
		
		var serverdata													= 	new Object();
		
		serverdata.virtualserver_reserved_slots							=	($('#serverCreateReservedSlots').val() != '') ? $('#serverCreateReservedSlots').val() : ts3_server_create_default['reserved_slots'];
		serverdata.virtualserver_hostmessage							=	($('#serverCreateHostMessage').val() != '' && !isRequest) ? $('#serverCreateHostMessage').val() : ts3_server_create_default['host_message'];
		serverdata.virtualserver_hostbanner_url							=	($('#serverCreateHostUrl').val() != '' && !isRequest) ? $('#serverCreateHostUrl').val() : ts3_server_create_default['host_url'];
		serverdata.virtualserver_hostbanner_gfx_url						=	($('#serverCreateHostBannerUrl').val() != '' && !isRequest) ? $('#serverCreateHostBannerUrl').val() : ts3_server_create_default['host_banner_url'];
		serverdata.virtualserver_hostbanner_gfx_interval				=	($('#serverCreateHostBannerInterval').val() != '' && !isRequest) ? $('#serverCreateHostBannerInterval').val() : ts3_server_create_default['host_banner_int'];
		serverdata.virtualserver_hostbutton_gfx_url						=	($('#serverCreateHostButtonGfxUrl').val() != '' && !isRequest) ? $('#serverCreateHostButtonGfxUrl').val() : ts3_server_create_default['host_button_gfx'];
		serverdata.virtualserver_hostbutton_tooltip						=	($('#serverCreateHostButtonTooltip').val() != '' && !isRequest) ? $('#serverCreateHostButtonTooltip').val() : ts3_server_create_default['host_button_tip'];
		serverdata.virtualserver_hostbutton_url							=	($('#serverCreateHostButtonUrl').val() != '' && !isRequest) ? $('#serverCreateHostButtonUrl').val() : ts3_server_create_default['host_button_url'];
		serverdata.virtualserver_complain_autoban_count					=	($('#serverCreateAutobanCount').val() != '' && !isRequest) ? $('#serverCreateAutobanCount').val() : ts3_server_create_default['auto_ban_count'];
		serverdata.virtualserver_complain_autoban_time					=	($('#serverCreateAutobanDuration').val() != '' && !isRequest) ? $('#serverCreateAutobanDuration').val() : ts3_server_create_default['auto_ban_time'];
		serverdata.virtualserver_complain_remove_time					=	($('#serverCreateAutobanDeleteAfter').val() != '' && !isRequest) ? $('#serverCreateAutobanDeleteAfter').val() : ts3_server_create_default['remove_time'];
		serverdata.virtualserver_antiflood_points_tick_reduce			=	($('#serverCreateReducePoints').val() != '' && !isRequest) ? $('#serverCreateReducePoints').val() : ts3_server_create_default['points_tick_reduce'];
		serverdata.virtualserver_antiflood_points_needed_command_block	=	($('#serverCreatePointsBlock').val() != '' && !isRequest) ? $('#serverCreatePointsBlock').val() : ts3_server_create_default['points_needed_block_cmd'];
		serverdata.virtualserver_antiflood_points_needed_ip_block		=	($('#serverCreatePointsBlockIp').val() != '' && !isRequest) ? $('#serverCreatePointsBlockIp').val() : ts3_server_create_default['needed_block_ip'];
		serverdata.virtualserver_max_upload_total_bandwidth				=	($('#serverCreateUploadLimit').val() != '' && !isRequest) ? $('#serverCreateUploadLimit').val() : ts3_server_create_default['upload_bandwidth_limit'];
		serverdata.virtualserver_upload_quota							=	($('#serverCreateUploadKontigent').val() != '' && !isRequest) ? $('#serverCreateUploadKontigent').val() : ts3_server_create_default['upload_quota'];
		serverdata.virtualserver_max_download_total_bandwidth			=	($('#serverCreateDownloadLimit').val() != '' && !isRequest) ? $('#serverCreateDownloadLimit').val() : ts3_server_create_default['download_bandwidth_limit'];
		serverdata.virtualserver_download_quota							=	($('#serverCreateDownloadKontigent').val() != '' && !isRequest) ? $('#serverCreateDownloadKontigent').val() : ts3_server_create_default['download_quota'];
		serverdata.virtualserver_log_client								=	(!isRequest) ? $('#serverCreateProtokolClient').is(':checked') : ts3_server_create_default['virtualserver_log_client'];
		serverdata.virtualserver_log_query								=	(!isRequest) ? $('#serverCreateProtokolQuery').is(':checked') : ts3_server_create_default['virtualserver_log_query'];
		serverdata.virtualserver_log_channel							=	(!isRequest) ? $('#serverCreateProtokolChannel').is(':checked') : ts3_server_create_default['virtualserver_log_channel'];
		serverdata.virtualserver_log_permissions						=	(!isRequest) ? $('#serverCreateProtokolRights').is(':checked') : ts3_server_create_default['virtualserver_log_permissions'];
		serverdata.virtualserver_log_server								=	(!isRequest) ? $('#serverCreateProtokolServer').is(':checked') : ts3_server_create_default['virtualserver_log_server'];
		serverdata.virtualserver_log_filetransfer						=	(!isRequest) ? $('#serverCreateProtokolTransfer').is(':checked') : ts3_server_create_default['virtualserver_log_filetransfer'];
		serverdata.virtualserver_name									=	($('#serverCreateServername').val() != '') ? $('#serverCreateServername').val() : ts3_server_create_default['servername'];
		serverdata.virtualserver_maxclients								=	($('#serverCreateSlots').val() != '') ? $('#serverCreateSlots').val() : ts3_server_create_default['slots'];
		serverdata.virtualserver_password								=	($('#serverCreatePassword').val() != '') ? $('#serverCreatePassword').val() : ts3_server_create_default['password'];
		serverdata.virtualserver_welcomemessage							=	$('#serverCreateWelcomeMessage').val();
		
		if($('#serverCreatePort').val() != '')
		{
			serverdata.virtualserver_port								=	$('#serverCreatePort').val();
		};
		
		if(!isRequest)
		{
			serverdata.virtualserver_hostmessage_mode					=	$('#serverCreateHosttype').val();
		};
		
		$.ajax({
			url: "./php/functions/functionsTeamspeakPost.php",
			type: "post",
			data: {
				action:			'createServer',
				instanz:		$('#serverCreateWhichInstanz').val(),
				serverdata:		encodeURIComponent(JSON.stringify(serverdata)),
				copyInstanz:	$('#serverCreateServerCopy').val(),
				copyPort:		$('#serverCreateServerCopyPort').val(),
				isRequest:		isRequest,
				requestName:	requestName,
				requestPw:		requestPw,
				filename:		filename
			},
			success: function(data){
				informations	=	JSON.parse(data);
				
				if(informations.success === "1")
				{
					if(isRequest)
					{
						changeContent('web_teamspeak_server_requests');
					};
					
					swal({
						type: 'info',
						html:
							'<span class="pull-xs-left">'+lang.name+'</span><span class="pull-xs-right">'+serverdata.virtualserver_name+'</span><div style="clear: both;"></div>' +
							'<span class="pull-xs-left">'+lang.server_id+'</span><span class="pull-xs-right">'+informations['serverid']+'</span><div style="clear: both;"></div>' +
							'<span class="pull-xs-left">'+lang.port+'</span><span class="pull-xs-right">'+informations['port']+'</span><div style="clear: both;"></div>' +
							'<span class="pull-xs-left">'+lang.token+'</span><span class="pull-xs-right">'+informations['token']+'</span><div style="clear: both;"></div>',
						showCloseButton: true
					});
				}
				else
				{
					setNotifyFailed(informations.error);
				};
				
				$('#createServer').prop('disabled', false);
				$('#createServer').removeClass('disabled');
			}
		});
	};
	
/*
	Serverview: Server Create: Delete Server Application
*/
	function deleteWantServer(file)
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsPost.php",
			data: {
				action:		'deleteServerRequest',
				file:		file
			},
			success: function(data)
			{
				if(data == 'error')
				{
					setNotifyFailed(lang.file_does_not_exist);
				}
				else
				{
					setNotifySuccess(lang.file_delete_success);
					$(".tag-server-request").each(function() {
						var serverRequests		=	$(this).text();
						$(this).text((serverRequests > 0) ? --serverRequests : 0);
						
						if(serverRequests  <= 0)
						{
							$('#naviWantServer').remove();
							changeContent('web_profil_dashboard');
						}
						else
						{
							changeContent('web_teamspeak_server_requests');
						}
					});
				};
			}
		});
	};

/*
	Serverview: Server Create: Copy Port (Server Create)
*/
	function serverCreateChangePort()
	{
		var instanz		=	$('#serverCreateServerCopy').val();
		
		if(instanz != 'nope')
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action:		'getTeamspeakPorts',
					instanz:	instanz
				},
				success: function(data){
					var element = document.getElementById('serverCreateServerCopyPort');
					
					while ( element.childNodes.length >= 1 )
					{
						element.removeChild(element.firstChild);
					};
					
					if(data != "[]")
					{
						var ports 	=	JSON.parse(data);
						for (i = 0; i < ports.length; i++)
						{
							port 					= 	document.createElement('option');
							port.value				=	ports[i];
							port.text				=	ports[i];
							element.appendChild(port);
						};
					}
					else
					{
						nope 						= 	document.createElement('option');
						nope.value					=	'nope';
						nope.text					=	unescape(lang.ts3_no_copy);
						element.appendChild(nope);
					};
				}
			});
		}
		else
		{
			var element = document.getElementById('serverCreateServerCopyPort');
			
			while ( element.childNodes.length >= 1 )
			{
				element.removeChild(element.firstChild);
			};
			
			nope 						= 	document.createElement('option');
			nope.value					=	'nope';
			nope.text					=	unescape(lang.ts3_no_copy);
			element.appendChild(nope);
		};
	};
	
/*
	Serverview: Serverhome: Delete Teamspeakchannel
*/
	function deleteTeamspeakChannel(cid, sid)
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'deleteChannel',
				cid:		cid,
				instanz:	instanz,
				port:		port,
				serverid:	sid
			},
			success: function(data){
				if(data == 'done')
				{
					setNotifySuccess(lang.channel_deleted);
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	
/*
	Serverview: Serverclients: Delete Databaseclient (time)
*/
	function deleteDBClientTime()
	{
		var datapickerValue		=	$('#datapickerClients').val().split(".");
		datapickerValue			=	datapickerValue[1]+'.'+datapickerValue[0]+'.'+datapickerValue[2];
		datapickerValue			=	new Date(datapickerValue).getTime() / 1000;
		
		if(!isNaN(datapickerValue))
		{
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action:		'deleteDBClient',
					time:		datapickerValue,
					instanz:	instanz,
					port:		port
				},
				success: function(data){
					var ids			=	JSON.parse(data);
					
					if(ids['success'])
					{
						$('#clientsTable').bootstrapTable('remove', {
							field: 'id',
							values: ids['ids']
						});
						
						setNotifySuccess(lang.client_successfull_deleted);
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
		
		$('#modalAreYouSure').modal('hide');
	};
	

	
/*
	web_teamspeak_server_requests: Show Server Request informations
*/
	function showServerRequest(file)
	{
		/*if ('replaceState' in history)
		{
			history.replaceState(null, document.title, "index.php?web_admin_user_info");
		};*/
		
		if(setLoading(true))
		{
			$('#myContent').load('./php/teamspeak/web_teamspeak_server_requests_info.php', { "file" : file }, function()
			{
				setLoading(false);
			});
		};
	};