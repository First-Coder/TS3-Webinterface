/*
	First-Coder Teamspeak 3 Webinterface for everyone
	Copyright (C) 2017 by L.Gmann

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
	for help look http://first-coder.de/
*/
		
/*
	Profil Edit: Update Informations
*/
	function profilUpdate()
	{
		var success		=	profilUpdateAction('profileUser');
		if(success) { profilUpdateAction('profilePassword') };
		if(success) { profilUpdateAction('profileVorname') };
		if(success) { profilUpdateAction('profileNachname') };
		if(success) { profilUpdateAction('profileTelefon') };
		if(success) { profilUpdateAction('profileHomepage') };
		if(success) { profilUpdateAction('profileSkype') };
		if(success) { profilUpdateAction('profileSteam') };
		if(success) { profilUpdateAction('profileTwitter') };
		if(success) { profilUpdateAction('profileFacebook') };
		if(success) { profilUpdateAction('profileGoogle') };
		
		if(success)
		{
			setNotifySuccess(lang.settigns_saved);
			OverlayButton.setButton(false);
		};
	};
	
	function profilUpdateAction(id)
	{
		if(id == 'profileUser' || id == 'profilePassword')
		{
			idContent = $('#'+id).val();
		}
		else
		{
			idContent = encodeURIComponent($('#'+id).val());
		};
		
		var regex_check				=	true;
		var pw_check				=	true;
		
		if(id == 'profileVorname' || id == 'profileNachname')
		{
			var regex 				=	/^[a-zA-Z0-9_]+$/;
			regex_check				= 	regex.test(idContent);
			
			if(!regex_check)
			{
				setNotifyFailed(lang.change_name_failed);
			};
		}
		else if(id == 'profilePassword' && idContent == "")
		{
			regex_check				=	false;
		}
		else if((id == 'profilePassword' || id == 'profileUser') && !isDataValid(id))
		{
			regex_check				=	false;
		}
		else if(idContent != $('#profilePassword2').val() && id == 'profilePassword')
		{
			pw_check				=	false;
			setNotifyFailed(lang.change_pw2_failed);
		};
		
		if(regex_check && pw_check)
		{
			var returnData;
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action:		'updateUser',
					id:			id,
					content:	idContent
				},
				async: false,
				success: function(data)
				{
					if(data == 'done')
					{
						returnData	=	true;
					}
					else
					{
						returnData	=	false;
					};
				}
			});
			return returnData;
		}
		else
		{
			return false;
		};
	};