'use strict';

function AreYouSure(label, clickEvent) {
	swal({
		title: label,
		text: lang.are_you_sure,
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: lang.yes,
		cancelButtonText: lang.abort,
		confirmButtonClass: 'confirm-class',
		cancelButtonClass: 'cancel-class',
		closeOnConfirm: false,
		closeOnCancel: false
	}, function(isConfirm) {
		if (isConfirm) {
			var data 			= 	JSON.parse(decodeURIComponent(clickEvent));
			var exitData 		=	"done";
			switch(data[0])
			{
				case "deleteNews":
					exitData	=	deleteNews(data[1]);
					break;
				case "deleteInstanz":
					exitData	=	deleteInstanz(data[1]);
					break;
				case "deleteUser":
					exitData	=	deleteUser(data[1]);
					break;
				case "deleteTeamspeakserver":
					exitData	=	deleteTeamspeakserver(data[1], data[2], data[3]);
					break;
				case "deleteTicket":
					exitData	=	deleteTicket(data[1]);
					break;
				case "deleteBackup":
					exitData	=	deleteBackup(data[1], data[2], data[3]);
					break;
				case "activateBackup":
					exitData	=	activateBackup(data[1], data[2]);
					break;
				case "deleteQueryBot":
					exitData	=	deleteQueryBot(data[1]);
					break;
			};
			
			if(exitData == "done") {
				swal(lang.succeeded, lang.succeeded_info, 'success');
			} else {
				swal(lang.aborted, exitData, 'error');
			};
		} else {
			swal(lang.aborted, lang.aborted_info, 'error');
		}
	});
};

function SelectText(element) {
    var doc = document
        , text = doc.getElementById(element)
        , range, selection;
	
    if (doc.body.createTextRange) {
        range = document.body.createTextRange();
        range.moveToElementText(text);
        range.select();
    } else if (window.getSelection) {
        selection = window.getSelection();        
        range = document.createRange();
        range.selectNodeContents(text);
        selection.removeAllRanges();
        selection.addRange(range);
    };
};

function convertTime(seconds) {
		var returnArray			=	Array();
		returnArray['days']		=	Math.floor(seconds / 86400);
		returnArray['hours']	=	Math.floor((seconds - (returnArray['days'] * 86400)) / 3600);
		returnArray['minutes']	=	Math.floor((seconds - ((returnArray['days'] * 86400)+(returnArray['hours'] * 3600))) / 60);
		returnArray['seconds']	=	Math.floor(seconds - ((returnArray['days'] * 86400)+(returnArray['hours'] * 3600)+(returnArray['minutes'] * 60)));
		
		return returnArray;
};

function slideMe(boxid, iconid, iconleft = false) {
	var box 		=	$('#'+boxid),
		icon		=	$('#'+iconid);
	
	if((icon.hasClass("fa-arrow-right") && !iconleft) || icon.hasClass("fa-arrow-left") && iconleft) {
		icon.removeClass((iconleft) ? "fa-arrow-left" : "fa-arrow-right");
		icon.addClass("fa-arrow-down");
		
		box.slideDown("slow");
	} else {
		icon.removeClass("fa-arrow-down");
		icon.addClass((iconleft) ? "fa-arrow-left" : "fa-arrow-right");
		
		box.slideUp("slow");
	};
};

function slideToTop() {
	$('html').animate({scrollTop:0}, 'slow');	//IE, FF
	$('body').animate({scrollTop:0}, 'slow');	//chrome, don't know if Safari works
};

function escapeText(text) {
	if(typeof(text) == "undefined")
	{
		return "";
	};
	
	return text.replace(/\\/g, '\\\\').
		replace(/\u0008/g, '\\b').
		replace(/\t/g, '\\t').
		replace(/\n/g, '\\n').
		replace(/\f/g, '\\f').
		replace(/\r/g, '\\r').
		replace(/'/g, '\\\'').
		replace(/"/g, '\\"');
};

function escapeHtml(text) {
	return text.replace(/&/g, "&amp;")
		  .replace(/</g, "&lt;")
		  .replace(/>/g, "&gt;")
		  .replace(/"/g, "&quot;")
		  .replace(/'/g, "&#039;");
};

function setNotifyFailed(text) {
	toastr.error(text);
};

function setNotifySuccess(text) {
	toastr.success(text);
};

function isDataValid(id) {
	if(document.getElementById(id)) {
		$('#'+id).focus().blur();
		return ($('#'+id).attr('data-valid') == "true") ? true : false;
	};
	
	return false;
};

function setLoading(show = true) {
	if(show) {
		if(!$('.backdrop').hasClass('fade in')) {
			$('.backdrop').addClass('fade in');
		};
		$('.backdrop .fa').css("display", "inline");
	} else {
		if($('.backdrop').hasClass('fade in')) {
			$('.backdrop').removeClass('fade in');
		};
		$('.backdrop .fa').css("display", "none");
	};
	
	return true;
};

function isError(element, message) {
    var el = $(element);
    el.parent().removeClass('has-success').addClass('has-danger')
    el.removeClass('form-control-success').addClass('form-control-danger')
    el.next().text(message).removeClass('text-success').addClass('text-danger');
    el.attr('data-valid', false);
};

function isSuccess(element, message) {
    var el = $(element);
    el.parent().removeClass('has-danger').addClass('has-success')
    el.removeClass('form-control-danger').addClass('form-control-success')
    el.next().text(message).removeClass('text-danger').addClass('text-success');
    el.attr('data-valid', true);
};

function resetMessages(element) {
    var el = $(element);
    el.parent().removeClass('has-danger').removeClass('has-success')
    el.removeClass('form-control-danger').removeClass('form-control-success')
    el.next().text('');
};

function validateOnChange(element, rules, successMessage, errorMessage) {
    $(document).on('focus', element, function(e) {
        e.preventDefault();
        //resetMessages(element);
        return false;
    });
    $(document).on('blur', element, function(e) {
        e.preventDefault();
        var result = approve.value($(element).val(), rules);
        if (result.approved) {
            isSuccess(element, successMessage);
        } else {
            isError(element, errorMessage);
        };
        return false;
    });
};

function animatedPeityBar(element, height, color) {
    var chart = $(element).peity('bar', {
        height: height,
        width: '100%',
        fill: [color]
    });
    setInterval(function() {
        var random = Math.floor(Math.random() * 10) + 2;
        var values = chart.text().split(',');
        values.shift();
        values.push(random);
        chart.text(values.join(',')).change();
    }, 1000);
};

function animatedPeityArea(element, height, color) {
    var chart = $(element).peity('line', {
        height: height,
        width: '100%',
        fill: color,
        stroke: color
    });
    setInterval(function() {
        var random = Math.floor(Math.random() * 10) + 2;
        var values = chart.text().split(',');
        values.shift();
        values.push(random);
        chart.text(values.join(',')).change();
    }, 1000);
};

function animatedPeityLine(element, height, color) {
    var chart = $(element).peity('line', {
        height: height,
        width: '100%',
        fill: 'white',
        stroke: color
    });
    setInterval(function() {
        var random = Math.floor(Math.random() * 10) + 2;
        var values = chart.text().split(',');
        values.shift();
        values.push(random);
        chart.text(values.join(',')).change();
    }, 1000);
};

function animatedLineChart(id, color) {
    var lineChart = echarts.init(document.getElementById(id));

    function randomData() {
        now = new Date(+now + oneDay);
        value = value + Math.random() * 21 - 10;
        return {
            name: now.toString(),
            value: [
                [now.getFullYear(), now.getMonth() + 1, now.getDate()].join('-'),
                Math.round(value)
            ]
        };
    }
    var data = [];
    var now = new Date(2010, 9, 3);
    var oneDay = 24 * 3600 * 1000;
    var value = Math.random() * 1000;
    for (var i = 0; i < 1000; i++) {
        data.push(randomData());
    };
    var option = {
        color: [color],
        title: {
            text: null
        },
        tooltip: {
            trigger: 'axis',
            formatter: function(params) {
                params = params[0];
                var date = new Date(params.name);
                return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear() + ' : ' + params.value[1];
            },
            axisPointer: {
                animation: false
            }
        },
        xAxis: {
            show: false,
            type: 'time',
            splitLine: {
                show: false
            }
        },
        yAxis: {
            show: false,
            type: 'value',
            boundaryGap: [0, '100%'],
            splitLine: {
                show: false
            }
        },
        series: [{
            name: 'Serie A',
            type: 'line',
            showSymbol: false,
            hoverAnimation: false,
            data: data
        }]
    };
    lineChart.setOption(option);
    setInterval(function() {
        for (var i = 0; i < 5; i++) {
            data.shift();
            data.push(randomData());
        }
        lineChart.setOption({
            series: [{
                data: data
            }]
        });
    }, 1000);
};

function peityDonut(element, radius, colors) {
    return $(element).peity('donut', {
        width: radius,
        radius: radius,
        fill: colors
    });
};

function peityPie(element, radius, colors) {
    return $(element).peity('pie', {
        height: radius,
        width: radius,
        radius: radius,
        fill: colors
    });
}

function peityBar(element, height, width, color) {
    return $(element).peity('bar', {
        height: height,
        width: width,
        fill: [color]
    });
}

function peityLine(element, height, width, color) {
    return $(element).peity('line', {
        height: height,
        width: width,
        fill: color,
        stroke: color
    });
}

function element_exists(id) {
        if ($(id).length === 0) {
            return false;
        }
        return true;
    }
    //http://www.sitepoint.com/javascript-generate-lighter-darker-color/

function colorLuminance(hex, lum) {
        // validate hex string
        hex = String(hex).replace(/[^0-9a-f]/gi, '');
        if (hex.length < 6) {
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        lum = lum || 0;
        // convert to decimal and change luminosity
        var rgb = "#",
            c, i;
        for (i = 0; i < 3; i++) {
            c = parseInt(hex.substr(i * 2, 2), 16);
            c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
            rgb += ("00" + c).substr(c.length);
        }
        return rgb;
    }
    //http://stackoverflow.com/questions/21646738/convert-hex-to-rgba

function hexToRgbA(hex, opacity) {
    var c;
    var o = opacity || 1;
    if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
        c = hex.substring(1).split('');
        if (c.length == 3) {
            c = [c[0], c[0], c[1], c[1], c[2], c[2]];
        }
        c = '0x' + c.join('');
        return 'rgba(' + [(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',') + ',' + o + ')';
    }
    return false;
}

function incrementingData() {
    var series = [];
    var labels = [];
    for (var x = 0; x < 50; x++) {
        if (x % 2 === 0) {
            continue;
        }
        labels.push('Label ' + x);
        series.push(Functions.random(x, x + 10));
    }
    return {
        series: series,
        labels: labels
    }
}

function decrementingData() {
    var series = [];
    var labels = [];
    for (var x = 50; x > 0; x--) {
        if (x % 2 === 0) {
            continue;
        }
        labels.push('Label ' + x);
        series.push(Functions.random(x + 10, x));
    }
    return {
        series: series,
        labels: labels
    }
}

function randomData() {
    var series = [];
    var labels = [];
    for (var x = 0; x < 30; x++) {
        labels.push('Label ' + x);
        series.push(Functions.random(20, 80));
    }
    return {
        series: series,
        labels: labels
    }
}

function reverseArray(input) {
    var ret = [];
    for (var i = input.length - 1; i >= 0; i--) {
        ret.push(input[i]);
    }
    return ret;
}

function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function lighten(col, amt) {
    amt = Math.abs(amt);
    amt = amt / 100;
    return colorLuminance(col, amt);
}

function darken(col, amt) {
    amt = Math.abs(amt);
    amt = (amt / 100) * -1;
    return colorLuminance(col, amt);
}