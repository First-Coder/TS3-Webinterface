/**
	Bootstrap progress bar
*/
!function($) {
	$.fn.progress = function(bar, val, cb) {
		if(typeof(bar) === 'object') {
			return bar = $.extend(defaults = {
				speed: 1e3,
				color: "progress-blue",
				interactive: false,
				onFinish: function() { return false; },
				onSetFinish: function() { return false; }
			}, bar || {}), this.each(function() {
				var el = $(this);
				var bar = el.find(".progress");
				var width = (bar.attr("data-width") === undefined) ? 0 : bar.attr("data-width");
				el.attr('interactive', defaults.interactive);
				bar.css('width', '0%');
				bar.find(".bar-label-percentage").text();
				
				if(defaults.interactive) {
					if(width >= 0 && width <= 20) {
						defaults.color = "progress-red";
					} else if(width > 20 && width <= 40) {
						defaults.color = "progress-orange";
					} else if(width > 40 && width <= 60) {
						defaults.color = "progress-blue";
					} else if(width > 60 && width <= 80) {
						defaults.color = "progress-blue-green";
					} else if(width > 80) {
						defaults.color = "progress-green";
					} else {
						defaults.color = "progress-blue";
					};
				};
				
				el.addClass("custom-progress-bar").addClass(defaults.theme);
				bar.addClass(defaults.color);
				bar.animate({
					width: width + "%"
				}, defaults.speed).find(".bar-label-percentage").prop("Counter", 0).animate({
					Counter: width
				}, {
					duration: defaults.speed,
					easing: "swing",
					step: function(a) {
						$(this).text(this.Counter.toFixed(0) + "%")
					}
				});
			});
		};
		if(typeof(bar) === 'string') {
			switch(bar) {
				case 'update':
					if(typeof(val) === 'undefined') {
						console.error('Cant set value of undefined');
						return;
					};
					
					var interactive = ($(this).attr('interactive') === undefined) ? false : ($(this).attr('interactive') === 'true');
					var bar = $(this).find(".progress");
					
					val = (val > 100) ? 100 : val;
					
					if(defaults.interactive) {
						if(val >= 0 && val <= 20) {
							defaults.color = "progress-red";
						} else if(val > 20 && val <= 40) {
							defaults.color = "progress-orange";
						} else if(val > 40 && val <= 60) {
							defaults.color = "progress-blue";
						} else if(val > 60 && val <= 80) {
							defaults.color = "progress-blue-green";
						} else if(val > 80) {
							defaults.color = "progress-green";
						} else {
							defaults.color = "progress-blue";
						};
						
						bar.removeClass('progress-red').removeClass('progress-orange').removeClass('progress-blue').removeClass('progress-blue-green').removeClass('progress-green');
						bar.addClass(defaults.color);
					};
					
					bar.animate({
						width: val + "%"
					}, defaults.speed, function() {
						defaults.onSetFinish();
						if(val === 100 || val === 0) {
							defaults.onFinish();
						};
						if(typeof(cb) === 'function') {
							cb();
						};
					}).find(".bar-label-percentage").animate({
						Counter: val
					}, {
						duration: defaults.speed,
						easing: "swing",
						step: function(a) {
							$(this).text(this.Counter.toFixed(0) + "%")
						}
					});
					break;
				default:
					console.error('Command not found!');
					break;
			};
		} else {
			console.error('Unknown method!');
		};
	};
}(jQuery);

/**
	Replace all global method
*/
String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

/**
	String date formatter
*/
(function () {
	// Defining locale
	Date.shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	Date.longMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	Date.shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
	Date.longDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
	// Defining patterns
	var replaceChars = {
		// Day
		d: function () { var d = this.getDate(); return (d < 10 ? '0' : '') + d; },
		D: function () { return Date.shortDays[this.getDay()]; },
		j: function () { return this.getDate(); },
		l: function () { return Date.longDays[this.getDay()]; },
		N: function () { var N = this.getDay(); return (N === 0 ? 7 : N); },
		S: function () { var S = this.getDate(); return (S % 10 === 1 && S !== 11 ? 'st' : (S % 10 === 2 && S !== 12 ? 'nd' : (S % 10 === 3 && S !== 13 ? 'rd' : 'th'))); },
		w: function () { return this.getDay(); },
		z: function () { var d = new Date(this.getFullYear(), 0, 1); return Math.ceil((this - d) / 86400000); },
		// Week
		W: function () {
			var target = new Date(this.valueOf());
			var dayNr = (this.getDay() + 6) % 7;
			target.setDate(target.getDate() - dayNr + 3);
			var firstThursday = target.valueOf();
			target.setMonth(0, 1);
			if (target.getDay() !== 4) {
				target.setMonth(0, 1 + ((4 - target.getDay()) + 7) % 7);
			};
			var retVal = 1 + Math.ceil((firstThursday - target) / 604800000);
			return (retVal < 10 ? '0' + retVal : retVal);
		},
		// Month
		F: function () { return Date.longMonths[this.getMonth()]; },
		m: function () { var m = this.getMonth(); return (m < 9 ? '0' : '') + (m + 1); },
		M: function () { return Date.shortMonths[this.getMonth()]; },
		n: function () { return this.getMonth() + 1; },
		t: function () {
			var year = this.getFullYear();
			var nextMonth = this.getMonth() + 1;
			if (nextMonth === 12) {
				year = year++;
				nextMonth = 0;
			};
			return new Date(year, nextMonth, 0).getDate();
		},
		// Year
		L: function () { var L = this.getFullYear(); return (L % 400 === 0 || (L % 100 !== 0 && L % 4 === 0)); },
		o: function () { var d = new Date(this.valueOf()); d.setDate(d.getDate() - ((this.getDay() + 6) % 7) + 3); return d.getFullYear(); },
		Y: function () { return this.getFullYear(); },
		y: function () { return ('' + this.getFullYear()).substr(2); },
		// Time
		a: function () { return this.getHours() < 12 ? 'am' : 'pm'; },
		A: function () { return this.getHours() < 12 ? 'AM' : 'PM'; },
		B: function () { return Math.floor((((this.getUTCHours() + 1) % 24) + this.getUTCMinutes() / 60 + this.getUTCSeconds() / 3600) * 1000 / 24); },
		g: function () { return this.getHours() % 12 || 12; },
		G: function () { return this.getHours(); },
		h: function () { var h = this.getHours(); return ((h % 12 || 12) < 10 ? '0' : '') + (h % 12 || 12); },
		H: function () { var H = this.getHours(); return (H < 10 ? '0' : '') + H; },
		i: function () { var i = this.getMinutes(); return (i < 10 ? '0' : '') + i; },
		s: function () { var s = this.getSeconds(); return (s < 10 ? '0' : '') + s; },
		v: function () { var v = this.getMilliseconds(); return (v < 10 ? '00' : (v < 100 ? '0' : '')) + v; },
		// Timezone
		e: function () { return Intl.DateTimeFormat().resolvedOptions().timeZone; },
		I: function () {
			var DST = null;
			for (var i = 0; i < 12; ++i) {
				var d = new Date(this.getFullYear(), i, 1);
				var offset = d.getTimezoneOffset();

				if (DST === null) {
					ST = offset;
				} else if (offset < DST) {
					DST = offset;
					break;
				} else if (offset > DST) {
					break;
				};
			};
			return (this.getTimezoneOffset() === DST) | 0;
		},
		O: function () { var O = this.getTimezoneOffset(); return (-O < 0 ? '-' : '+') + (Math.abs(O / 60) < 10 ? '0' : '') + Math.floor(Math.abs(O / 60)) + (Math.abs(O % 60) === 0 ? '00' : ((Math.abs(O % 60) < 10 ? '0' : '')) + (Math.abs(O % 60))); },
		P: function () { var P = this.getTimezoneOffset(); return (-P < 0 ? '-' : '+') + (Math.abs(P / 60) < 10 ? '0' : '') + Math.floor(Math.abs(P / 60)) + ':' + (Math.abs(P % 60) === 0 ? '00' : ((Math.abs(P % 60) < 10 ? '0' : '')) + (Math.abs(P % 60))); },
		T: function () { var tz = this.toLocaleTimeString(navigator.language, {timeZoneName: 'short'}).split(' '); return tz[tz.length - 1] },
		Z: function () { return -this.getTimezoneOffset() * 60; },
		// Full Date/Time
		c: function () { return this.format('Y-m-d\\TH:i:sP'); },
		r: function () { return this.toString(); },
		U: function () { return Math.floor(this.getTime() / 1000); }
	};

	// Simulates PHP's date function
	Date.prototype.format = function (format) {
		var date = this;
		return format.replace(/(\\?)(.)/g, function (_, esc, chr) {
			return (esc === '' && replaceChars[chr]) ? replaceChars[chr].call(date) : chr;
		});
	};
}).call(this);

/**
 * Rebuild of PHP cutsring function
 * @param {string} str
 * @param {int} length
 */
function cutString(str, length) {
	if(str.length <= length) {
	  return str;
	} else {
	  return str.substring(length, 0) + '...';
	};
};

/**
	Rebuild of PHP round function
	@param {int} value
	@param {int} precision
	@param {string} mode
	@return {float}
*/
function round(value, precision, mode) {
	var m, f, isHalf, sgn;
	precision |= 0;
	m = Math.pow(10, precision);
	value *= m;
	sgn = (value > 0) | -(value < 0);
	isHalf = value % 1 === 0.5 * sgn;
	f = Math.floor(value);

	if (isHalf) {
		switch (mode) {
			case 'PHP_ROUND_HALF_DOWN':
				// rounds .5 toward zero
				value = f + (sgn < 0);
				break;
			case 'PHP_ROUND_HALF_EVEN':
				// rouds .5 towards the next even integer
				value = f + (f % 2 * sgn);
				break;
			case 'PHP_ROUND_HALF_ODD':
				// rounds .5 towards the next odd integer
				value = f + !(f % 2);
				break;
			default:
				// rounds .5 away from zero
				value = f + (sgn > 0);
		};
	};

	return (isHalf ? value : Math.round(value)) / m;
};

/**
	Function to get file size into readable string
	@param {int} bits
	@return {string}
*/
function getFileSize(bits) {
	if(bits < 1024) {
		ret = round(bits, 2)+' Byte'; 
	} else if(bits >= 1024 && bits < Math.pow(1024, 2)) { 
		ret = round(bits/1024, 2)+' KByte'; 
	} else if(bits >= Math.pow(1024, 2) && bits < Math.pow(1024, 3)) { 
		ret = round(bits/Math.pow(1024, 2), 2)+' MByte'; 
	} else { 
		ret = round(bits/Math.pow(1024, 3), 2)+' GByte'; 
	};
	
	return ret; 
};

/**
	Function to get teamspeak ports from a instance
	@param {string} id
	@param {string} select
	@param {bool} justText
*/
function getPortsFromInstance(id, select, justText = false, cb = null) {
	if(!document.getElementById(id) || !document.getElementById(select)) {
		console.error('getPortsFromInstance: Cant find id or select element');
		return;
	};
	
	var instance = $('#'+id).val();
	var sel = $('#'+select);
	
	if(!justText) {
		sel.prop("disabled", true);
	};
	
	$.ajax({
		type: "POST",
		url: "./php/functions/functionsTeamspeakPost.php",
		data: {
			action: 'getTeamspeakPorts',
			instance: escapeText(instance)
		},
		success: function(data){
			var info = JSON.parse(data);
			if(!justText) {
				var el = document.getElementById(select);
				while ( el.childNodes.length >= 1 ) {
					el.removeChild(el.firstChild);
				};
			};
			
			if(info.success) {
				if(justText) {
					var ports = '';
					for(var port in info.data) {
						ports += info.data[port];
						if(port < (info.data.length - 1)) {
							ports += ', ';
						};
					};
					sel.text(ports);
				} else {
					for (i = 0; i < info['data'].length; i++) {
						port = document.createElement('option');
						port.value = info['data'][i];
						port.text = info['data'][i];
						el.appendChild(port);
					};
					sel.prop("disabled", false);
				};
				if(cb !== null) {
					cb();
				};
			} else {
				if(justText) {
					sel.text('');
				} else {
					var nope = document.createElement('option');
					nope.value = '';
					nope.text = unescape(lang.none);
					el.appendChild(nope);
				};
				
				new Notification({
					message : info.error,
					icon: 'fas fa-times',
					type : 'danger'
				}).show();
			};
		}
	});
};

/**
	Function to change a bool into a int
	@param {boolean} bool
	@return {int}
*/
function boolToInt(bool) {
	return (bool) ? 1 : 0;
};

/**
	Function to change a bool into a string
	@param {boolean} bool
	@return {string}
*/
function boolToString(bool) {
	return (bool) ? 'true' : 'false';
};

/**
	Function to change a string into a bool
	@param {string} string
	@return {bool}
*/
function stringToBool(string) {
	return (string === 'true');
};

/**
	Function to flash a text color
	@param {Object} el
	@param {string} color (optional)
*/
function flashText(el, color = "#ca6a6a") {
	if(!el.length) {
		console.error('Element cant be found!');
		return;
	};
	
	var oldColor = el.css('color');
	el.css('color', color);
	setTimeout(function() {
		el.css('transition', 'color 1s linear');
		el.css('color', oldColor);
		setTimeout(function() {
			el.css('transition', '');
			el.css('color', '');
		}, 1000);
	}, 1000);
};

/**
	Function parse a timestamp
	@param {int} seconds
	@return {Object}
*/
function convertSecondsToArrayTime(seconds) {
	var convTime = { };
	convTime.days = Math.floor(seconds / 86400);
	convTime.hours = Math.floor((seconds - (convTime.days * 86400)) / 3600);
	convTime.minutes = Math.floor((seconds - ((convTime.days * 86400) + (convTime.hours * 3600))) / 60);
	convTime.seconds = Math.floor((seconds - ((convTime.days * 86400) + (convTime.hours * 3600) + (convTime.minutes * 60))));
	return convTime;
};

/**
	Functions for validation checked
*/
function isDataValid(id) {
	if(document.getElementById(id)) {
		$('#'+id).focus().blur();
		return ($('#'+id).attr('data-valid') == "true") ? true : false;
	};
	return false;
};

function isError(element, message) {
	var el = $(element);
	var span = el.next();

	el.parent().removeClass('has-success').addClass('has-danger');
	el.removeClass('form-control-success').addClass('form-control-danger');
	span.attr('data-old-msg', span.text());
	span.text(message).removeClass('color-success').addClass('color-danger');

	el.attr('data-valid', false);
};

function isSuccess(element, message) {
	var el = $(element);
	var span = el.next();
	el.parent().removeClass('has-danger').addClass('has-success');
	el.removeClass('form-control-danger').addClass('form-control-success');
	
	if(message == '') {
		if(span.attr('data-old-msg') !== undefined) {
			span.text(span.attr('data-old-msg')).removeClass('color-danger').addClass('color-success');
			span.removeAttr('data-old-msg');
		} else {
			span.removeClass('color-danger').addClass('color-success');
		};
	} else {
		span.text(message).removeClass('color-danger').addClass('color-success');
	};
	
	el.attr('data-valid', true);
};

function resetMessages(element) {
    var el = $(element);
    el.parent().removeClass('has-danger').removeClass('has-success');
    el.removeClass('form-control-danger').removeClass('form-control-success');
    el.next().text('');
};

function validateOnChange(element, rules, successMessage, errorMessage) {
	$(document).off('blur', element);
	$(document).on('focus', element, function(e) {
		e.preventDefault();
		return false;
	});
	$(document).on('blur', element, function(e) {
		e.preventDefault();
		var result = approve.value($(element).val(), rules);
		if (result.approved) {
			isSuccess(element, successMessage);
		} else {
			isError(element, errorMessage);
		};
		return false;
	});
};

/**
	Function to convert a timestamp to string
	@param {int} time
	@param {boolean} withSeconds
	@return {string}
*/
function convertSecondsToStrTime(time, withSeconds = true) {
	convTime = convertSecondsToArrayTime(time);
	if(withSeconds) {
		return convTime.days+'d '+convTime.hours+'h '+convTime.minutes+'m '+convTime.seconds+'s';
	} else {
		return convTime.days+'d '+convTime.hours+'h '+convTime.minutes+'m';
	};
};

/*
	Deprecated
*/
'use strict';

function AreYouSure(label, clickEvent) {
	swal({
		title: label,
		text: lang.are_you_sure,
		type: 'warning',
		showCancelButton: true,
		confirmButtonColor: '#3085d6',
		cancelButtonColor: '#d33',
		confirmButtonText: lang.yes,
		cancelButtonText: lang.abort,
		confirmButtonClass: 'confirm-class',
		cancelButtonClass: 'cancel-class',
		closeOnConfirm: false,
		closeOnCancel: false
	}, function(isConfirm) {
		if (isConfirm) {
			var data 			= 	JSON.parse(decodeURIComponent(clickEvent));
			var exitData 		=	"done";
			switch(data[0])
			{
				case "deleteNews":
					exitData	=	deleteNews(data[1]);
					break;
				case "deleteInstanz":
					exitData	=	deleteInstanz(data[1]);
					break;
				case "deleteUser":
					exitData	=	deleteUser(data[1]);
					break;
				case "deleteTeamspeakserver":
					exitData	=	deleteTeamspeakserver(data[1], data[2], data[3]);
					break;
				case "deleteTicket":
					exitData	=	deleteTicket(data[1]);
					break;
				case "deleteBackup":
					exitData	=	deleteBackup(data[1], data[2], data[3]);
					break;
				case "activateBackup":
					exitData	=	activateBackup(data[1], data[2]);
					break;
				case "deleteQueryBot":
					exitData	=	deleteQueryBot(data[1]);
					break;
			};
			
			if(exitData == "done") {
				swal(lang.succeeded, lang.succeeded_info, 'success');
			} else {
				swal(lang.aborted, exitData, 'error');
			};
		} else {
			swal(lang.aborted, lang.aborted_info, 'error');
		}
	});
};

function SelectText(element) {
    var doc = document
        , text = doc.getElementById(element)
        , range, selection;
	
    if (doc.body.createTextRange) {
        range = document.body.createTextRange();
        range.moveToElementText(text);
        range.select();
    } else if (window.getSelection) {
        selection = window.getSelection();        
        range = document.createRange();
        range.selectNodeContents(text);
        selection.removeAllRanges();
        selection.addRange(range);
    };
};

function convertTime(seconds) {
		var returnArray			=	Array();
		returnArray['days']		=	Math.floor(seconds / 86400);
		returnArray['hours']	=	Math.floor((seconds - (returnArray['days'] * 86400)) / 3600);
		returnArray['minutes']	=	Math.floor((seconds - ((returnArray['days'] * 86400)+(returnArray['hours'] * 3600))) / 60);
		returnArray['seconds']	=	Math.floor(seconds - ((returnArray['days'] * 86400)+(returnArray['hours'] * 3600)+(returnArray['minutes'] * 60)));
		
		return returnArray;
};

function slideMe(boxid, iconid, iconleft = false) {
	var box 		=	$('#'+boxid),
		icon		=	$('#'+iconid);
	
	if((icon.hasClass("fa-arrow-right") && !iconleft) || icon.hasClass("fa-arrow-left") && iconleft) {
		icon.removeClass((iconleft) ? "fa-arrow-left" : "fa-arrow-right");
		icon.addClass("fa-arrow-down");
		
		box.slideDown("slow");
	} else {
		icon.removeClass("fa-arrow-down");
		icon.addClass((iconleft) ? "fa-arrow-left" : "fa-arrow-right");
		
		box.slideUp("slow");
	};
};



function escapeText(text) {
	if(typeof(text) == "undefined")
	{
		return "";
	};
	
	return text.replace(/\\/g, '\\\\').
		replace(/\u0008/g, '\\b').
		replace(/\t/g, '\\t').
		replace(/\n/g, '\\n').
		replace(/\f/g, '\\f').
		replace(/\r/g, '\\r').
		replace(/'/g, '\\\'').
		replace(/"/g, '\\"');
};

function escapeHtml(text) {
	return text.replace(/&/g, "&amp;")
		  .replace(/</g, "&lt;")
		  .replace(/>/g, "&gt;")
		  .replace(/"/g, "&quot;")
		  .replace(/'/g, "&#039;");
};

function setNotifyFailed(text) {
	toastr.error(text);
};

function setNotifySuccess(text) {
	toastr.success(text);
};



function setLoading(show = true) {
	$('.spinner').css("opacity", (show) ? "1" : "0");
	return true;
};



function animatedPeityBar(element, height, color) {
    var chart = $(element).peity('bar', {
        height: height,
        width: '100%',
        fill: [color]
    });
    setInterval(function() {
        var random = Math.floor(Math.random() * 10) + 2;
        var values = chart.text().split(',');
        values.shift();
        values.push(random);
        chart.text(values.join(',')).change();
    }, 1000);
};

function animatedPeityArea(element, height, color) {
    var chart = $(element).peity('line', {
        height: height,
        width: '100%',
        fill: color,
        stroke: color
    });
    setInterval(function() {
        var random = Math.floor(Math.random() * 10) + 2;
        var values = chart.text().split(',');
        values.shift();
        values.push(random);
        chart.text(values.join(',')).change();
    }, 1000);
};

function animatedPeityLine(element, height, color) {
    var chart = $(element).peity('line', {
        height: height,
        width: '100%',
        fill: 'white',
        stroke: color
    });
    setInterval(function() {
        var random = Math.floor(Math.random() * 10) + 2;
        var values = chart.text().split(',');
        values.shift();
        values.push(random);
        chart.text(values.join(',')).change();
    }, 1000);
};

function animatedLineChart(id, color) {
    var lineChart = echarts.init(document.getElementById(id));

    function randomData() {
        now = new Date(+now + oneDay);
        value = value + Math.random() * 21 - 10;
        return {
            name: now.toString(),
            value: [
                [now.getFullYear(), now.getMonth() + 1, now.getDate()].join('-'),
                Math.round(value)
            ]
        };
    }
    var data = [];
    var now = new Date(2010, 9, 3);
    var oneDay = 24 * 3600 * 1000;
    var value = Math.random() * 1000;
    for (var i = 0; i < 1000; i++) {
        data.push(randomData());
    };
    var option = {
        color: [color],
        title: {
            text: null
        },
        tooltip: {
            trigger: 'axis',
            formatter: function(params) {
                params = params[0];
                var date = new Date(params.name);
                return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear() + ' : ' + params.value[1];
            },
            axisPointer: {
                animation: false
            }
        },
        xAxis: {
            show: false,
            type: 'time',
            splitLine: {
                show: false
            }
        },
        yAxis: {
            show: false,
            type: 'value',
            boundaryGap: [0, '100%'],
            splitLine: {
                show: false
            }
        },
        series: [{
            name: 'Serie A',
            type: 'line',
            showSymbol: false,
            hoverAnimation: false,
            data: data
        }]
    };
    lineChart.setOption(option);
    setInterval(function() {
        for (var i = 0; i < 5; i++) {
            data.shift();
            data.push(randomData());
        }
        lineChart.setOption({
            series: [{
                data: data
            }]
        });
    }, 1000);
};

function peityDonut(element, radius, colors) {
    return $(element).peity('donut', {
        width: radius,
        radius: radius,
        fill: colors
    });
};

function peityPie(element, radius, colors) {
    return $(element).peity('pie', {
        height: radius,
        width: radius,
        radius: radius,
        fill: colors
    });
}

function peityBar(element, height, width, color) {
    return $(element).peity('bar', {
        height: height,
        width: width,
        fill: [color]
    });
}

function peityLine(element, height, width, color) {
    return $(element).peity('line', {
        height: height,
        width: width,
        fill: color,
        stroke: color
    });
}

function element_exists(id) {
        if ($(id).length === 0) {
            return false;
        }
        return true;
    }
    //http://www.sitepoint.com/javascript-generate-lighter-darker-color/

function colorLuminance(hex, lum) {
        // validate hex string
        hex = String(hex).replace(/[^0-9a-f]/gi, '');
        if (hex.length < 6) {
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        lum = lum || 0;
        // convert to decimal and change luminosity
        var rgb = "#",
            c, i;
        for (i = 0; i < 3; i++) {
            c = parseInt(hex.substr(i * 2, 2), 16);
            c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
            rgb += ("00" + c).substr(c.length);
        }
        return rgb;
    }
    //http://stackoverflow.com/questions/21646738/convert-hex-to-rgba

function hexToRgbA(hex, opacity) {
    var c;
    var o = opacity || 1;
    if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
        c = hex.substring(1).split('');
        if (c.length == 3) {
            c = [c[0], c[0], c[1], c[1], c[2], c[2]];
        }
        c = '0x' + c.join('');
        return 'rgba(' + [(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',') + ',' + o + ')';
    }
    return false;
}

function incrementingData() {
    var series = [];
    var labels = [];
    for (var x = 0; x < 50; x++) {
        if (x % 2 === 0) {
            continue;
        }
        labels.push('Label ' + x);
        series.push(Functions.random(x, x + 10));
    }
    return {
        series: series,
        labels: labels
    }
}

function decrementingData() {
    var series = [];
    var labels = [];
    for (var x = 50; x > 0; x--) {
        if (x % 2 === 0) {
            continue;
        }
        labels.push('Label ' + x);
        series.push(Functions.random(x + 10, x));
    }
    return {
        series: series,
        labels: labels
    }
}

function randomData() {
    var series = [];
    var labels = [];
    for (var x = 0; x < 30; x++) {
        labels.push('Label ' + x);
        series.push(Functions.random(20, 80));
    }
    return {
        series: series,
        labels: labels
    }
}

function reverseArray(input) {
    var ret = [];
    for (var i = input.length - 1; i >= 0; i--) {
        ret.push(input[i]);
    }
    return ret;
}

function random(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function lighten(col, amt) {
    amt = Math.abs(amt);
    amt = amt / 100;
    return colorLuminance(col, amt);
}

function darken(col, amt) {
    amt = Math.abs(amt);
    amt = (amt / 100) * -1;
    return colorLuminance(col, amt);
}