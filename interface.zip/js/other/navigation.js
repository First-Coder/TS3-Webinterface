$(function() {
	/*
		Reload on history back
	*/
	window.onpopstate = function(e) { location.reload(); };
	
	/*
		Fixed Button
	*/
	setOverlayButton();
	$(window).scroll(setOverlayButton);
	
	function setOverlayButton()
	{
		var element					=	$('#OverlayButton'),
			currentTop				=	element.offset().top,
			boxBottom				=	($('.page-on-top').offset().top - $(window).scrollTop())+$('.page-on-top').height() - OverlayButton.getBottom();
		
		if(boxBottom > 0)
		{
			element.css("transform", "translate3d(0,"+this.scrollY+"px,0)");
		};
	};
	
	/*
		Menu right side
	*/
	$(document).on('click', '.navbar-left-links > .open > .dropdown-menu > .dropdown-item > a', function(e)
	{
		e.preventDefault();
		$('.navbar-left-links .dropdown-submenu').removeClass('open');
		var next = $(this).next();
		next.toggleClass('open')
		return false;
	});
	
	$('.dropdown-parent').on('hide.bs.dropdown', function()
	{
		$('.dropdown-submenu').removeClass('open');
	});
	
	$(document).on('click', '.toggle-layout', function(e)
	{
		e.preventDefault();
		$('body').toggleClass('layout-collapsed');
		if ($('body').hasClass('layout-collapsed')) {
			$('.backdrop').toggleClass('fade in');
		};
		return false;
	});
	
	$('.backdrop').on('click', function()
	{
		if ($('body').hasClass('layout-collapsed'))
		{
			$(this).removeClass('fade');
			$(this).removeClass('in');
			$('body').toggleClass('layout-collapsed');
		};
	});
	
	/*
		Other
	*/
	checkIfUserIsBlocked();
});

/*
	Overlay button
*/
function OverlayButton() {
	var id 							= 	"OverlayButton",
		element 					= 	null,
		icon 						= 	null,
		savedClass 					= 	"",
		savedIcon 					= 	"",
		savedTtip					=	"",
		currentClass				=	"",
		currentIcon					=	"",
		handlers 					= 	[],
		OverlayButtonOffsetBottom	=	271;
	
	var setClass = function() {
		currentClass = savedClass;
		savedClass = "";
	}
	
	var setIcon = function() {
		currentIcon = savedIcon;
		savedIcon = "";
	}
	
	/*
		Events
	*/
	this.on = function(eventName, handler) {
		switch (eventName) {
			case "click":
				return handlers.push(handler);
			case "somethingElse":
				return console.log("Event not found!");
		};
	};
	
	this.dispatch = function() {
		var handler, i, len, ref;
		ref = handlers;
		for (i = 0, len = ref.length; i < len; i++) {
			handler = ref[i];
			setTimeout(handler, 0);
		};
	};
	
	this.reset = function() {
		handlers = [];
	};
	
	/*
		Public functions
	*/
	this.start = function(top = 285, bottom = 271) {
		element = $("#OverlayButton");
		icon = $("#OverlayButton>i");
		
		//remove all classes, that he could saved
		element.removeClass("btn-danger");
		element.removeClass("btn-success");
		element.removeClass("btn-info");
		element.removeClass("btn-secondary");
		element.removeClass("btn-warning");
		
		$(icon.attr('class').toString().split(' ')).each(function() { 
			if (this !== '' && this != 'fa')
			{
				icon.removeClass(this.trim());
			};
		});
		
		if(savedClass != "") {
			element.addClass(savedClass);
			setClass();
		};
		
		if(savedIcon != "") {
			icon.addClass(savedIcon);
			setIcon();
		};
		
		element.attr("data-original-title", savedTtip);
		element.attr("onclick", "OverlayButton.dispatch();");
		
		$('#OverlayButton').css("top", top+"px");
		OverlayButtonOffsetBottom	=	bottom;
	}
	
	this.refresh = function() {
		if(savedClass != "" && element != null) {
			element.removeClass(currentClass);
			element.addClass(savedClass);
			setClass();
		};
		
		if(savedIcon != "" && element != null) {
			element.removeClass(currentIcon);
			element.addClass(savedIcon);
			setIcon();
		};
		
		element.attr("data-original-title", savedTtip);
		element.attr("onclick", "OverlayButton.dispatch();");
	}
	
	this.getBottom = function() {
		return OverlayButtonOffsetBottom;
	}
	
	this.setButton = function(active) {
		if(element != null) {
			if(active) {
				element.fadeIn("slow");
			} else {
				element.fadeOut("slow");
			};
		};
	}
	
	this.setButtonClass = function(classname) {
		savedClass = classname;
	}
	
	this.setTooltip = function(text) {
		savedTtip = text;
	}
	
	this.setIconClass = function(iconName) {
		savedIcon = iconName;
	}
}

/*
	Permissionscheck
*/
function checkIfUserIsBlocked()
{
	if(typeof(logged) == "undefined") { return; };
	
	if(logged == "true")
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsSqlPost.php",
			data: {
				action:		'checkUserBlocked'
			},
			success: function(data){
				var informations		= 	JSON.parse(data);
				
				if(informations['blocked'] == 'true')
				{
					ausloggenInit();
				}
				else
				{
					if(checkClientInterval != -1)
					{
						setTimeout(checkIfPermissionModulIsBlocked, checkClientInterval);
					};
				};
			}
		});
	}
	else
	{
		if(checkClientInterval != -1)
		{
			checkIfPermissionModulIsBlocked();
		};
	};
};

function checkIfPermissionModulIsBlocked()
{
	var webinterface	=	new Array();
	
	$.ajax({
		type: "POST",
		url: "./php/functions/functionsSqlPost.php",
		data: {
			action:		'getModuls'
		},
		success: function(data){
			var informations		= 	JSON.parse(data);
			webinterface			=	informations;
			
			if(webinterface == null)
			{
				return;
			};
			
			if(logged == "true")
			{
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action:		'refreshRights'
					},
					success: function(data) {
						informations			= 	JSON.parse(data);
						var link				=	String(window.location).split("?");
						
						if($('.mainNaviServerview').css("display") == "none")
						{
							if(webinterface['free_ts3_server_application'] == 'true')
							{
								$('.mainApplyForServer').removeClass("no-display");
								$('.mainApplyForServer').fadeIn("slow");
							}
							else
							{
								$('.mainApplyForServer').fadeOut("slow");
								
								if(link[1].includes("web_main_apply_server"))
								{
									changeContent('web_main_main');
								};
							};
							
							if(webinterface['masterserver'] == 'true')
							{
								$('.mainMasterserver').removeClass("no-display");
								$('.mainMasterserver').fadeIn("slow");
							}
							else
							{
								$('.mainMasterserver').fadeOut("slow");
								
								if(link[1].includes("web_main_masterserver"))
								{
									changeContent('web_main_main');
								};
							};
						};
						
						checkPermItem(typeof(informations['right_web']) != 'undefined' && webinterface['webinterface'] == 'true', "teamspeakServer", "web_teamspeak_server", link);
						checkPermItem(typeof(informations['right_web_server_create']) != 'undefined' && webinterface['webinterface'] == 'true', "teamspeakServerCreate", "web_teamspeak_server_create", link);
						checkPermItem(typeof(informations['right_web_server_create']) != 'undefined' && webinterface['webinterface'] == 'true', "teamspeakServerRequests", "web_teamspeak_server_requests", link);
						checkPermItem(typeof(informations['right_hp_main']) != 'undefined', "adminSettings", "web_admin_settings", link);
						checkPermItem(typeof(informations['right_hp_ts3']) != 'undefined', "adminInstanz", "web_admin_instanz", link);
						checkPermItem(typeof(informations['right_hp_user_create']) != 'undefined' || typeof(informations['right_hp_user_delete']) != 'undefined' || typeof(informations['right_hp_user_edit']) != 'undefined', "adminUser", "web_admin_user", link);
						checkPermItem(typeof(informations['right_hp_mails']) != 'undefined', "adminMail", "web_admin_mail", link);
						checkPermItem(typeof(informations['right_hp_logs']) != 'undefined', "adminLogs", "web_admin_logs", link);
						
						if(webinterface['webinterface'] != 'true' || (typeof(informations['right_web_server_create']) == 'undefined' && typeof(informations['right_web']) == 'undefined'))
						{
							$(".webinterfacearea").addClass("no-display");
							
							if(link[1].includes("web_teamspeak"))
							{
								changeContent('web_profil_dashboard');
							};
						}
						else
						{
							$(".webinterfacearea").removeClass("no-display");
						};
						
						if(typeof(informations['right_hp_user_create']) == 'undefined' && typeof(informations['right_hp_user_delete']) == 'undefined' && typeof(informations['right_hp_user_edit']) == 'undefined'
							&& typeof(informations['right_hp_ts3']) == 'undefined' && typeof(informations['right_hp_main']) == 'undefined' && typeof(informations['right_hp_mails']) == 'undefined')
						{
							$(".settingsarea").addClass("no-display");
						}
						else
						{
							$(".settingsarea").removeClass("no-display");
						};
						
						if(typeof(link[2]) != 'undefined' && typeof(link[3]) != 'undefined' && typeof(port) != "undefined" && typeof(informations['right_web_global_server']) == 'undefined')
						{
							if(typeof(informations['right_web_server_view']) == 'undefined')
							{
								changeContent('web_teamspeak_server');
								changeNavigation();
							}
							else
							{
								if(!informations['right_web_server_view'][instanz].includes(port))
								{
									changeContent('web_teamspeak_server');
									changeNavigation();
								};
								
								var permission									=	Array();
								permission["right_web_server_protokoll"]		=	false;
								permission["right_web_server_mass_actions"]		=	false;
								permission["right_web_server_icons"]			=	false;
								permission["right_web_server_clients"]			=	false;
								permission["right_web_server_bans"]				=	false;
								permission["right_web_server_token"]			=	false;
								permission["right_web_file_transfer"]			=	false;
								permission["right_web_server_backups"]			=	false;
								
								for(info in informations)
								{
									if(typeof(informations[info]) != "undefined")
									{
										if(typeof(informations[info][instanz]) != "undefined")
										{
											if(informations[info][instanz].includes(port))
											{
												permission[info]				=	true;
											};
										};
									};
								};
								
								changeClass(permission['right_web_server_protokoll'], "teamspeakProtokol", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_serverprotokol');closeSideMenu();", "web_teamspeak_serverprotokol", link[1]);
								changeClass(permission['right_web_server_mass_actions'], "teamspeakMassActions", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_servermassactions');closeSideMenu();", "web_teamspeak_servermassactions", link[1]);
								changeClass(permission['right_web_server_icons'], "teamspeakIcons", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_servericons');closeSideMenu();", "web_teamspeak_servericons", link[1]);
								changeClass(permission['right_web_server_clients'], "teamspeakClients", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_serverclients');closeSideMenu();", "web_teamspeak_serverclients", link[1]);
								changeClass(permission['right_web_server_bans'], "teamspeakBans", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_serverbans');closeSideMenu();", "web_teamspeak_serverbans", link[1]);
								changeClass(permission['right_web_server_token'], "teamspeakToken", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_servertoken');closeSideMenu();", "web_teamspeak_servertoken", link[1]);
								changeClass(permission['right_web_file_transfer'], "teamspeakFilelist", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_serverfilelist');closeSideMenu();", "web_teamspeak_serverfilelist", link[1]);
								changeClass(permission['right_web_server_backups'], "teamspeakBackup", "changeTeamspeakContent('"+link[3]+"', '"+link[2]+"', 'web_teamspeak_serverbackups');closeSideMenu();", "web_teamspeak_serverbackups", link[1]);
							};
						};
					}
				});
			}
			else
			{
				var link				=	String(window.location).split("?");
				
				if(webinterface['free_ts3_server_application'] == 'true')
				{
					$('.mainApplyForServer').fadeIn("slow");
				}
				else
				{
					$('.mainApplyForServer').fadeOut("slow");
					
					if(link[1].includes("web_main_apply_server"))
					{
						changeContent('web_main_main');
					};
				};
				
				if(webinterface['masterserver'] == 'true')
				{
					$('.mainMasterserver').fadeIn("slow");
				}
				else
				{
					$('.mainMasterserver').fadeOut("slow");
					
					if(link[1].includes("web_main_masterserver"))
					{
						changeContent('web_main_main');
					};
				};
			};
			
			setTimeout(checkIfPermissionModulIsBlocked, checkClientInterval);
		}
	});
};

function checkPermItem(hasPermission, classPermission, filePermission, link)
{
	if(hasPermission)
	{
		if($('.'+classPermission).hasClass("disabled"))
		{
			$('.'+classPermission).removeClass("disabled");
			$('.'+classPermission).attr("onclick", "changeContent('"+filePermission+"');closeSideMenu();");
		};
	}
	else
	{
		if(!$('.'+classPermission).hasClass("disabled"))
		{
			$('.'+classPermission).addClass("disabled");
			$('.'+classPermission).attr("onclick","");
		};
		
		if(link[1].includes(filePermission))
		{
			changeContent('web_profil_dashboard');
		};
	};
};

function changeClass(add, changeClass, onClick, headerSite, link)
{
	if(add)
	{
		if($('.'+changeClass).hasClass("disabled"))
		{
			$('.'+changeClass).removeClass("disabled");
			$('.'+changeClass).attr('onclick',onClick);
		};
	}
	else
	{
		if(!$('.'+changeClass).hasClass("disabled"))
		{
			$('.'+changeClass).addClass("disabled");
			$('.'+changeClass).attr('onclick',"");
		};
		
		if(link.includes(headerSite))
		{
			teamspeakViewInit();
		};
	};
};

/*
	Close Collapse menu
*/
function closeSideMenu()
{
	$('body').removeClass('layout-collapsed');
};

/*
	Function Logout
*/
function ausloggenInit()
{
	replaceHistory("index.php?web_main_main");
	
	if(setLoading(true))
	{
		$("#myContent").load("./php/login/logout.php", function()
		{
			logged = false;
			sessionStorage.clear();
			$(".showOnLogged").css("display", "none");
			$(".showOnUnlogged").css("display", "inline");
			changeContent('web_main_main');
		});
	};
};

/*
	Replace history
*/
function replaceHistory(name, stateObj = null)
{
	history.pushState(stateObj, document.title, name);
};

(function(history){
    var pushState = history.pushState;
    history.pushState = function(state) {
        if (typeof history.onpushstate == "function")
		{
            history.onpushstate({state: state});
        };
		
        return pushState.apply(history, arguments);
    };
})(window.history);

/*
	Change Navigation
*/
function changeNavigation(toNormal = true, id = 0, instance = 0, page = "web_teamspeak_serverview")
{
	if(toNormal)
	{
		$('.mainNaviServerview').css("display", "none");
		$('.mainNaviLogged').not('.no-display').css("display", "inline");
		$('#naviContent').load("./php/login/web_logged.php");
	}
	else
	{
		replaceHistory("index.php?"+page+"?"+instance+"?"+id);
		
		$('.mainNaviServerview').css("display", "inline");
		$('.mainNaviLogged').css("display", "none");
		
		$('#naviContent').load("./php/login/web_logged_serverview.php");
	};
};

/*
	Change Maincontent(Teamspeakarea)
*/
function changeTeamspeakContent(id = 0, instance = 0, page = "web_teamspeak_serverview")
{
	replaceHistory("index.php?"+page+"?"+instance+"?"+id);
	
	if(setLoading(true))
	{
		document.getElementById('firstBread').innerText				=	lang.interface;
		$('#firstBread').attr("onClick", "changeNavigation();changeContent('web_teamspeak_server');");
		
		switch(page)
		{
			case "web_teamspeak_serverview":
				document.getElementById('secondBread').innerHTML	=	lang.server_overview;
				break;
			case "web_teamspeak_serverbanner":
				document.getElementById('secondBread').innerText	=	lang.serverbanner;
				break;
			case "web_teamspeak_serverprotokol":
				document.getElementById('secondBread').innerText	=	lang.protokoll;
				break;
			case "web_teamspeak_servermassactions":
				document.getElementById('secondBread').innerText	=	lang.mass_actions;
				break;
			case "web_teamspeak_servericons":
				document.getElementById('secondBread').innerText	=	lang.icons;
				break;
			case "web_teamspeak_serverclients":
				document.getElementById('secondBread').innerText	=	lang.client;
				break;
			case "web_teamspeak_serverbans":
				document.getElementById('secondBread').innerText	=	lang.bans;
				break;
			case "web_teamspeak_servertoken":
				document.getElementById('secondBread').innerText	=	lang.token;
				break;
			case "web_teamspeak_serverfilelist":
				document.getElementById('secondBread').innerText	=	lang.filelist;
				break;
			case "web_teamspeak_serverbackups":
				document.getElementById('secondBread').innerText	=	lang.backups;
				break;
		};
		
		$('#myContent').load("./php/teamspeak/"+page+".php", function()
		{
			$("html, body").animate({
				scrollTop: 0
			},
			600,
			function() {
				setLoading(false);
			});
		});
	};
};

/*
	Change Maincontent
*/
function changeContent(which, replace = true)
{
	if(replace)
	{
		replaceHistory("index.php?"+which);
	};
	
	OverlayButton.reset();
	OverlayButton.setButton(false);
	
	if(setLoading(true))
	{
		var subfolder 		= 	"";
		
		if(which.includes("login"))
		{
			subfolder		=	"login";
			$('.breadline').css("display", "none");
		};
		
		if(which.includes("main"))
		{
			subfolder		=	"main";
			$('.breadline').css("display", "none");
		};
		
		if(!which.includes("main") && !which.includes("login"))
		{
			$('.breadline').css("display", "inline");
		};
		
		if(which.includes("profil"))
		{
			subfolder		=	"profile";
			
			document.getElementById('firstBread').innerText				=	lang.profile;
			
			switch(which)
			{
				case "web_profil_dashboard":
					document.getElementById('secondBread').innerText	=	"Dashboard";
					break;
				case "web_profil_edit":
					document.getElementById('secondBread').innerText	=	lang.edit_profile;
					break;
			};
			
			$('#firstBread').attr("onClick", "changeContent('web_profil_dashboard');");
		};
		if(which.includes("admin"))
		{
			subfolder		=	"admin";
			
			document.getElementById('firstBread').innerText				=	lang.global_settings;
			
			switch(which)
			{
				case "web_admin_settings":
					document.getElementById('secondBread').innerText	=	lang.settings;
					break;
				case "web_admin_instanz":
					document.getElementById('secondBread').innerText	=	lang.instances;
					break;
				case "web_admin_user":
					document.getElementById('secondBread').innerText	=	lang.client;
					break;
				case "web_admin_mail":
					document.getElementById('secondBread').innerText	=	lang.mail_settings;
					break;
				case "web_admin_logs":
					document.getElementById('secondBread').innerText	=	lang.logs;
					break;
			};
			
			$('#firstBread').attr("onClick", "changeContent('web_admin_settings');");
		};
		if(which.includes("teamspeak"))
		{
			subfolder		=	"teamspeak";
			
			document.getElementById('firstBread').innerText				=	lang.interface;
			
			switch(which)
			{
				case "web_teamspeak_server":
					document.getElementById('secondBread').innerText	=	lang.server;
					break;
				case "web_teamspeak_server_create":
					document.getElementById('secondBread').innerText	=	lang.create_server;
					break;
				case "web_teamspeak_server_requests":
					document.getElementById('secondBread').innerHTML	=	lang.server_requests;
					break;
				case "web_teamspeak_serverview":
					document.getElementById('secondBread').innerHTML	=	lang.server_overview;
					break;
				case "web_teamspeak_serverbanner":
					document.getElementById('secondBread').innerText	=	lang.serverbanner;
					break;
				case "web_teamspeak_serverprotokol":
					document.getElementById('secondBread').innerText	=	lang.protokoll;
					break;
				case "web_teamspeak_servermassactions":
					document.getElementById('secondBread').innerText	=	lang.mass_actions;
					break;
				case "web_teamspeak_servericons":
					document.getElementById('secondBread').innerText	=	lang.icons;
					break;
				case "web_teamspeak_serverclients":
					document.getElementById('secondBread').innerText	=	lang.client;
					break;
				case "web_teamspeak_serverbans":
					document.getElementById('secondBread').innerText	=	lang.bans;
					break;
				case "web_teamspeak_servertoken":
					document.getElementById('secondBread').innerText	=	lang.token;
					break;
				case "web_teamspeak_serverfilelist":
					document.getElementById('secondBread').innerText	=	lang.filelist;
					break;
				case "web_teamspeak_serverbackups":
					document.getElementById('secondBread').innerText	=	lang.backups;
					break;
			};
			
			$('#firstBread').attr("onClick", "changeNavigation();changeContent('web_teamspeak_server');");
		};
		if(which.includes("bot"))
		{
			subfolder		=	"bot";
			
			document.getElementById('firstBread').innerText				=	lang.botinterface;
			
			switch(which)
			{
				case "web_bot_query":
					document.getElementById('secondBread').innerText	=	"blub";
					break;
			};
			
			$('#firstBread').attr("onClick", "changeNavigation();changeContent('web_teamspeak_server');");
		};
		if(which.includes("ticket"))
		{
			subfolder		=	"ticket";
			document.getElementById('firstBread').innerText				=	lang.ticket_system;
			document.getElementById('secondBread').innerText			=	lang.tickets;
			$('#firstBread').attr("onClick", "changeContent('web_ticket');");
		};
		
		$('#myContent').load("./php/"+subfolder+"/"+which+".php", function()
		{
			if(which == "web_main_apply_server")
			{
				if(typeof(wantServer['4']) != 'undefined')
				{
					$('#wantServerStep1').remove();
					$('#wantServerStep2').remove();
					$('#wantServerStep3').show();
				}
				else if(typeof(wantServer['0']) != 'undefined')
				{
					$('#wantServerStep1').remove();
					$('#wantServerStep2').show();
				};
			};
			
			$("html, body").animate({
				scrollTop: 0
			},
			600,
			function() {
				setLoading(false);
			});
		});
	};
};