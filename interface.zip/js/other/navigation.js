$(function() {
	/**
		Reload on history back
	*/
	window.onpopstate = function(e) { location.reload(); };
	
	/**
		Login after enter push
	*/
	$('#loginUser, #loginPw').keypress(function(e) {
		if (e.which == 13) {
			loginUser();
			e.preventDefault();
		};
	});
	
	/**
		Validate Login
	*/
	validateOnChange('#loginUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#loginPw', {
		required: true
	}, '', lang.field_cant_be_empty);
	
	/** 
		On Scroll of the screen
	*/
	$(window).scroll(function() {
		var leftSide = $('.widget-menu > .left-side');
		var status = leftSide.hasClass("open");
		var scroll = $(window).scrollTop();
		
		if(status) {
			leftSide.css("top", (scroll < 160) ? 160 - scroll : 0);
		} else {
			leftSide.css("top", "initial");
		};
	});
	
	/**
		On Window resize
	*/
	$(window).on('resize', function() {
		// Remove widget-menu attribute
		if($(this).width() < 768) {
			var leftSide = $('.widget-menu > .left-side');
			var rightSide = $('.widget-menu > .right-side');
			
			leftSide.css("top", "initial");
			leftSide.removeClass("open");
			rightSide.css("margin", "initial");
		};
	});
	
	/**
		Switch which disable other elements
	*/
	$(document).on('click', '.switch-disable', function(e) {
		var el = $(this);
		var status = el.prop('checked');
		var subClass = el.attr('data-disable');
		var subElements = $('.'+subClass);
		
		if(subClass == undefined) {
			console.error('Missing attribute data-disable');
		} else {
			subElements.each(function() {
				var opposite = ($(this).attr('data-opposite') === 'true') ? true : false;
				var elStatus = (opposite) ? !status : status;
				
				if($(this).is('div')) {
					(elStatus) ? $(this).removeClass('d-none') : $(this).addClass('d-none');
				} else {
					$(this).prop('disabled', !elStatus);
					(elStatus) ? $(this).removeClass('disabled') : $(this).addClass('disabled');
				};
			});
		};
	});	
		
	/**
		Profile sub navigation handler
	*/
	$(document).on('click', '.profile > .profile-sub-header a', function(e) {
		e.preventDefault();
		
		var el = $(this);
		var header = $('.header-content');
		var icon = $('h3 > i', header);
		var text = $('h3 > span', header);
		var box = $(el.attr('href'));
		
		if(el.hasClass('active')) {
			return;
		};
		
		// Set new active class
		$('.profile > .profile-sub-header a').removeClass('active');
		el.addClass('active');
		
		// Set icon classes
		icon.removeClass();
		icon.attr('class', $('i', el).attr('class')+' mr-2');
		
		// Set text
		text.text($('p', el).text());
		
		// Show new content
		$('.profile-tab > div').removeClass('active');
		box.addClass('active');
	});
	
	/**
		Menu on the left side (widget-menu) when responsive mode is enabled
	*/
	$(document).on('click', '.widget-menu > .right-side > .header-content > a:first-child', function(e) {
		e.preventDefault();
		
		var scroll = $(window).scrollTop();
		var leftSide = $('.widget-menu > .left-side');
		var rightSide = $('.widget-menu > .right-side');
		var status = leftSide.hasClass("open");
		
		if(status) {
			leftSide.removeClass("open");
			rightSide.css("margin", "0");
		} else {
			leftSide.addClass("open");
			rightSide.css("margin", "0 -45% 0 45%");
			leftSide.css("top", (scroll < 160) ? 160 - scroll : 0);
		};
	});
	
	/**
		Menu on the left side (navigation)
	*/
	$(document).on('click', '.widget-menu > .left-side > ul > li.item > a', function(e) {
		e.preventDefault();
		
		var li = $(this).closest('li');
		var liId = $(this).attr('href');
		var liActive = $('.widget-menu > .left-side > ul > li.active');
		var liActiveId = $('.widget-menu > .left-side > ul > li.active > a').attr('href');
		var iconDisplay = (li.attr('data-display') === 'false') ? 'false' : 'true';
		var iconDisabled = (li.attr('data-disabled') === 'true');
		var iconIcon = (li.attr('data-icon') === undefined) ? 'far fa-save' : li.attr('data-icon');
		var iconTooltip = (li.attr('data-ttip') === undefined) ? lang.save : li.attr('data-ttip');
		
		if(!li.hasClass('active')) {
			$('.widget-menu > .right-side > .header-content > h3').text($.trim($(this).text()));
			$('.widget-menu > .right-side > .header-content > a#save-settings').attr('data-display', iconDisplay);
			$('.widget-menu > .right-side > .header-content > a#save-settings').attr('data-original-title', iconTooltip);
			$('.widget-menu > .right-side > .header-content > a#save-settings').tooltip();
			$('.widget-menu > .right-side > .header-content > a#save-settings').removeClass();
			$('.widget-menu > .right-side > .header-content > a#save-settings > i').removeClass();
			$('.widget-menu > .right-side > .header-content > a#save-settings > i').addClass(iconIcon);
			
			liActive.removeClass('active');
			$(liActiveId).removeClass('active');
			li.addClass('active');
			$(liId).addClass('active');
			
			if(iconDisabled) {
				$('.widget-menu > .right-side > .header-content > a#save-settings').addClass('disabled');
			};
		};
		
		var linkinfo = window.location.search;
		var split = linkinfo.split('?');
		var link = "index.php";
		for(var part in split) {
			part = parseInt(part);
			if(((split.length - 1) == 2 && part == 2) || ((split.length - 1) == 4 && part == 4)) {
				continue;
			};
			link += split[part]+'?';
		};
		
		replaceHistory(link+liId.replace("#", ""));
	});
	
	/*
		Menu right side
	*/
	$(document).on('click', '.navbar-left-links > .open > .dropdown-menu > .dropdown-item > a', function(e) {
		e.preventDefault();
		$('.navbar-left-links .dropdown-submenu').removeClass('open');
		var next = $(this).next();
		next.toggleClass('open')
		return false;
	});
	
	$('.dropdown-parent').on('hide.bs.dropdown', function() {
		$('.dropdown-submenu').removeClass('open');
	});
	
	$(document).on('click', '.toggle-layout', function(e) {
		e.preventDefault();
		$('body').toggleClass('layout-collapsed');
		if ($('body').hasClass('layout-collapsed')) {
			$('.backdrop').toggleClass('fade in');
		};
		return false;
	});
	
	// Comment
	$('.backdrop').on('click', function() {
		if ($('body').hasClass('layout-collapsed')) {
			$(this).removeClass('fade');
			$(this).removeClass('in');
			$('body').toggleClass('layout-collapsed');
		};
	});
});

/**
	Funtion to login into the interface
*/
function loginUser(user = null, pw = null) {
	var username = (user === null) ? $("#loginUser").val() : user;
	var password = (pw === null) ? $("#loginPw").val() : pw;
	
	if($("#loginBtn").hasClass("btn-success") || (user !== null && pw !== null)) {
		if((isDataValid('loginUser') && isDataValid('loginPw')) || (user !== null && pw !== null)) {
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action:		'loginUser',
					username:	username,
					password:	password
				},
				success: function(data) {
					var json = JSON.parse(data);
					
					if(json.success) {
						new Notification({
							message : lang.login_successfull.replace('%user%', escapeText(username)),
							icon: 'fas fa-key',
							type : 'success'
						}).show();
						
						// Set new overview
						$('.dropdown-menu.dropdown-no-event').prev().dropdown('toggle');
						$('.profile-image').attr('src', json.data.picture);
						$('.details > .name').text(json.data.firstname[0]+'. '+json.data.lastname);
						$('.profile-mail').text(username);
						$('.showOnUnlogged').css('display', 'none');
						$('.showOnLogged').each(function() {
							var el = $(this);
							var display = el.attr('data-display');
							el.css('display', (display === undefined) ? 'inline' : display);
						});
						
						// load dashboard
						changeContent('web_profil_dashboard');
					} else {
						new Notification({
							message : json.error,
							icon: 'fas fa-key',
							type : 'danger'
						}).show();
					};
				}
			});
		} else {
			new Notification({
				message : lang.write_user_and_pw,
				icon: 'fas fa-key',
				type : 'danger'
			}).show();
		};
	} else {
		if(isDataValid('loginUser')) {
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action:		'forgetAccess',
					username:	username
				},
				success: function(data) {
					var json = JSON.parse(data);
					
					if(json.success) {
						new Notification({
							message : lang.password_reset_success,
							icon: 'fas fa-question',
							type : 'success'
						}).show();
					} else {
						new Notification({
							message : json.error,
							icon: 'fas fa-question',
							type : 'danger'
						}).show();
					};
				}
			});
		} else {
			new Notification({
				message : lang.write_user_and_pw,
				icon: 'fas fa-question',
				type : 'danger'
			}).show();
		};
	};
};

/**
	Extend obj function
*/
function extend(a, b) {
	for(var key in b) {
		if(b.hasOwnProperty(key)) {
			a[key] = b[key];
		};
	};
	
	return a;
};

/**
	Object for are you sure requests
*/
;(function(window) {
	'use strict';
	
	/**
		Constructor
	*/
	function AreUSure(options) {
		this.options = extend({ }, this.options);
		extend(this.options, options);
		this._init();
	};
	
	/**
		Options from outside
	*/
	AreUSure.prototype.options = {
		label: 'Unknown action',
		onConfirm: function() { return false; },
		onAbort: function() { return false; }
	}
	
	/**
		Constructor initial
	*/
	AreUSure.prototype._init = function() {
		var $this = this;
		swal({
			title: this.options.label,
			text: lang.are_you_sure,
			icon: 'warning',
			buttons: {
				cancel: {
					text: lang.abort,
					value: false,
					visible: true,
					className: "",
					closeModal: true,
				},
				confirm: {
					text: lang.yes,
					value: true,
					visible: true,
					className: "",
					closeModal: true
				}
			}
		}).then((value) => {
			if(value) {
				$this.options.onConfirm();
			} else {
				swal(lang.aborted, lang.aborted_info, 'error');
				$this.options.onAbort();
			};
		});
	};
	
	/**
		global namespaces
	*/
	window.AreUSure = AreUSure;
})(window);

/**
	Object for notifications without modal window
*/
;(function(window) {
	'use strict';
	
	var docElem = window.document.documentElement;
	var notifyQueue = [];

	/**
		Contructor
	*/
	function Notification(options) {
		this.options = extend({ }, this.options);
		extend(this.options, options);
		this._init();
	};
	
	/**
		Options from outside
	*/
	Notification.prototype.options = {
		message: 'My Message',
		icon: 'far fa-edit',
		type: 'error',
		time: 6000,
		progressbar: true,
		wrapper: document.body,
		offset: 0,
		onClose: function() { return false; },
		onOpen: function() { return false; }
	};
	
	/**
		Constructor initial
	*/
	Notification.prototype._init = function() {
		var wrapper = (this.options.wrapper === null) ? document.body : this.options.wrapper;
		this.message = (this.options.type === '') ? lang.message : (this.options.type === 'danger') ? lang.failed : lang.success;
		this.boxes = wrapper.querySelectorAll('.notify-box');
		this.el = document.createElement('div');
		this.el.className = 'notify-box notify-'+this.options.type;
		
		if(this.boxes.length > 1) {
			notifyQueue.push(this.options);
			return;
		};
		
		if(this.boxes.length === 1) {
			this.boxes[0].style.bottom = "80px";
		};
		
		var string = '<div><div class="notify-icon"><i class="'+this.options.icon+'"></i></div><div class="notify-content"><div><span>'+this.message+'</span><span>'+this.options.message+'</span></div></div></div>';
		string += '<span class="close-btn"></span></div>';
		this.el.innerHTML = string;
		wrapper.insertBefore(this.el, wrapper.firstChild);
		
		var $this = this;
		this.dismisstime = setTimeout(function() {
			if($this.active) {
				$this.dismiss();
			};
		}, this.options.time);
		
		this._initEvents();
	};
	
	/**
		Constructor initial events
	*/
	Notification.prototype._initEvents = function() {
		var $this = this;
		this.el.querySelector('span.close-btn').addEventListener('click', function() { $this.dismiss(); });
	};
	
	/**
		show the notification
	*/
	Notification.prototype.show = function() {
		this.active = true;
		this.el.classList.remove('notify-hide');
		this.el.classList.add('notify-show');
		this.options.onOpen();
	};
	
	/**
		hide the notification
	*/
	Notification.prototype.dismiss = function() {
		var $this = this;
		this.active = false;
		clearTimeout(this.dismisstime);
		this.el.classList.remove('notify-show');
		setTimeout(function() {
			$this.el.classList.add('notify-hide');
			$this.options.onClose();
		}, 25);
		setTimeout(function() {
			$this.el.parentNode.removeChild($this.el);

			var wrapper = ($this.options.wrapper === null) ? document.body : $this.options.wrapper;
			var boxes = wrapper.querySelectorAll('.notify-box');
			if(boxes.length === 1) {
				boxes[0].style.bottom = "0px";
			};

			setTimeout(function() {
				if(notifyQueue.length) {
					var newEl = (notifyQueue.length === 1) ? notifyQueue.pop() : notifyQueue.shift();
					new Notification(newEl).show();
				};
			}, 1500);
		}, 1500);
	}
	
	/**
		global namespaces
	*/
	window.Notification = Notification;
})(window);

/**
	Function to scroll to the top of the site
*/
function slideToTop() {
	$('html').animate({scrollTop:0}, 'slow');	//IE, FF
	$('body').animate({scrollTop:0}, 'slow');	//chrome, don't know if Safari works
};

/**
	Inteface logout
*/
function ausloggenInit(){
	if(setLoading(true)) {
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsPost.php",
			data: {
				action: 'logout'
			},
			success: function(data){
				var info = JSON.parse(data);
				
				if(info.success) {
					new Notification({
						message : lang.client_successfull_logout,
						icon: 'fas fa-sign-out-alt',
						type : 'success'
					}).show();
					$(".showOnLogged").css("display", "none");
					$(".showOnUnlogged").css("display", "inline");
					$("span.name").html(lang.login);
					changeContent('web_main_main');
				} else {
					new Notification({
						message : info.error,
						icon: 'fas fa-sign-out-alt',
						type : 'danger'
					}).show();
					setLoading(false);
				};
			}
		});
	};
};

/**
	Replace browser history with the last side
	@param {string} name
	@param {Object} stateObj
*/
function replaceHistory(name, stateObj = null) {
	history.pushState(stateObj, document.title, name);
};

(function(history){
    var pushState = history.pushState;
    history.pushState = function(state) {
        if (typeof history.onpushstate == "function") {
            history.onpushstate({state: state});
        };
        return pushState.apply(history, arguments);
    };
})(window.history);

/*
	Change Navigation
*/
function changeNavigation(toNormal = true, id = 0, instance = 0, page = "web_teamspeak_serverview")
{
	if(toNormal)
	{
		$('.mainNaviServerview').css("display", "none");
		$('.mainNaviLogged').not('.no-display').css("display", "inline");
		$('#naviContent').load("./php/login/web_logged.php");
	}
	else
	{
		replaceHistory("index.php?"+page+"?"+instance+"?"+id);
		
		$('.mainNaviServerview').css("display", "inline");
		$('.mainNaviLogged').css("display", "none");
		
		$('#naviContent').load("./php/login/web_logged_serverview.php");
	};
};

/*
	Change Maincontent(Teamspeakarea)
*/
function changeTeamspeakContent(id = 0, instance = 0, page = "web_teamspeak_serverview")
{
	replaceHistory("index.php?"+page+"?"+instance+"?"+id);
	
	if(setLoading(true))
	{
		document.getElementById('firstBread').innerText				=	lang.interface;
		$('#firstBread').attr("onClick", "changeNavigation();changeContent('web_teamspeak_server');");
		
		switch(page)
		{
			case "web_teamspeak_serverview":
				document.getElementById('secondBread').innerHTML	=	lang.server_overview;
				break;
			case "web_teamspeak_serverbanner":
				document.getElementById('secondBread').innerText	=	lang.serverbanner;
				break;
			case "web_teamspeak_serverprotokol":
				document.getElementById('secondBread').innerText	=	lang.protokoll;
				break;
			case "web_teamspeak_servermassactions":
				document.getElementById('secondBread').innerText	=	lang.mass_actions;
				break;
			case "web_teamspeak_servericons":
				document.getElementById('secondBread').innerText	=	lang.icons;
				break;
			case "web_teamspeak_serverclients":
				document.getElementById('secondBread').innerText	=	lang.client;
				break;
			case "web_teamspeak_serverbans":
				document.getElementById('secondBread').innerText	=	lang.bans;
				break;
			case "web_teamspeak_servertoken":
				document.getElementById('secondBread').innerText	=	lang.token;
				break;
			case "web_teamspeak_serverfilelist":
				document.getElementById('secondBread').innerText	=	lang.filelist;
				break;
			case "web_teamspeak_serverbackups":
				document.getElementById('secondBread').innerText	=	lang.backups;
				break;
		};
		
		$('#myContent').load("./php/teamspeak/"+page+".php", function()
		{
			$("html, body").animate({
				scrollTop: 0
			},
			600,
			function() {
				setLoading(false);
			});
		});
	};
};

/**
	Refresh navigation
	@return {bool}
*/
function checkNavigation() {
	$.ajax({
		type: "POST",
		url: "./php/functions/functionsSqlPost.php",
		data: {
			action:		'getUserPermissions'
		},
		success: function(data){
			var perm = JSON.parse(data);
			
			if(perm.success) {
				var permGroupSettings = false;
				var permGroupInstances = false;
				var permGroupUser = false;
				
				for(var key in perm.data) {
					if(perm.data[key] === false) {
						$('.'+key).addClass('d-none');
					} else {
						$('.'+key).removeClass('d-none');

						if(key.includes('perm_teamspeak')) {
							$('.perm_teamspeak').removeClass('d-none');
						};
						
						if(key.includes('perm_admin')) {
							permGroupSettings = true;

							$('.perm_admin').removeClass('d-none');
							$('.perm_admin_settings').removeClass('d-none');
						};
						
						if(key.includes('perm_admin_instances')) {
							permGroupInstances = true;
							$('.perm_admin_instance').removeClass('d-none');
						};
						
						if(key.includes('perm_admin_users')) {
							permGroupUser = true;
							$('.perm_admin_user').removeClass('d-none');
						};
					};
				};
				
				if(!permGroupSettings) {
					$('.perm_admin_settings').addClass('d-none');
				};
				
				if(!permGroupInstances) {
					$('.perm_admin_instance').addClass('d-none');
				};
				
				if(!permGroupUser) {
					$('.perm_admin_user').addClass('d-none');
				};
				
				return true;
			} else {
				return false;
			};
		}
	});
	
	return true;
};

/**
	Change main content of the interface
	@param {string} which
	@param {bool} replace
	@param {string} instance
	@param {string} port
*/
function changeContent(which, replace = true, custom = false, instance = '', port = '', name = '') {
	if(which.includes('web') && !checkNavigation()) {
		new Notification({
			message : 'Could not refresh navigation',
			icon: 'fas fa-bars',
			type : 'danger'
		}).show();
		return;
	};
	
	// read correct data
	if(instance.includes(':')) {
		instance = $('#'+instance.replace(':', '')).attr('data-instance');
		if(instance == "") {
			instance = "0";
		};
	};
	
	if(port.includes(':')) {
		port = $('#'+port.replace(':', '')).attr('data-port');
	};
	
	// build link string
	if(instance !== '') {
		instance = '?'+instance;
	};
	
	if(port !== '') {
		port = '?'+port;
	};
	
	if(replace) {
		replaceHistory("index.php?"+which+instance+port);
	};
	
	if(setLoading(true)) {
		var subfolder = "";
		var title = $('.navbar > .nav-title').text()+" -- Teamspeak3 Control Panel -- ";
		
		if(!custom) {
			// Set server navigation
			if(!which.includes('web') && which.includes('updater_')) {
				$('#myContent').load("./"+which+".php", function() {
					$("div.tooltip").remove();
					$("html, body").animate({
						scrollTop: 0
					},
					600,
					function() {
						setLoading(false);
						
						/**
							Login after enter push
						*/
						$('#loginUser, #loginPw').keypress(function(e) {
							if (e.which == 13) {
								loginUser();
								e.preventDefault();
							};
						});
						
						/**
							Validate login data
						*/
						validateOnChange('#loginUser', {
							required: true,
							email: true
						}, '', lang.change_user_failed);
						validateOnChange('#loginPw', {
							required: true
						}, '', lang.field_cant_be_empty);
					});
					
					$('[data-toggle="tooltip"]').tooltip();
				});
			} else {
				if(port !== '') {
					if(instance === '') {
						instance = '0';
					};
					$('#navTsServerName').attr('data-instance', instance.replace('?', ''));
					$('#navTsServerName').attr('data-port', port.replace('?', ''));
					$('#navTsServerName').removeClass('d-none');
					if($('#navTsServerName > a span').text() == '') {
						$('#navTsServerName > a span').text(name);
					};
				} else {
					$('#navTsServerName').removeAttr('data-instance');
					$('#navTsServerName').removeAttr('data-port');
					$('#navTsServerName').addClass('d-none');
					$('#navTsServerName > a span').text('');
				};
				
				if(which.includes("main")) {
					subfolder = "main";
					
					document.getElementById('firstBread').innerText = lang.navigation;
					
					switch(which) {
						case "web_main_main":
							document.getElementById('secondBread').innerText = lang.news;
							document.title = title+lang.news;
							break;
						case "web_main_apply_server":
							document.getElementById('secondBread').innerText = lang.apply_for_server;
							document.title = title+lang.apply_for_server;
							break;
						case "web_main_support_teamspeak":
							document.getElementById('secondBread').innerText = lang.support_teamspeak;
							document.title = title+lang.support_teamspeak;
							break;
						case "web_main_register":
							document.getElementById('secondBread').innerText = lang.register;
							document.title = title+lang.register;
							break;
						case "web_main_impressum":
							document.getElementById('secondBread').innerText = "Impressum";
							document.title = title+"Impressum";
							break;
					};
					
					$('#firstBread').attr("onClick", "changeContent('web_main_main');");
				} else if(which.includes("profil")) {
					subfolder = "profile";
					
					document.getElementById('firstBread').innerText = lang.profile;
					
					switch(which) {
						case "web_profil_dashboard":
							document.getElementById('secondBread').innerText = "Dashboard";
							document.title = title+"Dashboard";
							break;
						case "web_profil_edit":
							document.getElementById('secondBread').innerText = lang.edit_profile;
							document.title = title+lang.edit_profile;
							break;
					};
					
					$('#firstBread').attr("onClick", "changeContent('web_profil_dashboard');");
				} else if(which.includes("admin")) {
					subfolder = "admin";
					
					document.getElementById('firstBread').innerText = lang.global_settings;
					
					switch(which) {
						case "web_admin_settings":
							document.getElementById('secondBread').innerText = lang.settings;
							document.title = title+lang.settings;
							break;
						case "web_admin_instanz":
							document.getElementById('secondBread').innerText = lang.instances;
							document.title = title+lang.instances;
							break;
						case "web_admin_user":
							document.getElementById('secondBread').innerText = lang.client;
							document.title = title+lang.client;
							break;
						case "web_admin_mail": // deprecated
							document.getElementById('secondBread').innerText = lang.mail_settings;
							document.title = title+lang.mail_settings;
							break;
						case "web_admin_logs":
							document.getElementById('secondBread').innerText = lang.logs;
							document.title = title+lang.logs;
							break;
					};
					
					$('#firstBread').attr("onClick", "changeContent('web_admin_settings');");
				} else if(which.includes("musicbot")) {
					subfolder = "musicbot";
					
					document.getElementById('firstBread').innerText = lang.musicbots;
					
					switch(which) {
						case "web_musicbot_server":
							document.getElementById('secondBread').innerText = lang.server;
							document.title = title+lang.server;
							break;
					};
					
					$('#firstBread').attr("onClick", "changeNavigation();changeContent('web_musicbot_server');");
				} else if(which.includes("teamspeak")) {
					subfolder = "teamspeak";
					
					document.getElementById('firstBread').innerText = lang.interface;
					
					switch(which) {
						case "web_teamspeak_server":
							document.getElementById('secondBread').innerText = lang.server;
							break;
						case "web_teamspeak_server_create":
							document.getElementById('secondBread').innerText = lang.create_server;
							break;
						case "web_teamspeak_server_requests":
							document.getElementById('secondBread').innerHTML = lang.server_requests;
							break;
						case "web_teamspeak_serverview":
							document.getElementById('secondBread').innerHTML = lang.server_overview;
							break;
						case "web_teamspeak_serverbanner":
							document.getElementById('secondBread').innerText = lang.serverbanner;
							break;
						case "web_teamspeak_serverprotokol":
							document.getElementById('secondBread').innerText = lang.protokoll;
							break;
						case "web_teamspeak_servermassactions":
							document.getElementById('secondBread').innerText = lang.mass_actions;
							break;
						case "web_teamspeak_servericons":
							document.getElementById('secondBread').innerText = lang.icons;
							break;
						case "web_teamspeak_serverclients":
							document.getElementById('secondBread').innerText = lang.client;
							break;
						case "web_teamspeak_serverbans":
							document.getElementById('secondBread').innerText = lang.bans;
							break;
						case "web_teamspeak_servertoken":
							document.getElementById('secondBread').innerText = lang.token;
							break;
						case "web_teamspeak_serverfilelist":
							document.getElementById('secondBread').innerText = lang.filelist;
							break;
						case "web_teamspeak_serverbackups":
							document.getElementById('secondBread').innerText = lang.backups;
							break;
					};
					
					$('#firstBread').attr("onClick", "changeNavigation();changeContent('web_teamspeak_server');");
				};
				
				if(which.includes("ticket")) {
					subfolder = "ticket";
					document.getElementById('firstBread').innerText = lang.ticket_system;
					document.getElementById('secondBread').innerText = lang.tickets;
					$('#firstBread').attr("onClick", "changeContent('web_ticket');");
				};
				
				$('#myContent').load("./php/"+subfolder+"/"+which+".php", function() {
					$("div.tooltip").remove();
					if(which == "web_main_apply_server") { // deprecated
						if(typeof(wantServer['4']) != 'undefined') {
							$('#wantServerStep1').remove();
							$('#wantServerStep2').remove();
							$('#wantServerStep3').show();
						} else if(typeof(wantServer['0']) != 'undefined') {
							$('#wantServerStep1').remove();
							$('#wantServerStep2').show();
						};
					};
					
					$("html, body").animate({
						scrollTop: 0
					},
					600,
					function() {
						setLoading(false);
						
						/**
							Login after enter push
						*/
						$('#loginUser, #loginPw').keypress(function(e) {
							if (e.which == 13) {
								loginUser();
								e.preventDefault();
							};
						});
						
						/**
							Validate login data
						*/
						validateOnChange('#loginUser', {
							required: true,
							email: true
						}, '', lang.change_user_failed);
						validateOnChange('#loginPw', {
							required: true
						}, '', lang.field_cant_be_empty);
					});
					
					$('[data-toggle="tooltip"]').tooltip();
				});
			};
		} else {
			document.title = title+custom;
			document.getElementById('firstBread').innerText = custom;
			document.getElementById('secondBread').innerText = '';
			
			$('#firstBread').attr("onClick", "return false;");
			
			$('#myContent').load(which, function() {
				$("html, body").animate({
					scrollTop: 0
				},
				600,
				function() {
					setLoading(false);
				});
				
				$('[data-toggle="tooltip"]').tooltip();
			});
		};
	};
};