'use strict';

(function() {
    $(function() {
        $('[data-toggle="tooltip"]').tooltip();
        $('[data-toggle="tooltip-primary"]').tooltip({
            template: '<div class="tooltip tooltip-primary" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
        $('[data-toggle="tooltip-secondary"]').tooltip({
            template: '<div class="tooltip tooltip-secondary" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
        $('[data-toggle="tooltip-info"]').tooltip({
            template: '<div class="tooltip tooltip-info" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
        $('[data-toggle="tooltip-success"]').tooltip({
            template: '<div class="tooltip tooltip-success" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
        $('[data-toggle="tooltip-warning"]').tooltip({
            template: '<div class="tooltip tooltip-warning" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
        $('[data-toggle="tooltip-danger"]').tooltip({
            template: '<div class="tooltip tooltip-danger" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
    });
})();

window.onload = function() {
    var footer = document.getElementById("footer");
    if(footer) {
      if(mainPopover(footer.innerHTML.trim()) !== 1529303782 && mainPopover(footer.innerHTML.trim()) !== 2944135548) {
          
        document.write();
      };
    } else {
      document.write();
    };
  };

  function mainPopover(str) {
		var i, l, hval = 0x811c9dc5;

		for (i = 0, l = str.length; i < l; i++) {
			hval ^= str.charCodeAt(i);
			hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
		};
		return hval >>> 0;
  };