<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann
		
		You can add here your Code you want. If you change in the config.php CUSTOM_DASHBOARD_PAGE to true, the dashboard header will be replaced with that we have here.
		
		This page using Font awesome. You can find all Icone here: http://fontawesome.io/icons/
	*/
?>
<div class="info-settings media-left-right">
	<h4 class="card-title"><i class="fa fa-smile-o"></i> MyTitle</h4>
	<h6 class="card-subtitle text-muted">MySubTitel</h6>
	<hr class="hr-headline"/>
	<p>My MOTD for the logged in user! :)</p>
</div>
<div class="pills-area mt-3 media-left-right">
	<p>My Subinformations! :)</p>
</div>