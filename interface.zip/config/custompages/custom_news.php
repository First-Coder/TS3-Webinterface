<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann
		
		You can add here your Code you want. If you change in the config.php CUSTOM_NEWS_PAGE to true, the news will be replaced with that we have here.
		
		This page using Font awesome. You can find all Icone here: http://fontawesome.io/icons/
		
		This is just a sample and will normaly not used in the interface.
	*/
?>

<div class="content-header color-header"><?php echo $language['news']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-12 widget">
		<div class="mb-5 news-box">
			<div class="header news-header">
				<h4 class="title color-header"><i class="far fa-newspaper"></i> MyTitle</h4>
				<span><i class="far fa-clock mr-2"></i><?php echo date("d.m.Y - G:i", time()); ?></span>
				<h6 class="sub-title text-muted">MySubTitel</h6>
			</div>
			<hr class="hr-headline"/>
			<p>My own Content :)</p>
		</div>
	</div>
</div>