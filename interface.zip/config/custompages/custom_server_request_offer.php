<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann
		
		You can add here your Code you want. The content will be shown, if you open the server request page.
		
		This page using Font awesome. You can find all Icone here: http://fontawesome.io/icons/
	*/
?>

<div class="header news-header">
	<h4 class="title color-header"><i class="fas fa-hands-helping"></i> <?php echo $language['we_offer_that']; ?></h4>
</div>
<hr class="hr-headline"/>
<p class="color-light">
	<?php echo $language['server_application_info_3']; ?>:
	<ul class="list-group-2 color-light">
		<a>
			<i class="fas fa-user"></i>
			<span><?php echo $language['server_application_info_4']; ?></span>
		</a>
		<a>
			<i class="fab fa-teamspeak"></i>
			<span><?php echo $language['server_application_info_5']; ?></span>
		</a>
		<a>
			<i class="fas fa-users-cog"></i>
			<span><?php echo $language['server_application_info_6']; ?></span>
		</a>
		<a>
			<i class="fas fa-hands"></i>
			<span><?php echo $language['server_application_info_7']; ?></span>
		</a>
	</ul>
</p>