<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann
		
		You can add here your Code you want. The content will be shown, if you open the server request page.
		
		This page using Font awesome. You can find all Icone here: http://fontawesome.io/icons/
	*/
?>

<div class="header news-header">
	<h4 class="title color-header"><i class="fas fa-info-circle"></i> <?php echo $language['informations']; ?></h4>
</div>
<hr class="hr-headline"/>
<p class="color-light">
	<?php echo $language['server_application_info_1']; ?>
	<?php echo $language['server_application_info_2']; ?><br /><br />
</p>