<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann
		
		You can add here your Code you want. The content will be shown, if you open the server request page.
		
		This page using Font awesome. You can find all Icone here: http://fontawesome.io/icons/
	*/
?>
<div class="card-block-header">
	<h4 class="card-title"><i class="fa fa-info"></i> <?php echo $language['apply_for_server']; ?></h4>
</div>
<hr class="hr-headline"/>
<p class="color-light">
	<?php echo $language['server_application_info_1']; ?>
	<?php echo $language['server_application_info_2']; ?><br /><br />
</p>
<p class="color-light">
	<?php echo $language['server_application_info_3']; ?>
	<ul class="list-group color-light">
		<li class="list-group-item">
			<i class="material-icons">check_circle</i>
			<p class="list-group-item-heading"><?php echo $language['server_application_info_4']; ?></p>
		</li>
		<li class="list-group-item">
			<i class="material-icons">check_circle</i>
			<p class="list-group-item-heading"><?php echo $language['server_application_info_5']; ?></p>
		</li>
		<li class="list-group-item">
			<i class="material-icons">check_circle</i>
			<p class="list-group-item-heading"><?php echo $language['server_application_info_6']; ?></p>
		</li>
		<li class="list-group-item">
			<i class="material-icons">check_circle</i>
			<p class="list-group-item-heading"><?php echo $language['server_application_info_7']; ?></p>
		</li>
	</ul>
</p>