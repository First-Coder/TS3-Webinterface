<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		This file has the defaul configuration for a server create. You can change here in the interface under server/create server/templates or directly here.
		
		* Definitions:
		** host_message_show => Host message show 0=No message 1=Show message in Log 2=Show modal message 3=Modal message and exit
		** virtualserver_log_* => Log Clients,Query, Channel, Server, Permissions or Filetransfer no=0 yes=1
	*/
	
	$ts3_server_create_default['virtualserver_name'] = 'First Coder Teamspeak 3 Server';
	$ts3_server_create_default['virtualserver_maxclients'] = '32';
	$ts3_server_create_default['virtualserver_welcomemessage'] = 'Willkommen auf unserem Teamspeak 3 Server';
	$ts3_server_create_default['virtualserver_reserved_slots'] = '0';
	
	$ts3_server_create_default['virtualserver_hostmessage'] = '';
	$ts3_server_create_default['virtualserver_hostmessage_mode'] = '0';
	$ts3_server_create_default['virtualserver_hostbanner_url'] = '';
	$ts3_server_create_default['virtualserver_hostbanner_gfx_url'] = '';
	$ts3_server_create_default['virtualserver_hostbanner_gfx_interval'] = '';
	$ts3_server_create_default['virtualserver_hostbutton_gfx_url'] = '';
	$ts3_server_create_default['virtualserver_hostbutton_tooltip'] = '';
	$ts3_server_create_default['virtualserver_hostbutton_url'] = '';
	
	$ts3_server_create_default['virtualserver_complain_autoban_count'] = '';
	$ts3_server_create_default['virtualserver_complain_autoban_time'] = '';
	$ts3_server_create_default['virtualserver_complain_remove_time'] = '';
	
	$ts3_server_create_default['virtualserver_antiflood_points_tick_reduce'] = '';
	$ts3_server_create_default['virtualserver_antiflood_points_needed_command_block'] = '';
	$ts3_server_create_default['virtualserver_antiflood_points_needed_ip_block'] = '';
	
	$ts3_server_create_default['virtualserver_max_upload_total_bandwidth'] = '';
	$ts3_server_create_default['virtualserver_upload_quota'] = '';
	$ts3_server_create_default['virtualserver_max_download_total_bandwidth'] = '';
	$ts3_server_create_default['virtualserver_download_quota'] = '';
	
	$ts3_server_create_default['virtualserver_log_client'] = '1';
	$ts3_server_create_default['virtualserver_log_query'] = '0';
	$ts3_server_create_default['virtualserver_log_channel'] = '0';
	$ts3_server_create_default['virtualserver_log_permissions'] = '1';
	$ts3_server_create_default['virtualserver_log_server'] = '1';
	$ts3_server_create_default['virtualserver_log_filetransfer'] = '0';
?>