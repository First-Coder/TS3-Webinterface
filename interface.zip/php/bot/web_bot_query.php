<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsBot.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'] || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right		=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_web']['key'] != $mysql_keys['right_web'] || $user_right['right_web_server_create']['key'] != $mysql_keys['right_web_server_create'] || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite();
	};
?>

<!-- Modal: Create Querybot -->
<div id="modalCreateQueryBot" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="modalCreateQueryBotLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content form-secondary">
			<div class="modal-header alert-success">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="modalCreateQueryBotLabel"><?php echo $language['create_querybot']; ?></h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="selectCreateQueryBotInstance"><?php echo $language['instance']; ?></label>
					<select onChange="addQueryBotChangePort();" class="form-control w-100-percent" id="selectCreateQueryBotInstance">
						<option value="none" selected style="display: none;"><?php echo $language['choose_instance']; ?></option>
						<?php
							foreach($ts3_server AS $instanz=>$server)
							{
								if($server['alias'] != '')
								{
									echo '<option value="' . $instanz . '">' . $server['alias'] . '</option>';
								}
								else
								{
									echo '<option value="' . $instanz . '">' . $server['ip'] . '</option>';
								};
							};
						?>
					</select>
					<small class="form-text text-muted"><?php echo $language['which_instance_create_bot']; ?></small>
				</div>
				<div class="form-group">
					<label for="selectCreateQueryBotPort"><?php echo $language['port']; ?></label>
					<select class="form-control c-select" id="selectCreateQueryBotPort" style="width:100%;">
						<option value="none" selected style="display: none;"><?php echo $language['choose_serverport']; ?></option>
					</select>
					<small class="form-text text-muted"><?php echo $language['choose_serverport_info']; ?></small>
				</div>
				
				<div class="form-group">
					<label for="createQueryBotName"><?php echo $language['name']; ?></label>
					<input type="text" class="form-control" id="createQueryBotName" value="First-Coder: Serverwache">
					<small class="form-text text-muted"><?php echo $language['querybot_name_info']; ?></small>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-fw fa-close"></i> <?php echo $language['abort']; ?></button>
				<button id="bttnCreateQueryBot" onClick="createQueryBot();" type="button" class="btn btn-success" disabled data-dismiss="modal"><i class="fa fa-fw fa-edit"></i> <?php echo $language['create']; ?></button>
			</div>
		</div>
	</div>
</div>

<!-- Show list with Server Requests -->
<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row m-b-40">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<!-- Systemlogs -->
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-list" aria-hidden="true"></i> <?php echo $language['query_botlist']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<div id="botToolbar">
					<button data-toggle="modal" data-target="#modalCreateQueryBot" class="btn btn-success btn-flat"><i class="fa fa-plus" aria-hidden="true"></i> Bot hinzuf&uuml;gen</button>
				</div>
				<table id="botTable" data-card-view="true" data-classes="table-no-bordered table-hover table"
					data-striped="true" data-pagination="true" data-search="true" data-toolbar="#botToolbar">
					<thead>
						<tr>
							<th data-field="client"><?php echo "Botname"; ?></th>
							<th data-field="status"><?php echo $language['status']; ?></th>
							<th data-field="instanz"><?php echo $language['instance']; ?></th>
							<th data-field="port"><?php echo $language['port']; ?></th>
							<th data-field="actions"><?php echo $language['actions']; ?></th>
							<th data-field="id" data-visible="false"><!-- Temp --></th>
						</tr>
					</thead>
					<tbody>
						<?php
							$bots					=	getQuerybots();
							
							if(!empty($bots))
							{
								foreach ($bots as $bot)
								{
									$isActive		=	($bot['isActive']) ? "<span style=\"font-size: 15px;\" class=\"label label-success\">".$language['online']."</span>" : "<span style=\"font-size: 15px;\" class=\"label label-danger\">".$language['offline']."</span>";
									$instanzname	=	($ts3_server[$bot['instance']]['alias'] != "") ? $ts3_server[$bot['instance']]['alias'] : $ts3_server[$bot['instance']]['ip'];
									$label			=	($bot['isActive']) ? "success" : "danger";
									echo '<tr>
											<td>'.xssSafe($bot['botname']).'</td>
											<td><span style="font-size: 15px;font-weight: normal;" class="tag tag-pill tag-outline-'.$label.'">'.$isActive.'</span></td>
											<td>'.xssSafe($instanzname).'</td>
											<td>'.xssSafe($bot['port']).'</td>
											<td>
												<button class="btn btn-success btn-xs btn-flat" onClick="showQueryBot(\''.$bot['id'].'\', \''.$bot['instance'].'\', \''.$bot['port'].'\');"><i class="fa fa-edit"></i> <font class="hidden-md-down">'.$language['edit'].'</font>
												<button class="btn btn-danger btn-xs btn-flat" onClick="AreYouSure(\''.$language['delete_bot'].'\', \''.urlencode(json_encode(array("deleteQueryBot", $bot['id']))).'\');"><i class="fa fa-trash"></i> <font class="hidden-md-down">'.strtolower($language['delete']).'</font>
											</td>
											<td>'.xssSafe($bot['id']).'</td>
										</tr>';
								};
							};
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Javascripte Laden -->
<script src="js/bootstrap/bootstrap-table.js"></script>
<script src="js/webinterface/bot.js"></script>
<script>
	$('#botTable').bootstrapTable({
		formatNoMatches: function ()
		{
			return "Keine Bots installiert";
		}
	});
</script>