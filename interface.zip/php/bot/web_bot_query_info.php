 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsBot.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'] || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right		=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_web']['key'] != $mysql_keys['right_web'] || $user_right['right_web_server_create']['key'] != $mysql_keys['right_web_server_create'] || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite();
	};
	
	/*
		Teamspeak Functions
	*/
	$tsAdmin 			= 	new ts3admin($ts3_server[$_POST['instanz']]['ip'], $ts3_server[$_POST['instanz']]['queryport']);
	
	if($tsAdmin->getElement('success', $tsAdmin->connect()))
	{
		$tsAdmin->login($ts3_server[$_POST['instanz']]['user'], $ts3_server[$_POST['instanz']]['pw']);
		$tsAdmin->selectServer($_POST['port'], 'port', true);
		
		$channels		=	$tsAdmin->getElement('data', $tsAdmin->channelList());
		$sgroups		=	$tsAdmin->getElement('data', $tsAdmin->serverGroupList());
		$cgroups		=	$tsAdmin->getElement('data', $tsAdmin->channelGroupList());
		
		$channelTree	=	getChannelTree($channels, false);
		$subChannelTree	=	getChannelTree($channels, true);
	}
	else
	{
		reloadSite();
	};
	
	/*
		Servergruppen erstellen
	*/
	$groupElements		=	array();
	if(!empty($sgroups))
	{
		foreach($sgroups AS $sgroup)
		{
			if($sgroup['type'] == 1)
			{
				$push			=	array();
				$push['value']	=	intval($sgroup['sgid']);
				$push['text']	=	xssSafe($sgroup['name']);
				array_push($groupElements, $push);
			};
		};
	};
	
	/*
		Ask for all informations
	*/
	$bot			=	getAllQueryBotInformation($_POST['id']);
	print_r($bot);
?>

<!-- Main settings -->
<div class="card">
	<div class="card-block card-block-header">
		<h4 class="card-title">
			<div class="pull-xs-left" id="mailOverview">
				<i class="fa fa-user-secret"></i> <?php echo "Bot Haupteinstellungen"; ?>
			</div>
			<div class="pull-xs-right">
				<div onClick="botQueryInit();" data-tooltip="tooltip" data-placement="top" title="<?php echo $language['back']; ?>" class="pull-xs-right btn btn-secondary user-header-icons">
					<i class="fa fa-fw fa-arrow-left"></i>
				</div>
			</div>
			<div style="clear:both;"></div>
		</h4>
	</div>
	<div class="card-block">
		<div class="form-group">
			<label for="queryBotName"><?php echo $language['name']; ?></label>
			<div class="input-group">
				<input type="text" class="form-control" id="createQueryBotName" value="<?php xssEcho($bot['botname']); ?>">
				<span class="input-group-btn">
					<button class="btn btn-success"><i class="fa fa-save" aria-hidden="true"></i> <?php echo $language['save']; ?></button>
				</span>
			</div>
			<small class="form-text text-muted"><?php echo "Name des Querybots im Teamspeak"; ?></small>
		</div>
		<button class="btn btn-success" style="width: 100%;"><i class="fa fa-play" aria-hidden="true"></i> Bot starten</button>
	</div>
</div>

<!-- Servergroup protection -->
<div class="card">
	<div style="cursor:pointer;" class="card-block card-block-header" onClick="slideMe('sgroupProtectionBox', 'sgroupProtectionIcon');">
		<h4 class="card-title">
			<div class="pull-xs-left">
				<i id="sgroupProtectionIcon" class="fa fa-arrow-right"></i> <?php echo "Bot Servergruppenüberwachung"; ?>
			</div>
			<div class="pull-xs-right">
				<div style="margin-top:0px;padding: .175rem 1rem;"
					onclick="saveBotSettings('');" class="pull-xs-right btn btn-secondary user-header-icons">
					<i class="fa fa-fw fa-save"></i> <?php echo $language['save']; ?>
				</div>
			</div>
			<div style="clear:both;"></div>
		</h4>
	</div>
	<div id="sgroupProtectionBox" class="card-block" style="display: none;">
		<div class="row">
			<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 top-bottom-margin">
				<?php echo "Abwesenheits Modul"; ?>
			</div>
			<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 top-bottom-margin">
				<input data-width="100%" id="setAfkModul" type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="secondary" data-on="<?php echo $language['active']; ?>" data-off="<?php echo $language['deactive']; ?>" <?php if($bot['isAfkMoving']) { echo 'checked'; } ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="setSgroupProtection"><?php echo "Gesch&uuml;tzte Servergruppe"; ?></label>
			<div>
				<input style="width: 100%;" type="text" class="form-control" id="setSgroupProtection">
			</div>
			<small class="form-text text-muted"><?php echo "Tragen Sie hier die Servergruppen ein, die nicht verschoben werden sollen."; ?></small>
		</div>
	</div>
</div>

<!-- Afk settings -->
<div class="card">
	<div style="cursor:pointer;" class="card-block card-block-header" onClick="slideMe('afkBox', 'afkIcon');">
		<h4 class="card-title">
			<i id="afkIcon" class="fa fa-arrow-right"></i> <?php echo "Bot Abwesenheitseinstellungen"; ?>
		</h4>
	</div>
	<div id="afkBox" class="card-block" style="display: none;">
		<div class="row">
			<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 top-bottom-margin">
				<?php echo "Abwesenheits Modul"; ?>
			</div>
			<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 top-bottom-margin">
				<input data-width="100%" id="setAfkModul" type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="secondary" data-on="<?php echo $language['active']; ?>" data-off="<?php echo $language['deactive']; ?>" <?php if($bot['isAfkMoving']) { echo 'checked'; } ?>>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 top-bottom-margin">
				<?php echo "Verschieben bei ausgeschaltetem Mikophone"; ?>
			</div>
			<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 top-bottom-margin">
				<input data-width="100%" id="setAfkMicMuted" type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="secondary" data-on="<?php echo $language['active']; ?>" data-off="<?php echo $language['deactive']; ?>" <?php if($bot['isMovingMicMuted']) { echo 'checked'; } ?>>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 top-bottom-margin">
				<?php echo "Verschieben bei ausgeschaltetem Headset"; ?>
			</div>
			<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 top-bottom-margin">
				<input data-width="100%" id="setAfkHeadsetMuted" type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="secondary" data-on="<?php echo $language['active']; ?>" data-off="<?php echo $language['deactive']; ?>" <?php if($bot['isMovingHeadsetMuted']) { echo 'checked'; } ?>>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 top-bottom-margin">
				<?php echo "Verschieben bei Abwesenheitsstatus"; ?>
			</div>
			<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 top-bottom-margin">
				<input data-width="100%" id="setAfkAway" type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="secondary" data-on="<?php echo $language['active']; ?>" data-off="<?php echo $language['deactive']; ?>" <?php if($bot['isMovingAway']) { echo 'checked'; } ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="afkChannel"><?php echo "Abwesenheitschannel"; ?></label>
			<select id="afkChannel" class="form-control c-select">
				<optgroup label="<?php echo $language['channel']; ?>">
					<?php echo str_replace("<option value='".$bot['AfkMovingChannel']."'>", "<option value='".$bot['AfkMovingChannel']."' selected>", $channelTree); ?>
				</optgroup>
				<optgroup label="<?php echo $language['sub_channel']; ?>">
					<?php echo $subChannelTree; ?>
				</optgroup>
			</select>
			<small class="form-text text-muted"><?php echo "Channel indem der Inaktive Benutzer geschoben wird."; ?></small>
		</div>
		<div class="form-group">
			<label for="setAfkIdleTime"><?php echo "Verschieben bei Inaktivit&auml;t im Teamspeak"; ?></label>
			<input type="number" class="form-control" id="setAfkIdleTime" value="<?php echo $bot['isMovingIdleTime']; ?>">
			<small class="form-text text-muted"><?php echo "Gib hier die Anzahl der Sekunden an, ab wann der Inaktive Benutzer verschoben werden soll. (0 = ausgeschaltet)"; ?></small>
		</div>
		<div class="row">
			<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12 top-bottom-margin">
				<?php echo "Warnung an den Benutzer bei inaktivit&auml;t im Teamspeak"; ?>
			</div>
			<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 top-bottom-margin">
				<input data-width="100%" id="setAfkIdleWarningMessage" type="checkbox" data-toggle="toggle" data-onstyle="success" data-offstyle="secondary" data-on="<?php echo $language['active']; ?>" data-off="<?php echo $language['deactive']; ?>" <?php if($bot['isMovingIdleWarningMessage']) { echo 'checked'; } ?>>
			</div>
		</div>
		<div class="form-group">
			<label for="setAfkIdleMessage"><?php echo "Warnnachricht"; ?></label>
			<input type="text" class="form-control" id="setAfkIdleMessage" value="<?php xssEcho($bot['MovingIdleWarningMessage']); ?>">
			<small class="form-text text-muted"><?php echo "Gib hier die Nachricht an, die der Benutzer bei Inaktivit&auml;t im Teamspeak erhalten soll."; ?></small>
		</div>
		<div class="form-group">
			<label for="setAfkImmunSgroups"><?php echo "Immune Servergruppen"; ?></label>
			<div>
				<input style="width: 100%;" type="text" class="form-control" id="setAfkImmunSgroups">
			</div>
			<small class="form-text text-muted"><?php echo "Tragen Sie hier die Servergruppen ein, die nicht verschoben werden sollen."; ?></small>
		</div>
		<button onclick="saveBotSettings('bot_settigns_afk');" style="width: 100%;" class="btn btn-success"><i class="fa fa-fw fa-save"></i> <?php echo $language['submit']; ?></button>
	</div>
</div>

<!-- Javascripte Laden -->
<script src="js/bootstrap/bootstrap-table.js"></script>
<script src="js/bootstrap/bootstrap-toggle.js"></script>
<script src="js/sonstige/typeahead.bundle.js"></script>
<script src="js/sonstige/bloodhound.js"></script>
<script src="js/bootstrap/bootstrap-tagsinput.js"></script>
<script src="js/webinterface/bot.js"></script>
<script>
	/*
		Variables
	*/
	var botid		=	<?php echo $_POST['id']; ?>;
	
	/*
		Create Sgroup Bloodhound
	*/
	var sgroups = new Bloodhound({
		datumTokenizer: Bloodhound.tokenizers.obj.whitespace('text'),
		queryTokenizer: Bloodhound.tokenizers.whitespace,
		local: <?php echo json_encode($groupElements); ?>
	});
	sgroups.initialize();
	
	/*
		Createing Tagsinput for Afksettings
	*/
	var elt = $('#setAfkImmunSgroups');
	elt.tagsinput({
		tagClass: function(item)
		{
			return 'label label-warning';
		},
		itemValue: 'value',
		itemText: 'text',
		typeaheadjs:
		{
			name: 'sgroups',
			displayKey: 'text',
			source: sgroups.ttAdapter()
		}
	});
	
	/*
		Updating Tagesinput for Afksettings
	*/
	var afkSgroupElements		=	JSON.parse('<?php echo $bot['afkMoveingImmunSgroups']; ?>');
	for(var element in afkSgroupElements)
	{
		elt.tagsinput('add', afkSgroupElements[element]);
	};
</script>
<script src="js/sonstige/preloader.js"></script>