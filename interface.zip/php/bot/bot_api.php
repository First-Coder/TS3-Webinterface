<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once("../../config/config.php");
	require_once("../../config/instance.php");
	require_once("../functions/functionsSql.php");
	
	/*
		Check if Api key is correct
	*/
	if($_POST['action'] == "checkKey")
	{
		if(BOT_API_KEY == $_POST['key'])
		{
			returnArray(true, null, null);
		}
		else
		{
			returnArray(false, null, "Loginkey is not valid!");
		};
	}
	else
	{
		if(BOT_API_KEY != $_POST['key'])
		{
			returnArray(false, null, "Loginkey is not valid!");
		};
	};
	
	/*
		Function to get the resultarray
	*/
	function returnArray($success, $data, $error)
	{
		echo json_encode(array('success' => $success, 'data' => $data, 'error' => $error));
		exit();
	};
	
	function setMutliarray($array)
	{
		$return		=	array();
		$return[0]	=	$array;
		returnArray(true, $return, null);
	}
	
	/*
		Send instances to the bot
	*/
	if($_POST['action'] == "getInstances")
	{
		returnArray(true, $ts3_server, null);
	};
	
	/*
		Send the Bots in the database
	*/
	if($_POST['action'] == "getBots")
	{
		if(($databaseConnection = getSqlConnection(false)) !== false)
		{
			if (($data = $databaseConnection->query("SELECT id, instance, sid, botname, isActive FROM bot_connections")) !== false)
			{
				returnArray(true, $data->fetchAll(PDO::FETCH_ASSOC), null);
			}
			else
			{
				returnArray(false, null, "Databasecommand failed!");
			};
		}
		else
		{
			returnArray(false, null, "Databaseconnection failed!");
		};
	};
	
	/*
		Send the pattern for bad nicknames or bad channelnames
	*/
	if($_POST['action'] == "getPattern")
	{
		if(($databaseConnection = getSqlConnection(false)) !== false)
		{
			if (($data = $databaseConnection->query("SELECT pattern FROM bot_bad_pattern WHERE id=".$_POST['bid']." AND sid =".$_POST['sid']." AND type='".$_POST['type']."'")) !== false)
			{
				$sqlData	=	$data->fetchAll(PDO::FETCH_ASSOC);
				returnArray(true, (empty($sqlData)) ? null : $sqlData, null);
			}
			else
			{
				returnArray(false, null, "Databasecommand failed!");
			};
		}
		else
		{
			returnArray(false, null, "Databaseconnection failed!");
		};
	};
	
	/*
		Send the servergroups for servergroupprotection
	*/
	if($_POST['action'] == "getSgroups")
	{
		if(($databaseConnection = getSqlConnection(false)) !== false)
		{
			if (($data = $databaseConnection->query("SELECT protectedId, protectedDatabaseId FROM bot_sgroup_protection WHERE id=".$_POST['bid']." AND sid =".$_POST['sid'])) !== false)
			{
				$sqlData	=	$data->fetchAll(PDO::FETCH_ASSOC);
				returnArray(true, (empty($sqlData)) ? null : $sqlData, null);
			}
			else
			{
				returnArray(false, null, "Databasecommand failed!");
			};
		}
		else
		{
			returnArray(false, null, "Databaseconnection failed!");
		};
	};
	
	/*
		Send Botdetails from the Database
	*/
	if($_POST['action'] == "getBotDetails")
	{
		if(($databaseConnection = getSqlConnection(false)) !== false)
		{
			if (($data = $databaseConnection->query("SELECT con.id, con.botname, afk.*, record.*, messages.*, general.*, channelCreator.* FROM bot_connections con, bot_settigns_afk afk, bot_record record, bot_settings_messages messages, bot_general_settings general, bot_channel_creator_settings channelCreator WHERE con.sid =".$_POST['sid']." AND con.id =".$_POST['bid']." AND afk.id =".$_POST['bid']." AND channelCreator.id=".$_POST['bid']." AND messages.id =".$_POST['bid'])) !== false)
			{
				$sqlData	=	$data->fetchAll(PDO::FETCH_ASSOC);
				returnArray(true, (empty($sqlData)) ? null : $sqlData, null);
			}
			else
			{
				returnArray(false, null, "Databasecommand failed!");
			};
		}
		else
		{
			returnArray(false, null, "Databaseconnection failed!");
		};
	}; 