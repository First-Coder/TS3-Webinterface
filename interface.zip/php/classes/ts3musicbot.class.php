<?php
	/*
	 *                         ts3musicbot.class.php
	 *                         ------------------                    
	 *   created              : 16. Oktober 2018
	 *   last modified        : 17. January 2019
	 *   version              : 1.0.2
	 *   website              : https://first-coder.de/
	 *   copyright            : (C) 2019 L.Gmann
	 *  
	 *  This program is free software: you can redistribute it or modify
	 *  it under the terms of the GNU General Public License as published by
	 *  the Free Software Foundation, either version 3 of the License, or
	 *  any later version.
	 *  
	 *  This program is distributed in the hope that it will be useful,
	 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
	 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 *  GNU General Public License for more details.
	 *  
	 *  You should have received a copy of the GNU General Public License
	 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
	 */
	 
	/** 
	 * @file
	 * The ts3musicbot.class is a powerful api for communication with the MusicBot from Splamy! Your creativity knows no bounds!
	 * 
	 * @author      L.Gmann
	 * @copyright   Copyright (c) 2019, L.Gmann
	 * @version     1.0.2
	 * @package		ts3musicbot
	 *
	 */
	 
	class ts3musicbot {
		private $runtime = array('url' => null, 'port' => null, 'https' => 'http://', 'timeout' => null, 'key' => '');
		
		/**
		* __construct
		*
		* @param	string		$url		musicbot url (can also be a ip)
		* @param	integer		$port		musicbot port
		* @param	boolean		$https		use https connection true/false (default = false)
		* @param	integer		$timeout	socket timeout (default = 30) [optional]
		* @return	void
		*/
		function __construct($url, $port, $https = false, $timeout = 10) {
			$this->runtime['url'] = $url;
			$this->runtime['port'] = $port;
			$this->runtime['https'] = ($https) ? 'https://' : 'http://';
			$this->runtime['timeout'] = $timeout;
		}
		
		/**
		* generateOutput
		* 
		* Builds a method return as array
		*
		* @param		boolean		$success	true/false
		* @param		array		$errors		all errors which occured while executing a method
		* @param		mixed		$data		parsed data from server
		* @return     	array 		output
		*/
		private function generateOutput($success, $errors, $data) {
			return array('success' => $success, 'errors' => $errors, 'data' => $data);
		}
		
		/**
		* executeCurl
		* 
		* Execute a command via curl
		*
		* @param		string		$command	commmand which will be executed
		* @return     	array 		output
		*/
		private function executeCurl($command) {
			if($this->runtime['url'] === null || $this->runtime['port'] === null) {
				return generateOutput(false, 'url or port is missing. Please set them over the constructor', null);
			};
			
			if(substr($command, 0, 1) !== '/') {
				$command = '/'.$command;
			};
			
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => $this->runtime['https'].$this->runtime['url'].':'.$this->runtime['port'].$command,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_TIMEOUT => $this->runtime['timeout'],
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
					"Authorization: Basic ".$this->runtime['key']
				),
			));
			
			$response = json_decode(curl_exec($curl));
			$error = curl_error($curl);
			curl_close($curl);
			
			if($response !== null && @property_exists($response, 'ErrorCode')) {
				return $this->generateOutput(false, array($response->ErrorMessage), null);
			};
			
			//return $this->generateOutput(($response !== false && $response !== null) ? true : false, array($error), $response);
			return $this->generateOutput((($response !== false && $response !== null) || $error === "") ? true : false, array($error), $response);
		}
		
		/**
		* setAuthorization
		* 
		* Set authentication key to get permissions on a api request
		*
		* @param		string		$user		user of the ts3 musicbot (unique id)
		* @param		string		$password	password of the ts3 musicbot
		* @return     	void
		*/
		public function setAuthorization($user, $password) {
			$this->runtime['key'] = base64_encode($user.':'.$password);
		}
		
		/**
		* executeCommand
		* 
		* Execute a command over the api
		*
		* @param		string		$command	command for the api (commands: https://github.com/Splamy/TS3AudioBot/wiki/CommandSystem#existing-commands)
		* @return     	void
		*/
		public function executeCommand($command) {
			return $this->executeCurl($command);
		}
	};
?>