 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	require_once(__DIR__."/../../php/functions/functionsMusicBot.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	$mysql_modul = getModuls();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success']) {
		if($user_right['data']['perm_admin_users_edit'] != $mysql_keys['perm_admin_users_edit']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_users_edit missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Set the selected Client to the First one in the List
	*/
	$choosedUserRight = getUserRights('pk', $_POST['id']);
	
	/**
		Get private information above the Client
	*/
	$userInformations = getUserInformations($_POST['id']);
	if($userInformations['success']) {
		$userInformations = $userInformations['data'];
		$lastLogin = explode(' - ', $userInformations['last_login']);
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/** 
		Could not load all settings
	*/
	if(!$choosedUserRight['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/** 
		Could not load all settings
	*/
	if(!$mysql_modul['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
?>

<div class="profile shadow-default-content mb-3">
	<div class="profile-header">
		<div class="row">
			<div class="col-lg-3 col-md-4 col-12">
				<div class="profile-img">
					<img class="profile-image" src="<?php echo getUserPicture($_POST['id']); ?>" />
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-12 mt-4">
				<div class="profile-text">
					<h4><?php xssEcho($userInformations['firstname'].' '.$userInformations['lastname']); ?></h4>
					<p><?php echo str_replace(array('%date%', '%time%'), array($lastLogin[0], $lastLogin[1]), $language['profile_last_login']); ?></p>
					<button <?php echo ($_SESSION['user']['id'] == $_POST['id']) ? 'disabled' : ''; ?> class="btn btn-sm btn-<?php echo ($userInformations['user_blocked'] == 'false') ? 'success' : 'danger'; ?>"><?php echo ($userInformations['user_blocked'] == 'false') ? '<i class="fas fa-check mr-2"></i><span>'.$language['unblocked'].'</span>' : '<i class="fas fa-ban mr-2"></i><span>'.$language['blocked'].'</span>'; ?></button>
				</div>
			</div>
		</div>
	</div>
	<div class="profile-sub-header">
		<ul>
			<li>
				<a href="#home" class="active">
					<i class="fas fa-home"></i>
					<p><?php echo $language['general']; ?></p>
				</a>
			</li>
			<li>
				<a href="#globe-perm">
					<i class="fas fa-globe"></i>
					<p><?php echo $language['global']; ?></p>
				</a>
			</li>
			<li>
				<a href="#server-perm">
					<i class="fas fa-server"></i>
					<p><?php echo $language['server']; ?></p>
				</a>
			</li>
		</ul>
	</div>
</div>

<div class="shadow-default-content widget mb-3">
	<div class="header-content pt-0">
		<h3 class="color-header"><i class="fas fa-cog mr-2"></i><span><?php echo $language['settings']; ?></span></h3>
		<a href="#" id="save-profile" data-toggle="tooltip" data-placement="left" title="<?php echo $language['save']; ?>"><i class="far fa-save"></i></a>
	</div>
	<div class="right-side-content profile-tab">
		<div id="home" class="active">
			<div class="tabs shadow-none">
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link active" href="#general" data-toggle="tab" role="tab"><?php echo $language['general']; ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#personally" data-toggle="tab" role="tab"><?php echo $language['personally']; ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#contact" data-toggle="tab" role="tab"><?php echo $language['contact']; ?></a>
					</li>
				</ul>
				<div class="tab-content form">
					<div class="tab-pane fade show active" id="general" role="tabpanel">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['mail']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileUser" class="form-control form-control-sm" type="text" placeholder="Login Mail" value="<?php xssEcho($_POST['mail']); ?>">
									<small class="form-text text-muted"><?php echo $language['mail_help']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profilePassword" class="form-control form-control-sm" type="password" placeholder="Change Password">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"></label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profilePassword2" class="form-control form-control-sm" type="password" placeholder="Change Password">
									<small class="form-text text-muted"><?php echo $language['password_help']; ?></small>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="personally" role="tabpanel">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['firstname']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileFirstname" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['field_cant_be_empty']; ?>" value="<?php xssEcho($userInformations['firstname']); ?>">
									<small class="form-text text-muted"><?php echo $language['firstname_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['lastname']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileLastname" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['field_cant_be_empty']; ?>" value="<?php xssEcho($userInformations['lastname']); ?>">
									<small class="form-text text-muted"><?php echo $language['lastname_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['telefon']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profilePhone" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['phone']); ?>">
									<small class="form-text text-muted"><?php echo $language['telefon_info']; ?></small>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="contact" role="tabpanel">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['homepage']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileHomepage" class="form-control form-control-sm" type="text" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['homepage'])); ?>">
									<small class="form-text text-muted"><?php echo $language['homepage_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['skype']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileSkype" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['skype']); ?>">
									<small class="form-text text-muted"><?php echo $language['skype_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['steam']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileSteam" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['steam']); ?>">
									<small class="form-text text-muted"><?php echo $language['steam_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['twitter']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileTwitter" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['twitter']); ?>">
									<small class="form-text text-muted"><?php echo $language['twitter_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['facebook']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileFacebook" class="form-control form-control-sm" type="text" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['facebook'])); ?>">
									<small class="form-text text-muted"><?php echo $language['facebook_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['google_plus']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileGoogle" class="form-control form-control-sm" type="text" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['google'])); ?>">
									<small class="form-text text-muted"><?php echo $language['google_plus_info']; ?></small>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="globe-perm">
			<div class="tabs shadow-none">
				<ul class="nav nav-tabs">
					
					<li class="nav-item">
						<a class="nav-link active" href="#admin" data-toggle="tab" role="tab"><?php echo $language['global_settings']; ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#teamspeak" data-toggle="tab" role="tab">Teamspeak</a>
					</li>
					<?php if($mysql_modul['data']['splamy_musicbot'] == "true") { ?>
						<li class="nav-item">
							<a class="nav-link" href="#bot" data-toggle="tab" role="tab">Bot</a>
						</li>
					<?php }; ?>
				</ul>
				<div class="tab-content form">
					<div class="tab-pane fade show active" id="admin" role="tabpanel">
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['client']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_rights_profile_perm']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_profile_see_perm" type="checkbox" <?php echo ($choosedUserRight['data']['perm_profile_see_perm'] == $mysql_keys['perm_profile_see_perm']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_rights_profile_perm_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ticket_admin']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_profile_ticket_admin" type="checkbox" <?php echo ($choosedUserRight['data']['perm_profile_ticket_admin'] == $mysql_keys['perm_profile_ticket_admin']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['ticket_admin_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ticket_admin_settings']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_profile_ticket_settings" type="checkbox" <?php echo ($choosedUserRight['data']['perm_profile_ticket_settings'] == $mysql_keys['perm_profile_ticket_settings']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['ticket_admin_settings_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0 mt-3">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['homepage']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_create_news']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_main_news_create" type="checkbox" <?php echo ($choosedUserRight['data']['perm_main_news_create'] == $mysql_keys['perm_main_news_create']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_create_news_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_create_delete']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_main_news_delete" type="checkbox" <?php echo ($choosedUserRight['data']['perm_main_news_delete'] == $mysql_keys['perm_main_news_delete']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_create_delete_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_rights_edit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_settings_main" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_settings_main'] == $mysql_keys['perm_admin_settings_main']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_rights_edit_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_rights_edit_lang']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_settings_lang" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_settings_lang'] == $mysql_keys['perm_admin_settings_lang']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_rights_edit_lang_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_rights_edit_mail']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_settings_mail" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_settings_mail'] == $mysql_keys['perm_admin_settings_mail']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_rights_edit_mail_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_rights_edit_module']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_settings_module" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_settings_module'] == $mysql_keys['perm_admin_settings_module']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_rights_edit_module_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_rights_edit_designs']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_settings_designs" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_settings_designs'] == $mysql_keys['perm_admin_settings_designs']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_rights_edit_designs_info']; ?></small>
							</div>
						</div><div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['hp_rights_edit_sites']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_settings_sites" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_settings_sites'] == $mysql_keys['perm_admin_settings_sites']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['hp_rights_edit_sites_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['user_add']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_users_add" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_users_add'] == $mysql_keys['perm_admin_users_add']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['user_add_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['user_delete']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_users_delete" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_users_delete'] == $mysql_keys['perm_admin_users_delete']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['user_delete_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['user_edit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_users_edit" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_users_edit'] == $mysql_keys['perm_admin_users_edit']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['user_edit_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['logs']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_logs" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_logs'] == $mysql_keys['perm_admin_logs']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['logs_info']; ?></small>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="teamspeak" role="tabpanel">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_rights_edit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_instances_ts" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_instances_ts'] == $mysql_keys['perm_admin_instances_ts']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['ts3_rights_edit_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_rights_add']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_instances_ts_add" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_instances_ts_add'] == $mysql_keys['perm_admin_instances_ts_add']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['ts3_rights_add_info']; ?></small>
							</div>
						</div><div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_rights_delete']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_admin_instances_ts_delete" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_instances_ts_delete'] == $mysql_keys['perm_admin_instances_ts_delete']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['ts3_rights_delete_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['instance_msg_poke']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_teamspeak_global_msg_poke" type="checkbox" <?php echo ($choosedUserRight['data']['perm_teamspeak_global_msg_poke'] == $mysql_keys['perm_teamspeak_global_msg_poke']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['instance_msg_poke_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['create_server']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_teamspeak_create_server" type="checkbox" <?php echo ($choosedUserRight['data']['perm_teamspeak_create_server'] == $mysql_keys['perm_teamspeak_create_server']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['create_server_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['delete_server']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_teamspeak_delete_server" type="checkbox" <?php echo ($choosedUserRight['data']['perm_teamspeak_delete_server'] == $mysql_keys['perm_teamspeak_delete_server']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['delete_server_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['access_to_all_server']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="perm_teamspeak_access_server" type="checkbox" <?php echo ($choosedUserRight['data']['perm_teamspeak_access_server'] == $mysql_keys['perm_teamspeak_access_server']) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['access_to_all_server_info']; ?></small>
							</div>
						</div>
					</div>
					<?php if($mysql_modul['data']['splamy_musicbot'] == "true") { ?>
						<div class="tab-pane fade" id="bot" role="tabpanel">
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['bot_rights_edit']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="perm_admin_instances_bot" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_instances_bot'] == $mysql_keys['perm_admin_instances_bot']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['bot_rights_edit_info']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['bot_rights_add']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="perm_admin_instances_bot_add" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_instances_bot_add'] == $mysql_keys['perm_admin_instances_bot_add']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['bot_rights_add_info']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['bot_rights_delete']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="perm_admin_instances_bot_delete" type="checkbox" <?php echo ($choosedUserRight['data']['perm_admin_instances_bot_delete'] == $mysql_keys['perm_admin_instances_bot_delete']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['bot_rights_delete_info']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['bot_rights_create_bot']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="perm_bot_create_bot" type="checkbox" <?php echo ($choosedUserRight['data']['perm_bot_create_bot'] == $mysql_keys['perm_bot_create_bot']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['bot_rights_create_bot_info']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['bot_rights_delete_bot']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="perm_bot_delete_bot" type="checkbox" <?php echo ($choosedUserRight['data']['perm_bot_delete_bot'] == $mysql_keys['perm_bot_delete_bot']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['bot_rights_delete_bot_info']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['bot_rights_access_bot']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="perm_bot_access_bot" type="checkbox" <?php echo ($choosedUserRight['data']['perm_bot_access_bot'] == $mysql_keys['perm_bot_access_bot']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['bot_rights_access_bot_info']; ?></small>
								</div>
							</div>
						</div>
					<?php }; ?>
				</div>
			</div>
		</div>
		<div id="server-perm">
			<div class="tabs shadow-none">
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link active" href="#server-teamspeak" data-toggle="tab" role="tab">Teamspeak</a>
					</li>
					<?php if($mysql_modul['data']['splamy_musicbot'] == "true") { ?>
						<li class="nav-item">
							<a class="nav-link" href="#server-bot" data-toggle="tab" role="tab">Bot</a>
						</li>
					<?php }; ?>
				</ul>
				<div class="tab-content form">
					<div class="tab-pane fade show active" id="server-teamspeak" role="tabpanel">
						<div class="alert alert-table alert-warning <?php echo ($choosedUserRight['data']['perm_teamspeak_access_server'] == $mysql_keys['perm_teamspeak_access_server']) ? '' : 'd-none'; ?>">
							<i class="fas fa-exclamation-triangle"></i>
							<span><?php echo $language['attention_serverpermission']; ?></span>
						</div>
						<div class="form">
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['instance']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<select id="server-instance" class="form-control form-control-sm" <?php echo ($choosedUserRight['data']['perm_teamspeak_access_server'] == $mysql_keys['perm_teamspeak_access_server']) ? 'disabled' : 'onChange="getPortsFromInstance(\'server-instance\', \'server-port\', false, showServerSection);"'; ?>>
										<option class="d-none" selected><?php echo $language['choose']; ?></option>
										<?php if(!empty($ts3_server)) {
												foreach($ts3_server AS $num=>$instanz) { ?>
													<option value="<?php echo $num; ?>"><?php xssEcho($instanz['alias']); ?></option>
											<?php };
										}; ?>
									</select>
									<small class="form-text text-muted"><?php echo $language['instance_choose']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<select id="server-port" class="form-control form-control-sm" disabled>
										<option selected><?php echo $language['choose']; ?></option>
									</select>
									<small class="form-text text-muted"><?php echo $language['port_choose']; ?></small>
								</div>
							</div>
							<div id="perm-ts-server" style="display: none;">
								<hr class="mt-4"/>
								<?php
									$titles = array(
										'perm_ts_server_start_stop' => 'server_start_stop',
										'perm_ts_server_create_channel' => 'create_channel',
										'perm_ts_server_delete_channel' => 'delete_channel',
										'perm_ts_server_message_poke' => 'server_msg_poke',
										'perm_ts_server_mass_actions' => 'server_mass_actions',
										'perm_ts_server_client_actions' => 'client_actions',
										'perm_ts_server_client_sgroups' => 'client_permission',
										'perm_ts_server_edit_groups' => 'edit_groups',
										'perm_ts_server_clients' => 'server_clients',
										'perm_ts_server_delete_clients' => 'server_delete_clients',
										'perm_ts_server_protocol' => 'server_protokoll',
										'perm_ts_server_token' => 'server_token',
										'perm_ts_server_bans' => 'server_bans',
										'perm_ts_server_icons' => 'server_icons',
										'perm_ts_server_filelist' => 'server_filelist',
										'perm_ts_server_create_backups' => 'server_create_backups',
										'perm_ts_server_use_backups' => 'server_use_backups',
										'perm_ts_server_delete_backups' => 'server_delete_backups'
									);
									$titlesEdit = array(
										'perm_ts_server_edit' => 'server_edit',
										'perm_ts_server_edit_name' => 'change_server_name',
										'perm_ts_server_edit_port' => 'change_server_port',
										'perm_ts_server_edit_clients' => 'change_server_slots',
										'perm_ts_server_edit_password' => 'change_server_password',
										'perm_ts_server_edit_welcome' => 'change_server_welcome',
										'perm_ts_server_edit_complain' => 'change_complainsettings',
										'perm_ts_server_edit_host' => 'change_hostsettings',
										'perm_ts_server_edit_antiflood' => 'change_antifloodsettings',
										'perm_ts_server_edit_transfer' => 'change_transfersettings',
										'perm_ts_server_edit_protocol' => 'change_protokollsettings'
									);

									foreach($titles AS $name=>$key) {
										echo '<div class="row mr-0 ml-0">
												<label class="col-lg-4 form-label color-light">'.$language[$key].':</label>
												<div class="col-lg-8 col-xl-4">
													<div class="switch">
														<label>
															<input id="'.$name.'" type="checkbox">
															&nbsp;
														</label>
													</div>
													<small class="form-text text-muted">'.$language[$key.'_info'].'</small>
												</div>
											</div>';
									};

									echo '<hr/>';

									$disabled = ($choosedUserRight['data']['perm_ts_server_edit'] == $mysql_keys['perm_ts_server_edit']) ? '' : 'disabled';
									foreach($titlesEdit AS $name=>$key) {
										$switch = '';
										if($name === 'perm_ts_server_edit') {
											$switch = 'class="switch-disable" data-disable="edit-disable"';
										} else {
											$switch = 'class="edit-disable '.$disabled.'" '.$disabled.'';
										};

										echo '<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light">'.$language[$key].':</label>
											<div class="col-lg-8 col-xl-4">
												<div class="switch">
													<label>
														<input id="'.$name.'" type="checkbox" '.$switch.'>
														&nbsp;
													</label>
												</div>
												<small class="form-text text-muted">'.$language[$key.'_info'].'</small>
											</div>
										</div>';
									};
								?>
							</div>
						</div>
					</div>
					<?php if($mysql_modul['data']['splamy_musicbot'] == "true") { ?>
						<div class="tab-pane fade" id="server-bot" role="tabpanel">
							<div class="alert alert-table alert-warning <?php echo ($choosedUserRight['data']['perm_bot_access_bot'] == $mysql_keys['perm_bot_access_bot']) ? '' : 'd-none'; ?>">
								<i class="fas fa-exclamation-triangle"></i>
								<span><?php echo $language['attention_serverpermission']; ?></span>
							</div>
							<div class="form">
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['instance']; ?>:</label>
									<div class="col-lg-8 col-xl-4">
										<select id="bot-instance" class="form-control form-control-sm" <?php echo ($choosedUserRight['data']['perm_bot_access_bot'] == $mysql_keys['perm_bot_access_bot']) ? 'disabled' : 'onChange=""'; ?>>
											<option class="d-none" selected><?php echo $language['choose']; ?></option>
											<?php if(!empty($music_server)) {
													foreach($music_server AS $num=>$instanz) { ?>
														<option value="<?php echo $num; ?>"><?php xssEcho($instanz['alias']); ?></option>
												<?php };
											}; ?>
										</select>
										<small class="form-text text-muted"><?php echo $language['smtp_encoding_info']; ?></small>
									</div>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
									<div class="col-lg-8 col-xl-4">
										<select id="server-port" class="form-control form-control-sm" disabled>
											<option selected><?php echo $language['choose']; ?></option>
										</select>
										<small class="form-text text-muted"><?php echo $language['smtp_encoding_info']; ?></small>
									</div>
								</div>
								<hr />
							</div>
						</div>
					<?php }; ?>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/admin.js"></script>
<script>
	/**
		PHP Vars
	*/
	var pk = "<?php echo $_POST['id']; ?>";

	/**
		Server permissions
	 */
	$('#server-port').change(function (e) { 
		showServerSection();
	});

	function showServerSection() {
		const instance = $('#server-instance').val();
		const port = $('#server-port').val();
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsSqlPost.php",
			data: {
				action: 'getClientPortPermissions',
				pk: pk
			},
			success: function(data){
				var info = JSON.parse(data);
				
				if(info.success) {
					for(var i in info.data) {
						if(info.data[i][instance] === undefined) {
							$('#'+i).prop('checked', (i.includes('perm_ts_server_edit_') && i !== 'perm_ts_server_edit_groups'));
						} else {
							if(i.includes('perm_ts_server_edit_') && i !== 'perm_ts_server_edit_groups') {
								$('#'+i).prop('checked', !info.data[i][instance].includes($('#server-port').val()));
							} else {
								$('#'+i).prop('checked', info.data[i][instance].includes($('#server-port').val()));
							};
						};
					};
					$('#perm-ts-server').slideDown("fast");
				} else {
					new Notification({
						message : info.error,
						icon: 'far fa-list',
						type : 'danger'
					}).show();
				};
			}
		});
	};
	
	/**
		Block / unblock client
	*/
	$('.profile-header .profile-text button').click(function() {
		var el = $(this);
		var isBlocked = $('span', el).text() == lang.blocked
		var heading = (isBlocked) ? lang.user_unblock : lang.user_block;
		var infotext = (isBlocked) ? lang.user_unblocked : lang.user_blocked;
		
		new AreUSure({
			label: heading,
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'setClientBlock',
						pk: pk,
						blocked: !isBlocked
					},
					success: function(data){
						var info = JSON.parse(data);
						
						if(info.success) {
							swal(lang.succeeded, infotext, 'success');
							
							if(isBlocked) {
								el.removeClass('btn-danger').addClass('btn-success');
								$('i', el).removeClass('fa-ban').addClass('fa-check');
								$('span', el).text(lang.unblocked);
								el.blur();
							} else {
								el.removeClass('btn-success').addClass('btn-danger');
								$('i', el).removeClass('fa-check').addClass('fa-ban');
								$('span', el).text(lang.blocked);
								el.blur();
							};
						} else {
							swal(lang.aborted, info.error, 'error');
						};
					}
				});
			}
		});
	});
	
	/**
		Save changed settings
	*/
	$('a#save-profile').click(function(e) {
		var el = $(this);
		var link = $('.profile-sub-header a.active').attr('href');
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		
		el.addClass('disabled');
		
		switch(link) {
			case '#home':
				if(!isDataValid('profileUser') || !isDataValid('profileFirstname') || !isDataValid('profileLastname')) {
					el.removeClass('disabled');
					return;
				};
				
				var data = {
					user: $('#profileUser').val(),
					password: $('#profilePassword').val(),
					firstname: encodeURIComponent($('#profileFirstname').val()),
					lastname: encodeURIComponent($('#profileLastname').val()),
					phone: encodeURIComponent($('#profilePhone').val()),
					homepage: encodeURIComponent($('#profileHomepage').val()),
					skype: encodeURIComponent($('#profileSkype').val()),
					steam: encodeURIComponent($('#profileSteam').val()),
					twitter: encodeURIComponent($('#profileTwitter').val()),
					facebook: encodeURIComponent($('#profileFacebook').val()),
					google: encodeURIComponent($('#profileGoogle').val())
				};
				
				if(data.password !== $('#profilePassword2').val()) {
					isError('#profilePassword', lang.password_not_equal.replace('&ouml;', '\u00f6'));
					isError('#profilePassword2', lang.password_not_equal.replace('&ouml;', '\u00f6'));
					el.removeClass('disabled');
					return;
				} else {
					resetMessages('#profilePassword');
					resetMessages('#profilePassword2');
					
					$.ajax({
						type: "POST",
						url: "./php/functions/functionsSqlPost.php",
						data: {
							action: 'updateUser',
							pk: pk,
							data: JSON.stringify(data)
						},
						success: function(data) {
							var json = JSON.parse(data);
							if(json.success) {
								new Notification({
									message : lang.settigns_saved,
									icon: 'far fa-save',
									type : 'success'
								}).show();
							} else {
								new Notification({
									message : json.error,
									icon: 'far fa-save',
									type : 'danger'
								}).show();
							};
							el.removeClass('disabled');
						}
					});
				};
				break;
			case '#globe-perm':
				var data = { };
				$('#globe-perm.active input').each(function() {
					data[$(this).attr('id')] = $(this).prop('checked');
				});

				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'setGlobePerm',
						pk: pk,
						data: JSON.stringify(data)
					},
					success: function(string) {
						var json = JSON.parse(string);

						if(json.success) {
							new Notification({
								message : lang.settigns_saved,
								icon: 'far fa-save',
								type : 'success'
							}).show();
							
							if(data.perm_bot_access_bot) {
								$('#server-bot > .alert').removeClass('d-none');
								$('#server-bot select').prop('disabled', true);
							} else {
								$('#server-bot > .alert').addClass('d-none');
								$('#server-bot select#bot-instance').prop('disabled', false);
							};
							
							if(data.perm_teamspeak_access_server) {
								$('#server-teamspeak > .alert').removeClass('d-none');
								$('#server-teamspeak select').prop('disabled', true);
								$('#perm-ts-server').css('display', 'none');
								$('#server-instance').attr('onchange', '');
							} else {
								$('#server-teamspeak > .alert').addClass('d-none');
								$('#server-teamspeak select#server-instance').prop('disabled', false);
								$('#server-instance').attr('onchange', 'getPortsFromInstance(\'server-instance\', \'server-port\', false, showServerSection);');
							};
						} else {
							new Notification({
								message : json.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			case '#server-perm':
				if($('#perm-ts-server').css('display') === 'none') {
					el.removeClass('disabled');
					return;
				};

				var data = {
					instance: $('#server-instance').val(),
					port: $('#server-port').val()
				};
				$('#server-perm.active #perm-ts-server input').each(function() {
					var id = $(this).attr('id');
					if(id.includes('perm_ts_server_edit_') && id !== 'perm_ts_server_edit_groups') {
						data[$(this).attr('id')] = !$(this).prop('checked');
					} else {
						data[$(this).attr('id')] = $(this).prop('checked');
					};
				});
				el.removeClass('disabled');
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'setServerPerm',
						pk: pk,
						data: JSON.stringify(data)
					},
					success: function(string) {
						var json = JSON.parse(string);
						
						if(json.success) {
							new Notification({
								message : lang.settigns_saved,
								icon: 'far fa-save',
								type : 'success'
							}).show();
						} else {
							new Notification({
								message : json.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
		};
	});
	
	/**
		Validate check
	*/
	validateOnChange('#profileUser', {
		required: true,
		email: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#profileFirstname', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#profileLastname', {
		required: true
	}, '', lang.field_cant_be_empty);
</script>