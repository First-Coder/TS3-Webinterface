 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../classes/ts3admin.class.php");
	
	/*
		Variables
	*/
	$LoggedIn		=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys		=	getKeys();
	$mysql_modul	=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right				=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_hp_user_edit']['key'] != $mysql_keys['right_hp_user_edit'] && $user_right['right_hp_user_create']['key'] != $mysql_keys['right_hp_user_create']
		&& $user_right['right_hp_user_delete']['key'] != $mysql_keys['right_hp_user_delete'])
	{
		reloadSite();
	};
	
	/*
		Set the selected Client to the First one in the List
	*/
	$choosedUserRight		=	getUserRights('pk', $_POST['id'], false, 'all');
	$choosedUserBlock		=	getUserBlock($_POST['id']);
	$userInformations		=	getUserInformations($_POST['id']);
	
	/*
		Teamspeak Funktions
	*/
	$ts3_servers							=	array();
	foreach ($ts3_server AS $server_number => $server)
	{
		$tsAdmin 							= 	new ts3admin($server['ip'], $server['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($server['user'], $server['pw']);
			$ts3_servers[$server_number]	=	$tsAdmin->serverList();
			$tsAdmin->logout();
		};
	};
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row m-b-40">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="row">
					<div class="col-md-4 mb-3">
						<div>
							<div class="dashboard-profile">
								<div class="row">
									<div class="col-md-12">
										<img class="img-circle h-100 w-100" src="<?php echo getUserPicture($_POST['id']); ?>" alt="face" />
										<h5 id="mailOverview" pk="<?php echo $_POST['id']; ?>"><?php xssEcho($_POST['mail']); ?></h5>
									</div>
								</div>
								<div class="row stats">
									<div class="col-xs-12">
										<p class="pt-2"><?php echo $language['last_login']; ?>: <?php xssEcho($_POST['lastLogin']); ?></p>
									</div>
								</div>
							</div>
						</div>
						<button onClick="changeContent('web_admin_user');" class="btn btn-outline-info mt-3 mb-3 w-100-percent"><i class="fa fa-arrow-left" aria-hidden="true"></i> <?php echo $language['back']; ?></button>
					</div>
					<div class="col-md-8">
						 <ul class="list-group listodd">
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['vorname'] == '') ? $language['no_information'] : $userInformations['vorname']); ?></p>
									<p class="list-group-item-text"><?php echo $language['firstname']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-user"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['nachname'] == '') ? $language['no_information'] : $userInformations['nachname']); ?></p>
									<p class="list-group-item-text"><?php echo $language['lastname']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-user"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['telefon'] == '') ? $language['no_information'] : $userInformations['telefon']); ?></p>
									<p class="list-group-item-text"><?php echo $language['telefon']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-phone"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['homepage'] == '') ? $language['no_information'] : $userInformations['homepage']); ?></p>
									<p class="list-group-item-text"><?php echo $language['homepage']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-globe"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['skype'] == '') ? $language['no_information'] : $userInformations['skype']); ?></p>
									<p class="list-group-item-text"><?php echo $language['skype']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-skype"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['steam'] == '') ? $language['no_information'] : $userInformations['steam']); ?></p>
									<p class="list-group-item-text"><?php echo $language['steam']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-steam"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['twitter'] == '') ? $language['no_information'] : $userInformations['twitter']); ?></p>
									<p class="list-group-item-text"><?php echo $language['twitter']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-twitter"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['facebook'] == '') ? $language['no_information'] : $userInformations['facebook']); ?></p>
									<p class="list-group-item-text"><?php echo $language['facebook']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-facebook"></i>
							</li>
							<li class="list-group-item">
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php xssEcho(($userInformations['google'] == '') ? $language['no_information'] : $userInformations['google']); ?></p>
									<p class="list-group-item-text"><?php echo $language['google_plus']; ?></p>
								</div>
								<i class="pull-xs-right fa fa-google-plus"></i>
							</li>
						</ul>
					</div>
				</div>
				<?php if($user_right['right_hp_user_edit']['key'] == $mysql_keys['right_hp_user_edit']) { ?>
					<hr class="mt-3 hr-headline"/>
					<ul class="mt-3 nav nav-tabs">
						<li class="nav-item">
							<a href="#" class="nav-link active" data-toggle="tab" data-target="#global-permissions"><?php echo $language['global_rights']; ?></a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#global-serverpermissions"><?php echo $language['server_permission']; ?></a>
						</li>
					</ul>
					<div class="tab-content form-secondary">
						<div role="tabpanel" class="tab-pane active" id="global-permissions">
							<h4 class="mt-3"><i class="fa fa-sign-in"></i> <?php echo $language['userdata']; ?></h4>
							<h6 class="card-subtitle text-muted mb-3"><?php echo $language['userdata_info']; ?></h6>
							
							<label><?php echo $language['user_blocked']; ?></label>
							<div class="row">
								<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
									<div class="switch switch-danger" style="display: inline;">
										<label>
											<input area="user" id="adminCheckboxBlocked" <?php echo ($choosedUserBlock['blocked'] == "true") ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxBlockedText"><?php echo ($choosedUserBlock['blocked'] == "true") ? $language['blocked'] : $language['unblocked']; ?></span>
										</label>
									</div>
								</div>
								<div class="col-xs-6 col-sm-6 col-md-8">
									<input area="user" id="adminDatapickerBlocked" timestamp="<?php echo ($choosedUserBlock['until'] > 0) ? $choosedUserBlock['until'] : "-1"; ?>" <?php echo ($choosedUserBlock['blocked'] == "true") ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
								</div>
							</div>
							<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['user_blocked_admin_info']; ?></span>
							<div class="form-group">
								<label style="font-size: 1rem;top: 0.7rem;"><?php echo $language['mail']; ?></label>
								<input area="user" id="adminUsername" type="email" class="form-control" placeholder="&#xF090; <?php xssEcho($_POST['mail']); ?>" style="font-family:Arial, FontAwesome">
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['mail_help']; ?></span>
							</div>
							
							<div class="form-group">
								<label style="font-size: 1rem;top: 0.7rem;"><?php echo $language['password']; ?></label>
								<input area="user" id="adminPassword" type="password" class="form-control" placeholder="&#xF084; ******" style="font-family:Arial, FontAwesome">
							</div>
							<div class="form-group pt-0">
								<input area="user" id="adminPassword2" type="password" class="form-control" placeholder="&#xF021; ******" style="font-family:Arial, FontAwesome">
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['password_help']; ?></span>
							</div>
							
							<h4 class="mt-3"><i class="fa fa-globe"></i> <?php echo $language['hp_rights']; ?></h4>
							<h6 class="card-subtitle text-muted mb-3"><?php echo $language['global_rights']; ?></h6>
							<div>
								<?php $permission		=	($choosedUserRight['right_hp_main']['time'] == '0' || $choosedUserRight['right_hp_main']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['hp_rights_edit']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsEdit" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsEditText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input id="adminDatapickerRightsEdit" timestamp="<?php echo ($choosedUserRight['right_hp_main']['time'] > 0) ? $choosedUserRight['right_hp_main']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['hp_rights_edit_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_hp_ts3']['time'] == '0' || $choosedUserRight['right_hp_ts3']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['ts3_rights_edit']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsTSEdit" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsTSEditText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="homepage" id="adminDatapickerRightsTSEdit" timestamp="<?php echo ($choosedUserRight['right_hp_ts3']['time'] > 0) ? $choosedUserRight['right_hp_ts3']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['ts3_rights_edit_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_hp_user_create']['time'] == '0' || $choosedUserRight['right_hp_user_create']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['user_add']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsUserCreate" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsUserCreateText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="homepage" id="adminDatapickerRightsUserCreate" timestamp="<?php echo ($choosedUserRight['right_hp_user_create']['time'] > 0) ? $choosedUserRight['right_hp_user_create']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['user_add_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_hp_user_delete']['time'] == '0' || $choosedUserRight['right_hp_user_delete']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['user_delete']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsUserDelete" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsUserDeleteText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="homepage" id="adminDatapickerRightsUserDelete" timestamp="<?php echo ($choosedUserRight['right_hp_user_delete']['time'] > 0) ? $choosedUserRight['right_hp_user_delete']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['user_delete_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_hp_user_edit']['time'] == '0' || $choosedUserRight['right_hp_user_edit']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['user_edit']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsUserEdit" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsUserEditText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="homepage" id="adminDatapickerRightsUserEdit" timestamp="<?php echo ($choosedUserRight['right_hp_user_edit']['time'] > 0) ? $choosedUserRight['right_hp_user_edit']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['user_edit_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_hp_ticket_system']['time'] == '0' || $choosedUserRight['right_hp_ticket_system']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['ticket_admin']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsTicketsystem" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsTicketsystemText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="homepage" id="adminDatapickerRightsTicketsystem" timestamp="<?php echo ($choosedUserRight['right_hp_ticket_system']['time'] > 0) ? $choosedUserRight['right_hp_ticket_system']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['ticket_admin_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_hp_mails']['time'] == '0' || $choosedUserRight['right_hp_mails']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['mail_settings']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsMails" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsMailsText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="homepage" id="adminDatapickerRightsMails" timestamp="<?php echo ($choosedUserRight['right_hp_mails']['time'] > 0) ? $choosedUserRight['right_hp_mails']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['mail_settings_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_hp_logs']['time'] == '0' || $choosedUserRight['right_hp_logs']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['logs']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="homepage" id="adminCheckboxRightsLogs" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsLogsText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="homepage" id="adminDatapickerRightsLogs" timestamp="<?php echo ($choosedUserRight['right_hp_logs']['time'] > 0) ? $choosedUserRight['right_hp_logs']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['logs_info']; ?></span>
							</div>
							
							<h4 class="mt-3"><i class="fa fa-globe"></i> <?php echo $language['ts_rights']; ?></h4>
							<h6 class="card-subtitle text-muted mb-3"><?php echo $language['global_rights']; ?></h6>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_web']['time'] == '0' || $choosedUserRight['right_web']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['access_interface']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="teamspeak" id="adminCheckboxRightWeb" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightWebText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="teamspeak" id="adminDatapickerRightsWeb" timestamp="<?php echo ($choosedUserRight['right_web']['time'] > 0) ? $choosedUserRight['right_web']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['access_interface_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_web_global_message_poke']['time'] == '0' || $choosedUserRight['right_web_global_message_poke']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['instance_msg_poke']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="teamspeak" id="adminCheckboxRightWebGlobalMessagePoke" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightWebGlobalMessagePokeText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="teamspeak" id="adminDatapickerRightsWebGlobalMessagePoke" timestamp="<?php echo ($choosedUserRight['right_web_global_message_poke']['time'] > 0) ? $choosedUserRight['right_web_global_message_poke']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['instance_msg_poke_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_web_server_create']['time'] == '0' || $choosedUserRight['right_web_server_create']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['create_server']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="teamspeak" id="adminCheckboxRightWebServerCreate" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightWebServerCreateText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="teamspeak" id="adminDatapickerRightsWebServerCreate" timestamp="<?php echo ($choosedUserRight['right_web_server_create']['time'] > 0) ? $choosedUserRight['right_web_server_create']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['create_server_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_web_server_delete']['time'] == '0' || $choosedUserRight['right_web_server_delete']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['delete_server']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="teamspeak" id="adminCheckboxRightWebServerDelete" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightWebServerDeleteText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="teamspeak" id="adminDatapickerRightsWebServerDelete" timestamp="<?php echo ($choosedUserRight['right_web_server_delete']['time'] > 0) ? $choosedUserRight['right_web_server_delete']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['delete_server_info']; ?></span>
							</div>
							<div class="mt-3">
								<?php $permission		=	($choosedUserRight['right_web_global_server']['time'] == '0' || $choosedUserRight['right_web_global_server']['time'] > time()) ? true : false; ?>
								<label><?php echo $language['access_to_all_server']; ?></label>
								<div class="row">
									<div class="col-xs-6 col-sm-6 col-md-4" style="text-align: center;">
										<div class="switch switch-success" style="display: inline;">
											<label>
												<input area="teamspeak" id="adminCheckboxRightsWebGlobalServer" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><span id="adminCheckboxRightsWebGlobalServerText"><?php echo ($permission) ? $language['yes'] : $language['no']; ?></span>
											</label>
										</div>
									</div>
									<div class="col-xs-6 col-sm-6 col-md-8">
										<input area="teamspeak" id="adminDatapickerRightsWebGlobalServer" timestamp="<?php echo ($choosedUserRight['right_web_global_server']['time'] > 0) ? $choosedUserRight['right_web_global_server']['time'] : "-1"; ?>" <?php echo ($permission) ? "" : "disabled"; ?> type="text" class="form-control datepicker" placeholder="<?php echo $language['unlimited']; ?>">
									</div>
								</div>
								<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['access_to_all_server_info']; ?></span>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="global-serverpermissions">
							<div id="alert-global-admin" class="alert alert-warning" style="display: <?php echo ($choosedUserRight['right_web_global_server']['key'] == $mysql_keys['right_web_global_server']) ? "block" : "none"; ?>">
								<b><i class="fa fa-warning" aria-hidden="true"></i> <?php echo $language['attention']; ?>!</b>
								<p><?php echo $language['attention_serverpermission']; ?></p>
							</div>
							
							<?php if(sizeof($ts3_servers) > 0)
							{
								foreach($ts3_server AS $instanz => $values)
								{
									if(!empty($ts3_servers[$instanz]['data']))
									{
										foreach($ts3_servers[$instanz]['data'] AS $number => $port)
										{
											$permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_view')) ? true : false; ?>
											<div class="card-block">
												<div id="colorBox_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" class="alert alert-outline-<?php echo ($permission) ? "success" : "danger"; ?>">
													<div style="cursor:pointer;" onClick="slideMe('permissionbox_<?php echo $instanz; ?>_<?php echo $port['virtualserver_port']; ?>', 'permissionboxicon_<?php echo $instanz; ?>_<?php echo $port['virtualserver_port']; ?>');">
														<h5 class="card-title">
															<div class="pull-xs-left <?php echo (isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_view')) ? "text-success" : ""; ?>">
																<i id="permissionboxicon_<?php echo $instanz; ?>_<?php echo $port['virtualserver_port']; ?>" class="fa fa-fw fa-arrow-right"></i>
																<?php echo $language['port']; ?>: <?php echo $port['virtualserver_port']; ?>
															</div>
															<div class="pull-xs-right">
																<button id="saveButton_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" onClick="adminProfilUpdatePorts('<?php echo $port['virtualserver_port']; ?>', '<?php echo $instanz; ?>');" style="display: none;" class="btn btn-outline-success"><i class="fa fa-save" aria-hidden="true"></i> <span class="hidden-xs-down"><?php echo $language['save']; ?></span></button>
															</div>
															<div style="clear:both;"></div>
														</h5>
														<h6 class="card-subtitle  text-muted"><?php echo $language['instance']; ?>: <?php echo ($values['alias'] != '') ? $values['alias'] : $values['ip']; ?></h6>
													</div>
													<div class="card-block" style="padding: 0 1.25rem;color: #212121;">
														<div id="permissionbox_<?php echo $instanz; ?>_<?php echo $port['virtualserver_port']; ?>" style="display:none;margin-top:20px;">
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_view']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerView_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerView_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_view_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_banner')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['serverbanner']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerBanner_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerBanner_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['serverbanner_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_clients')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_clients']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerClients_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerClients_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_clients_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_start_stop')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_start_stop']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerStartStop_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerStartStop_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_start_stop_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_message_poke')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_msg_poke']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerMessagePoke_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerMessagePoke_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_msg_poke_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_mass_actions')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_mass_actions']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerMassActions_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerMassActions_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_mass_actions_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_protokoll')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_protokoll']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerProtokoll_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerProtokoll_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_protokoll_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_icons')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_icons']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerIcons_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerIcons_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_icons_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_bans')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_bans']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerBans_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerBans_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_bans_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_token')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_token']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerToken_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerToken_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_token_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_file_transfer')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_filelist']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerFilelist_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerFilelist_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_filelist_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_backups')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_backups']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerBackups_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerBackups_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_backups_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_server_edit')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['server_edit']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerEdit_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerEdit_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<button class="btn btn-info btn-flat w-100-percent btn-sm btn-raised serverEditBlockIcon" data-id="<?php echo $_POST['id']; ?>" data-instanz="<?php echo $instanz; ?>" data-port="<?php echo $port['virtualserver_port']; ?>">
																	<i class="fa fa-eye" aria-hidden="true"></i> <?php echo $language['server_edit_subcategory']; ?>
																</button>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['server_edit_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_client_actions')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['client_actions']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerClientActions_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerClientActions_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['client_actions_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_client_rights')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['client_permission']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerClientRights_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerClientRights_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['client_permission_info']; ?></span>
															</div>
															
															<?php $permission		=	(isPortPermission($choosedUserRight, $instanz, $port['virtualserver_port'], 'right_web_channel_actions')) ? true : false; ?>
															<div class="mt-3">
																<label class="pull-xs-left"><?php echo $language['channel_actions']; ?></label>
																<div class="switch switch-success pull-xs-right">
																	<label>
																		<input area="port" id="adminCheckboxRightWebServerChannelActions_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>" <?php echo ($permission) ? "checked" : ""; ?> type="checkbox"><font id="adminCheckboxRightWebServerChannelActions_<?php echo $port['virtualserver_port']; ?>_<?php echo $instanz; ?>Text"><?php echo ($permission) ? $language['unblocked'] : $language['blocked']; ?></font>
																	</label>
																</div>
																<div style="clear: both;"></div>
																<span class="text-muted" style="font-size: 0.75rem;"><?php echo $language['channel_actions_info']; ?></span>
															</div>
														</div>
													</div>
												</div>
											</div>
										<?php };
									};
								};
							}; ?>
						</div>
					</div>
				<?php }; ?>
			</div>
		</div>
	</div>
</div>

<!-- Modal: Server edit -->
<div id="modalServerEdit" class="modal modal-info fade scale" data-backdrop="true" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="modalLabel"><?php echo $language['server_edit']; ?></h4>
			</div>
			<div class="modal-body">
				<div id="editServerEditLoading" class="row">
					<div class="col-lg-12 col-md-12" style="text-align:center;">
						<i style="font-size:100px;" class="fa fa-cogs fa-spin"></i>
					</div>
				</div>
				<div id="editServerEditContent" class="card-block" style="display:none;">
					<p style="text-align: center;"><?php echo $language['server_edit_settings_info']; ?></p>
					
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_server_port']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditPort" right="right_server_edit_port" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_server_slots']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditSlots" right="right_server_edit_slots" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_autostart']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditAutostart" right="right_server_edit_autostart" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_min_client']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditMinClientVersion" right="right_server_edit_min_client_version" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_main_settings']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditMainSettings" right="right_server_edit_main_settings" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_default_group']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditDefaultServerGroups" right="right_server_edit_default_servergroups" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_hostsettings']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditHostSettings" right="right_server_edit_host_settings" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_complainsettings']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditComplaintSettings" right="right_server_edit_complain_settings" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_antifloodsettings']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditAntiFloodSettings" right="right_server_edit_antiflood_settings" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_transfersettings']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditTransferSettings" right="right_server_edit_transfer_settings" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
					<div class="mt-3">
						<label class="pull-xs-left pt-2"><?php echo $language['change_protokollsettings']; ?></label>
						<div class="switch switch-success pull-xs-right">
							<label>
								<input id="adminCheckboxRightServerEditProtokollSettings" right="right_server_edit_protokoll_settings" type="checkbox" class="serverEditChangeClass">
							</label>
						</div>
						<div style="clear: both;"></div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button onClick="closeModalServerEdit();" type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-fw fa-close"></i> <?php echo $language['abort']; ?></button>
				<button onClick="saveServerEditSettingsBttn();closeModalServerEdit();" id="saveServerEditSettingsBttn" type="button" class="btn btn-success" data-dismiss="modal"><i class="fa fa-fw fa-check"></i> <?php echo $language['save']; ?></button>
			</div>
		</div>
	</div>
</div>

<script src="js/other/moment.js"></script>
<script src="js/bootstrap/bootstrap-material-datetimepicker.js"></script>
<script src="js/webinterface/admin.js"></script>
<script>
	/*
		Remove / Show Overlaybutton on Navigation switch
	*/
	$('.nav-item>a').click(function()
	{
		if($(this).attr("data-target") == "#global-permissions")
		{
			if(changedUser || changedHomepage || changedTeamspeak)
			{
				OverlayButton.setButton(true);
			};
		}
		else
		{
			OverlayButton.setButton(false);
		};
	});
	
	/*
		Changes Text / Classes / Datapicker if you click on a switch
	*/
	$('.switch>label>input').change(function()
	{
		if($(this).attr("area") == "port")
		{
			var idParts		=	$(this).attr("id").split("_");
			$('#saveButton_'+idParts[1]+'_'+idParts[2]).fadeIn("slow");
			
			$('#'+$(this).attr("id")+'Text').text(($(this).prop("checked")) ? lang.unblocked : lang.blocked);
		}
		else
		{
			var datapicker		=	$(this).attr("id").replace("Checkbox", "Datapicker");
			
			if($(this).prop("checked"))
			{
				$('#'+$(this).attr("id")+'Text').text(($(this).attr("id") == "adminCheckboxBlocked") ? lang.blocked : lang.yes);
				$('#'+datapicker).prop("disabled", false);
				$('#'+datapicker).bootstrapMaterialDatePicker({
					time: false,
					clearButton: true,
					format: 'DD.MM.YYYY',
					minDate : new Date()
				});
			}
			else
			{
				$('#'+datapicker).val("");
				$('#'+datapicker).prop("disabled", true);
				$('#'+$(this).attr("id")+'Text').text(($(this).attr("id") == "adminCheckboxBlocked") ? lang.unblocked : lang.no);
			};
			
			if($(this).attr("id") == "adminCheckboxRightsWebGlobalServer")
			{
				$('#alert-global-admin').css("display", $("#"+id).is(":checked") ? "block" : "none");
			};
		};
	});
	
	/*
		Detect changed input
	*/
	var changedUser					=	false,
		changedHomepage				=	false,
		changedTeamspeak			=	false;
	
	$('input, select').change(function()
	{
		changeInput($(this));
	});
	$('input').on('input',function()
	{
		changeInput($(this));
	});
	
	function changeInput(element)
	{
		switch(element.attr("area"))
		{
			case "user":
				changedUser			=	true;
				OverlayButton.setButton(true);
				break;
			case "homepage":
				changedHomepage		=	true;
				OverlayButton.setButton(true);
				break;
			case "teamspeak":
				changedTeamspeak	=	true;
				OverlayButton.setButton(true);
				break;
		};
	};
	
	/*
		Overlay button
	*/
	OverlayButton.setButtonClass("btn-secondary");
	OverlayButton.setIconClass("fa-save");
	OverlayButton.setTooltip(lang.save);
	OverlayButton.on("click", function() {
		var status		=	true;
		
		if(changedUser)
		{
			status		=	setGlobalPermissions("user");
		};
		
		if(changedHomepage && status)
		{
			status		=	setGlobalPermissions("homepage");
		};
		
		if(changedTeamspeak && status)
		{
			status		=	setGlobalPermissions("teamspeak");
		};
		
		if(status)
		{
			setNotifySuccess(lang.user_edit_done);
			OverlayButton.setButton(false);
		}
		else
		{
			setNotifyFailed(lang.user_edit_failed);
		};
	});
	OverlayButton.start();
	OverlayButton.setButton(false);
	
	$(function () {
		benutzerChange	=	false;
		
		setTimeout(function()
		{
			$('.datepicker').bootstrapMaterialDatePicker({
				time: false,
				clearButton: true,
				format: 'DD.MM.YYYY',
				minDate : new Date()
			});
			
			$('.datepicker').each(function()
			{
				var timestamp 	=	$(this).attr("timestamp");
				if(timestamp != "-1")
				{
					$(this).bootstrapMaterialDatePicker('setDate', getTime(timestamp));
				};
			});
		}, 500);
	});
	
	$(".serverEditBlockIcon").click(function() {
		var id 			= 	$(this).attr('data-id');
		var instanz 	= 	$(this).attr('data-instanz');
		var port	 	= 	$(this).attr('data-port');
		
		$('#modalServerEdit').find('#saveServerEditSettingsBttn').attr( { pk:id, instanz:instanz, port:port } );
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsSqlPost.php",
			data: {
				action:		'getCheckedClientServerEditRights',
				pk:			escapeText(id),
				port:		escapeText(port),
				instanz:	escapeText(instanz)
			},
			success: function(data)
			{
				if(data == 'null')
				{
					$('.serverEditChangeClass').each(function() {
						$(this).attr('checked','checked');
					});
					
					$('#editServerEditLoading').slideUp("slow", function() {
						$('#editServerEditContent').slideDown("slow");
					});
				}
				else
				{
					var informations		= 	JSON.parse(data);
					
					$('.serverEditChangeClass').each(function() {
						if(typeof(informations[$(this).attr("right")]) == 'undefined')
						{
							$(this).attr('checked','checked');
						};
					});
					
					$('#editServerEditLoading').slideUp("slow", function() {
						$('#editServerEditContent').slideDown("slow");
					});
				};
			}
		});
		$('#modalServerEdit').modal('show');
	});
	
	function closeModalServerEdit()
	{
		$('#editServerEditContent').slideUp("slow", function() {
			$('#editServerEditLoading').slideDown("slow");
		});
	};
	
	function getTime(timestamp)
	{
		var Zeit 			= 	new Date();  
		Zeit.setTime(timestamp * 1000);  
		
		return Zeit.toLocaleString();
	};
</script>