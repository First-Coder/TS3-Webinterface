<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	require_once(__DIR__."/../../php/functions/functionsMusicBot.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_modul = getModuls();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success'] && $mysql_modul['success']) {
		if(!hasPermGroup('perm_admin_instances')) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_instances_ts, perm_admin_instances_ts_add, perm_admin_instances_ts_delete, perm_admin_instances_bot, perm_admin_instances_bot_add, perm_admin_instances_bot_delete missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Got heading
	*/
	switch($LinkInformations[2]) {
		case 'tsAddInstance':
			$heading = $language['add_instanz'];
			break;
		default:
			$heading = $language['instances'];
			break;
	};
	
	/**
		Saved instances
	*/
	$instances = [];
	$cinstances = [];
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<?php if(hasPermGroup('perm_admin_instances_ts')) { ?>
				<li class="section"><h4>Teamspeak</h4></li>
				<li class="item <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'tsInfo') ? "active" : ""; ?>">
					<a href="#tsInfo">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['instances']; ?></span>
					</a>
				</li>
				<?php if($user_right['data']['perm_admin_instances_ts_add'] == $mysql_keys['perm_admin_instances_ts_add']) { ?>
					<li class="item <?php echo ($LinkInformations[2] == 'tsAddInstance') ? "active" : ""; ?>" data-icon="fas fa-plus" data-ttip="<?php echo ucfirst($language['add']); ?>">
						<a href="#tsAddInstance">
							<i class="fas fa-circle"></i>
							<span><?php echo $language['add_instanz']; ?></span>
						</a>
					</li>
				<?php }; ?>
			<?php }; ?>
			
			<?php if($mysql_modul['data']['splamy_musicbot'] == 'true' && hasPermGroup('perm_admin_instances_bot')) { ?>
				<li class="section"><h4>Splamy Musicbot</h4></li>
				<li class="item <?php echo ($LinkInformations[2] == 'botInfo') ? "active" : ""; ?>">
					<a href="#botInfo">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['instances']; ?></span>
					</a>
				</li>
				<?php if(extension_loaded('curl')) { ?>
					<?php if($user_right['data']['perm_admin_instances_bot_add'] == $mysql_keys['perm_admin_instances_bot_add']) { ?>
						<li class="item <?php echo ($LinkInformations[2] == 'botAddInstance') ? "active" : ""; ?>" data-icon="fas fa-plus" data-ttip="<?php echo ucfirst($language['add']); ?>">
							<a href="#botAddInstance">
								<i class="fas fa-circle"></i>
								<span><?php echo $language['add_instanz']; ?></span>
							</a>
						</li>
					<?php };
				};
			}; ?>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-display="true" data-toggle="tooltip" data-placement="left" title="<?php echo ($LinkInformations[2] == 'tsAddInstance' || $LinkInformations[2] == 'botAddInstance') ? ucfirst($language['add']) : $language['save']; ?>"><i class="<?php echo ($LinkInformations[2] == 'tsAddInstance' || $LinkInformations[2] == 'botAddInstance') ? "fas fa-plus" : "far fa-save"; ?>"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="tsInfo" class="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'tsInfo') ? "active" : ""; ?>">
					<div class="tabs">
						<ul class="nav nav-tabs">
							<li class="nav-item">
								<a class="nav-link active" href="#version" data-toggle="tab" role="tab"><?php echo $language['version']; ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="#instance" data-toggle="tab" role="tab"><?php echo $language['instances']; ?></a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="#console" data-toggle="tab" role="tab"><?php echo $language['console']; ?></a>
							</li>
						</ul>
						<div class="tab-content form">
							<div class="tab-pane fade show active" id="version" role="tabpanel">
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['installed_class']; ?>:</label>
									<span class="col-lg-8 col-xl-4">TS3-admin.class <a class="default-link" target="_blank" href="https://github.com/First-Coder/TS3-admin.class">(GitHub Link)</a></span>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['installed_version']; ?>:</label>
									<span class="col-lg-8 col-xl-4">1.1.0.2</span>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['developer']; ?>:</label>
									<span class="col-lg-8 col-xl-4">Stefan Zehnpfennig & L. Gmann</span>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light">SSH2:</label>
									<span class="col-lg-8 col-xl-4 color-<?php echo (extension_loaded('ssh2')) ? 'success' : 'danger'; ?>"><?php echo (extension_loaded('ssh2')) ? $language['active'] : $language['deactive']; ?></span>
								</div>
								
							</div>
							<div class="tab-pane fade" id="instance" role="tabpanel">
								<?php if(isset($ts3_server)) {
									foreach($ts3_server AS $num=>$instance) {
										$conn = checkTS3Connection($num);
										if($conn['success']) {
											$instances[$num] = $instance;
										}; ?>
										<div class="row mr-0 ml-0">
											<h6 class="col-lg-12 color-light mt-2"><?php echo $language['instance']; ?>: <?php echo xssEcho($instance['alias']); ?></h6>
										</div>
										<div class="row mr-0 ml-0 mb-2">
											<label class="col-lg-4 form-label color-light"><?php echo $language['status']; ?>:</label>
											<span class="col-lg-8 col-xl-4 color-<?php echo ($conn['success']) ? 'success' : 'danger'; ?>"><?php echo ($conn['success']) ? $language['connection_successfull'] : $conn['error'][0]; ?></span>
										</div>
										<div class="row mr-0 ml-0 mb-2">
											<label class="col-lg-4 form-label color-light"><?php echo $language['teamspeakserver']; ?>:</label>
											<span class="col-lg-8 col-xl-4"><?php echo ($conn['success']) ? (strpos($conn['data'], 'TS3') !== false) ? 'TeamSpeak' : 'TeaSpeak' : $language['unknown']; ?></span>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['alias']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input id="<?php echo $num; ?>-alias" class="form-control form-control-sm" type="text" value="<?php xssEcho($instance['alias']); ?>">
													<small class="form-text text-muted"><?php echo $language['alias_info']; ?></small>
												</div>
											</div>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['protokoll']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<select id="<?php echo $num; ?>-protocol" class="form-control form-control-sm" <?php echo (extension_loaded('ssh2')) ? '' : 'disabled'; ?>>
													<option value="raw" <?php echo ($instance['protocol'] == "raw") ? "selected" : ""; ?>>RAW</option>
													<option value="ssh" <?php echo ($instance['protocol'] == "ssh") ? "selected" : ""; ?>>SSH</option>
												</select>
												<small class="form-text text-muted"><?php echo $language['protokoll_info']; ?></small>
											</div>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['ip_adress']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input id="<?php echo $num; ?>-ip" class="form-control form-control-sm" type="text" value="<?php xssEcho($instance['ip']); ?>">
													<small class="form-text text-muted"><?php echo $language['ip_info']; ?></small>
												</div>
											</div>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_query_user']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input id="<?php echo $num; ?>-queryport" class="form-control form-control-sm" type="number" value="<?php xssEcho($instance['queryport']); ?>">
													<small class="form-text text-muted"><?php echo $language['queryport_info']; ?></small>
												</div>
											</div>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_query_user']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input id="<?php echo $num; ?>-user" class="form-control form-control-sm" type="text" value="<?php xssEcho($instance['user']); ?>">
													<small class="form-text text-muted"><?php echo $language['client_info_instanz']; ?></small>
												</div>
											</div>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input id="<?php echo $num; ?>-pw" class="form-control form-control-sm" type="password" placeholder="****">
													<small class="form-text text-muted"><?php echo $language['password_info_instanz']; ?></small>
												</div>
											</div>
										</div>
										<?php if($user_right['data']['perm_admin_instances_ts_delete'] == $mysql_keys['perm_admin_instances_ts_delete']) { ?>
											<div class="row mr-0 ml-0">
												<button onClick="deleteInstanz('<?php echo $num; ?>');" class="btn btn-sm col-12 btn-flat btn-danger"><i class="fas fa-trash mr-2"></i><?php echo $language['delete_instanz']; ?></button>
											</div>
										<?php }; ?>
										<?php if($num < count($ts3_server)-1) { ?>
											<hr class="hr-headline" />
										<?php }; ?>
									<?php };
									}; ?>
							</div>
							<div class="tab-pane fade" id="console" role="tabpanel">
								<div id="terminal">
									# Welcome to the Teamspeak instance console. Please choose one of the following instances:
									<?php if(!empty($instances)) { ?>
										<?php foreach($instances AS $num=>$instance) {
											$cinstances[] = array('ip'=>$instance['ip'], 'user'=>$instance['user']); ?>
											<?php echo $num; ?>> <?php xssEcho($instance['alias']); ?><br/>
										<?php };
									} else { ?>
										Sorry! Looks like no instance is online now.
									<?php }; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php if($user_right['data']['perm_admin_instances_ts_add'] == $mysql_keys['perm_admin_instances_ts_add']) { ?>
					<div id="tsAddInstance" class="<?php echo ($LinkInformations[2] == 'tsAddInstance') ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="alert-table mb-3 color-light" style="height: auto;">
								<i class="fas fa-info-circle"></i>
								<span><?php echo $language['instanz_info']; ?></span>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['alias']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="add-alias" class="form-control form-control-sm" type="text" placeholder="First-Coder Instance">
										<small class="form-text text-muted"><?php echo $language['alias_info']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['protokoll']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<select id="add-protocol" class="form-control form-control-sm" <?php echo (extension_loaded('ssh2')) ? '' : 'disabled'; ?>>
										<option value="raw" selected>RAW</option>
										<option value="ssh">SSH</option>
									</select>
									<small class="form-text text-muted"><?php echo $language['protokoll_info']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ip_adress']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="add-ip" class="form-control form-control-sm" type="text" placeholder="127.0.0.1">
										<small class="form-text text-muted"><?php echo $language['ip_info']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['queryport']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="add-queryport" class="form-control form-control-sm" type="number" placeholder="10011 / 10022">
										<small class="form-text text-muted"><?php echo $language['queryport_info']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['client']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="add-client" class="form-control form-control-sm" type="text" placeholder="serveradmin">
										<small class="form-text text-muted"><?php echo $language['client_info_instanz']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="add-password" class="form-control form-control-sm" type="password" placeholder="****">
										<small class="form-text text-muted"><?php echo $language['password_info_instanz']; ?></small>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
				<?php if($mysql_modul['data']['splamy_musicbot'] == 'true') { ?>
					<div id="botInfo" class="<?php echo ($LinkInformations[2] == 'botInfo') ? "active" : ""; ?>">
						<div class="tabs">
							<ul class="nav nav-tabs">
								<li class="nav-item">
									<a class="nav-link active" href="#bot-version" data-toggle="tab" role="tab"><?php echo $language['version']; ?></a>
								</li>
								<?php if(extension_loaded('curl')) { ?>
									<li class="nav-item">
										<a class="nav-link" href="#bot-instance" data-toggle="tab" role="tab"><?php echo $language['instances']; ?></a>
									</li>
								<?php }; ?>
							</ul>
							<div class="tab-content form">
								<div class="tab-pane fade show active" id="bot-version" role="tabpanel">
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['installed_class']; ?>:</label>
										<span class="col-lg-8 col-xl-4">TS3-musicbot.class</span>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['installed_version']; ?>:</label>
										<span class="col-lg-8 col-xl-4">1.0.2</span>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['developer']; ?>:</label>
										<span class="col-lg-8 col-xl-4">L. Gmann</span>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light">cURL:</label>
										<span class="col-lg-8 col-xl-4 color-<?php echo (extension_loaded('curl')) ? 'success' : 'danger'; ?>"><?php echo (extension_loaded('curl')) ? $language['active'] : $language['deactive']; ?></span>
									</div>
								</div>
								<?php if(extension_loaded('curl')) { ?>
									<div class="tab-pane fade" id="bot-instance" role="tabpanel">
										<?php foreach($music_server AS $num=>$instance) {
											$conn = checkBotConnection($num); ?>
											<div class="row mr-0 ml-0">
												<h6 class="col-lg-12 color-light mt-2"><?php echo $language['instance']; ?>: <?php echo xssEcho($instance['alias']); ?></h6>
											</div>
											<div class="row mr-0 ml-0 mb-3">
												<label class="col-lg-4 form-label color-light"><?php echo $language['status']; ?>:</label>
												<span class="col-lg-8 col-xl-4 color-<?php echo ($conn['success']) ? 'success' : 'danger'; ?>"><?php echo ($conn['success']) ? $language['connection_successfull'] : $conn['error'][0]; ?></span>
											</div>
											<div class="row mr-0 ml-0 mb-2">
												<label class="col-lg-4 form-label color-light"><?php echo $language['version']; ?>:</label>
												<span class="col-lg-8 col-xl-4"><?php echo ($conn['success']) ? $conn['data']->Version.' ('.$conn['data']->Branch.')' : $language['unknown']; ?></span>
											</div>
											<div class="row mr-0 ml-0">
												<label class="col-lg-4 form-label color-light"><?php echo $language['alias']; ?>:</label>
												<div class="col-lg-8 col-xl-4">
													<div class="form-group">
														<input id="<?php echo $num; ?>-bot-alias" class="form-control form-control-sm" type="text" value="<?php xssEcho($instance['alias']); ?>">
														<small class="form-text text-muted"><?php echo $language['alias_info']; ?></small>
													</div>
												</div>
											</div>
											<div class="row mr-0 ml-0">
												<label class="col-lg-4 form-label color-light"><?php echo $language['ip_adress']; ?>:</label>
												<div class="col-lg-8 col-xl-4">
													<div class="form-group">
														<input id="<?php echo $num; ?>-bot-ip" class="form-control form-control-sm" type="text" value="<?php xssEcho($instance['ip']); ?>">
														<small class="form-text text-muted"><?php echo $language['ip_bot_info']; ?></small>
													</div>
												</div>
											</div>
											<div class="row mr-0 ml-0">
												<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
												<div class="col-lg-8 col-xl-4">
													<div class="form-group">
														<input id="<?php echo $num; ?>-bot-port" class="form-control form-control-sm" type="number" value="<?php xssEcho($instance['port']); ?>">
														<small class="form-text text-muted"><?php echo $language['queryport_bot_info']; ?></small>
													</div>
												</div>
											</div>
											<div class="row mr-0 ml-0">
												<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_uniquie_id']; ?>:</label>
												<div class="col-lg-8 col-xl-4">
													<div class="form-group">
														<input id="<?php echo $num; ?>-bot-uuid" class="form-control form-control-sm" type="text" value="<?php xssEcho($instance['uuid']); ?>">
														<small class="form-text text-muted"><?php echo $language['ts3_uniquie_id_info']; ?></small>
													</div>
												</div>
											</div>
											<div class="row mr-0 ml-0">
												<label class="col-lg-4 form-label color-light"><?php echo $language['token']; ?>:</label>
												<div class="col-lg-8 col-xl-4">
													<div class="form-group">
														<input id="<?php echo $num; ?>-bot-token" class="form-control form-control-sm" type="text" value="<?php xssEcho($instance['token']); ?>">
														<small class="form-text text-muted"><?php echo $language['token_bot_info']; ?></small>
													</div>
												</div>
											</div>
											<?php if($user_right['data']['perm_admin_instances_bot_delete'] == $mysql_keys['perm_admin_instances_bot_delete']) { ?>
												<div class="row mr-0 ml-0">
													<button onClick="deleteBotInstanz('<?php echo $num; ?>');" disabled class="btn btn-sm col-12 btn-flat btn-danger"><i class="fas fa-trash mr-2"></i><?php echo $language['delete_instanz']; ?></button>
												</div>
											<?php }; ?>
											<?php if($num < count($music_server)-1) { ?>
												<hr class="hr-headline" />
											<?php }; ?>
										<?php }; ?>
									</div>
								<?php }; ?>
							</div>
						</div>
					</div>
					<?php if($user_right['data']['perm_admin_instances_ts_add'] == $mysql_keys['perm_admin_instances_ts_add']) { ?>
						<div id="botAddInstance" class="<?php echo ($LinkInformations[2] == 'botAddInstance') ? "active" : ""; ?>">
							<div class="alert alert-table form">
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['alias']; ?>:</label>
									<div class="col-lg-8 col-xl-4">
										<div class="form-group">
											<input id="add-bot-alias" class="form-control form-control-sm" type="text" placeholder="First-Coder Instance">
											<small class="form-text text-muted"><?php echo $language['alias_info']; ?></small>
										</div>
									</div>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['ip_adress']; ?>:</label>
									<div class="col-lg-8 col-xl-4">
										<div class="form-group">
											<input id="add-bot-ip" class="form-control form-control-sm" type="text" placeholder="127.0.0.1">
											<small class="form-text text-muted"><?php echo $language['ip_bot_info']; ?></small>
										</div>
									</div>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
									<div class="col-lg-8 col-xl-4">
										<div class="form-group">
											<input id="add-bot-port" class="form-control form-control-sm" type="number" placeholder="58913">
											<small class="form-text text-muted"><?php echo $language['queryport_bot_info']; ?></small>
										</div>
									</div>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['token']; ?>:</label>
									<div class="col-lg-8 col-xl-4">
										<div class="form-group">
											<input id="add-bot-token" class="form-control form-control-sm" type="text" placeholder="">
											<small class="form-text text-muted"><?php echo $language['token_bot_info2']; ?></small>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php };
				}; ?>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/admin.js"></script>
<script src="js/other/console.js"></script>
<script>
	/**
		Save changed settings in the database
	*/
	$('a#save-settings').click(function(e) {
		var el = $(this);
		var link = $('li.item.active > a').attr('href');
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		
		el.addClass('disabled');
		
		switch(link) {
			case '#botInfo':
				var check = true;
				var file = [];
				
				$('#botInfo.active #bot-instance.tab-pane input, #botInfo.active #bot-instance.tab-pane select').each(function() {
					var el = $(this);
					var id = el.attr('id');
					var idParts = id.split('-');
					var instance = idParts[0];
					var part = idParts[2];
					var value = $(this).val();
					
					if(value == '') {
						check = false;
					};
					
					if(file[instance] === undefined) {
						file[instance] = { };
					};
					
					file[instance][part] = (part == 'token' || part == 'uuid' || part == 'alias') ? encodeURIComponent(value) : value;
				});
				
				if(!check) {
					new Notification({
						message : lang.ticket_fill_all,
						icon: 'far fa-save',
						type : 'danger'
					}).show();
					el.removeClass('disabled');
					return;
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'updateBotInstance',
						data: JSON.stringify(file)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							new Notification({
								message : lang.instanz_change_done,
								icon: 'far fa-save',
								type : 'success'
							}).show();
							changeContent('web_admin_instance');
						} else {
							new Notification({
								message : info.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			case '#botAddInstance':
				var file = {};
				if(!isDataValid('add-bot-alias') || !isDataValid('add-bot-ip') || !isDataValid('add-bot-port') || !isDataValid('add-bot-token')) {
					new Notification({
						message : lang.ticket_fill_all,
						icon: 'fas fa-plus',
						type : 'danger'
					}).show();
					el.removeClass('disabled');
					return;
				};

				$('#botAddInstance.active input, #botAddInstance.active select').each(function() {
					var el = $(this);
					var id = el.attr('id');
					var part = id.split('-')[2];
					var value = $(this).val();
					
					file[part] = (part == 'alias') ? encodeURIComponent(value) : value;
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'addBotInstance',
						data: JSON.stringify(file)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.instanz_add_done,
									icon: 'fas fa-plus',
									type : 'success'
								}).show();
								changeContent('web_admin_instance');
							}, 3000);
						} else {
							new Notification({
								message : info.error,
								icon: 'fas fa-plus',
								type : 'danger'
							}).show();
							el.removeClass('disabled');
						};
					}
				});
				break;
			case '#tsAddInstance':
				var file = {};
				if(!isDataValid('add-alias') || !isDataValid('add-ip') || !isDataValid('add-queryport') || !isDataValid('add-client') || !isDataValid('add-password')) {
					new Notification({
						message : lang.ticket_fill_all,
						icon: 'fas fa-plus',
						type : 'danger'
					}).show();
					el.removeClass('disabled');
					return;
				};
				
				$('#tsAddInstance.active input, #tsAddInstance.active select').each(function() {
					var el = $(this);
					var id = el.attr('id');
					var part = id.split('-')[1];
					var value = $(this).val();
					
					file[part] = (part == 'password' || part == 'alias') ? encodeURIComponent(value) : value;
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'addInstance',
						data: JSON.stringify(file)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.instanz_add_done,
									icon: 'fas fa-plus',
									type : 'success'
								}).show();
								changeContent('web_admin_instance');
							}, 3000);
						} else {
							new Notification({
								message : info.error,
								icon: 'fas fa-plus',
								type : 'danger'
							}).show();
							el.removeClass('disabled');
						};
					}
				});
				break;
			case '#tsInfo':
				var check = true;
				var file = [];
				
				$('#tsInfo.active #instance.tab-pane input, #tsInfo.active #instance.tab-pane select').each(function() {
					var el = $(this);
					var id = el.attr('id');
					var idParts = id.split('-');
					var instance = idParts[0];
					var part = idParts[1];
					var value = $(this).val();
					
					if(value == '' && part != 'pw') {
						check = false;
					};
					
					if(file[instance] === undefined) {
						file[instance] = { };
					};
					
					file[instance][part] = (part == 'pw' || part == 'alias') ? encodeURIComponent(value) : value;
				});
				
				if(!check) {
					new Notification({
						message : lang.ticket_fill_all,
						icon: 'far fa-save',
						type : 'danger'
					}).show();
					el.removeClass('disabled');
					return;
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'updateInstance',
						data: JSON.stringify(file)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							new Notification({
								message : lang.instanz_change_done,
								icon: 'far fa-save',
								type : 'success'
							}).show();
							changeContent('web_admin_instance');
						} else {
							new Notification({
								message : info.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			default:
				el.removeClass('disabled');
				break;
		};
	});
	
	/**
		Configure the instance console
	*/
	var selected = false;
	var sserver = -1;
	var instances = JSON.parse('<?php echo json_encode($cinstances); ?>');
	new CreateConsole({
		input: {
			commandHandle:function(line){
				if(line === "!deselect") {
					selected = false;
					sserver = -1;
					$('#terminal-title').text('user@localhost:~');
					
					return [{
						msg: "> You have deselected your instance. You can now select another instance!",
						className:"color-warning"
					}];
				};
				
				if(selected === false) {
					var num = parseInt(line);
					var instance = instances[num];
					
					if(isNaN(num)) {
						return [{
							msg: "!!> Please choose a number of the instance!",
							className:"color-danger"
						}];
					};
					
					if(instance === undefined) {
						return [{
							msg: "!!> Your choosen instance does not exist!",
							className:"color-danger"
						}];
					};
					
					selected = num;
					$('#terminal-title').text(instance.user+'@'+instance.ip+':~');
					
					return [
						{ msg:"> "+instance.ip+" successfull selected! You can now send every command to the teamspeak query." },
						{ msg:"> How to add and remove a client from the server adminquery:" },
						{ msg:"> servergroupaddclient sgid=2 cldbid=MYDBID" },
						{ msg:"> servergroupdelclient sgid=2 cldbid=MYDBID" },
						{ msg:"> To deselect the server type !deselect." }
					];
				} else {
					var obj;
					$.ajax({
						type: "POST",
						url: "./php/functions/functionsTeamspeakPost.php",
						data: {
							action: 'commandQueryConsole',
							instance: selected,
							command: line,
							server : sserver
						},
						async: false,
						success: function(data) {
							var json = JSON.parse(data);
							
							if(!json.success || json.data === false) {
								obj = {
									msg: (!json.success) ? "!!> "+json.error : "!!> Command not found!",
									className:"color-danger"
								};
							} else {
								if(line.substr(0, 3) == "use") {
									sserver = line.split('use ')[1];
								};
								obj = {
									msg:"> "+json.data
								};
							};
						}
					});
					return [obj];
				};
			}
		}
	});

	/**
		Validation Teamspeak instance
	*/
	validateOnChange('#add-alias', {
		required: true,
	});
	validateOnChange('#add-ip', {
		required: true,
	});
	validateOnChange('#add-queryport', {
		required: true,
	});
	validateOnChange('#add-client', {
		required: true,
	});
	validateOnChange('#add-password', {
		required: true,
	});

	validateOnChange('#add-bot-alias', {
		required: true,
	});
	validateOnChange('#add-bot-ip', {
		required: true,
	});
	validateOnChange('#add-bot-port', {
		required: true,
	});
	validateOnChange('#add-bot-token', {
		required: true,
	});
</script>