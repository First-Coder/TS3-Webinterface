 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success']) {
		if(!hasPermGroup('perm_admin_users')) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_users_add, perm_admin_users_edit, perm_admin_users_delete missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Get all Clients
	*/
	$users = getUsers();
?>


<!-- Modal: Delete All users -->
<div class="modal fade" id="modalDeleteAllUser" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header modal-danger">
				<h5 class="modal-title"><?php echo $language['title_delete_all_user']; ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<p class="mb-4"><?php echo $language['user_del_info']; ?></p>
				<h6><?php echo $language['login_informations']; ?></h6>
				<div class="form-group mb-3">
					<label><?php echo $language['mail']; ?></label>
					<input id="adminDeleteAllUsersUser" type="email" class="form-control">
					<span class="bmd-help"><?php echo $language['mail_help']; ?></span>
				</div>
				<div class="form-group mb-5">
					<label><?php echo $language['password']; ?></label>
					<input id="adminDeleteAllUsersPassword" type="password" class="form-control">
					<span class="bmd-help"><?php echo $language['password_help']; ?></span>
				</div>
				<h6><?php echo $language['perso_infos']; ?></h6>
				<div class="form-group mb-3">
					<label><?php echo $language['firstname']; ?></label>
					<input id="adminDeleteAllUsersFirstName" type="text" class="form-control">
					<span class="bmd-help"><?php echo $language['firstname_info']; ?></span>
				</div>
				<div class="form-group mb-3">
					<label><?php echo $language['lastname']; ?></label>
					<input id="adminDeleteAllUsersLastName" type="text" class="form-control">
					<span class="bmd-help"><?php echo $language['lastname_info']; ?></span>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-flat btn-success mr-2" data-dismiss="modal"><i class="fas fa-times"></i> <?php echo $language['abort']; ?></button>
				<button onClick="deleteAllUsers();" type="button" class="btn btn-danger btn-flat"><i class="far fa-trash-alt"></i> <?php echo $language['delete']; ?></button>
			</div>
		</div>
	</div>
</div>

<!-- Modal: Create User -->
<div class="modal fade" id="modalCreateUser" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><?php echo $language['title_user_add']; ?></h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h6><?php echo $language['login_informations']; ?></h6>
				<div class="form-group mb-3">
					<label><?php echo $language['mail']; ?></label>
					<input id="adminCreateUser" type="email" class="form-control">
					<span class="bmd-help"><?php echo $language['mail_help']; ?></span>
				</div>
				<div class="form-group mb-5">
					<label><?php echo $language['password']; ?></label>
					<input id="adminCreatePassword" type="password" class="form-control">
					<span class="bmd-help"><?php echo $language['password_help']; ?></span>
				</div>
				<h6><?php echo $language['perso_infos']; ?></h6>
				<div class="form-group mb-3">
					<label><?php echo $language['firstname']; ?></label>
					<input id="adminCreateFirstName" type="text" class="form-control">
					<span class="bmd-help"><?php echo $language['firstname_info']; ?></span>
				</div>
				<div class="form-group mb-3">
					<label><?php echo $language['lastname']; ?></label>
					<input id="adminCreateLastName" type="text" class="form-control">
					<span class="bmd-help"><?php echo $language['lastname_info']; ?></span>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-flat btn-danger mr-2" data-dismiss="modal"><i class="fas fa-times"></i> <?php echo $language['abort']; ?></button>
				<button onClick="createUser();" type="button" class="btn btn-success btn-flat"><i class="far fa-edit"></i> <?php echo $language['create']; ?></button>
			</div>
		</div>
	</div>
</div>

<div class="content-header color-header"><?php echo $language['userlist']; ?></div>

<div class="row mb-3">
	<div class="col-md-12 table-style">
		<div id="toolbar">
			<button class="btn btn-danger btn-flat <?php echo ($user_right['data']['perm_admin_users_delete'] == $mysql_keys['perm_admin_users_delete']) ? '" data-toggle="modal" data-target="#modalDeleteAllUser"' : 'disabled"'; ?>">
				<i class="fa fa-fw fa-trash"></i>
			</button>
			<button class="btn-success btn btn-flat <?php echo ($user_right['data']['perm_admin_users_add'] == $mysql_keys['perm_admin_users_add']) ? '" data-toggle="modal" data-target="#modalCreateUser"' : 'disabled"'; ?>">
				<i id="createUser" class="fa fa-fw fa-user-plus"></i>
			</button>
		</div>
		
		<div>
			<table id="userList" data-toggle="table" data-classes="table-no-bordered table-hover table table-default-hover" data-pagination="true" data-search="true" data-toolbar="#toolbar">
				<thead>
					<tr>
						<th data-field="client" class="w-33-percent"></th>
						<th data-field="status" class="w-33-percent"></th>
						<th data-field="actions" class="w-34-percent"></th>
						<th data-field="pk" data-visible="false"></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($users AS $user) {
							$infos = getUserInformations($user['pk_client']);
							
							if(!$infos['success']) {
								redirectSite(REDIRECT_SERVER_ERROR);
							};
							
							$btnDelete = "";
							$btnEdit = "";
							
							if($user['user_blocked'] == "true") {
								$icon = 'fa-ban';
								$content = $language['deactive'];
							} else {
								$icon = 'fa-check';
								$content = $language['active'];
							};
							
							if(count($users) > 1 && $user_right['data']['perm_admin_users_delete'] == $mysql_keys['perm_admin_users_delete']) {
								$btnDelete	=	"<button onClick=\"deleteUser('".$user['pk_client']."');\" class=\"btn btn-custom btn-red btn-sm w-100-percent\"><i class=\"fas fa-trash mr-2\"></i>".$language['delete']."</button>";
							};
							
							if($user_right['data']['perm_admin_users_edit'] == $mysql_keys['perm_admin_users_edit']) {
								$btnEdit	=	"<button onClick=\"showUser('".$user['pk_client']."', '".xssSafe($user['user'])."', '".$user['last_login']."');\" class=\"btn btn-custom btn-green btn-sm w-100-percent mb-3\"><i class=\"fas fa-edit mr-2\"></i>".$language['edit']."</button>";
							};
							
							echo "<tr>
									<td>
										<div class=\"card card-user\">
											<div class=\"image\">
												<img src=\"./images/work1.jpg\" />
											</div>
											<div class=\"card-body\">
												<div>
													<img src=\"".getUserPicture($user['pk_client'])."\" />
												</div>
												<h5>".xssSafe($infos['data']['firstname'])." ".xssSafe($infos['data']['lastname'])."</h5>
											</div>
										</div>
									</td>
									<td>
										<ul class=\"list-group\">
											<a class=\"list-group-item\">
												<i class=\"fas fa-at\"></i>
												".xssSafe($user['user'])."
											</a>
											<a class=\"list-group-item\">
												<i class=\"fas fa-user-clock\"></i>
												".$user['last_login']."
											</a>
											<a class=\"list-group-item\">
												<i class=\"fas ".$icon."\"></i>
												".$content."
											</a>
										</ul>
									</td>
									<td>
										".$btnEdit."
										".$btnDelete."
									</td>
									<td>".$user['pk_client']."</td>
								</tr>";
					}; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>

<!-- Javascripte Laden -->
<script src="js/bootstrap/bootstrap-table.js"></script>
<script src="js/webinterface/admin.js"></script>
<script>
	validateOnChange('#adminDeleteAllUsersUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#adminDeleteAllUsersPassword', {
		required: true,
		min: 6
	}, '', lang.password_needs);
	validateOnChange('#adminDeleteAllUsersFirstName', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#adminDeleteAllUsersLastName', {
		required: true
	}, '', lang.field_cant_be_empty);
	
	validateOnChange('#adminCreatePassword', {
		required: true,
		min: 6
	}, '', lang.password_needs);
	validateOnChange('#adminCreateUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#adminCreateFirstName', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#adminCreateLastName', {
		required: true
	}, '', lang.field_cant_be_empty);
	
</script>