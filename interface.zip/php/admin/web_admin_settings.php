 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls(false);
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_hp_main']['key'] != $mysql_keys['right_hp_main'])
	{
		reloadSite();
	};
	
	/*
		Ports abfragen
	*/
	if(MASTERSERVER_INSTANZ != "" && MASTERSERVER_INSTANZ != "nope")
	{
		$tsPorts		=	getTeamspeakPorts(MASTERSERVER_INSTANZ);
	};
	
	/*
		Themes
	*/
	$firstLoad								=	true;
	$themes									=	array();
	$files 									= 	scandir(__dir__.'/../../css/themes/');
	$files[0]								=	"style.css";
	$index 									=	0;
	unset($files[1]);
	
	foreach($files AS $file)
	{ 
		if($file != "style.css")
		{
			$data 							= 	file(__dir__."/../../css/themes/$file");
		}
		else
		{
			$data 							= 	file(__dir__."/../../css/$file");
		};
		
		$themes[$index]						=	array();
		$themes[$index]['filename']			=	($file == "style.css") ? "css/$file" : "css/themes/$file";
		$themes[$index]['file']				=	$file;
		
		foreach($data as $line)
		{
			if(strpos($line, "#name") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['name']		=	trim($tmpLine[1]);
			}
			else if(strpos($line, "#autor") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['autor']	=	trim($tmpLine[1]);
			}
			else if(strpos($line, "#img") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['img']		=	trim($tmpLine[1]);
			}
			else if(strpos($line, "#txtcolor") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['txtcolor']	=	trim($tmpLine[1]);
			};
		};
		$index++;
	};
?>

<div class="col-xs-12 main">
	<div class="page-on-top settings">
		<div class="info-settings">
			<div class="row mb-3">
				<div class="col-xs-12 col-sm-12 col-xl-12">
					<div class="card-block-header">
						<h4 class="card-title"><i class="fa fa-info"></i> <?php echo $language['version_info']; ?></h4>
					</div>
					<hr class="hr-headline"/>
					<div class="row">
						<?php $versionPossible			=	getUpdateInformations(); ?>
						<div class="col-lg-8" style="border-right: 1px solid rgba(0, 0, 0, 0.1)">
							<div class="row mb-2">
								<div class="col-md-6">
									<?php echo $language['installed_version']; ?>:
								</div>
								<div class="col-md-6" style="text-align:center;">
									<div class="tag-outline-<?php echo ($versionPossible['isUpdatePossible']) ? "danger" : "success"; ?> tag"><?php echo INTERFACE_VERSION; ?></div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<?php echo $language['newest_version']; ?>:
								</div>
								<div class="col-md-6" style="text-align:center;">
									<div class="tag-outline-success tag"><?php echo checkNewVersion(); ?></div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 hidden-md-down">
							<div class="row mb-2">
								<div class="col-md-6">
									<?php echo $language['donator']; ?>:
								</div>
								<div class="col-md-6" style="text-align:center;">
									<div class="tag-outline-<?php echo ($versionPossible['isDonator']) ? "success" : "danger"; ?> tag"><i class="fa fa-<?php echo ($versionPossible['isDonator']) ? "check" : "warning"; ?>" aria-hidden="true"></i> <?php echo ($versionPossible['isDonator']) ? $language['yes'] : $language['no']; ?></div>
								</div>
							</div>
							<?php if(!$versionPossible['isDonator']) { ?>
								<div class="row" style="text-align: center;">
									<div class="col-md-12">
										<a class="default-link" href="https://first-coder.de/index.php?download#donate" target="_blank"><?php echo $language['get_donator']; ?></a>
									</div>
								</div>
							<?php }; ?>
						</div>
						<?php if(!empty($versionPossible['secretInformation'])) { ?>
							<div class="alert alert-warning mt-2 mr-3 ml-3 w-100-percent" role="alert">
								<strong><i class="fa fa-info-circle"></i> <?php echo $language['informations']; ?></strong>
								<p><?php echo $versionPossible['secretInformation']; ?></p>
							</div>
						<?php }; ?>
						<?php if($versionPossible['isUpdatePossible']) { ?>
							<div class="alert alert-danger mt-2 mr-3 ml-3 w-100-percent" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
									<span aria-hidden="true">×</span>
									<span class="sr-only">Close</span>
								</button>
								<strong><i class="fa fa-warning"></i> <?php echo $language['attention']; ?>!</strong>
								<p><?php echo $language['download_new_version']; ?></p>
							</div>
						<?php }; ?>
					</div>
				</div>
			</div>
		</div>
		<div class="pills-area mt-3">
			<div class="pills-navigation">
				<ul>
					<li class="nav-item"><a class="nav-link" href="#Settings" data-toggle="tab"><?php echo $language['settings']; ?></a></li>
					<li class="nav-item"><a class="nav-link" href="#ModulAndDesign" data-toggle="tab"><?php echo $language['module_design']; ?></a></li>
				</ul>
			</div>
			<div class="tab-content pt-0">
				<div class="tab-pane" id="Settings">
					<div class="row mb-3">
						<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
							<div class="card-block-header">
								<h4 class="card-title">
									<i class="fa fa-cogs"></i> <?php echo $language['homepage_settings']; ?>
								</h4>
							</div>
							<hr class="hr-headline"/>
							<div class="form-group mb-3">
								<label><?php echo $language['donator_mail']; ?></label>
								<input id="donator" type="password" class="form-control" placeholder="Enter PayPal Mail" value="<?php xssEcho(DONATOR_MAIL); ?>" area="homepagesettings">
								<span class="bmd-help"><?php echo $language['donator_mail_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['webinterface_title']; ?></label>
								<input id="heading" type="text" class="form-control" placeholder="Enter Heading" value="<?php xssEcho(HEADING); ?>" area="homepagesettings">
								<span class="bmd-help"><?php echo $language['webinterface_title_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['teamspeak_name']; ?></label>
								<input id="chatname" type="text" class="form-control" placeholder="Enter Chatname" value="<?php xssEcho(TS3_CHATNAME); ?>" area="homepagesettings">
								<span class="bmd-help"><?php echo $language['teamspeak_name_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['masterserver_instanz']; ?></label>
								<select id="masterserverSelectInstanz" onChange="adminSettingsChangePort();" class="form-control" area="homepagesettings"
									<?php if($mysql_modul['masterserver'] != "true") { echo "disabled"; }; ?>>
									<option value="nope" <?php echo (MASTERSERVER_INSTANZ == "" || MASTERSERVER_INSTANZ == "nope") ? "selected" : ""; ?>><?php echo $language['no_masterserver']; ?></option>
									<?php for ($i = 0; $i < count($ts3_server); $i++) { ?>
										<option value="<?php echo $i; ?>" <?php echo (MASTERSERVER_INSTANZ == "$i") ? "selected" : ""; ?>>
											<?php if($ts3_server[$i]['alias'] != '') {
													xssEcho($ts3_server[$i]['alias']);
												} else {
													xssEcho($ts3_server[$i]['ip']); 
												}; ?>
										</option>
									<?php } ?>
								</select>
								<span class="bmd-help"><?php echo $language['masterserver_instanz_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['masterserver_port']; ?></label>
								<select id="masterserverSelectPort" onChange="adminSettingsChangePort();" class="form-control" area="homepagesettings"
									<?php if($mysql_modul['masterserver'] != "true" || MASTERSERVER_INSTANZ == "" || MASTERSERVER_INSTANZ == "nope") { echo "disabled"; }; ?>>
									<option value="nope" <?php echo (MASTERSERVER_INSTANZ == "" || MASTERSERVER_INSTANZ == "nope") ? "selected" : ""; ?>><?php echo $language['no_masterserver']; ?></option>
									<?php if(MASTERSERVER_INSTANZ != "" && MASTERSERVER_INSTANZ != "nope" && !empty($tsPorts)) {
										foreach($tsPorts AS $port) { ?>
											<option value="<?php echo $port; ?>" <?php echo (MASTERSERVER_PORT == $port) ? "selected" : ""; ?>>
												<?php echo $port; ?>
											</option>
										<?php };
									}; ?>
								</select>
								<span class="bmd-help"><?php echo $language['masterserver_port_info']; ?></span>
							</div>
						</div>
					</div>
					<div class="row mt-2 mb-3">
						<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
							<div class="card-block-header">
								<h4 class="card-title">
									<i class="fa fa-inbox"></i> <?php echo $language['mail_settings']; ?>
								</h4>
							</div>
							<hr class="hr-headline"/>
							<div class="row mb-1">
								<div class="col-xs-7">
									<?php echo $language['mails']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input area="mailsettings" id="setMails" type="checkbox" <?php if(USE_MAILS == 'true') { echo 'checked'; } ?>><span id="setMailsText"><?php echo (USE_MAILS == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['interface_mail']; ?></label>
								<input id="setMail" type="email" class="form-control" placeholder="Enter Mail" value="<?php xssEcho(MAILADRESS); ?>" area="mailsettings">
								<span class="bmd-help"><?php echo $language['mailadress_info']; ?></span>
							</div>
							<div class="row">
								<div class="col-xs-7">
									SMTP
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input area="mailsettings" id="setMailSmtp" type="checkbox" <?php if(MAIL_SMTP == 'true') { echo 'checked'; } ?>><span id="setMailSmtpText"><?php echo (MAIL_SMTP == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['smtp_host']; ?></label>
								<input id="smtpHost" type="text" class="form-control" placeholder="Enter Host" value="<?php xssEcho(MAIL_SMTP_HOST); ?>" area="mailsettings">
								<span class="bmd-help"><?php echo $language['smtp_host_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['smtp_port']; ?></label>
								<input id="smtpPort" type="number" class="form-control" placeholder="Enter Port" value="<?php xssEcho(MAIL_SMTP_PORT); ?>" area="mailsettings">
								<span class="bmd-help"><?php echo $language['smtp_port_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['smtp_user']; ?></label>
								<input id="smtpUser" type="text" class="form-control" placeholder="Enter User" value="<?php xssEcho(MAIL_SMTP_USERNAME); ?>" area="mailsettings">
								<span class="bmd-help"><?php echo $language['smtp_user_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['smtp_password']; ?></label>
								<input id="smtpPassword" type="password" class="form-control" placeholder="Enter Password" value="<?php xssEcho(MAIL_SMTP_PASSWORD); ?>" area="mailsettings">
								<span class="bmd-help"><?php echo $language['smtp_password_info']; ?></span>
							</div>
							<div class="form-group mb-3">
								<label><?php echo $language['smtp_encoding']; ?></label>
								<select id="smtpEncoding" class="form-control" area="mailsettings">
									<option value="off" <?php echo (MAIL_SMTP_ENCRYPTION == "off") ? "selected" : ""; ?>><?php echo $language['none']; ?></option>
									<option value="tls" <?php echo (MAIL_SMTP_ENCRYPTION == "tls") ? "selected" : ""; ?>>TLS</option>
									<option value="ssl" <?php echo (MAIL_SMTP_ENCRYPTION == "ssl") ? "selected" : ""; ?>>SSL</option>
								</select>
								<span class="bmd-help"><?php echo $language['smtp_encoding_info']; ?></span>
							</div>
						</div>
					</div>
					<div class="row mb-3 mt-2">
						<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
							<div class="card-block-header">
								<h4 class="card-title">
									<i class="fa fa-file"></i> <?php echo $language['own_sites']; ?>
								</h4>
							</div>
							<hr class="hr-headline"/>
							<div class="row mb-2">
								<div class="col-xs-7">
									<?php echo $language['own_news_site']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input area="ownsites" id="setOwnNewsSite" type="checkbox" <?php if(CUSTOM_NEWS_PAGE == 'true') { echo 'checked'; } ?>><span id="setOwnNewsSiteText"><?php echo (CUSTOM_NEWS_PAGE == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-xs-7">
									<?php echo $language['own_dashboard_site']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input area="ownsites" id="setOwnDashboardSite" type="checkbox" <?php if(CUSTOM_DASHBOARD_PAGE == 'true') { echo 'checked'; } ?>><span id="setOwnDashboardSiteText"><?php echo (CUSTOM_DASHBOARD_PAGE == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row mb-3 mt-2">
						<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
							<div class="card-block-header">
								<h4 class="card-title">
									<i class="fa fa-flag"></i> <?php echo $language['languagesettings']; ?>
								</h4>
							</div>
							<hr class="hr-headline"/>
							<div class="row">
								<?php foreach ($installedLanguages AS $choosedLanguage => $languageLink) { ?>
									<div class="col-sm-6 col-md-3">
										<div class="card">
											<img style="width: 100%;" class="card-img-top" src="./images/<?php echo $choosedLanguage; ?>.gif">
											<div class="card-block">
												<h4 class="card-title"><?php echo ucfirst($choosedLanguage); ?></h4>
												<p class="card-text">Translated by <?php xssEcho($languageLink); ?></p>
												<div class="text-success pull-left langChoosed" id="lang<?php echo $choosedLanguage; ?>" style="<?php echo ($choosedLanguage == LANGUAGE) ? "" : "display: none;"; ?>">
													<?php echo $language['choosed']; ?>
												</div>
												<button type="button" onClick="changeLanguage('<?php echo $choosedLanguage; ?>');" class="btn btn-success btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
													<i class="material-icons f-s-18">check</i>
												</button>
											</div>
										</div>
									</div>
								<?php }; ?>
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane" id="ModulAndDesign">
					<div class="row mb-3">
						<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
							<div class="card-block-header">
								<h4 class="card-title">
									<i class="fa fa-external-link"></i> <?php echo $language['homepage_moduls']; ?>
								</h4>
							</div>
							<hr class="hr-headline"/>
							<div class="row mb-2">
								<div class="col-xs-7">
									<?php echo $language['self_register']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="setModulFreeRegister" onChange="changeModul('setModulFreeRegister');" type="checkbox" <?php if($mysql_modul['free_register'] == 'true') { echo 'checked'; } ?>><span id="setModulFreeRegisterText"><?php echo ($mysql_modul['free_register'] == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-xs-7">
									<?php echo $language['create_server_antrag']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="setModulServerAntrag" onChange="changeModul('setModulServerAntrag');" type="checkbox" <?php if($mysql_modul['free_ts3_server_application'] == 'true') { echo 'checked'; } ?>><span id="setModulServerAntragText"><?php echo ($mysql_modul['free_ts3_server_application'] == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-xs-7">
									<?php echo $language['write_news']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="setModulWriteNews" onChange="changeModul('setModulWriteNews');" type="checkbox" <?php if($mysql_modul['write_news'] == 'true') { echo 'checked'; } ?>><span id="setModulWriteNewsText"><?php echo ($mysql_modul['write_news'] == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-xs-7">
									<?php echo $language['interface']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="setModulWebinterface" onChange="changeModul('setModulWebinterface');" type="checkbox" <?php if($mysql_modul['webinterface'] == 'true') { echo 'checked'; } ?>><span id="setModulWebinterfaceText"><?php echo ($mysql_modul['webinterface'] == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row mb-2">
								<div class="col-xs-7">
									<?php echo $language['masterserver']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="setModulMasterserver" onChange="changeModul('setModulMasterserver');" type="checkbox" <?php if($mysql_modul['masterserver'] == 'true') { echo 'checked'; } ?>><span id="setModulMasterserverText"><?php echo ($mysql_modul['masterserver'] == 'true') ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row mb-3 mt-2">
						<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
							<div class="card-block-header">
								<h4 class="card-title">
									<i class="fa fa-tint"></i> Homepage Designs
								</h4>
							</div>
							<hr class="hr-headline"/>
							<div class="row">
								<?php foreach($themes AS $index=>$theme)
								{
									$src			=	"images/".$theme['img'];
									if(!file_exists(__dir__."/../../".$src))
									{
										$src		=	"images/no-preview.png";
									}; ?>
									<div class="col-sm-6 col-md-3">
										<div class="card">
											<img style="width: 100%;" class="card-img-top" src="<?php echo $src; ?>">
											<div class="card-block">
												<h4 class="card-title"><?php echo $theme['name']; ?></h4>
												<p class="card-text">Created by <?php echo $theme['autor']; ?></p>
												<div class="text-success pull-left themeChoosed" id="theme<?php echo str_replace(".css", "", $theme['file']); ?>" style="<?php echo (str_replace(".css", "", $theme['file']) == STYLE || (STYLE == "" && $firstLoad)) ? "" : "display: none;"; ?>">
													<?php echo $language['choosed']; ?>
												</div>
												<button type="button" onClick="changeTheme('<?php echo str_replace(".css", "", $theme['file']); ?>');" class="btn btn-success btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
													<i class="material-icons f-s-18">check</i>
												</button>
											</div>
										</div>
									</div>
								<?php 
									$firstLoad = false;
								}; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!--<div id="adminContent">
	<div class="card">
		<div class="card-block card-block-header">
			<h4 class="card-title"><i class="fa fa-tint"></i> </h4>
		</div>
		<div class="card-block">
			<div id="styleSlider" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
					<?php
					$firstLoad				=	true;
					foreach($themes AS $index=>$theme) {  ?>
						<li data-target="#styleSlider" data-slide-to="<?php echo $index; ?>" 
							<?php
								echo (str_replace(".css", "", $theme['file']) == STYLE || (STYLE == "" && $firstLoad)) ? 'class="active"' : '';
								$firstLoad	=	false;
							?>>
						</li>
					<?php }; ?>
				</ol>
				<div class="carousel-inner" role="listbox">
					<?php
						$firstLoad			=	true;
						foreach($themes AS $index=>$theme)
						{
							$src			=	"images/".$theme['img'];
							$active			=	(str_replace(".css", "", $theme['file']) == STYLE || (STYLE == "" && $firstLoad)) ? "active" : "";
							$txtcolor		=	(!empty($theme['txtcolor'])) ? $theme['txtcolor'] : '';
							
							if(!file_exists("../../".$src))
							{
								$src		=	"images/noImg.gif";
							};
							
							echo '<div class="carousel-item '.$active.'">
									<img class="d-block img-fluid" src="'.$src.'">
									<div class="carousel-caption d-none d-md-block">
										<h3 style="color: '.$txtcolor.'">'.$theme['name'].'</h3>
										<p class="hidden-md-down" style="color: '.$txtcolor.'">Created by '.$theme['autor'].'</p>
										<button onClick="changeTheme(\''.str_replace(".css", "", $theme['file']).'\');" class="btn btn-sm btn-success">'.$language['submit'].'</button>
									</div>
								</div>';
							
							$firstLoad		=	false;
						};
					?>
				</div>
				<a class="left carousel-control" href="#styleSlider" role="button" data-slide="prev">
					<span class="icon-prev" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#styleSlider" role="button" data-slide="next">
					<span class="icon-next" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>
	</div>
</div>-->

<script src="js/other/pills.js"></script>
<script src="js/webinterface/admin.js"></script>
<script>
	/*
		Set labeltext on btn switch
	*/
	$('.switch>label>input').change(function()
	{
		if($(this).prop("checked"))
		{
			$('#'+$(this).attr("id")+'Text').text(lang.active);
		}
		else
		{
			$('#'+$(this).attr("id")+'Text').text(lang.deactive);
		};
	});
	
	/*
		Detect changed input
	*/
	var changedHomepage				=	false,
		changedMail					=	false,
		changedOwnSites				=	false;
	
	$('input, select').change(function()
	{
		changeInput($(this));
	});
	$('input').on('input',function()
	{
		changeInput($(this));
	});
	
	function changeInput(element)
	{
		switch(element.attr("area"))
		{
			case "homepagesettings":
				changedHomepage		=	true;
				OverlayButton.setButton(true);
				break;
			case "mailsettings":
				changedMail			=	true;
				OverlayButton.setButton(true);
				break;
			case "ownsites":
				changedOwnSites		=	true;
				OverlayButton.setButton(true);
				break;
		};
	};
	
	/*
		Overlay button
	*/
	OverlayButton.setButtonClass("btn-secondary");
	OverlayButton.setIconClass("fa-save");
	OverlayButton.setTooltip(lang.save);
	OverlayButton.on("click", function() {
		var whichStr				=	"";
		
		if(changedHomepage)
		{
			whichStr				+=	"homepagesettings";
		};
		if(changedMail)
		{
			whichStr				+=	",mailsettings";
		};
		if(changedOwnSites)
		{
			whichStr				+=	",ownsites";
		};
		
		changedHomepage				=	false;
		changedMail					=	false;
		changedOwnSites				=	false;
		
		setConfig(whichStr);
	});
	OverlayButton.start(450, 511);
	OverlayButton.setButton(false);
</script>