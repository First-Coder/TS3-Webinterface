 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_modul = getModuls();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success']) {
		if(!hasPermGroup('perm_admin_settings')) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_settings_main, perm_admin_settings_lang, perm_admin_settings_mail, perm_admin_settings_module, perm_admin_settings_designs, perm_admin_settings_sites missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/*
		Themes
	*/
	/*$firstLoad								=	true;
	$themes									=	array();
	$files 									= 	scandir(__dir__.'/../../css/themes/');
	$files[0]								=	"style.css";
	$index 									=	0;
	unset($files[1]);
	
	foreach($files AS $file)
	{ 
		if($file != "style.css")
		{
			$data 							= 	file(__dir__."/../../css/themes/$file");
		}
		else
		{
			$data 							= 	file(__dir__."/../../css/$file");
		};
		
		$themes[$index]						=	array();
		$themes[$index]['filename']			=	($file == "style.css") ? "css/$file" : "css/themes/$file";
		$themes[$index]['file']				=	$file;
		
		foreach($data as $line)
		{
			if(strpos($line, "#name") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['name']		=	trim($tmpLine[1]);
			}
			else if(strpos($line, "#autor") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['autor']	=	trim($tmpLine[1]);
			}
			else if(strpos($line, "#img") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['img']		=	trim($tmpLine[1]);
			}
			else if(strpos($line, "#txtcolor") !== false)
			{
				$tmpLine					=	explode(":", $line);
				$themes[$index]['txtcolor']	=	trim($tmpLine[1]);
			};
		};
		$index++;
	};*/
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();

	/**
		Get SOAP Informations
	*/
	$versionPossible = getUpdateInformations($settings['data']);
	
	/**
		Get Mail Hompagesettings
	*/
	$mailsettings = getSqlMailSettings();
	
	/**
		Get Own Sites
	*/
	$ownSites = getSqlOwnSites();
	
	/**
		Got heading
	*/
	switch($LinkInformations[2]) {
		case 'langSettings':
			$heading = $language['languagesettings'];
			break;
		case 'mailSettings':
			$heading = $language['mail_settings'];
			break;
		case 'module':
			$heading = $language['module'];
			break;
		case 'ownSites':
			$heading = $language['own_sites'];
			break;
		default:
			$heading = $language['main_settings'];
			break;
	};
	
	/** 
		Could not load all settings
	*/
	if(!$settings['success'] || !$mailsettings['success'] || !$mysql_modul['success'] || !$ownSites['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Get ports for the support teamspeak if needed
	*/
	$ports = generateOutput(false, null, null);
	if($mysql_modul['data']['support_teamspeak'] == "true" && $mysql_modul['data']['support_teamspeak_instance'] !== false) {
		$ports = getTeamspeakPorts($mysql_modul['data']['support_teamspeak_instance']);
	};
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['settings']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'mainSettings') ? "active" : ""; ?>" data-display="<?php echo ($user_right['data']['perm_admin_settings_main'] == $mysql_keys['perm_admin_settings_main']) ? 'true' : 'false'; ?>">
				<a href="#mainSettings">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['main_settings']; ?></span>
				</a>
			</li>
			<?php if($user_right['data']['perm_admin_settings_lang'] == $mysql_keys['perm_admin_settings_lang']) { ?>
				<li class="item <?php echo ($LinkInformations[2] == 'langSettings') ? "active" : ""; ?>" data-display="false">
					<a href="#langSettings">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['languagesettings']; ?></span>
					</a>
				</li>
			<?php }; ?>
			<?php if($user_right['data']['perm_admin_settings_mail'] == $mysql_keys['perm_admin_settings_mail']) { ?>
				<li class="item <?php echo ($LinkInformations[2] == 'mailSettings') ? "active" : ""; ?>">
					<a href="#mailSettings">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['mail_settings']; ?></span>
					</a>
				</li>
			<?php }; ?>
			
			<?php if($user_right['data']['perm_admin_settings_module'] == $mysql_keys['perm_admin_settings_module'] ||
				$user_right['data']['perm_admin_settings_designs'] == $mysql_keys['perm_admin_settings_designs'] ||
				$user_right['data']['perm_admin_settings_sites'] == $mysql_keys['perm_admin_settings_sites']) { ?>
				<li class="section"><h4><?php echo $language['other']; ?></h4></li>
			<?php }; ?>
			<?php if($user_right['data']['perm_admin_settings_module'] == $mysql_keys['perm_admin_settings_module']) { ?>
				<li class="item <?php echo ($LinkInformations[2] == 'module') ? "active" : ""; ?>">
					<a href="#module">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['module']; ?></span>
					</a>
				</li>
			<?php }; ?>
			<?php if($user_right['data']['perm_admin_settings_designs'] == $mysql_keys['perm_admin_settings_designs']) { ?>
				<li class="item">
					<a href="#">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['themes']; ?></span>
					</a>
				</li>
			<?php }; ?>
			<?php if($user_right['data']['perm_admin_settings_sites'] == $mysql_keys['perm_admin_settings_sites']) { ?>
				<li class="item <?php echo ($LinkInformations[2] == 'ownSites') ? "active" : ""; ?>">
					<a href="#ownSites">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['own_sites']; ?></span>
					</a>
				</li>
			<?php }; ?>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-display="<?php echo ($LinkInformations[2] == 'langSettings') ? "false" : "true"; ?>" data-toggle="tooltip" data-placement="left" title="<?php echo $language['save']; ?>"><i class="far fa-save"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="mainSettings" class="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'mainSettings') ? "active" : ""; ?>">
					<?php if($versionPossible['secretInformation'] != false) { ?>
						<div class="alert alert-table color-warning">
							<i class="far fa-bell"></i>
							<span><?php echo $versionPossible['secretInformation']; ?></span>
						</div>
					<?php }; ?>
					<div class="tabs">
						<ul class="nav nav-tabs">
							<li class="nav-item">
								<a class="nav-link active" href="#version" data-toggle="tab" role="tab"><?php echo $language['version']; ?></a>
							</li>
							<?php if($user_right['data']['perm_admin_settings_main'] == $mysql_keys['perm_admin_settings_main']) { ?>
								<li class="nav-item">
									<a class="nav-link" href="#homepage" data-toggle="tab" role="tab"><?php echo $language['homepage']; ?></a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="#contact" data-toggle="tab" role="tab">Teamspeak</a>
								</li>
							<?php }; ?>
						</ul>
						<div class="tab-content form">
							<div class="tab-pane fade show active" id="version" role="tabpanel">
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['installed_version']; ?>:</label>
									<span class="col-lg-8 col-xl-4 color-<?php echo ($versionPossible['isUpdatePossible']) ? "danger" : "success"; ?>"><?php echo INTERFACE_VERSION; echo ($versionPossible['isUpdatePossible']) ? ' <a class="default-link" href="./updater/updater.php">(Updater)</a>' : ''; ?></span>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['newest_version']; ?>:</label>
									<span class="col-lg-8 col-xl-4 color-success"><?php echo checkNewVersion(true, $settings['data']['donator']); ?></span>
									<?php if($versionPossible['isUpdatePossible']) { ?>
										<span class="col-xl-4 d-none d-xl-block">
											<div class="badge badge-20 badge-danger" style="top: -2px;"><i class="fas fa-exclamation"></i></div>
										</span>
									<?php }; ?>
								</div>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['donator']; ?>:</label>
									<span class="col-lg-8 col-xl-4 color-<?php echo ($versionPossible['isDonator']) ? "success" : "danger"; ?>"><?php echo ($versionPossible['isDonator']) ? $language['yes'] : $language['no'].' <a class="default-link" href="https://first-coder.de/index.php?general?donate" target="_blank">('.$language['get_donator'].')</a>'; ?></span>
									<?php if(!$versionPossible['isDonator']) { ?>
										<span class="col-xl-4 d-none d-xl-block">
											<div class="badge badge-20 badge-danger" style="top: -2px;"><i class="fas fa-exclamation"></i></div>
										</span>
									<?php }; ?>
								</div>
								<hr class="hr-headline"/>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['webserver']; ?>:</label>
									<span class="col-lg-8 col-xl-4 color-light"><?php echo $_SERVER['SERVER_SOFTWARE']; ?></span>
								</div>
								<?php if($_SERVER['SERVER_SOFTWARE'] === 'Apache') { ?>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light">htaccess:</label>
										<span class="col-lg-8 col-xl-4 color-<?php echo (isset($_SERVER['HTACCESS'])) ? "success" : "danger"; ?>"><?php echo (isset($_SERVER['HTACCESS'])) ? $language['active'] : $language['deactive'].' <a class="default-link" href="https://first-coder.de/index.php?tsw?configuration" target="_blank">('.$language['details'].')</a>'; ?></span>
										<?php if(!isset($_SERVER['HTACCESS'])) { ?>
											<span class="col-xl-4 d-none d-xl-block">
												<div class="badge badge-20 badge-danger" style="top: -2px;"><i class="fas fa-exclamation"></i></div>
											</span>
										<?php }; ?>
									</div>
								<?php }; ?>
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['database']; ?>:</label>
									<span class="col-lg-8 col-xl-4 color-light"><?php echo SQL_Mode; ?></span>
								</div>
								<?php if($versionPossible['team'] != false) { ?>
									<hr class="hr-headline"/>
									<?php foreach($versionPossible['team'] as $team) { ?>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $team['name']; ?>:</label>
											<span class="col-lg-8 col-xl-4"><?php echo $team['job']; ?></span>
										</div>
									<?php };
								}; ?>
							</div>
							<?php if($user_right['data']['perm_admin_settings_main'] == $mysql_keys['perm_admin_settings_main']) { ?>
								<div class="tab-pane fade" id="homepage" role="tabpanel">
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['operator']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageOperator" class="form-control form-control-sm" type="text" placeholder="Name or Organisation" value="<?php xssEcho($settings['data']['operator']); ?>">
												<small class="form-text text-muted"><?php echo $language['operator_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['address']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<textarea id="homepageAdress" class="form-control form-control-sm" rows="3"><?php xssEcho($settings['data']['address']); ?></textarea>
												<small class="form-text text-muted"><?php echo $language['address_info']; ?></small>
											</div>
										</div>
									</div>
									<hr class="hr-headline"/>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['google_recaptcha']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageCaptcha" class="form-control form-control-sm" type="text" value="<?php xssEcho(GRECAPTCHA_SECRET); ?>">
												<small class="form-text text-muted"><?php echo $language['google_recaptcha_info']; ?></small>
											</div>
										</div>
									</div>
									<hr class="hr-headline"/>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['donator_mail']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageDonator" class="form-control form-control-sm" type="text" placeholder="Enter PayPal Mail" value="<?php xssEcho($settings['data']['donator']); ?>">
												<small class="form-text text-muted"><?php echo $language['donator_mail_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['webinterface_title']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageTitle" class="form-control form-control-sm" type="text" placeholder="Enter Heading" value="<?php xssEcho($settings['data']['title']); ?>">
												<small class="form-text text-muted"><?php echo $language['webinterface_title_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['delete_ticket']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="switch">
												<label>
													<input id="homepageDelTicket" type="checkbox" <?php echo ($settings['data']['delete_tickets'] != false) ? 'checked' : ''; ?>>
													&nbsp;
												</label>
											</div>
											<small class="form-text text-muted"><?php echo $language['delete_ticket_info']; ?></small>
										</div>
									</div>
								</div>
								<div class="tab-pane fade" id="contact" role="tabpanel">
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['teamspeak_name']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageExternName" class="form-control form-control-sm" type="text" placeholder="Enter Chatname" value="<?php xssEcho($settings['data']['extern_name']); ?>">
												<small class="form-text text-muted"><?php echo $language['teamspeak_name_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['tree_interval']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageTreeInt" class="form-control form-control-sm" type="number" placeholder="Enter a Number" value="<?php xssEcho($settings['data']['ts_tree_intervall']); ?>">
												<small class="form-text text-muted"><?php echo $language['tree_interval_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['banner_interval']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageBannerInt" class="form-control form-control-sm" type="number" placeholder="Enter a Number" value="<?php xssEcho($settings['data']['ts_banner_refresh']); ?>">
												<small class="form-text text-muted"><?php echo $language['banner_interval_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['db_clients']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="homepageDbClients" class="form-control form-control-sm" type="number" placeholder="Enter a Number" value="<?php xssEcho($settings['data']['ts_get_db_clients']); ?>">
												<small class="form-text text-muted"><?php echo $language['db_clients_info']; ?></small>
											</div>
										</div>
									</div>
								</div>
							<?php }; ?>
						</div>
					</div>
				</div>
				<?php if($user_right['data']['perm_admin_settings_lang'] == $mysql_keys['perm_admin_settings_lang']) { ?>
					<div id="langSettings" class="<?php echo ($LinkInformations[2] == 'langSettings') ? "active" : ""; ?>">
						<div class="row">
							<?php foreach ($installedLanguages AS $choosedLanguage => $languageLink) { ?>
								<div class="col-lg-6">
									<div class="card-2">
										<div class="card-header-2">
											<img class="w-100-percent" src="./images/<?php echo $choosedLanguage; ?>.gif" />
										</div>
										<div class="lang-card">
											<div>
												<h4><?php echo ucfirst($choosedLanguage); ?></h4>
												<span class="text-muted">Translated by <?php xssEcho($languageLink); ?></span>
											</div>
											<span data-language="<?php echo $choosedLanguage; ?>"><i class="fas fa-check"></i></span>
										</div>
										<div class="lang-card-footer">
											<span class="color-success"><?php echo ($choosedLanguage == $settings['data']['language']) ? $language['choosed'] : $language['available']; ?></span>
										</div>
									</div>
								</div>
							<?php }; ?>
						</div>
					</div>
				<?php }; ?>
				<?php if($user_right['data']['perm_admin_settings_mail'] == $mysql_keys['perm_admin_settings_mail']) { ?>
					<div id="mailSettings" class="<?php echo ($LinkInformations[2] == 'mailSettings') ? "active" : ""; ?>">
						<div class="tabs">
							<ul class="nav nav-tabs">
								<li class="nav-item">
									<a class="nav-link active" href="#msettings" data-toggle="tab" role="tab"><?php echo $language['settings']; ?></a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="#mtexte" data-toggle="tab" role="tab">Texte</a>
								</li>
							</ul>
							<div class="tab-content form">
								<div class="tab-pane fade show active" id="msettings" role="tabpanel">
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['interface_mail']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="MAILADRESS" class="form-control form-control-sm" type="mail" placeholder="Enter Interface Mail" value="<?php xssEcho(MAILADRESS); ?>">
												<small class="form-text text-muted"><?php echo $language['mailadress_info']; ?></small>
											</div>
										</div>
									</div>
									<?php $isSmtp = (MAIL_SMTP === 'true'); ?>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light">SMTP:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="switch">
												<label>
													<input id="MAIL_SMTP" class="switch-disable" data-disable="smtp-disable" type="checkbox" <?php echo ($isSmtp) ? 'checked' : ''; ?>>
													&nbsp;
												</label>
											</div>
											<small class="form-text text-muted"><?php echo $language['smtp_info']; ?></small>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['smtp_encoding']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<select id="MAIL_SMTP_ENCRYPTION" class="smtp-disable form-control form-control-sm" <?php echo ($isSmtp) ? "" : "disabled"; ?>>
												<option value="off" <?php echo (MAIL_SMTP_ENCRYPTION == "off") ? "selected" : ""; ?>><?php echo $language['none']; ?></option>
												<option value="tls" <?php echo (MAIL_SMTP_ENCRYPTION == "tls") ? "selected" : ""; ?>>TLS</option>
												<option value="ssl" <?php echo (MAIL_SMTP_ENCRYPTION == "ssl") ? "selected" : ""; ?>>SSL</option>
											</select>
											<small class="form-text text-muted"><?php echo $language['smtp_encoding_info']; ?></small>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['smtp_host']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="MAIL_SMTP_HOST" class="form-control form-control-sm smtp-disable" type="text" value="<?php xssEcho(MAIL_SMTP_HOST); ?>" <?php echo ($isSmtp) ? "" : "disabled"; ?>>
												<small class="form-text text-muted"><?php echo $language['smtp_host_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['smtp_port']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="MAIL_SMTP_PORT" class="form-control form-control-sm smtp-disable" type="number" value="<?php xssEcho(MAIL_SMTP_PORT); ?>" <?php echo ($isSmtp) ? "" : "disabled"; ?>>
												<small class="form-text text-muted"><?php echo $language['smtp_port_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['smtp_user']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="MAIL_SMTP_USERNAME" class="form-control form-control-sm smtp-disable" type="text" value="<?php xssEcho(MAIL_SMTP_USERNAME); ?>" <?php echo ($isSmtp) ? "" : "disabled"; ?>>
												<small class="form-text text-muted"><?php echo $language['smtp_user_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['smtp_password']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="MAIL_SMTP_PASSWORD" class="form-control form-control-sm smtp-disable" type="password" placeholder="****" <?php echo ($isSmtp) ? "" : "disabled"; ?>>
												<small class="form-text text-muted"><?php echo $language['smtp_password_info']; ?></small>
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane fade" id="mtexte" role="tabpanel">
									<?php
										$mtitles = array(
											"answer_ticket" => "ticket_answered",
											"closed_ticket" => "ticket_closed",
											"create_request" => "server_request_requested",
											"create_ticket" => "create_ticket",
											"create_ticket_admin" => "create_ticket_admin",
											"forgot_password" => "forgot_access",
											"request_failed" => "server_request_failed",
											"request_success" => "server_request_success"
										);
										foreach($mailsettings['data'] AS $num => $mail) { ?>
										<div class="row mr-0 ml-0">
											<h6 class="col-lg-12 color-light mt-2"><?php echo $language[$mtitles[$mail['id']]]; ?></h6>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['title']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input data-id="<?php echo $mail['id']; ?>" data-content="mail_subject" class="form-control form-control-sm" type="text" value="<?php echo $mail['mail_subject']; ?>" placeholder="Title">
													<small class="form-text text-muted"><?php echo $language['email_title_info']; ?></small>
												</div>
											</div>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['preheader_text']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input data-id="<?php echo $mail['id']; ?>" data-content="mail_preheader" class="form-control form-control-sm" type="text" value="<?php echo $mail['mail_preheader']; ?>" placeholder="This text will appear in the inbox preview, but not the email body.">
													<small class="form-text text-muted"><?php echo $language['preheader_text_info']; ?></small>
												</div>
											</div>
										</div>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['email_content']; ?>:</label>
											<div class="col-lg-8">
												<div class="editor" data-id="<?php echo $mail['id']; ?>"><?php echo $mail['mail_body']; ?></div>
											</div>
										</div>
										<button data-id="<?php echo $mail['id']; ?>" class="btn w-100-percent my-4"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['send_testmail']; ?></button>
										<?php if($num !== (count($mailsettings['data']) - 1)) { ?>
											<hr class="hr-headline" />
										<?php }; ?>
									<?php }; ?>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
				<?php if($user_right['data']['perm_admin_settings_module'] == $mysql_keys['perm_admin_settings_module']) { ?>
					<div id="module" class="<?php echo ($LinkInformations[2] == 'module') ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['modul']; ?>: <?php echo $language['splamy_musicbot']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['splamy_musicbot']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="moduleSplamy" type="checkbox" <?php echo ($mysql_modul['data']['splamy_musicbot'] === 'true') ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['splamy_musicbot_info']; ?></small>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['modul']; ?>: <?php echo $language['self_register']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['self_register']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="moduleFreeRegister" type="checkbox" <?php echo ($mysql_modul['data']['free_register'] === 'true') ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['self_register_info']; ?></small>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['modul']; ?>: <?php echo $language['server_requests']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['server_requests']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input disabled id="moduleServerRequest" type="checkbox" <?php echo ($mysql_modul['data']['free_ts3_server_application'] === 'true') ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['server_requests_info']; ?></small>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['modul']; ?>: <?php echo $language['support_teamspeak']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['support_teamspeak']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="moduleSupportTeamspeak" type="checkbox" class="switch-disable" data-disable="supp-teamspeak-disable" <?php echo ($mysql_modul['data']['support_teamspeak'] === 'true') ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
									<small class="form-text text-muted"><?php echo $language['support_teamspeak_info']; ?></small>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['instance']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<select onChange="getPortsFromInstance('moduleSupportTeamspeakInstance', 'moduleSupportTeamspeakPort');" id="moduleSupportTeamspeakInstance" class="form-control form-control-sm supp-teamspeak-disable" <?php echo ($mysql_modul['data']['support_teamspeak'] === 'true') ? '' : 'disabled'; ?>>
											<?php if(!empty($ts3_server)) {
												foreach($ts3_server AS $instance=>$data) { ?>
													<option value="<?php echo $instance; ?>" <?php echo ($mysql_modul['data']['support_teamspeak_instance'] == $instance) ? 'selected' : ''; ?>><?php echo $data['alias']; ?></option>
												<?php };
											}; ?>
										</select>
										<small class="form-text text-muted"><?php echo $language['support_teamspeak_instanz_info']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<select id="moduleSupportTeamspeakPort" class="form-control form-control-sm supp-teamspeak-disable" <?php echo ($ports['success'] && $mysql_modul['data']['support_teamspeak'] === 'true') ? '' : 'disabled'; ?>>
											<?php
												if($ports['success']) {
													foreach($ports['data'] AS $port) { ?>
														<option value="<?php echo $port; ?>" <?php echo ($mysql_modul['data']['support_teamspeak_port'] == $port) ? 'selected' : ''; ?>><?php echo $port; ?></option>';
													<?php };
												} else {
													echo '<option>'.$language['none'].'</option>';
												};
											?>
										</select>
										<small class="form-text text-muted"><?php echo $language['support_teamspeak_port_info']; ?></small>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
				<?php if($user_right['data']['perm_admin_settings_sites'] == $mysql_keys['perm_admin_settings_sites']) { ?>
					<div id="ownSites" class="<?php echo ($LinkInformations[2] == 'ownSites') ? "active" : ""; ?>">
						<div class="alert alert-table mb-3 color-light" style="height: auto;">
							<i class="fas fa-info-circle"></i>
							<span><?php echo $language['own_site_info']; ?></span>
						</div>
						<div class="tabs">
							<ul class="nav nav-tabs">
								<li class="nav-item">
									<a class="nav-link active" href="#override" data-toggle="tab" role="tab"><?php echo $language['override']; ?></a>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="#customSites" data-toggle="tab" role="tab"><?php echo $language['new']; ?></a>
								</li>
							</ul>
							<div class="tab-content form">
								<div class="tab-pane fade show active" id="override" role="tabpanel">
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['news']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_news-value" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['default']; ?>" value="<?php xssEcho($ownSites['data']['custom_news']['value']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light">Dashboard:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_dashboard-value" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['default']; ?>" value="<?php xssEcho($ownSites['data']['custom_dashboard']['value']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane fade" id="customSites" role="tabpanel">
									<div class="alert alert-table mb-3 color-light shadow-none" style="height: auto;">
										<i class="fas fa-info-circle"></i>
										<span><?php echo $language['own_site_info2']; ?></span>
									</div>
									<hr class="hr-headline"/>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 1:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_01-value" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_01']['value']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 1 Alias:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_01-name" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_01']['name']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 1 Icon:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_01-icon" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_01']['icon']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg2']; ?></small>
											</div>
										</div>
									</div>
									<hr class="hr-headline"/>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 2:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_02-value" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_02']['value']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 2 Alias:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_02-name" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_02']['name']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 2 Icon:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_02-icon" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_02']['icon']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg2']; ?></small>
											</div>
										</div>
									</div>
									<hr class="hr-headline"/>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 3:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_03-value" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_03']['value']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 3 Alias:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_03-name" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_03']['name']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 3 Icon:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_03-icon" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_03']['icon']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg2']; ?></small>
											</div>
										</div>
									</div>
									<hr class="hr-headline"/>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 4:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_04-value" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_04']['value']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 4 Alias:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_04-name" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_04']['name']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['custom_site']; ?> 4 Icon:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="custom_04-icon" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['deactive']; ?>" value="<?php xssEcho($ownSites['data']['custom_04']['icon']); ?>">
												<small class="form-text text-muted"><?php echo $language['own_site_default_msg2']; ?></small>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
			</div>
		</div>
	</div>
</div>

<script src="js/editor/summernote-bs4.js"></script>
<script src="js/webinterface/admin.js"></script>
<script>
	/**
		Editor stuff
	*/
	var editorOptions = {
		placeholder: 'Write here your mail',
		tabsize: 2,
		height: 150
	};
	var editors = {};
	$('.editor').each(function() {
		editors[$(this).attr("data-id")] = $(this).summernote(editorOptions);
	});

	/**
		Testmail
	 */
	$('#mailSettings').on("click", "#mtexte.active button[data-id]", function() {
		const id = $(this).attr("data-id");
		const data = {
			subject: $(`input[data-id="${id}"][data-content="mail_subject"]`).val(),
			id: id,
			body: editors[id].summernote('code'),
			preheader: $(`input[data-id="${id}"][data-content="mail_preheader"]`).val()
		};
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsSqlPost.php",
			data: {
				action: 'sendTestmail',
				data: JSON.stringify(data)
			},
			success: function(data) {
				var json = JSON.parse(data);
				if(json.success) {
					new Notification({
						message : lang.testmail_sended,
						icon: 'fas fa-paper-plane',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : json.error,
						icon: 'fas fa-paper-plane',
						type : 'danger'
					}).show();
				};
			}
		});
	});

	/**
		Save changed language in the database
	*/
	$('.lang-card > span').click(function() {
		var footer = $(this).closest('.lang-card').next();
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsSqlPost.php",
			data: {
				action: 'updateLanguage',
				lang: escapeHtml($(this).attr('data-language'))
			},
			success: function(data) {
				var json = JSON.parse(data);
				if(json.success) {
					$('.lang-card-footer > span').text(lang.available);
					$('span', footer).text(lang.choosed.replace('&auml;', '\u00e4'));
					
					new Notification({
						message : 'Language set! Reload the page to see your site in the new language!',
						icon: 'far fa-flag',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : json.error,
						icon: 'far fa-flag',
						type : 'danger'
					}).show();
				};
			}
		});
	});
	
	/**
		Save changed settings in the database
	*/
	$('a#save-settings').click(function(e) {
		var el = $(this);
		var link = $('li.item.active > a').attr('href');
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		el.addClass('disabled');
		
		switch(link) {
			case '#mainSettings':
				if(!isDataValid('homepageTitle') || !isDataValid('homepageExternName')) {
					new Notification({
						message : lang.ticket_fill_all,
						icon: 'far fa-save',
						type : 'danger'
					}).show();
					return;
				};

				var sqlCol = {
					donator: $('#homepageDonator').val(),
					title: encodeURIComponent($('#homepageTitle').val()),
					extern_name: encodeURIComponent($('#homepageExternName').val()),
					operator: encodeURIComponent($('#homepageOperator').val()),
					address: encodeURIComponent($('#homepageAdress').val()),
					delete_tickets: boolToInt($('#homepageDelTicket').prop( "checked" )),
					ts_tree_intervall: $('#homepageTreeInt').val(),
					ts_banner_refresh: $('#homepageBannerInt').val(),
					ts_get_db_clients: $('#homepageDbClients').val()
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'updateSettings',
						data: JSON.stringify(sqlCol)
					},
					success: function(data) {
						var json = JSON.parse(data);
						if(json.success) {
							$('.navbar-brand.nav-title').text($('#homepageTitle').val());
							
							$.ajax({
								type: "POST",
								url: "./php/functions/functionsPost.php",
								data: {
									action: 'updateConfig',
									data: JSON.stringify({
										GRECAPTCHA_SECRET: encodeURIComponent($('#homepageCaptcha').val())
									})
								},
								success: function(data) {
									var json = JSON.parse(data);
									
									if(json.success) {
										new Notification({
											message : lang.settigns_saved,
											icon: 'fas fa-puzzle-piece',
											type : 'success'
										}).show();
									} else {
										new Notification({
											message : json.error,
											icon: 'fas fa-puzzle-piece',
											type : 'danger'
										}).show();
									};
								}
							});
						} else {
							new Notification({
								message : json.error,
								icon: 'fas fa-puzzle-piece',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			case '#module':
				var sqlCol = {
					splamy_musicbot: boolToString($('#moduleSplamy').prop( "checked" )),
					free_register: boolToString($('#moduleFreeRegister').prop( "checked" )),
					free_ts3_server_application: boolToString($('#moduleServerRequest').prop( "checked" )),
					support_teamspeak: boolToString($('#moduleSupportTeamspeak').prop( "checked" )),
					support_teamspeak_instance: ($('#moduleSupportTeamspeakInstance').prop('disabled')) ? false : $('#moduleSupportTeamspeakInstance').val(),
					support_teamspeak_port: ($('#moduleSupportTeamspeakPort').prop('disabled')) ? false : $('#moduleSupportTeamspeakPort').val()
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'updateModules',
						data: JSON.stringify(sqlCol)
					},
					success: function(data) {
						var json = JSON.parse(data);
						
						if(json.success) {
							new Notification({
								message : lang.modul_settings_done,
								icon: 'fas fa-puzzle-piece',
								type : 'success'
							}).show();
						} else {
							new Notification({
								message : json.error,
								icon: 'fas fa-puzzle-piece',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			case '#ownSites':
				var sqlCol = {};
				$('#ownSites.active input').each(function() {
					var el = $(this);
					var split = el.attr('id').split('-');
					var id = split[0];
					var col = split[1];
					
					if(sqlCol[id] === undefined) {
						sqlCol[id] = {};
					};
					sqlCol[id][col] = el.val();
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'updateOwnSites',
						data: JSON.stringify(sqlCol)
					},
					success: function(data) {
						var json = JSON.parse(data);
						if(json.success) {
							new Notification({
								message : lang.modul_settings_done,
								icon: 'far fa-file',
								type : 'success'
							}).show();
						} else {
							new Notification({
								message : json.error,
								icon: 'far fa-file',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			case '#mailSettings':
				var tabs = $('#mailSettings > div > ul a.active').attr("href");
				switch(tabs) {
					case '#msettings':
						var data = {};
						$('#msettings.active input').each(function() {
							var el = $(this);
							var id = el.attr("id");
							
							if(!el.prop("disabled")) {
								if(el.attr('type') === 'checkbox') {
									data[id] = (el.prop('checked')) ? 'true' : 'false';
								} else {
									data[id] = el.val();
								};
							};
						});
						
						$.ajax({
							type: "POST",
							url: "./php/functions/functionsPost.php",
							data: {
								action: 'updateConfig',
								data: JSON.stringify(data)
							},
							success: function(data) {
								var json = JSON.parse(data);
								
								if(json.success) {
									new Notification({
										message : lang.settigns_saved,
										icon: 'fas fa-puzzle-piece',
										type : 'success'
									}).show();
								} else {
									new Notification({
										message : json.error,
										icon: 'fas fa-puzzle-piece',
										type : 'danger'
									}).show();
								};
								el.removeClass('disabled');
							}
						});
						break;
					case '#mtexte':
						var data = {};
						$('#mtexte.active input').each(function() {
							var el = $(this);
							var id = el.attr("data-id");
							var sub = el.attr("data-content");

							if(id === undefined) {
								return;
							};

							if(data[id] === undefined) {
								data[id] = {};
							};

							if(data[id]["mail_body"] === undefined) {
								data[id]["mail_body"] = editors[id].summernote('code');
							};
							
							if(!el.prop("disabled")) {
								if(el.attr('type') === 'checkbox') {
									data[id][sub] = (el.prop('checked')) ? 'true' : 'false';
								} else {
									data[id][sub] = el.val();
								};
							};
						});
						
						$.ajax({
							type: "POST",
							url: "./php/functions/functionsSqlPost.php",
							data: {
								action: 'updateMails',
								data: JSON.stringify(data)
							},
							success: function(data) {
								var json = JSON.parse(data);
								console.log(json);
								if(json.success) {
									new Notification({
										message : lang.settigns_saved,
										icon: 'fas fa-puzzle-piece',
										type : 'success'
									}).show();
								} else {
									new Notification({
										message : json.error,
										icon: 'fas fa-puzzle-piece',
										type : 'danger'
									}).show();
								};
								el.removeClass('disabled');
							}
						});
						break;
				};
				break;
			default:
				el.removeClass('disabled');
				break;
		};
	});
	
	/**
		Profile validation
	*/
	validateOnChange('#homepageTitle', {
		required: true,
	}, '', lang.field_cant_be_empty);
	validateOnChange('#homepageExternName', {
		required: true
	}, '', lang.field_cant_be_empty);
</script>