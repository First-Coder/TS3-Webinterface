<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_hp_ts3']['key'] != $mysql_keys['right_hp_ts3'])
	{
		reloadSite();
	};
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row mb-3 form-secondary">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-plus"></i> <?php echo $language['add_instanz']; ?></h4>
					<h6 class="card-subtitle text-muted"><?php echo $language['instanz_info']; ?></h6>
				</div>
				<hr class="hr-headline"/>
				<div class="form-group mb-3">
					<label><?php echo $language['alias']; ?></label>
					<input id="adminCreateInstanzAlias" type="text" class="form-control">
					<span class="bmd-help"><?php echo $language['alias_info']; ?></span>
				</div>
				<div class="form-group mb-3">
					<label><?php echo $language['ip_adress']; ?></label>
					<input id="adminCreateInstanzIp" type="text" class="form-control">
					<span class="bmd-help"><?php echo $language['ip_info']; ?></span>
				</div>
				<div class="form-group mb-3">
					<label><?php echo $language['queryport']; ?></label>
					<input id="adminCreateInstanzQueryport" type="number" class="form-control">
					<span class="bmd-help"><?php echo $language['queryport_info']; ?></span>
				</div>
				<div class="form-group mb-3">
					<label><?php echo $language['client']; ?></label>
					<input id="adminCreateInstanzClient" type="text" class="form-control">
					<span class="bmd-help"><?php echo $language['client_info_instanz']; ?></span>
				</div>
				<div class="form-group mb-3">
					<label><?php echo $language['password']; ?></label>
					<input id="adminCreateInstanzPassword" type="password" class="form-control">
					<span class="bmd-help"><?php echo $language['password_info_instanz']; ?></span>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="col-xs-12 main">
	<div class="page-on-middle">
		<div class="row mb-3">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-globe"></i> <?php echo $language['instances']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<ul class="list-group listodd">
					<?php foreach($ts3_server AS $instanz => $server)
					{
						$connection		=	checkTS3Connection($server['ip'], $server['queryport'], $server['user'], $server['pw']); ?>
						
						<li class="list-group-item instanzMain<?php echo $instanz; ?>">
							<div class="bmd-list-group-col">
								<p class="list-group-item-heading">
									<?php echo $language['instance']; ?>: 
									<?php 
										if($server['alias'] != '')
										{
											xssEcho($server['alias']);
										}
										else
										{
											xssEcho($server['ip']);
										};
									?>
								</p>
								<p class="list-group-item-text"><?php echo xssSafe($server['ip']).":".xssSafe($server['queryport']) ?></p>
								<p class="list-group-item-text text-primary">
									<span class="instanzControl<?php echo $instanz; ?>" style="cursor: pointer;" onClick="showInstanzEdit('<?php echo $instanz; ?>');">
										<i class="fa fa-edit mr-0" aria-hidden="true"></i> <?php echo ucfirst($language['edit']); ?>
									</span>
									<?php if($connection) { ?>
										<span class="instanzControl<?php echo $instanz; ?>" style="cursor: pointer;" onClick="showInstanzConsole('<?php echo $instanz; ?>');">
											<i class="fa fa-terminal mr-0" aria-hidden="true"></i> <?php echo ucfirst($language['console']); ?>
										</span>
									<?php }; ?>
									<span class="instanzControlBack<?php echo $instanz; ?>" style="cursor: pointer;display: none;" class="text-danger" onClick="showInstanzControl('<?php echo $instanz; ?>')">
										<i class="fa fa-arrow-left mr-0" aria-hidden="true"></i> <?php echo ucfirst($language['back']); ?>
									</span>
								</p>
							</div>
							<div class="pull-xs-right <?php echo ($connection) ? "text-success" : "text-danger"; ?>" id="instanzTextBox<?php echo $instanz; ?>">
								<?php if($connection) { ?>
									<i class="fa fa-check mr-0" aria-hidden="true"></i> <span class="hidden-xs-down "><?php echo $language['success']; ?></span>
								<?php } else { ?>
									<i class="fa fa-close mr-0" aria-hidden="true"></i> <span class="hidden-xs-down "><?php echo $language['failed']; ?></span>
								<?php }; ?>
							</div>
						</li>
						<li id="instanzEdit<?php echo $instanz; ?>" class="list-group-item instanzMain<?php echo $instanz; ?>" style="display: none;background-color: #f5f5f5 !important;">
							<div class="alert alert-outline-success mt-2 mr-3 w-100-percent form-secondary" role="alert">
								<div class="form-group mb-3 mr-0">
									<label><?php echo $language['ip_adress']; ?></label>
									<input id="instanzIp<?php echo $instanz; ?>" type="text" class="form-control" placeholder="<?php xssEcho($server['ip']); ?>">
									<span class="bmd-help"><?php echo $language['ip_info']; ?></span>
								</div>
								<div class="form-group mb-3">
									<label><?php echo $language['queryport']; ?></label>
									<input id="instanzQueryport<?php echo $instanz; ?>" type="number" class="form-control" placeholder="<?php xssEcho($server['queryport']); ?>">
									<span class="bmd-help"><?php echo $language['queryport_info']; ?></span>
								</div>
								<div class="form-group mb-3">
									<label><?php echo $language['client']; ?></label>
									<input id="instanzUser<?php echo $instanz; ?>" type="text" class="form-control" placeholder="<?php xssEcho($server['user']); ?>">
									<span class="bmd-help"><?php echo $language['client_info_instanz']; ?></span>
								</div>
								<div class="form-group mb-3">
									<label><?php echo $language['password']; ?></label>
									<input id="instanzPassword<?php echo $instanz; ?>" type="password" class="form-control" placeholder="******">
									<span class="bmd-help"><?php echo $language['password_info_instanz']; ?></span>
								</div>
								<div class="row">
									<div class="col-sm-6 mr-0">
										<button onClick="changeInstanz('<?php echo $instanz; ?>')" class="btn btn-success btn-flat mt-2 mr-0 w-100-percent"><i class="fa fa-save mr-0" aria-hidden="true"></i> <?php echo $language['save']; ?></button>
									</div>
									<div class="col-sm-6 mr-0">
										<button onClick="AreYouSure('<?php echo $language['delete_instanz']; ?>', '<?php echo urlencode(json_encode(array("deleteInstanz", $instanz))); ?>');" class="btn btn-danger btn-flat mt-2 mr-0 w-100-percent"><i class="fa fa-trash mr-0" aria-hidden="true"></i> <?php echo $language['delete_instanz']; ?></button>
									</div>
								</div>
								<?php if(!isWindows()) { ?>
									<button class="btn btn-info btn-flat mt-2 mb-2 mr-0 w-100-percent btn-sm" data-toggle="modal" data-target="#modalShellInstanz" data-ip="<?php echo $ts3_server[$instanz]['ip']; ?>"><i class="fa fa-terminal mr-0" aria-hidden="true"></i> Shell</button>
								<?php }; ?>
							</div>
						</li>
						<li id="instanzConsole<?php echo $instanz; ?>" class="list-group-item instanzMain<?php echo $instanz; ?>" style="display: none;">
							<div class="alert alert-outline-info mt-2 mr-3 w-100-percent has-success" role="alert">
								<i class="fa fa-info mr-0"></i> <?php echo $language['query_console']; ?>
								<input id="commandInput<?php echo $instanz; ?>" class="form-control form-control-success pull-xs-left mt-2 mb-2" placeholder="<?php echo $language['input']; ?>...">
								<button instanz="<?php echo $instanz; ?>" class="btn btn-success btn-flat pull-xs-right mb-2 commandQueryConsole"><i class="fa fa-paper-plane mr-0" aria-hidden="true"></i> <?php echo $language['senden']; ?></button>
								<button onClick="$('#commandInput<?php echo $instanz; ?>').val('servergroupaddclient sgid=2 cldbid=MY_CLIENT_DATABASEID');" class="btn btn-danger btn-flat pull-xs-left mb-2"><i class="fa fa-plus mr-0" aria-hidden="true"></i> Adminquery</button>
								<button onClick="$('#commandInput<?php echo $instanz; ?>').val('servergroupdelclient sgid=2 cldbid=MY_CLIENT_DATABASEID');" class="btn btn-danger btn-flat pull-xs-left mb-2"><i class="fa fa-minus mr-0" aria-hidden="true"></i> Adminquery</button>
								<div style="clear: both;"></div>
								
								<div class="mt-3">
									<div class="pull-xs-left">
										<i class="fa fa-history mr-0" aria-hidden="true"></i> <?php echo $language['last_entrys']; ?>
									</div>
									<div class="pull-xs-right">
										<button remove-id="commandInputHistory<?php echo $instanz; ?>" class="clearConsole btn btn-info btn-flat mr-0"><i class="fa fa-trash mr-0" aria-hidden="true"></i> <?php echo $language['clear']; ?></button>
									</div>
									<div style="clear:both;"></div>
								</div>
								<div id="commandInputHistory<?php echo $instanz; ?>" class="alert alert-info"></div>
								
								<div class="mt-3">
									<div class="pull-xs-left">
										<i class="fa fa-terminal mr-0" aria-hidden="true"></i> <?php echo $language['console']; ?>
									</div>
									<div class="pull-xs-right">
										<button remove-id="commandOutput<?php echo $instanz; ?>" class="clearConsole btn btn-info btn-flat mr-0"><i class="fa fa-trash mr-0" aria-hidden="true"></i> <?php echo $language['clear']; ?></button>
									</div>
									<div style="clear:both;"></div>
								</div>
								<div id="commandOutput<?php echo $instanz; ?>" class="alert alert-info"></div>
							</div>
						</li>
					<?php }; ?>
				</ul>
			</div>
		</div>
	</div>
</div>

<!-- Modal: Instanz Shell -->
<div id="modalShellInstanz" class="modal modal-info fade scale" data-backdrop="true" tabindex="-1" role="dialog" aria-labelledby="modalShellInstanzLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="modalShellInstanzLabel"><?php echo $language['instance_shell']; ?></h4>
			</div>
			<div class="modal-body form-info">
				<div class="form-group mb-2 mr-0">
					<label><?php echo $language['ssh_port']; ?></label>
					<input id="shellPort" type="number" class="form-control" value="22">
					<span class="bmd-help"><?php echo $language['ssh_port_info']; ?></span>
				</div>
				<div class="form-group mb-2 mr-0">
					<label><?php echo $language['folder_path']; ?></label>
					<input id="shellPath" type="text" class="form-control" placeholder="Example: /home/teamspeak/">
					<span class="bmd-help"><?php echo $language['ssh_folder_path_info']; ?></span>
				</div>
				<label style="font-size: 14px;">Login via</label>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="radio radio-info">
							<label>
								<input id="useShellClient" onChange="slideInstanzShell('client');" name="loginArtRadio" type="radio" checked><?php echo $language['client']; ?>
							</label>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="radio radio-info">
							<label>
								<input onChange="slideInstanzShell('key');" name="loginArtRadio" type="radio"><?php echo $language['key']; ?>
							</label>
						</div>
					</div>
				</div>
				<div id="shellClientArea" class="mb-3">
					<div class="form-group mb-2 mr-0">
						<label><?php echo $language['client']; ?></label>
						<input id="shellClient" type="text" class="form-control" placeholder="root">
						<span class="bmd-help"><?php echo $language['ssh_client_info']; ?></span>
					</div>
					<div class="form-group mb-2 mr-0">
						<label><?php echo $language['password']; ?></label>
						<input id="shellPassword" type="password" class="form-control" placeholder="*****">
						<span class="bmd-help"><?php echo $language['ssh_password_info']; ?></span>
					</div>
				</div>
				<div id="shellKeyArea" class="mb-3" style="display: none;">
					<div class="form-group">
						<label><?php echo $language['key']; ?></label>
						<select id="shellKeySelect" class="form-control">
							<option disabled selected style="display: none;"><?php echo $language['choose_key']; ?></option>
							<?php
								$keys 	= 	scandir(__dir__.'/../../files/shell/');
								foreach($keys AS $key)
								{
									if($key != "." && $key != ".." && strpos($key, ".ppk") !== false)
									{
										$key		=	str_replace(".ppk", "", $key);
										if(file_exists(__dir__."/../../files/shell/".$key))
										{
											echo '<option value="'.$key.'">'.$key.'</option>';
										};
									};
								};
							?>
						</select>
						<span class="form-text text-muted" style="font-size: 0.75rem;"><?php echo $language['ssh_key_info']; ?></span>
					</div>
					<div class="form-group mb-2 mr-0">
						<label><?php echo $language['client']; ?></label>
						<input id="shellClientKey" type="text" class="form-control" placeholder="root">
						<span class="bmd-help"><?php echo $language['ssh_client_info']; ?></span>
					</div>
					<div class="form-group mb-2 mr-0">
						<label><?php echo $language['passphare']; ?></label>
						<input id="shellPassphare" type="password" class="form-control" placeholder="*****">
						<span class="bmd-help"><?php echo $language['ssh_passphare_info']; ?></span>
					</div>
				</div>
				<ul class="list-group">
					<li style="cursor: pointer;" id="command-start" onClick="selectShellCommand('command-start');" class="list-group-item list-group-item-success active-shell">
						<div class="bmd-list-group-col">
							<p class="list-group-item-heading"><?php echo $language['shell_start_instanz']; ?></p>
							<p class="list-group-item-text"><?php echo $language['shell_start_instanz_info']; ?></p>
						</div>
						<i id="active-shell-start" class="material-icons">check</i>
					</li>
					<li style="cursor: pointer;" id="command-stop" onClick="selectShellCommand('command-stop');" class="list-group-item list-group-item-danger">
						<div class="bmd-list-group-col">
							<p class="list-group-item-heading"><?php echo $language['shell_stop_instanz']; ?></p>
							<p class="list-group-item-text"><?php echo $language['shell_stop_instanz_info']; ?></p>
						</div>
						<i id="active-shell-stop" style="display: none;" class="material-icons">check</i>
					</li>
					<li style="cursor: pointer;" id="command-restart" onClick="selectShellCommand('command-restart');" class="list-group-item list-group-item-warning">
						<div class="bmd-list-group-col">
							<p class="list-group-item-heading"><?php echo $language['shell_restart_instanz']; ?></p>
							<p class="list-group-item-text"><?php echo $language['shell_restart_instanz_info']; ?></p>
						</div>
						<i id="active-shell-restart" style="display: none;" class="material-icons">check</i>
					</li>
				</ul>
				<p style="text-align: center;" class="mt-2">
					<i class="fa fa-warning" aria-hidden="true"></i> <?php echo $language['shell_instanz_key_warning']; ?> <i class="fa fa-warning" aria-hidden="true"></i></p>
				</p>
				<div id="instanzShellConsoleBox" style="display: none;" class="alert alert-info mr-2">
					<i class="fa fa-info"></i> <?php echo $language['query_console']; ?>
					<div id="instanzShellConsole" style="margin-top: 10px;"></div>
				</div>
			</div>
			<div class="modal-footer">
				<button id="shellCommand" type="button" class="btn btn-success w-100-percent"><i class="fa fa-paper-plane mr-0" aria-hidden="true"></i> <?php echo $language['senden']; ?></button>
			</div>
		</div>
	</div>
</div>

<!-- Javascripte Laden -->
<script src="js/webinterface/admin.js"></script>
<script>
	validateOnChange('#adminCreateInstanzIp', {
		required: true,
	});
	validateOnChange('#adminCreateInstanzQueryport', {
		required: true,
	});
	validateOnChange('#adminCreateInstanzClient', {
		required: true,
	});
	validateOnChange('#adminCreateInstanzPassword', {
		required: true,
	});
	
	/*
		Detect changed Input
	*/
	$('input').on('input',function()
	{
		OverlayButton.setButton(true);
	});
	
	/*
		Overlay button
	*/
	OverlayButton.setButtonClass("btn-secondary");
	OverlayButton.setIconClass("fa-plus");
	OverlayButton.setTooltip(lang.create);
	OverlayButton.on("click", function() {
		createInstanz();
	});
	OverlayButton.start();
	OverlayButton.setButton(false);
	
	/*
		Instancequery
	*/
	queryConsoleSelected 				= 	new Array();
	
	function showInstanzConsole(instanz)
	{
		$(".instanzControl"+instanz).css("display", "none");
		$(".instanzControlBack"+instanz).css("display", "inline");
		$("#instanzConsole"+instanz).css("display", "inline");
	};
	
	function showInstanzEdit(instanz)
	{
		$(".instanzControl"+instanz).css("display", "none");
		$(".instanzControlBack"+instanz).css("display", "inline");
		$("#instanzEdit"+instanz).css("display", "inline");
	};
	
	function showInstanzControl(instanz)
	{
		$(".instanzControl"+instanz).css("display", "inline");
		$(".instanzControlBack"+instanz).css("display", "none");
		$("#instanzConsole"+instanz).css("display", "none");
		$("#instanzEdit"+instanz).css("display", "none");
	};
	
	/*
		Shell select command
	*/
	function selectShellCommand(id)
	{
		$('#active-shell-start').css("display", "none");
		$('#active-shell-stop').css("display", "none");
		$('#active-shell-restart').css("display", "none");
		
		switch(id)
		{
			case "command-start":
				$('.active-shell').removeClass("active-shell");
				$('#command-start').addClass("active-shell");
				$('#active-shell-start').css("display", "inline");
				break;
			case "command-stop":
				$('.active-shell').removeClass("active-shell");
				$('#command-stop').addClass("active-shell");
				$('#active-shell-stop').css("display", "inline");
				break;
			case "command-restart":
				$('.active-shell').removeClass("active-shell");
				$('#command-restart').addClass("active-shell");
				$('#active-shell-restart').css("display", "inline");
				break;
		};
	};
	
	/*
		Shellcommand
	*/
	function shellCommand(ip)
	{
		var command		=	"restart",
			useClient	=	$('#useShellClient').prop("checked");
		
		if($("#command-start").hasClass("active-shell"))
		{
			command		=	"start";
		}
		else if($("#command-stop").hasClass("active-shell"))
		{
			command		=	"stop";
		};
		
		if((($('#shellClient').val() != "" && useClient) || ($('#shellClientKey').val() != "" != "" && !useClient)) && $('#shellPort').val() != "")
		{
			if(($('#shellClient').val() != 'root' && useClient) || ($('#shellClientKey').val() != 'root' && !useClient))
			{
				if(useClient)
				{
					var postData	=	{
						action: 		'instanzShell',
						ip:				ip,
						port:			$('#shellPort').val(),
						username:		$('#shellClient').val(),
						password:		encodeURIComponent($('#shellPassword').val()),
						command:		command,
						path:			encodeURIComponent($('#shellPath').val())
					};
				}
				else
				{
					var postData	=	{
						action: 		'instanzShell',
						ip:				ip,
						port:			$('#shellPort').val(),
						username:		$('#shellClientKey').val(),
						password:		encodeURIComponent($('#shellPassphare').val()),
						command:		command,
						path:			encodeURIComponent($('#shellPath').val()),
						file:			$('#shellKeySelect').val()
					};
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsShell.php",
					data: postData,
					success: function(data) {
						console.log(data);
						document.getElementById("instanzShellConsole").innerHTML	=	data;
						$("#instanzShellConsoleBox").slideDown("slow");
					}
				});
			}
			else
			{
				setNotifyFailed(lang.no_root);
			};
		}
		else
		{
			setNotifyFailed(lang.instanz_add_empty);
		};
	};
	
	$('#modalShellInstanz').on('show.bs.modal', function (event)
	{
		var button 		=	$(event.relatedTarget),
			ip		 	= 	button.data('ip');
		
		document.getElementById('shellCommand').addEventListener("click", function(){
			shellCommand(ip)
		});
	});
</script>