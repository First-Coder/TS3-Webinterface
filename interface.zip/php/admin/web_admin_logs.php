 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/*
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success']) {
		if($user_right['data']['perm_admin_logs'] != $mysql_keys['perm_admin_logs']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_admin_logs missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Read logs
	*/
	$systemLogs = file(__DIR__."/../../logs/system.log");
	$userLogs = file(__DIR__."/../../logs/user.log");
?>

<script>
	function loglevelColor(row, index) {
		if(row.logLevel == "WARNING") {
			return { classes: 'text-warning' };
		} else if(row.logLevel == "CRITICAL" || row.logLevel == "ERROR") {
			return { classes: 'text-danger' };
		} else {
			return {};
		};
	};
</script>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['logs']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'systemlogs') ? "active" : ""; ?>">
				<a href="#systemlogs">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['system_logs']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'clientlogs') ? "active" : ""; ?>">
				<a href="#clientlogs">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['client_logs']; ?></span>
				</a>
			</li>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $language['system_logs']; ?></h3>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="systemlogs" class="alert <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'systemlogs') ? "active" : ""; ?>">
					<?php
						$logAvalible = explode("|", $systemLogs[0]);
						if(empty($systemLogs)) {
							echo "<p style=\"text-align: center;\">".$language['no_entrys']."</p>";
						} else { ?>
							<table data-toggle="table" data-card-view="true" data-classes="table-no-bordered table-hover table"
								data-striped="true" data-pagination="true" data-search="true" data-row-style="loglevelColor">
								<thead>
									<tr>
										<th data-field="date"><?php echo $language['date']; ?></th>
										<th data-field="logLevel"><?php echo $language['loglevel']; ?></th>
										<th data-field="description"><?php echo $language['description']; ?></th>
									</tr>
								</thead>
								<tbody>
									<?php
										foreach(array_reverse($systemLogs) AS $entry) {
											$entryParts = explode("|", $entry);
											echo "<tr>
													<td>".xssSafe(trim($entryParts[0]))."</td>
													<td>".xssSafe(trim($entryParts[1]))."</td>
													<td>".xssSafe(trim($entryParts[2]))."</td>
												</tr>";
										};
									?>
								</tbody>
							</table>
					<?php }; ?>
				</div>
				<div id="clientlogs" class="alert <?php echo ($LinkInformations[2] == 'clientlogs') ? "active" : ""; ?>">
					<?php
						$logAvalible = explode("|", $userLogs[0]);
						if(empty($userLogs)) {
							echo "<p style=\"text-align: center;\">".$language['no_entrys']."</p>";
						} else if(count($logAvalible) != 3) {
							echo "<p style=\"text-align: center;\">".$language['log_not_possible']."</p>";
						} else { ?>
							<table data-toggle="table" data-card-view="true" data-classes="table-no-bordered table-hover table"
								data-striped="true" data-pagination="true" data-search="true">
								<thead>
									<tr>
										<th data-field="date"><?php echo $language['date']; ?></th>
										<th data-field="name"><?php echo $language['client']; ?></th>
										<th data-field="description"><?php echo $language['description']; ?></th>
									</tr>
								</thead>
								<tbody>
									<?php
										foreach(array_reverse($userLogs) AS $entry) {
											$entryParts = explode("|", $entry);
											echo "<tr>
													<td>".xssSafe(trim($entryParts[0]))."</td>
													<td>".xssSafe(trim($entryParts[1]))."</td>
													<td>".xssSafe(trim($entryParts[2]))."</td>
												</tr>";
										};
									?>
								</tbody>
							</table>
					<?php }; ?>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/bootstrap/bootstrap-table.js"></script>