<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	require_once(__DIR__."/../../php/functions/functionsTicket.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right		=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Clientinformations
	*/
	$userServer		=	0;
	$userInstanzen	=	0;
	
	/*
		For the Diagramms
	*/
	$arrayOfSlots	=	array();
	
	/*
		Get Diagramm backgroundColor
	*/
	if(STYLE != "")
	{
		$data 							= 	file(__dir__."/../../css/themes/".STYLE.".css");
	}
	else
	{
		$data 							= 	file(__dir__."/../../css/style.css");
	};
	
	foreach($data as $line)
	{
		if(strpos($line, "#dashboardbgcolor") !== false)
		{
			$tmpLine					=	explode(":", $line);
			$dashboardBgColor			=	trim($tmpLine[1]);
			
			break;
		};
	};
?>

<div class="col-xs-12 main">
	<div class="page-on-top settings">
		<div class="row m-b-40">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<?php if(CUSTOM_DASHBOARD_PAGE == "true") {
						include(__DIR__."/../../config/custompages/custom_dashboard.php");
				} else { ?>
					<div class="info-settings media-left-right">
						<div class="row">
							<div class="col-md-4 mb-3">
								<div>
									<div class="dashboard-profile">
										<div class="row">
											<div class="col-md-12">
												<img class="img-circle h-100 w-100" src="<?php echo getUserPicture(); ?>" />
												<h5><?php xssEcho($_SESSION['user']['benutzer']); ?></h5>
											</div>
										</div>
										<div class="row stats">
											<div class="col-xs-12">
												<div class="row">
													<div class="col-xs-6">
														<div class="row">
															<div class="col-xs-12">
																<i class="fa fa-globe"></i>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-12" id="userInstanzen">0</div>
														</div>
													</div>
													<div class="col-xs-6">
														<div class="row">
															<div class="col-xs-12">
																<i class="fa fa-server"></i>
															</div>
														</div>
														<div class="row">
															<div class="col-xs-12" id="userServer">0</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-md-8">
								<div class="card">
									<div class="card-block">
										<h4 class="card-title"><i class="fa fa-history" aria-hidden="true"></i> <?php echo $language['last_actions']; ?></h4>
									</div>
									<div class="card-block pt-0">
										<?php
											$userLogs			=	file(__DIR__."/../../logs/user.log");
											$logAvalible		=	explode("|", $userLogs[0]);
											$maxCount			=	30;
											foreach($userLogs AS $index=>$entry)
											{
												$entryParts		=	explode("|", $entry);
												if(trim($entryParts[1]) != $_SESSION['user']['benutzer'] || empty(trim($entryParts[1])) || $maxCount <= 0)
												{
													unset($userLogs[$index]);
												}
												else
												{
													$maxCount--;
												};
											};
											
											if(empty($userLogs))
											{
												echo "<p style=\"text-align: center;\">".$language['no_entrys']."</p>";
											}
											else if(count($logAvalible) != 3)
											{
												echo "<p style=\"text-align: center;\">".$language['log_not_possible']."</p>";
											}
											else
											{ ?>
												<table data-toggle="table" data-card-view="true" data-classes="table-no-bordered table-hover table"
													data-striped="false" data-pagination="true" data-search="false" data-page-size="2" data-page-list="[2]">
													<thead>
														<tr>
															<th data-field="date"><?php echo $language['date']; ?></th>
															<th data-field="description"><?php echo $language['description']; ?></th>
														</tr>
													</thead>
													<tbody>
														<?php
															foreach($userLogs AS $entry)
															{
																$entryParts		=	explode("|", $entry);
																echo "<tr>
																		<td>".xssSafe(trim($entryParts[0]))."</td>
																		<td>".xssSafe(trim($entryParts[2]))."</td>
																	</tr>";
															};
														?>
													</tbody>
												</table>
										<?php }; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="pills-area mt-3 media-left-right">
						<?php if($mysql_modul['webinterface'] == "true")
						{
							foreach($ts3_server AS $instanz => $server)
							{
								if(hasUserInstanz($_SESSION['user']['id'], "$instanz") || $user_right['right_web_global_server']['key'] == $mysql_keys['right_web_global_server'])
								{
									$userInstanzen++;
									
									$errors						=	"";
									$connection					=	true;
									$tsAdmin 					= 	new ts3admin($server['ip'], $server['queryport']);
									
									if($tsAdmin->getElement('success', $tsAdmin->connect()))
									{
										$loginInfo				=	$tsAdmin->login($server['user'], $server['pw']);
										$serverList				=	$tsAdmin->getElement('data', $tsAdmin->serverList());
										$getTeamspeakInfo		=	getTeamspeakslotsArray($serverList, $instanz, true);
										
										if($loginInfo['success'] === false)
										{
											for($i=0; $i+1==count($loginInfo['errors']); $i++)
											{
												$errors		.=  $loginInfo['errors'][$i]."<br />";
											};
										};
									}
									else
									{
										$connection			=	false;
									};
									?>
									<div class="row serveroverview">
										<div class="col-xs-12">
											<div class="card">
												<div class="card-block">
													<div class="row">
														<div class="col-md-3">
															<?php
																if(!$connection)
																{
																	echo '<h3 class="text-danger"><i style="vertical-align: middle;" class="material-icons">warning</i> '.$language['offline'].'</h3>';
																}
																else if($errors != "")
																{
																	echo '<h3 class="text-warning"><i style="vertical-align: middle;" class="material-icons">done</i> '.$language['offline'].'</h3>';
																}
																else
																{
																	echo '<h3 class="text-success"><i style="vertical-align: middle;" class="material-icons">done_all</i> '.$language['online'].'</h3>';
																};
															?>
															<p class="text-sm">
																<?php
																	echo $language['instance'].": ";
																	if($server['alias'] != '')
																	{
																		xssEcho($server['alias']);
																	}
																	else
																	{
																		xssEcho($server['ip']);
																	};
																?>
															</p>
															<?php
																if(!$connection || $errors != "")
																{
																	echo '<span id="animatedBar'.$instanz.'" class="animatedBar isdead hidden-xs-down">0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0</span>';
																}
																else
																{
																	echo '<span id="animatedBar'.$instanz.'" class="animatedBar">0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0</span>';
																};
															?>
														</div>
														<div class="col-md-9 has-info">
															<?php
																if(!$connection || $errors != "")
																{?>
																	<div class="alert alert-danger">
																		<?php if(!$connection) { ?>
																			<i class="fa fa-ban" aria-hidden="true"></i> <?php echo $language['ts_instanz_connection_failed']; ?>
																		<?php } else { ?>
																			<i class="fa fa-ban" aria-hidden="true"></i> <?php echo $errors; ?>
																		<?php }; ?>
																	</div>
															<?php }
																else
																{ ?>
																	<div id="toolbar<?php echo $instanz; ?>">
																		<button onClick="changeContent('web_teamspeak_server');" class="btn btn-info btn-flat"><i class="fa fa-eye" aria-hidden="true"></i> <?php echo $language['server_overview']; ?></button>
																	</div>
																	<table data-toggle="table" data-card-view="false" data-classes="table-no-bordered table-hover table serveroverview-table" data-toolbar="#toolbar<?php echo $instanz; ?>"
																		data-striped="false" data-pagination="true" data-search="true" data-page-size="5" data-page-list="[5]">
																		<thead>
																			<tr>
																				<th class="hidden-sm-down" data-field="id" data-halign="left" data-align="center"><?php echo $language['server_id']; ?></th>
																				<th data-field="name"><?php echo $language['ts3_servername']; ?></th>
																				<th data-field="port" data-halign="left" data-align="center"><?php echo $language['port']; ?></th>
																				<th class="hidden-sm-down" data-field="status" data-halign="left" data-align="center"><?php echo $language['status']; ?></th>
																				<th data-field="clients" data-halign="left" data-align="center"><?php echo $language['client']; ?></th>
																			</tr>
																		</thead>
																		<tbody>
																			<?php foreach($getTeamspeakInfo AS $server) {
																				if(strpos($user_right['right_web_server_view'][$instanz], $server['virtualserver_port']) !== false || $user_right['right_web_global_server']['key'] == $mysql_keys['right_web_global_server'])
																				{
																					$userServer++; ?>
																					<tr data-sid="<?php echo $server['virtualserver_id']; ?>" data-instanz="<?php echo $instanz; ?>">
																						<td class="hidden-sm-down"><?php echo $server['virtualserver_id']; ?></td>
																						<td><?php xssEcho($server['virtualserver_name']); ?></td>
																						<td><?php echo $server['virtualserver_port']; ?></td>
																						<td id="status-<?php echo $instanz; ?>-<?php echo $server['virtualserver_id']; ?>" class="hidden-sm-down <?php echo ($server['virtualserver_status'] == "online") ? "text-success" : "text-danger"; ?>">
																							<?php xssEcho($server['virtualserver_status']); ?>
																						</td>
																						<td id="clients-<?php echo $instanz; ?>-<?php echo $server['virtualserver_id']; ?>">
																							<?php if($server['virtualserver_status'] == "online")
																							{
																								echo $server['virtualserver_clientsonline']." / ".$server['virtualserver_maxclients'];
																							}
																							else
																							{
																								echo "-";
																							}; ?>
																						</td>
																					</tr>
																				<?php };
																			}; ?>
																		</tbody>
																	</table>
															<?php }; ?>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								<?php };
							};
						};
					}; ?>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/jquery/jquery.peity.min.js"></script>
<script src="js/bootstrap/bootstrap-table.js"></script>
<script src="js/webinterface/teamspeak.js"></script>
<script>
 	$(function ()
	{
		if(document.getElementById('userInstanzen') && document.getElementById('userServer'))
		{
			document.getElementById('userInstanzen').innerText 	= 	"<?php echo $userInstanzen; ?>";
			document.getElementById('userServer').innerText 	= 	"<?php echo $userServer; ?>";
		};
		
		$('.animatedBar').each(function() {
			var id		=	'#'+$(this).attr("id");
			var chart 	= 	$(id).peity('bar', {
				height: 32,
				width: '100%',
				fill: ['#0081d1']
			});
			if(!$(this).hasClass("isdead"))
			{
				animatedPeityBar(chart);
			};
		});
		//animatedPeityBar('#small-bar-1', 32, "#0081d1");
		function animatedPeityBar(chart) {
			setInterval(function() {
				var random = Math.floor(Math.random() * 10) + 2;
				var values = chart.text().split(',');
				values.shift();
				values.push(random);
				chart.text(values.join(',')).change();
			}, 1000);
		};
		
		$('.serveroverview-table > tbody > tr').click(function() {
			var sid		=	$(this).attr("data-sid"),
				instanz	=	$(this).attr("data-instanz");
			
			changeNavigation(false, sid, instanz);
			changeContent('web_teamspeak_serverview', false);
		});
		
		/*var arrayOfSlots			=	JSON.parse('<?php echo str_replace ("'", "", json_encode($arrayOfSlots)); ?>');
		var pieObject				=	[];
		var instanzNumber			=	new Array();
		var tmpInstanzName			=	0;
		
		for (var instanz in arrayOfSlots)
		{
			var datasets													=	new Object();
			var serverNumber												=	0;
			datasets['datasets']											=	new Array();
			datasets['labels']												=	["<?php echo $language['client']; ?> Online", "Free Slots"];
			datasets['datasets']['label']									=	new Object();
			
			if(arrayOfSlots[instanz] != false && arrayOfSlots[instanz] != null)
			{
				for (var server of arrayOfSlots[instanz])
				{
					if(typeof(server['virtualserver_maxclients']) == "undefined" && typeof(server['virtualserver_name']) != "undefined")
					{
						server['virtualserver_maxclients']					=	32;
					};
					
					datasets['datasets'][serverNumber]						=	new Object();
					datasets['datasets'][serverNumber]['data']				=	[server['virtualserver_clientsonline'], server['virtualserver_maxclients'] - server['virtualserver_clientsonline']];
					datasets['datasets'][serverNumber]['backgroundColor']	=	["<?php echo $dashboardBgColor; ?>", "green"];
					if(typeof(server['virtualserver_name']) != "undefined")
					{
						datasets['datasets']['label'][serverNumber]			=	server['virtualserver_name'];
					}
					else
					{
						datasets['datasets']['label'][serverNumber]			=	server['instanz_name'];
					};
					serverNumber++;
				};
				
				var config =
				{
					type: 'pie',
					data: datasets,
					options:
					{
						responsive: true,
						tooltips:
						{
							callbacks:
							{
								label: function(tooltipItem, data)
								{
									var datasetLabel = data.datasets.label[tooltipItem.datasetIndex]+": ";
									var label = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
									return datasetLabel+label+" "+data.labels[tooltipItem.index];
								}
							}
						}
					},
				};
				
				pieObject.push(new Chart(document.getElementById("chart-instanz-"+instanz).getContext("2d"), config));
				instanzNumber[tmpInstanzName]		=	instanz;
				tmpInstanzName++;
			};
		};
		
		
		// Update Chart
		var chartUpdate = function() {
			if(!document.getElementById("activeDashboard"))
			{
				return;
			};
			
			// Array l�schen
			arrayOfSlots							=	new Object();
			
			// Informationen aktualisieren
			for (var instanz of instanzNumber)
			{
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action:		'getTeamspeakslots',
						instanz:	instanz
					},
					async: false,
					success: function(data){
						// Neue Daten �bergeben
						var informations			= 	JSON.parse(data);
						arrayOfSlots[instanz]		=	informations;
					}
				});
			};
			
			
			tmpInstanzName							=	0;
			for(pie of pieObject)
			{
				var tmpServerNumber					=	0;
				
				for (var server of arrayOfSlots[instanzNumber[tmpInstanzName]])
				{
					if(typeof(server['virtualserver_maxclients']) == "undefined" && typeof(server['virtualserver_name']) != "undefined")
					{
						server['virtualserver_maxclients']					=	32;
					};
					
					pie.config.data.datasets[tmpServerNumber].data[0] 		= 	server['virtualserver_clientsonline'];
					pie.config.data.datasets[tmpServerNumber].data[1] 		= 	server['virtualserver_maxclients'] - server['virtualserver_clientsonline'];
					
					if(typeof(server['virtualserver_id']) != "undefined")
					{
						if(server['virtualserver_status'] == "online" && document.getElementById("clients-"+tmpInstanzName+"-"+server['virtualserver_id']))
						{
							document.getElementById("clients-"+tmpInstanzName+"-"+server['virtualserver_id']).innerText = server['virtualserver_clientsonline']+" / "+server['virtualserver_maxclients'];
						};
					};
					
					tmpServerNumber++;
				};
				
				pie.update();
				tmpInstanzName++;
			};
			
			setTimeout (function() { chartUpdate(); }, 10000);
		};
		
		setTimeout (function() { chartUpdate(); }, 1000);*/
	});
</script>