<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	$mysql_modul = getModuls();
	
	/**
		Check Session
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	if(!$user_right['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};

	/**
		Get instance information
	*/
	if(!isset($ts3_server) || count($ts3_server) > 0) {
		$info = getInstanceInfo(0);
	};

	/**
		Create chartobject
	*/
	$chart = array(
		"labels" => array("Instance"),
		"series" => array(
			array(0),
			array(0)
		)
	);
	
	if(!empty($info['data']['clients'])) {
		foreach($info['data']['clients'] AS $y => $x) {
			if($y !== "Instance") {
				$chart['labels'][] = $y;
				$chart['series'][0][] = $x['clients'];
				$chart['series'][1][] = $x['online'];
			} else {
				$chart['series'][0][0] = $x['clients'];
				$chart['series'][1][0] = $x['online'];
			};
		};
	};
?>

<?php if(count($ts3_server) > 0) { ?>
	<div class="d-flex flex-row justify-content-between">
		<div class="content-header color-header justify-content-start">Dashboard</div>
		<?php if($mysql_modul['data']['splamy_musicbot'] === 'true') { ?>
			<div class="justify-content-end dashboard-jumbotron-content">
				<ul>
					<li class="active"><a href="#" class="mr-1"><i class="fab fa-teamspeak"></i>Teamspeak</a></li>
					<li><a href="#"><i class="fas fa-music"></i><?php echo $language['musicbot']; ?></a></li>
				</ul>
			</div>
		<?php }; ?>
	</div>

	<?php
		$SOAP_NEWS = getSoapNews();
		if(!empty($SOAP_NEWS)) { ?>
			<div class="row">
				<div class="col">
					<div class="card card-dashboard-comp">
						<div class="card-block">
							<div class="row align-items-center">
								<div class="col card-content">
									<h6><?php echo $language['important_inforamtion']; ?></h6>
									<h3><?php echo $SOAP_NEWS ?></h3>
								</div>
								<div class="col-auto">
									<i class="fas fa-info"></i>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php };
	?>

	<div class="row mb-4">
		<div class="col-xl-8 col-md-12">
			<div class="card card-dashboard">
				<div class="card-header">
					<h5><?php echo $language['user_statistics']; ?></h5>
				</div>
				<div class="card-block">
					<div class="ct-chart"></div>
				</div>
			</div>
		</div>
		<div class="col-xl-4 col-md-12">
			<div class="card card-dashboard-comp mb-3" data-color="blue">
				<div class="card-block">
					<div class="row align-items-center">
						<div class="col card-content">
							<h6><?php echo $language['choosed_instance']; ?></h6>
							<div class="dropdown">
								<button class="btn dropdown-toggle dashboard-dropdown" type="button" id="dropdownDashboardButton" data-instance="0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<h3><?php echo cutString($ts3_server[0]['alias'], 15); ?></h3>
								</button>
								<div class="dropdown-menu ml-0" aria-labelledby="dropdownDashboardButton">
									<?php foreach($ts3_server AS $i => $s) {
										if(($user_right === false || $user_right['data']['perm_teamspeak_access_server'] != $mysql_keys['perm_teamspeak_access_server']) && !checkClientHasInstance($_SESSION['user']['id'], $i)) {
											continue;
										}; ?>
										<a class="dropdown-item" href="#" data-instance="<?php echo $i; ?>"><?php echo $s['alias']; ?></a>
									<?php }; ?>
								</div>
							</div>
							<p><?php echo $language['choosed_instance_info']; ?></p>
						</div>
						<div class="col-auto">
							<i class="fas fa-globe"></i>
						</div>
					</div>
				</div>
			</div>
			<div class="card card-dashboard-comp server-status" data-color="<?php echo ($info['success']) ? "green" : "red"; ?>">
				<div class="card-block">
					<div class="row align-items-center">
						<div class="col card-content">
							<h6><?php echo $language['status']; ?></h6>
							<h3><?php echo ($info['success']) ? $language['online'] : $language['offline']; ?></h3>
							<p><?php echo ($info['success']) ? $language['online_since'].": ".convertSecondsToStrTime($info['data']['hostinfo']['instance_uptime'], false) : implode(" ", $info['error']); ?></p>
						</div>
						<div class="col-auto">
							<i class="fas <?php echo ($info['success']) ? "fa-signal" : "fa-exclamation"; ?>"></i>
						</div>
					</div>
				</div>
			</div>
			<div class="card card-dashboard-comp" data-color="yellow">
				<div class="card-block">
					<div class="row align-items-center">
						<div class="col card-content">
							<h6><?php echo $language['traffic']; ?></h6>
							<h3><?php echo '<span>'.($info['data']['hostinfo']['connection_bandwidth_sent_last_minute_total'] + $info['data']['hostinfo']['connection_bandwidth_received_last_minute_total']).'</span> '.$language['byte_m']; ?></h3>
							<p><?php echo $language['refresh_in']; ?> <span>60</span>s</p>
						</div>
						<div class="col-auto">
							<i class="fas fa-traffic-light"></i>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12">
			<div class="card card-dashboard-prog">
				<div class="card-block">
					<div class="row">
						<div class="col-md-6 col-sm-12 card-content" data-content="serveruse">
							<h6><?php echo $language['best_serveruse']; ?></h6>
							<h5><?php xssEcho($info['data']['statistics']['server_online']['virtualserver_name']); ?></h5>
							<div class="progress">
								<div class="progress-success" style="width: <?php echo ($info['data']['statistics']['server_online']['virtualserver_uptime'] / $info['data']['hostinfo']['instance_uptime']) * 100; ?>%;"></div>
							</div>
						</div>
						<div class="col-md-6 col-sm-12 card-content" data-content="traffic">
							<h6><?php echo $language['most_trafficuse']; ?></h6>
							<h5><?php xssEcho($info['data']['statistics']['server_traffic']['virtualserver_name']); ?></h5>
							<?php if(intval($info['data']['hostinfo']['connection_bandwidth_received_last_minute_total']) === 0 && intval($info['data']['hostinfo']['connection_bandwidth_sent_last_minute_total']) === 0) {
								$width = 100;
							} else {
								$width = ($info['data']['statistics']['server_traffic']['virtualserver_traffic'] / ($info['data']['hostinfo']['connection_bytes_sent_total'] + $info['data']['hostinfo']['connection_bytes_received_total'])) * 100;
							}; ?>
							<div class="progress">
								<div class="progress-danger" style="width: <?php echo $width; ?>%;"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-12">
			<div class="card card-dashboard">
				<div class="card-header">
					<h5><?php echo $language['all_users']; ?> <span id="clientNum" class="badge badge-pill badge-danger">0</span></h5>
				</div>
				<div class="card-block">
					<table id="clientTable" data-ajax="ajaxRequestTable" data-card-view="true" data-show-refresh="true" data-classes="table-no-bordered table-hover table" data-striped="true" data-pagination="true" data-search="true">
						<thead>
							<tr>
								<th data-field="client"><?php echo $language['client']; ?></th>
								<th data-field="status"><?php echo $language['status']; ?></th>
								<th data-field="first_con"><?php echo $language['first_con']; ?></th>
								<th data-field="last_con"><?php echo $language['last_con']; ?></th>
								<th data-field="ip"><?php echo $language['ip_adress']; ?></th>
								<th data-field="connection"><?php echo $language['connections']; ?></th>
								<th data-field="description"><?php echo $language['description']; ?></th>
								<th data-field="client_id"><?php echo $language['client']; ?> ID</th>
								<th data-field="id"><?php echo $language['client']; ?> DB ID</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php } else { ?>
	<div class="content-header color-header">Dashboard</div>

	<div class="row mb-4">
		<div class="col">
			<div class="card card-dashboard">
				<div class="card-block">
					<?php echo $language['dashboard_no_instance']; ?>
				</div>
			</div>
		</div>
	</div>
<?php }; ?>

<script src="js/bootstrap/bootstrap-table.js"></script>
<script src="js/chart/chartist.js"></script>
<script>
	/**
	 * Variables
	 */
	let counter = 60;
	let chart = null;

	/**
	 * Instance change
	 */
	$('.card-dashboard-comp[data-color="blue"] .dropdown-menu > a').click((e) => {
		counter = -1;

		e.preventDefault();
		document.getElementById('dropdownDashboardButton').setAttribute('data-instance', e.target.getAttribute('data-instance'));
		refresh(true, e.target.innerHTML);
	});

	/**
	 * Refresh
	 */
	let refresh = (instanceChange = false, name = "Unknown") => {
		if(document.querySelector('.card-dashboard-comp') === null) {
			return;
		};

		if(counter > 0) {
			document.querySelector('.card-dashboard-comp[data-color="yellow"] p > span').innerHTML = --counter;
			setTimeout(refresh, 1000);
		} else if(counter === 0 || instanceChange) {
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'getInstanceInfo',
					instance: document.querySelector('.card-dashboard-comp[data-color="blue"] button').getAttribute('data-instance')
				},
				success: function(data) {
					var json = JSON.parse(data);
					
					let chartData = {
						"labels": ["Instance"],
						"series": [
							[],
							[]
						]
					};

					if(instanceChange) {
						document.querySelector('.card-dashboard-comp[data-color="blue"] button > h3').innerHTML = escapeText(cutString(name, 15));
					};

					if(json.success && json.data.clients !== undefined && json.data.clients !== null) {
						chartData.series[0][0] = 0;
						chartData.series[1][0] = 0;

						for(let y in json.data.clients) {
							if(y !== "Instance") {
								chartData.labels.push(y);
								chartData.series[0].push(json.data.clients[y]['clients']);
								chartData.series[1].push(json.data.clients[y]['online']);
							} else {
								chartData.series[0][0] = json.data.clients[y]['clients'];
								chartData.series[1][0] = json.data.clients[y]['online'];
							};
						};
					};

					if(json.success) {
						document.querySelector('.card-dashboard-comp.server-status').setAttribute('data-color', 'green');
						document.querySelector('.card-dashboard-comp.server-status h3').innerHTML = lang.online;
						document.querySelector('.card-dashboard-comp.server-status p').innerHTML = lang.online_since+': '+convertSecondsToStrTime(json.data.hostinfo.instance_uptime, false);
						document.querySelector('.card-dashboard-comp.server-status i').classList.remove('fa-exclamation');
						document.querySelector('.card-dashboard-comp.server-status i').classList.add('fa-signal');

						document.querySelector('.card-dashboard-comp[data-color="yellow"] span').innerHTML = (parseInt(json.data.hostinfo.connection_bandwidth_sent_last_minute_total) + parseInt(json.data.hostinfo.connection_bandwidth_received_last_minute_total));
						document.querySelector('.progress-success').style.width = ((json.data.statistics.server_online.virtualserver_uptime / json.data.hostinfo.instance_uptime) * 100)+"%";
						document.querySelector('.progress-danger').style.width = ((json.data.statistics.server_traffic.virtualserver_traffic / (parseInt(json.data.hostinfo.connection_bytes_sent_total) + parseInt(json.data.hostinfo.connection_bytes_received_total))) * 100)+"%";
						document.querySelector('.card-content[data-content="serveruse"] h5').innerHTML = escapeText(json.data.statistics.server_online.virtualserver_name);
						document.querySelector('.card-content[data-content="traffic"] h5').innerHTML = escapeText(json.data.statistics.server_traffic.virtualserver_name);
						
						chart.update(chartData);
					} else {
						document.querySelector('.card-dashboard-comp.server-status').setAttribute('data-color', 'red');
						document.querySelector('.card-dashboard-comp.server-status h3').innerHTML = lang.offline;
						document.querySelector('.card-dashboard-comp.server-status p').innerHTML = json.error.join();
						document.querySelector('.card-dashboard-comp.server-status i').classList.remove('fa-signal');
						document.querySelector('.card-dashboard-comp.server-status i').classList.add('fa-exclamation');

						document.querySelector('.card-dashboard-comp[data-color="yellow"] span').innerHTML = "0";
						document.querySelector('.progress-success').style.width = "0%";
						document.querySelector('.progress-danger').style.width = "0%";
						document.querySelector('.card-content[data-content="serveruse"] h5').innerHTML = "-";
						document.querySelector('.card-content[data-content="traffic"] h5').innerHTML = "-";

						chart.update(chartData);
					};

					counter = 61;
					if(instanceChange) {
						$('#clientTable').bootstrapTable("refresh");
					} else {
						setTimeout(refresh, 1000);
					};
				}
			});
		} else {
			setTimeout(refresh, 1000);
		};
	};
	setTimeout(refresh, 1000);		

	/**
	 * Manage charts
	 */
	if(document.getElementById('clientTable')) {
		let data = JSON.parse('<?php echo json_encode($chart); ?>');
		let seq = 0, delays = 80, durations = 1000;
		const options = {
			seriesBarDistance: 10,
			height: '350px'
		};
		const responsiveOptions = [
			['screen and (max-width: 640px)', {
				seriesBarDistance: 5,
				axisX: {
					labelInterpolationFnc: function (value) {
						return (value === "Instance") ? value[0] : value;
					}
				}
			}]
		];

		chart = new Chartist.Bar('.ct-chart', data, options, responsiveOptions);
		chart.on('created', function() {
			seq = 0;
		});

		chart.on('draw', function(data) {
			seq++;

			if(data.type == 'bar') {
				if(data.seriesIndex == 0) {
					data.element.animate({
						y2: {
							begin: delays + durations + 500,
							dur: '1s',
							from: data.y1,
							to: data.y2
						}
					});
				};
				if(data.seriesIndex == 1) {
					data.element.animate({
						y2: {
							begin: delays + durations + 1500,
							dur: '1s',
							from: data.y1,
							to: data.y2
						}
					});
				};
			} else if(data.type === 'grid') {
				var pos1Animation = {
					begin: seq * delays,
					dur: durations,
					from: data[data.axis.units.pos + '1'] - 30,
					to: data[data.axis.units.pos + '1'],
					easing: 'easeOutQuart'
				};

				var pos2Animation = {
					begin: seq * delays,
					dur: durations,
					from: data[data.axis.units.pos + '2'] - 100,
					to: data[data.axis.units.pos + '2'],
					easing: 'easeOutQuart'
				};

				var animations = {};
				animations[data.axis.units.pos + '1'] = pos1Animation;
				animations[data.axis.units.pos + '2'] = pos2Animation;
				animations['opacity'] = {
					begin: seq * delays,
					dur: durations,
					from: 0,
					to: 1,
					easing: 'easeOutQuart'
				};

				data.element.animate(animations);
			};
		});
	};

	/**
		Manage tables
	*/
	if(document.getElementById('clientTable')) {
		$('#clientTable').bootstrapTable({
			formatNoMatches: function () {
				return lang.filelist_none;
			}
		});
	};

	function ajaxRequestTable(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getInstanceClients',
				instance: document.querySelector('.card-dashboard-comp[data-color="blue"] button').getAttribute('data-instance')
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					if(info.data.length > 0) {
						$('#clientNum').removeClass('badge-danger').addClass('badge-success');
						for(var entry of info.data) {
							data.push({
								'client': entry.client_nickname,
								'status': (entry.client_online) ? '<span class="text-success">'+lang.online+'</span>' : '<span class="text-danger">'+lang.offline+'</span>',
								'first_con': entry.client_created,
								'last_con': entry.client_lastconnected,
								'ip': entry.client_lastip,
								'connection': entry.client_totalconnections,
								'description': entry.client_description,
								'client_id': entry.client_unique_identifier,
								'id': entry.cldbid
							});
						};
					} else {
						$('#clientNum').removeClass('badge-success').addClass('badge-danger');
					};
					$('#clientNum').text(info.data.length);
				} else {
					console.log(`Client List: ${info.error.join()}`);
				};
				
				params.success({
					total: 100,
					rows: data
				});
			}
		});
	};
</script>