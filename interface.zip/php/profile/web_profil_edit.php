<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get private information above the Client
	*/
	$userInformations	=	getUserInformations($_SESSION['user']['id']);
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a href="#" class="nav-link active" data-toggle="tab" data-target="#profile-edit"><?php echo $language['profile']; ?></a>
					</li>
					<li class="nav-item">
						<a href="#" class="nav-link" data-toggle="tab" data-target="#profile-picture"><?php echo $language['profil_picture']; ?></a>
					</li>
					<li class="nav-item">
						<a href="#" class="nav-link" data-toggle="tab" data-target="#profile-permission"><?php echo $language['permission']; ?></a>
					</li>
				</ul>
				<div class="tab-content form-secondary">
					<div role="tabpanel" class="tab-pane active" id="profile-edit">
						<h4><i class="fa fa-sign-in"></i> <?php echo $language['login_informations']; ?></h4>
						<div class="form-group">
							<label><?php echo $language['mail']; ?></label>
							<input id="profileUser" type="email" class="form-control" value="<?php xssEcho($_SESSION['user']['benutzer']); ?>">
							<span class="bmd-help"><?php echo $language['mail_help']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['password']; ?></label>
							<input id="profilePassword" type="password" class="form-control" placeholder="******">
							<span class="bmd-help"><?php echo $language['password_help']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['password']; ?></label>
							<input id="profilePassword2" type="password" class="form-control" placeholder="******">
							<span class="bmd-help"><?php echo $language['password_help']; ?></span>
						</div>
						
						<h4 class="mt-3"><i class="fa fa-address-card-o"></i> <?php echo $language['perso_infos']; ?></h4>
						<div class="form-group" style="clear: both;">
							<label><?php echo $language['firstname']; ?></label>
							<input id="profileVorname" type="text" class="form-control" value="<?php xssEcho($userInformations['vorname']); ?>">
							<span class="bmd-help"><?php echo $language['firstname_info']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['lastname']; ?></label>
							<input id="profileNachname" type="text" class="form-control" value="<?php xssEcho($userInformations['nachname']); ?>">
							<span class="bmd-help"><?php echo $language['lastname_info']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['telefon']; ?></label>
							<input id="profileTelefon" type="number" class="form-control" value="<?php xssEcho($userInformations['telefon']); ?>">
							<span class="bmd-help"><?php echo $language['telefon_info']; ?></span>
						</div>
						
						<h4 class="mt-3"><i class="fa fa-address-book-o"></i> <?php echo $language['kontakt_infos']; ?></h4>
						<div class="form-group" style="clear: both;">
							<label><?php echo $language['homepage']; ?></label>
							<input id="profileHomepage" type="text" class="form-control" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['homepage'])); ?>">
							<span class="bmd-help"><?php echo $language['homepage_info']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['skype']; ?></label>
							<input id="profileSkype" type="text" class="form-control" value="<?php xssEcho($userInformations['skype']); ?>">
							<span class="bmd-help"><?php echo $language['skype_info']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['steam']; ?></label>
							<input id="profileSteam" type="text" class="form-control" value="<?php xssEcho($userInformations['steam']); ?>">
							<span class="bmd-help"><?php echo $language['steam_info']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['twitter']; ?></label>
							<input id="profileTwitter" type="text" class="form-control" value="<?php xssEcho($userInformations['twitter']); ?>">
							<span class="bmd-help"><?php echo $language['twitter_info']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['facebook']; ?></label>
							<input id="profileFacebook" type="text" class="form-control" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['facebook'])); ?>">
							<span class="bmd-help"><?php echo $language['facebook_info']; ?></span>
						</div>
						<div class="form-group">
							<label><?php echo $language['google_plus']; ?></label>
							<input id="profileGoogle" type="text" class="form-control" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['google'])); ?>">
							<span class="bmd-help"><?php echo $language['google_plus_info']; ?></span>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane" id="profile-picture">
						<h4><i class="fa fa-file-image-o"></i> <?php echo $language['profil_picture']; ?></h4>
						<div class="row mt-3">
							<div class="col-xs-12 col-md-4" style="text-align: center;">
								<img id="profile-picture-img" src="<?php echo getUserPicture(); ?>" width="100" height="100" class="img-rounded"/>
							</div>
							<div class="col-xs-12 col-md-8">
								<label class="custom-file w-100-percent">
									<input type="file" id="uploadProfilePicture" class="custom-file-input">
									<span class="custom-file-control"></span>
								</label>
								<p><?php echo $language['profile_picture_info']; ?></p>
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane" id="profile-permission">
						<h4 class="card-title"><i class="fa fa-university"></i> <?php echo $language['hp_rights']; ?></h4>
						<h6 class="card-subtitle text-muted mb-3"><?php echo $language['global_rights']; ?></h6>
						<table class="table permission-table">
							<tbody>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_main']['key'] == $mysql_keys['right_hp_main']) { ?>
									<tr class="<?php echo ($user_right['right_hp_main']['key'] == $mysql_keys['right_hp_main']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['hp_rights_edit']; ?><p class="text-muted"><?php echo $language['hp_rights_edit_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_main']['key'] == $mysql_keys['right_hp_main']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_ts3']['key'] == $mysql_keys['right_hp_ts3']) { ?>
									<tr class="<?php echo ($user_right['right_hp_ts3']['key'] == $mysql_keys['right_hp_ts3']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['ts3_rights_edit']; ?><p class="text-muted"><?php echo $language['ts3_rights_edit_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_ts3']['key'] == $mysql_keys['right_hp_ts3']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_user_create']['key'] == $mysql_keys['right_hp_user_create']) { ?>
									<tr class="<?php echo ($user_right['right_hp_user_create']['key'] == $mysql_keys['right_hp_user_create']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['user_add']; ?><p class="text-muted"><?php echo $language['user_add_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_user_create']['key'] == $mysql_keys['right_hp_user_create']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_user_delete']['key'] == $mysql_keys['right_hp_user_delete']) { ?>
									<tr class="<?php echo ($user_right['right_hp_user_delete']['key'] == $mysql_keys['right_hp_user_delete']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['user_delete']; ?><p class="text-muted"><?php echo $language['user_delete_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_user_delete']['key'] == $mysql_keys['right_hp_user_delete']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_user_edit']['key'] == $mysql_keys['right_hp_user_edit']) { ?>
									<tr class="<?php if($user_right['right_hp_user_edit']['key'] == $mysql_keys['right_hp_user_edit']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['user_edit']; ?><p class="text-muted"><?php echo $language['user_edit_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_user_edit']['key'] == $mysql_keys['right_hp_user_edit']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_ticket_system']['key'] == $mysql_keys['right_hp_ticket_system']) { ?>
									<tr class="<?php if($user_right['right_hp_ticket_system']['key'] == $mysql_keys['right_hp_ticket_system']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['ticket_admin']; ?><p class="text-muted"><?php echo $language['ticket_admin_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_ticket_system']['key'] == $mysql_keys['right_hp_ticket_system']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_mails']['key'] == $mysql_keys['right_hp_mails']) { ?>
									<tr class="<?php if($user_right['right_hp_mails']['key'] == $mysql_keys['right_hp_mails']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['mail_settings']; ?><p class="text-muted"><?php echo $language['mail_settings_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_mails']['key'] == $mysql_keys['right_hp_mails']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_hp_logs']['key'] == $mysql_keys['right_hp_logs']) { ?>
									<tr class="<?php if($user_right['right_hp_logs']['key'] == $mysql_keys['right_hp_logs']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['logs']; ?><p class="text-muted"><?php echo $language['logs_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_hp_logs']['key'] == $mysql_keys['right_hp_logs']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
							</tbody>
						</table>
						
						<h4 class="card-title mt-3"><i class="fa fa-university"></i> <?php echo $language['ts_rights']; ?></h4>
						<h6 class="card-subtitle text-muted mb-3"><?php echo $language['global_rights']; ?></h6>
						<table class="table permission-table">
							<tbody>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_web']['key'] == $mysql_keys['right_web']) { ?>
									<tr class="<?php echo ($user_right['right_web']['key'] == $mysql_keys['right_web']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['access_interface']; ?><p class="text-muted"><?php echo $language['access_interface_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_web']['key'] == $mysql_keys['right_web']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_web_global_message_poke']['key'] == $mysql_keys['right_web_global_message_poke']) { ?>
									<tr class="<?php echo ($user_right['right_web_global_message_poke']['key'] == $mysql_keys['right_web_global_message_poke']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['instance_msg_poke']; ?><p class="text-muted"><?php echo $language['instance_msg_poke_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_web_global_message_poke']['key'] == $mysql_keys['right_web_global_message_poke']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_web_server_create']['key'] == $mysql_keys['right_web_server_create']) { ?>
									<tr class="<?php echo ($user_right['right_web_server_create']['key'] == $mysql_keys['right_web_server_create']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['create_server']; ?><p class="text-muted"><?php echo $language['create_server_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_web_server_create']['key'] == $mysql_keys['right_web_server_create']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_web_server_delete']['key'] == $mysql_keys['right_web_server_delete']) { ?>
									<tr class="<?php echo ($user_right['right_web_server_delete']['key'] == $mysql_keys['right_web_server_delete']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['delete_server']; ?><p class="text-muted"><?php echo $language['delete_server_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_web_server_delete']['key'] == $mysql_keys['right_web_server_delete']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
								<?php if(SHOW_PROFILE_PERMISSIONS == "true" || $user_right['right_web_global_server']['key'] == $mysql_keys['right_web_global_server']) { ?>
									<tr class="<?php echo ($user_right['right_web_global_server']['key'] == $mysql_keys['right_web_global_server']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['access_to_all_server']; ?><p class="text-muted"><?php echo $language['access_to_all_server_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['right_web_global_server']['key'] == $mysql_keys['right_web_global_server']) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
									</tr>
								<?php }; ?>
							</tbody>
						</table>
						
						<?php foreach($ts3_server AS $instanz => $values)
						{
							if(!empty($user_right['right_web_server_view'][$instanz]))
							{
								$ports								=	array_filter(explode(",", $user_right['right_web_server_view'][$instanz]));
								foreach($ports AS $port)
								{
									$instanzname					=	($values['alias'] != '') ? xssSafe($values['alias']) : xssSafe($values['ip']); ?>
									<div onClick="slideMe('box-<?php echo $instanz; ?>-<?php echo $port; ?>', 'arrow-<?php echo $instanz; ?>-<?php echo $port; ?>');" class="mb-3 mt-3" style="cursor: pointer;">
										<h4 class="card-title">
											<i id="arrow-<?php echo $instanz; ?>-<?php echo $port; ?>" class="fa fa-arrow-right"></i> <?php echo $language['port'].': '.$port; ?>
										</h4>
										<h6 class="card-subtitle text-muted">
											<?php echo $language['instance'].': '.$instanzname; ?>
										</h6>
									</div>
									<div id="box-<?php echo $instanz; ?>-<?php echo $port; ?>" style="padding-top: 0;display: none;">
										<table class="table permission-table">
											<tbody>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_view')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_view')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_view']; ?><p class="text-muted"><?php echo $language['server_view_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_view')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_banner')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_banner')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['serverbanner']; ?><p class="text-muted"><?php echo $language['serverbanner_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_banner')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_edit')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_edit')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_edit']; ?><p class="text-muted"><?php echo $language['server_edit_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_edit')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_start_stop')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_start_stop')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_start_stop']; ?><p class="text-muted"><?php echo $language['server_start_stop_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_start_stop')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_message_poke')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_message_poke')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_msg_poke']; ?><p class="text-muted"><?php echo $language['server_msg_poke_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_message_poke')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_mass_actions')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_mass_actions')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_mass_actions']; ?><p class="text-muted"><?php echo $language['server_mass_actions_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_mass_actions')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_protokoll')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_protokoll')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_protokoll']; ?><p class="text-muted"><?php echo $language['server_protokoll_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_protokoll')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_icons')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_icons')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_icons']; ?><p class="text-muted"><?php echo $language['server_icons_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_icons')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_bans')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_bans')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_bans']; ?><p class="text-muted"><?php echo $language['server_bans_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_bans')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_token')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_token')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_token']; ?><p class="text-muted"><?php echo $language['server_token_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_token')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_backups')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_backups')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_backups']; ?><p class="text-muted"><?php echo $language['server_backups_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_backups')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_server_clients')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_clients')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_clients']; ?><p class="text-muted"><?php echo $language['server_clients_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_server_clients')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_file_transfer')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_file_transfer')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['server_filelist']; ?><p class="text-muted"><?php echo $language['server_filelist_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_file_transfer')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_client_actions')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_client_actions')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['client_actions']; ?><p class="text-muted"><?php echo $language['client_actions_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_client_actions')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_client_rights')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_client_rights')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['client_permission']; ?><p class="text-muted"><?php echo $language['client_permission_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_client_rights')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
												<?php if(SHOW_PROFILE_PERMISSIONS == "true" || isPortPermission($user_right, $instanz, $port, 'right_web_channel_actions')) { ?>
													<tr class="<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_channel_actions')) ? "text-success" : "text-danger"; ?>">
														<td><?php echo $language['channel_actions']; ?><p class="text-muted"><?php echo $language['channel_actions_info']; ?></p></td>
														<td class="icon"><i class="fa fa-<?php echo (isPortPermission($user_right, $instanz, $port, 'right_web_channel_actions')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
													</tr>
												<?php }; ?>
											</tbody>
										</table>
									</div>
								<?php };
							};
						}; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/profile.js"></script>
<script>
	/*
		Vars
	*/
	var hasProfilePicture	=	<?php echo (file_exists(__dir__."/../../images/user/".$_SESSION['user']['id'])) ? "true" : "false"; ?>,
		currentContent		=	"edit";
	
	/*
		Profil validation
	*/
	validateOnChange('#profileUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#profilePassword', {
		required: true,
		min: 6
	}, '', lang.change_pw1_failed);
	validateOnChange('#profileVorname', {
		required: true,
		min: 6
	}, '', lang.field_cant_be_empty);
	validateOnChange('#profileNachname', {
		required: true,
		min: 6
	}, '', lang.field_cant_be_empty);
	
	/*
		Upload Profile Picture
	*/
	function dateiauswahl(evt)
	{
		var file = evt.target.files[0];
		
		if (file.type.match('image/png') || file.type.match('image/gif') || file.type.match('image/jpeg'))
		{
			var formData = new FormData();
			formData.append("file", file);
			$.ajax({
				type: 'POST',
				url: './php/functions/functionsUploadProfilePicture.php',
				data: formData,
				contentType: false,
				processData: false,
				success: function(data) {
					if(data != "Client is not logged in!" && data != "Forbidden characters!")
					{
						$('.navbar .dropdown-toggle>div>img').attr("src", "./images/user/"+data);
						$('#profile-picture-img').attr("src", "./images/user/"+data);
						
						OverlayButton.setButton(true);
						
						setNotifySuccess(lang.profile_picture_changed)
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		}
		else
		{
			setNotifyFailed(lang.failed_imagetype);
		};
	};
	
	document.getElementById('uploadProfilePicture').addEventListener('change', dateiauswahl, false);
	
	/*
		Change Profilcontent
	*/
	$('.nav-item>a').click(function()
	{
		var which	=	$(this).attr("data-target");
		
		switch(which)
		{
			case "#profile-edit":
				currentContent		=	"edit";
				
				OverlayButton.setButtonClass("btn-secondary");
				OverlayButton.setIconClass("fa-save");
				OverlayButton.setTooltip(lang.save);
				OverlayButton.start();
				
				if(isEditedProfile)
				{
					OverlayButton.setButton(true);
				}
				else
				{
					OverlayButton.setButton(false);
				};
				break;
			case "#profile-picture":
				currentContent		=	"picture";
				
				OverlayButton.setButtonClass("btn-danger");
				OverlayButton.setIconClass("fa-trash");
				OverlayButton.setTooltip(lang.delete_profile_picture);
				OverlayButton.start();
				
				if(hasProfilePicture)
				{
					OverlayButton.setButton(true);
				}
				else
				{
					OverlayButton.setButton(false);
				};
				break;
			case "#profile-permission":
				OverlayButton.setButton(false);
				break;
		};
	});
	
	/*
		Detect changed input
	*/
	var isEditedProfile 	= 	false;
	$('input, select').not(".custom-file-input").change(function()
	{
		isEditedProfile		=	true;
		OverlayButton.setButton(true);
	});
	$('input').not(".custom-file-input").on('input',function()
	{
		isEditedProfile		=	true;
		OverlayButton.setButton(true);
	});
	
	/*
		Overlay button
	*/
	OverlayButton.setButtonClass("btn-secondary");
	OverlayButton.setIconClass("fa-save");
	OverlayButton.setTooltip(lang.save);
	OverlayButton.on("click", function() {
		if(currentContent == "edit")
		{
			if(isDataValid('profileUser') && isDataValid('profileVorname') && isDataValid('profileNachname'))
			{
				profilUpdate();
				isEditedProfile		=	false;
			}
			else
			{
				setNotifyFailed(lang.ticket_fill_all);
			};
		}
		else
		{
			
		};
	});
	OverlayButton.start();
	OverlayButton.setButton(false);
</script>
