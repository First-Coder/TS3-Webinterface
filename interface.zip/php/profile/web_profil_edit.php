<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysqlKeys = getKeys();
	
	/**
		Check Session
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	if(!$user_right['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Get private information above the Client
	*/
	$userInformations = getUserInformations($_SESSION['user']['id']);
	if($userInformations['success']) {
		$userInformations = $userInformations['data'];
		$lastLogin = explode(' - ', $userInformations['last_login']);
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
?>

<div class="profile shadow-default-content mb-3">
	<div class="profile-header">
		<div class="row">
			<div class="col-lg-3 col-md-4 col-12">
				<div class="profile-img">
					<img class="profile-image" src="<?php echo getUserPicture(); ?>" />
				</div>
			</div>
			<div class="col-lg-6 col-md-8 col-12 mt-4">
				<div class="profile-text">
					<h4><?php xssEcho($userInformations['firstname'].' '.$userInformations['lastname']); ?></h4>
					<p><?php echo str_replace(array('%date%', '%time%'), array($lastLogin[0], $lastLogin[1]), $language['profile_last_login']); ?></p>
					<button class="btn btn-sm btn-danger mr-2 mt-2"><i class="fas fa-trash mr-2"></i><?php echo $language['delete_account']; ?></button>
					<button class="btn btn-sm mt-2"><i class="fas fa-trash mr-2"></i><?php echo $language['delete_profile_picture']; ?></button>
				</div>
			</div>
		</div>
	</div>
	<div class="profile-sub-header">
		<ul>
			<li>
				<a href="#settings" class="active">
					<i class="fas fa-cog"></i>
					<p><?php echo $language['settings']; ?></p>
				</a>
			</li>
			<?php if($user_right['data']['perm_profile_see_perm'] == $mysqlKeys['perm_profile_see_perm']) { ?>
				<li>
					<a href="#permission">
						<i class="fas fa-globe"></i>
						<p><?php echo $language['permission']; ?></p>
					</a>
				</li>
			<?php }; ?>
			<li>
				<a href="#logs">
					<i class="fas fa-archive"></i>
					<p><?php echo $language['logs']; ?></p>
				</a>
			</li>
		</ul>
	</div>
</div>

<div class="shadow-default-content widget mb-3">
	<div class="header-content pt-0">
		<h3 class="color-header"><i class="fas fa-cog mr-2"></i><span><?php echo $language['settings']; ?></span></h3>
		<a href="#" id="save-profile" data-toggle="tooltip" data-placement="left" title="<?php echo $language['save']; ?>"><i class="far fa-save"></i></a>
	</div>
	<div class="right-side-content profile-tab">
		<div id="settings" class="active">
			<div class="tabs shadow-none">
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link active" href="#general" data-toggle="tab" role="tab"><?php echo $language['general']; ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#personally" data-toggle="tab" role="tab"><?php echo $language['personally']; ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#contact" data-toggle="tab" role="tab"><?php echo $language['contact']; ?></a>
					</li>
				</ul>
				<div class="tab-content form">
					<div class="tab-pane fade show active" id="general" role="tabpanel">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['mail']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileUser" class="form-control form-control-sm" type="text" placeholder="Login Mail" value="<?php xssEcho($_SESSION['user']['benutzer']); ?>">
									<small class="form-text text-muted"><?php echo $language['mail_help']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profilePassword" class="form-control form-control-sm" type="password" placeholder="Change Password">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"></label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profilePassword2" class="form-control form-control-sm" type="password" placeholder="Change Password">
									<small class="form-text text-muted"><?php echo $language['password_help']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['profil_picture']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="uploadProfilePicture" class="form-control form-control-sm " type="file" placeholder="Change Password">
									<small class="form-text text-muted"><?php echo $language['profile_picture_info']; ?></small>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="personally" role="tabpanel">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['firstname']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileFirstname" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['field_cant_be_empty']; ?>" value="<?php xssEcho($userInformations['firstname']); ?>">
									<small class="form-text text-muted"><?php echo $language['firstname_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['lastname']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileLastname" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['field_cant_be_empty']; ?>" value="<?php xssEcho($userInformations['lastname']); ?>">
									<small class="form-text text-muted"><?php echo $language['lastname_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['telefon']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profilePhone" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['phone']); ?>">
									<small class="form-text text-muted"><?php echo $language['telefon_info']; ?></small>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="contact" role="tabpanel">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['homepage']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileHomepage" class="form-control form-control-sm" type="text" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['homepage'])); ?>">
									<small class="form-text text-muted"><?php echo $language['homepage_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['skype']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileSkype" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['skype']); ?>">
									<small class="form-text text-muted"><?php echo $language['skype_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['steam']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileSteam" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['steam']); ?>">
									<small class="form-text text-muted"><?php echo $language['steam_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['twitter']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileTwitter" class="form-control form-control-sm" type="text" value="<?php xssEcho($userInformations['twitter']); ?>">
									<small class="form-text text-muted"><?php echo $language['twitter_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['facebook']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileFacebook" class="form-control form-control-sm" type="text" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['facebook'])); ?>">
									<small class="form-text text-muted"><?php echo $language['facebook_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['google_plus']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="profileGoogle" class="form-control form-control-sm" type="text" value="<?php xssEcho(str_replace("%2F", "/", $userInformations['google'])); ?>">
									<small class="form-text text-muted"><?php echo $language['google_plus_info']; ?></small>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php if($user_right['data']['perm_profile_see_perm'] == $mysqlKeys['perm_profile_see_perm']) { ?>
			<div id="permission">
				<div class="tabs shadow-none">
					<ul class="nav nav-tabs">
						<li class="nav-item">
							<a class="nav-link active" href="#homepage" data-toggle="tab" role="tab"><?php echo $language['homepage']; ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#teamspeak" data-toggle="tab" role="tab">Teamspeak</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#bot" data-toggle="tab" role="tab">Bot</a>
						</li>
					</ul>
					<div class="tab-content form">
						<div class="tab-pane fade show active" id="homepage" role="tabpanel">
							<table class="table permission-table">
								<tbody>
									<tr class="<?php echo ($user_right['data']['perm_profile_see_perm'] == $mysqlKeys['perm_profile_see_perm']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['hp_rights_profile_perm']; ?><p class="text-muted"><?php echo $language['hp_rights_profile_perm_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_profile_see_perm'] == $mysqlKeys['perm_profile_see_perm']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_profile_ticket_admin'] == $mysqlKeys['perm_profile_ticket_admin']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['ticket_admin']; ?><p class="text-muted"><?php echo $language['ticket_admin_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_profile_ticket_admin'] == $mysqlKeys['perm_profile_ticket_admin']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_profile_ticket_settings'] == $mysqlKeys['perm_profile_ticket_settings']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['ticket_admin_settings']; ?><p class="text-muted"><?php echo $language['ticket_admin_settings_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_profile_ticket_settings'] == $mysqlKeys['perm_profile_ticket_settings']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_main_news_create'] == $mysqlKeys['perm_main_news_create']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['hp_create_news']; ?><p class="text-muted"><?php echo $language['hp_create_news_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_main_news_create'] == $mysqlKeys['perm_main_news_create']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_main_news_delete'] == $mysqlKeys['perm_main_news_delete']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['hp_create_delete']; ?><p class="text-muted"><?php echo $language['hp_create_delete_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_main_news_delete'] == $mysqlKeys['perm_main_news_delete']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_settings_main'] == $mysqlKeys['perm_admin_settings_main']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['hp_rights_edit']; ?><p class="text-muted"><?php echo $language['hp_rights_edit_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_settings_main'] == $mysqlKeys['perm_admin_settings_main']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_settings_lang'] == $mysqlKeys['perm_admin_settings_lang']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['hp_rights_edit_lang']; ?><p class="text-muted"><?php echo $language['hp_rights_edit_lang_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_settings_lang'] == $mysqlKeys['perm_admin_settings_lang']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_settings_mail'] == $mysqlKeys['perm_admin_settings_mail']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['hp_rights_edit_mail']; ?><p class="text-muted"><?php echo $language['hp_rights_edit_mail_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_settings_mail'] == $mysqlKeys['perm_admin_settings_mail']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_settings_module'] == $mysqlKeys['perm_admin_settings_module']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['hp_rights_edit_module']; ?><p class="text-muted"><?php echo $language['hp_rights_edit_module_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_settings_module'] == $mysqlKeys['perm_admin_settings_module']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_settings_designs'] == $mysqlKeys['perm_admin_settings_designs']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['hp_rights_edit_designs']; ?><p class="text-muted"><?php echo $language['hp_rights_edit_designs_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_settings_designs'] == $mysqlKeys['perm_admin_settings_designs']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_settings_sites'] == $mysqlKeys['perm_admin_settings_sites']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['hp_rights_edit_sites']; ?><p class="text-muted"><?php echo $language['hp_rights_edit_sites_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_settings_sites'] == $mysqlKeys['perm_admin_settings_sites']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_users_add'] == $mysqlKeys['perm_admin_users_add']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['user_add']; ?><p class="text-muted"><?php echo $language['user_add_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_users_add'] == $mysqlKeys['perm_admin_users_add']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_users_delete'] == $mysqlKeys['perm_admin_users_delete']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['user_delete']; ?><p class="text-muted"><?php echo $language['user_delete_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_users_delete'] == $mysqlKeys['perm_admin_users_delete']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_users_edit'] == $mysqlKeys['perm_admin_users_edit']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['user_edit']; ?><p class="text-muted"><?php echo $language['user_edit_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_users_edit'] == $mysqlKeys['perm_admin_users_edit']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php if($user_right['data']['perm_admin_logs'] == $mysqlKeys['perm_admin_logs']) { echo "text-success"; } else { echo "text-danger"; } ?>">
										<td><?php echo $language['logs']; ?><p class="text-muted"><?php echo $language['logs_info']; ?></p></td>
										<td class="icon"><i class="fas fa-<?php echo ($user_right['data']['perm_admin_logs'] == $mysqlKeys['perm_admin_logs']) ? "check" : "ban"; ?>"></i></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="tab-pane fade" id="teamspeak" role="tabpanel">
							<table class="table permission-table">
								<tbody>
									<tr class="<?php echo ($user_right['data']['perm_admin_instances_ts'] == $mysqlKeys['perm_admin_instances_ts']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['ts3_rights_edit']; ?><p class="text-muted"><?php echo $language['ts3_rights_edit_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_admin_instances_ts'] == $mysqlKeys['perm_admin_instances_ts']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_admin_instances_ts_add'] == $mysqlKeys['perm_admin_instances_ts_add']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['ts3_rights_add']; ?><p class="text-muted"><?php echo $language['ts3_rights_add_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_admin_instances_ts_add'] == $mysqlKeys['perm_admin_instances_ts_add']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_admin_instances_ts_delete'] == $mysqlKeys['perm_admin_instances_ts_delete']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['ts3_rights_delete']; ?><p class="text-muted"><?php echo $language['ts3_rights_delete_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_admin_instances_ts_delete'] == $mysqlKeys['perm_admin_instances_ts_delete']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_teamspeak_global_msg_poke'] == $mysqlKeys['perm_teamspeak_global_msg_poke']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['instance_msg_poke']; ?><p class="text-muted"><?php echo $language['instance_msg_poke_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_teamspeak_global_msg_poke'] == $mysqlKeys['perm_teamspeak_global_msg_poke']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_teamspeak_create_server'] == $mysqlKeys['perm_teamspeak_create_server']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['create_server']; ?><p class="text-muted"><?php echo $language['create_server_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_teamspeak_create_server'] == $mysqlKeys['perm_teamspeak_create_server']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_teamspeak_delete_server'] == $mysqlKeys['perm_teamspeak_delete_server']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['delete_server']; ?><p class="text-muted"><?php echo $language['delete_server_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_teamspeak_delete_server'] == $mysqlKeys['perm_teamspeak_delete_server']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_teamspeak_access_server'] == $mysqlKeys['perm_teamspeak_access_server']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['access_to_all_server']; ?><p class="text-muted"><?php echo $language['access_to_all_server_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_teamspeak_access_server'] == $mysqlKeys['perm_teamspeak_access_server']) ? "check" : "ban"; ?>"></i></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="tab-pane fade" id="bot" role="tabpanel">
							<table class="table permission-table">
								<tbody>
									<tr class="<?php echo ($user_right['data']['perm_admin_instances_bot'] == $mysqlKeys['perm_admin_instances_bot']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['bot_rights_edit']; ?><p class="text-muted"><?php echo $language['bot_rights_edit_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_admin_instances_bot'] == $mysqlKeys['perm_admin_instances_bot']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_admin_instances_bot_add'] == $mysqlKeys['perm_admin_instances_bot_add']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['bot_rights_add']; ?><p class="text-muted"><?php echo $language['bot_rights_add_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_admin_instances_bot_add'] == $mysqlKeys['perm_admin_instances_bot_add']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_admin_instances_bot_delete'] == $mysqlKeys['perm_admin_instances_bot_delete']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['bot_rights_delete']; ?><p class="text-muted"><?php echo $language['bot_rights_delete_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_admin_instances_bot_delete'] == $mysqlKeys['perm_admin_instances_bot_delete']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_bot_create_bot'] == $mysqlKeys['perm_bot_create_bot']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['bot_rights_create_bot']; ?><p class="text-muted"><?php echo $language['bot_rights_create_bot_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_bot_create_bot'] == $mysqlKeys['perm_bot_create_bot']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_bot_delete_bot'] == $mysqlKeys['perm_bot_delete_bot']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['bot_rights_delete_bot']; ?><p class="text-muted"><?php echo $language['bot_rights_delete_bot_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_bot_delete_bot'] == $mysqlKeys['perm_bot_delete_bot']) ? "check" : "ban"; ?>"></i></td>
									</tr>
									<tr class="<?php echo ($user_right['data']['perm_bot_access_bot'] == $mysqlKeys['perm_bot_access_bot']) ? "text-success" : "text-danger"; ?>">
										<td><?php echo $language['bot_rights_access_bot']; ?><p class="text-muted"><?php echo $language['bot_rights_access_bot_info']; ?></p></td>
										<td class="icon"><i class="fa fa-<?php echo ($user_right['data']['perm_bot_access_bot'] == $mysqlKeys['perm_bot_access_bot']) ? "check" : "ban"; ?>"></i></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		<?php }; ?>
		<div id="logs">
			<table id="clientTable" data-ajax="ajaxRequestTable" data-card-view="false" data-classes="table-no-bordered table-hover table" data-striped="true" data-pagination="true" data-search="true">
				<thead>
					<tr>
						<th data-field="date"><?php echo $language['date']; ?></th>
						<th data-field="message"><?php echo $language['message']; ?></th>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	</div>
</div>

<script>
	/**
		Manage tables
	*/
	$('#clientTable').bootstrapTable({
		formatNoMatches: function () {
			return lang.filelist_none;
		}
	});

	function ajaxRequestTable(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsPost.php",
			data: {
				action: 'getProfileLog'
			},
			success: function(ret){
				var info = JSON.parse(ret);
				if(info.success) {
					for(var entry of info.data) {
						data.push({
							'date': entry.date,
							'message': escapeHtml(entry.message)
						});
					};
				} else {
					console.log(`ProfileLog: ${info.error}`);
				};
				
				params.success({
					total: 100,
					rows: data
				});
			}
		});
	};
	
	/**
		Delete profile or profile picture
	*/
	$('.profile-header .profile-text button').click(function() {
		var el = $(this);
		
		if(el.hasClass('btn-danger')) {
			new AreUSure({
				label: lang.delete_account.replace("&ouml;", "\u00f6"),
				onConfirm: function() {
					$.ajax({
						type: "POST",
						url: "./php/functions/functionsSqlPost.php",
						data: {
							action: 'deleteOwnProfile'
						},
						success: function(data){
							var info = JSON.parse(data);
							
							if(info.success) {
								swal(lang.succeeded, lang.delete_account_success.replace("&ouml;", "\u00f6"), 'success');
								setTimeout(ausloggenInit(), 1500);
							} else {
								swal(lang.aborted, info.error, 'error');
							};
						}
					});
				}
			});
		} else {
			new AreUSure({
				label: lang.delete_profile_picture.replace("&ouml;", "\u00f6"),
				onConfirm: function() {
					$.ajax({
						type: "POST",
						url: "./php/functions/functionsPost.php",
						data: {
							action: 'deleteProfilePicture'
						},
						success: function(data){
							var info = JSON.parse(data);
							
							if(info.success) {
								swal(lang.succeeded, lang.profile_picture_changed.replace("&auml;", "\u00E4"), 'success');
								$('.profile-image').attr('src', './images/dummy.jpg');
							} else {
								swal(lang.aborted, info.error, 'error');
							};
						}
					});
				}
			});
		};
	});
	
	/**
		Save changed profile in the database
	*/
	$('a#save-profile').click(function(e) {
		var el = $(this);
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		
		if(isDataValid('profileUser') && isDataValid('profileFirstname') && isDataValid('profileLastname')) {
			el.addClass('disabled');
			
			var sqlCol = {
				user: $('#profileUser').val(),
				password: $('#profilePassword').val(),
				firstname: encodeURIComponent($('#profileFirstname').val()),
				lastname: encodeURIComponent($('#profileLastname').val()),
				phone: encodeURIComponent($('#profilePhone').val()),
				homepage: encodeURIComponent($('#profileHomepage').val()),
				skype: encodeURIComponent($('#profileSkype').val()),
				steam: encodeURIComponent($('#profileSteam').val()),
				twitter: encodeURIComponent($('#profileTwitter').val()),
				facebook: encodeURIComponent($('#profileFacebook').val()),
				google: encodeURIComponent($('#profileGoogle').val())
			};
			var profileCheck = (/^[a-zA-Z0-9_]+$/.test(sqlCol.firstname) || /^[a-zA-Z0-9_]+$/.test(sqlCol.lastname));
			var passwordCheck = (sqlCol.password === $('#profilePassword2').val());
			
			if(profileCheck && passwordCheck) {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsSqlPost.php",
					data: {
						action: 'updateUser',
						data: JSON.stringify(sqlCol)
					},
					success: function(data) {
						var json = JSON.parse(data);
						if(json.success) {
							new Notification({
								message : lang.settigns_saved,
								icon: 'far fa-save',
								type : 'success'
							}).show();
						} else {
							new Notification({
								message : json.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
			} else {
				new Notification({
					message : (!profileCheck) ? lang.change_name_failed : lang.change_pw2_failed,
					icon: 'far fa-save',
					type : 'danger'
				}).show();
				el.removeClass('disabled');
			};
			
		} else {
			new Notification({
				message : lang.ticket_fill_all,
				icon: 'far fa-save',
				type : 'danger'
			}).show();
			el.removeClass('disabled');
		};
	});

	/**
		Profile validation
	*/
	validateOnChange('#profileUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#profilePassword', {
		required: true,
		min: 6
	}, '', lang.change_pw1_failed);
	validateOnChange('#profileFirstname', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#profileLastname', {
		required: true
	}, '', lang.field_cant_be_empty);
	
	/**
		Upload Profile Picture
	*/
	document.getElementById('uploadProfilePicture').addEventListener('change', uploadFile, false);
	
	function uploadFile(evt) {
		var file = evt.target.files[0];
		
		if (file.type.match('image/png') || file.type.match('image/gif') || file.type.match('image/jpeg')) {
			var formData = new FormData();
			formData.append("file", file);
			$.ajax({
				type: 'POST',
				url: './php/functions/functionsUploadProfilePicture.php',
				data: formData,
				contentType: false,
				processData: false,
				success: function(data) {
					if(data != "Client is not logged in!" && data != "Forbidden characters!") {
						$('.profile-image').attr("src", "./images/user/"+data);
						new Notification({
							message : lang.profile_picture_changed,
							icon: 'fas fa-upload',
							type : 'success'
						}).show();
					} else {
						new Notification({
							message : data,
							icon: 'fas fa-upload',
							type : 'danger'
						}).show();
					};
				}
			});
		} else {
			new Notification({
				message : lang.failed_imagetype,
				icon: 'fas fa-upload',
				type : 'danger'
			}).show();
		};
	};
</script>
