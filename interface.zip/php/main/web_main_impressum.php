<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../functions/functions.php");
	require_once(__dir__."/../functions/functionsSql.php");
	
	/**
		Get homepage settings
	*/
	$settings = getSqlHomepagesettings();
?>

<div class="content-header color-header">Impressum</div>

<div class="row shadow-default-content mb-3">
	<div class="col border-right widget">
		<?php if($settings['success']) { ?>
			<div class="header news-header">
				<h4 class="title color-header"><?php echo $language['operator']; ?></h4>
			</div>
			<hr class="hr-headline mb-3"/>
			<p style="text-align:justify;white-space:pre-wrap;"><?php echo (empty($settings['data']['operator'])) ? $language['unknown'] : $settings['data']['operator']; ?><br/><?php echo $settings['data']['address']; ?></p>
			
		<?php }; ?>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_1']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_2']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_3']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_4']; ?></p>
		<ul class="bt-group">
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_5']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_6']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_7']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_8']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_9']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_10']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_11']; ?></div>
				</div>
			</span>
		</ul>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_12']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_13']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_14']; ?></p>
		<ul class="bt-group">
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_15']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_16']; ?></div>
				</div>
			</span>
			<span class="list-group-item">
				<i class="far fa-dot-circle"></i>
				<div>
					<div class="mute-text"><?php echo $language['disclaimer_text_17']; ?></div>
				</div>
			</span>
		</ul>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_18']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_19']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_20']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_21']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_22']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_23']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_24']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_25']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_26']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_27']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_28']; ?></p>
		<div class="header news-header">
			<h4 class="title color-header"><?php echo $language['disclaimer_text_29']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p style="text-align:justify;"><?php echo $language['disclaimer_text_30']; ?></p>
	</div>
</div>