<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../config/instance.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../functions/functions.php");
	require_once(__dir__."/../functions/functionsSql.php");
	
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysqlModul = getModuls();
	$ownSites = getSqlOwnSites();
	
	/**
		Check Session
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get Client Permissions
	*/
	if($LoggedIn) {
		$user_right = getUserRights('pk', $_SESSION['user']['id'], "global");
		if(!$user_right['success']) {
			writeInLog(L_ERROR, 'web_main_main: '.$user_right['error']);
		};
	};
	
	/**
		Get support teamspeak if module is active
	*/
	$supportTeamspeak = false;
	if($mysqlModul['success'] && $mysqlModul['data']['support_teamspeak'] == 'true' && isset($ts3_server[$mysqlModul['data']['support_teamspeak_instance']]) &&
		$mysqlModul['data']['support_teamspeak_instance'] != '' && $mysqlModul['data']['support_teamspeak_port'] != '') {
		require_once(__dir__.'/../functions/functionsTeamspeak.php');
		$supportTeamspeak = getServerInfo($mysqlModul['data']['support_teamspeak_instance'], $mysqlModul['data']['support_teamspeak_port']);
	};
	
	/**
		Read News
	*/
	$news = getNews();
?>

<?php if($ownSites['success'] && !empty($ownSites['data']['custom_news']['value'])) {
	@include($ownSites['data']['custom_news']['value']);
} else { ?>
	<div class="content-header color-header"><?php echo $language['news']; ?></div>

	<div class="row shadow-default-content mb-3">
		<div class="col-md-<?php echo ($supportTeamspeak) ? '7' : '12'; ?> border-right widget">
			<?php
				if($news['success']) {
					if(!empty($news['data'])) {
						foreach (array_reverse($news['data']) as $row) {
							$disabled = strtotime($row['show_on']) > time();
							if($disabled && $user_right['data']['perm_main_news_create'] != $mysql_keys['perm_main_news_create']) {
								continue;
							}; ?>
							<div id="<?php xssEcho($row['id']); ?>-box" class="mb-5 news-box">
								<div class="header news-header">
									<h4 class="title color-header"><i class="far fa-newspaper"></i> <?php xssEcho($row['title']); ?></h4>
									<span class="<?php echo ($disabled) ? 'text-danger' : ''; ?>"><i class="far fa-clock mr-2"></i><?php echo (!$disabled) ? date("d.m.Y - G:i", strtotime($row['created'])) : 'Unver&ouml;ffentlicht'; ?></span>
									<h6 class="sub-title text-muted"><?php xssEcho($row['sub_title']); ?></h6>
								</div>
								<hr class="hr-headline"/>
								<div id="<?php xssEcho($row['id']); ?>-editor">
									<?php echo $row['text']; ?>
								</div>
								<?php if($LoggedIn) {
									if($user_right['success']) {
										if(hasPermGroup('perm_main_news')) { ?>
											<div class="news-buttons">
												<?php if($user_right['data']['perm_main_news_create'] == $mysql_keys['perm_main_news_create']) { ?>
													<button id="<?php xssEcho($row['id']); ?>" class="btn btn-flat-sm edit-save"><i class="fas fa-edit"></i></button>
												<?php }; ?>
												<?php if($user_right['data']['perm_main_news_delete'] == $mysql_keys['perm_main_news_delete']) { ?>
													<button onClick="deleteNews('<?php echo $row['id']; ?>');" class="btn btn-danger btn-flat-sm"><i class="fas fa-trash"></i></button>
												<?php }; ?>
											</div>
										<?php };
									};
								}; ?>
							</div>
						<?php };
					};
				};
			?>
		</div>
		<?php if($supportTeamspeak) { ?>
			<div class="col-md-5 d-none d-md-block widget">
				<?php
					$success = true;
					$err = null;
					if($supportTeamspeak['success'] && !empty($supportTeamspeak['data'])) {
						$supportTeamspeak = $supportTeamspeak['data'];
					} else {
						$success = false;
						$err = $supportTeamspeak['error'][0];
					};
				?>
				<div class="header news-header">
					<h4 class="title color-header"><i class="fab fa-teamspeak"></i> <?php echo ($success) ? xssSafe($supportTeamspeak['virtualserver_name']) : $language['offline']; ?></h4>
					<h6 class="sub-title text-muted"><?php echo $language['support_teamspeak']; ?></h6>
				</div>
				<hr class="hr-headline mb-3"/>
				<?php if($success) { ?>
					<div class="row mb-3">
						<div class="col">
							<i class="fas fa-power-off w-20"></i> <?php echo $language['online_since']; ?>
						</div>
						<div class="col text-right">
							<span class="badge badge-text badge-success"><?php echo convertSecondsToStrTime($supportTeamspeak['virtualserver_uptime']); ?></span>
						</div>
					</div>
					<div class="row mb-3">
						<div class="col">
							<i class="fas fa-users w-20"></i> <?php echo $language['client']; ?>
						</div>
						<div class="col text-right">
							<span class="badge badge-text badge-primary"><?php echo ($supportTeamspeak['virtualserver_clientsonline'] - $supportTeamspeak['virtualserver_queryclientsonline']).' / '.$supportTeamspeak['virtualserver_maxclients'].' ('.round(($supportTeamspeak['virtualserver_clientsonline'] - $supportTeamspeak['virtualserver_queryclientsonline'])/$supportTeamspeak['virtualserver_maxclients'], 2).'%)'; ?>
						</div>
					</div>
					<div class="row mb-3">
						<div class="col">
							<i class="fas fa-code-branch w-20"></i> <?php echo $language['version']; ?>
						</div>
						<div class="col text-right">
							<span class="badge badge-text badge-primary"><?php echo preg_replace("/\[.*/", "", $supportTeamspeak['virtualserver_version']).'@ '.$supportTeamspeak['virtualserver_platform']; ?></span>
						</div>
					</div>
					<div class="row">
						<div class="col">
							<i class="fas fa-bolt w-20"></i> <?php echo $language['packagelost']; ?>
						</div>
						<div class="col text-right">
							<span class="badge badge-text badge-primary"><?php echo round($supportTeamspeak['virtualserver_total_packetloss_total'], 2).' %'; ?></span>
						</div>
					</div>
					<hr class="hr-headline mt-3"/>
					<a href="ts3server://<?php echo $ts3_server[$mysqlModul['data']['support_teamspeak_instance']]['ip']; ?>?port=<?php echo $mysqlModul['data']['support_teamspeak_port']; ?>""><button class="btn btn-success w-100-percent"><i class="fas fa-sign-in-alt mr-2"></i><?php echo $language['connect']; ?></button></a>
				<?php } else { ?>
					<p class="color-danger"><?php echo $err; ?></p>
					<hr class="hr-headline mt-3"/>
				<?php }; ?>
			</div>
		<?php }; ?>
	</div>

	<?php if($LoggedIn) {
		if($user_right['success']) {
			if($user_right['data']['perm_main_news_create'] == $mysql_keys['perm_main_news_create']) { ?>
				<div class="row shadow-default-content mb-3">
					<div class="widget w-100-percent pb-0">
						<div class="header">
							<h4 class="title color-header"><i class="far fa-edit"></i> <?php echo $language['write_news']; ?></h4>
						</div>
						<hr class="hr-headline"/>
						<div class="form-secondary row">
							<div class="col-md-4">
								<div class="form-group mb-2">
									<label><?php echo $language['title']; ?></label>
									<input id="newsTitle" type="text" class="form-control">
									<small class="form-control-feedback"></small>
								</div>
								<div class="form-group mb-3">
									<label><?php echo $language['subtitle']; ?></label>
									<input id="newsSubTitle" type="text" class="form-control">
									<small class="form-control-feedback"></small>
								</div>
								<div class="form-group mb-3">
									<label><?php echo $language['publish']; ?></label>
									<input id="newsPublish" type="text" class="form-control" placeholder="<?php echo $language['now']; ?>">
									<small class="form-control-feedback"></small>
								</div>
							</div>
							<div class="col-md-8">
								<div id="create-editor"></div>
							</div>
							<div class="col-md-4">
								<button onClick="writeNews();" class="btn btn-success mt-3 mb-3 w-100-percent"><i class="fas fa-paper-plane"></i> <?php echo $language['senden']; ?></button>
							</div>
						</div>
					</div>
				</div>
			<?php };
		};
	};
}; ?>

<script src="js/editor/summernote-bs4.js"></script>
<script src="js/other/moment.js"></script>
<script src="js/bootstrap/bootstrap-material-datetimepicker.js"></script>
<script src="js/webinterface/main.js"></script>
<script>
	/**
		Editor stuff
	*/
	var editorOptions = {
		placeholder: 'Write here your news',
		tabsize: 2,
		height: 150
	};
	
	$('#create-editor').summernote(editorOptions);
	$('.edit-save').click(function() {
		var icon = $(this).find('i');
		var id = $(this).attr('id');
		var editor = $('#'+id+'-editor');
		
		if(icon.hasClass('fa-edit')) {
			editor.summernote(editorOptions);
			
			icon.addClass('fa-save');
			icon.removeClass('fa-edit');
		} else {
			var text = editor.summernote('code');
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action: 'editNews',
					id: id,
					text: text
				},
				success: function(data){
					var info = JSON.parse(data);
					
					if(info.success) {
						new Notification({
							message : lang.news_edited,
							type : 'success'
						}).show();
						editor.summernote('destroy');
						
						icon.addClass('fa-edit');
						icon.removeClass('fa-save');
					} else {
						new Notification({
							message : info.error,
							type : 'danger'
						}).show();
					};
				}
			});
		};
	});
	
	/**
		Datetimepicker
	*/
	$('#newsPublish').bootstrapMaterialDatePicker({
		time: false,
		clearButton: true,
		format: 'DD.MM.YYYY',
		minDate : new Date()
	});
	
	/**
		Validation
	*/
	validateOnChange('#newsTitle', {
		required: true
	}, '', lang.field_cant_be_empty);
</script>