<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../functions/functions.php");
	require_once(__dir__."/../functions/functionsSql.php");
	
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys		=	getKeys();
	$mysql_modul	=	getModuls();
	
	/*
		Check Session
	*/
	$LoggedIn		=	(checkSession($mysql_keys['login_key'])) ? true : false;
	
	/*
		Get Client Permissions
	*/
	if($LoggedIn)
	{
		$user_right	=	getUserRights('pk', $_SESSION['user']['id'], true, "global");
	};
	
	/*
		Read News
	*/
	$alledateien 	= 	scandir(__dir__.'/../../files/news');
	$first			=	true;
?>

<!-- Modal: Create News -->
<?php if($LoggedIn && $user_right['right_hp_main'] == $mysql_keys['right_hp_main'] && $mysql_modul['write_news'] == "true" && CUSTOM_NEWS_PAGE == "false") { ?>
	<div id="modalCreateNews" class="modal modal-success fade scale" data-backdrop="true" tabindex="-1" role="dialog" aria-labelledby="modalCreateNewsLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h4 class="modal-title" id="modalCreateNewsLabel"><?php echo $language['write_news']; ?></h4>
				</div>
				<div class="modal-body">
					<div class="form-secondary mb-3">
						<div class="form-group mb-2">
							<label><?php echo $language['title']; ?></label>
							<input id="newsTitle" type="text" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
						<div class="form-group mb-3">
							<label><?php echo $language['subtitle']; ?></label>
							<input id="newsSubTitle" type="text" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
						<div id="create-editor">
							Text...
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-fw fa-close"></i> <?php echo $language['abort']; ?></button>
					<button onClick="writeNews();" type="button" class="btn btn-success"><i class="fa fa-fw fa-paper-plane"></i> <?php echo $language['create']; ?></button>
				</div>
			</div>
		</div>
	</div>
<?php }; ?>

<!-- News -->
<div class="cke_contents_ltr">
	<div class="col-xs-12 main">
		<div class="page-on-top">
			<div class="row m-b-40">
				<div class="col-xs-12 col-sm-12 col-xl-12">
					<?php
						if($mysql_modul['write_news'] == "true" && CUSTOM_NEWS_PAGE == "false" && !empty($alledateien))
						{
							foreach (array_reverse($alledateien) as $datei)
							{
								if($datei != "." && $datei != "..")
								{
									$time	=	str_replace(".json", "", $datei);
									$cont	=	array();
									$json 	= 	file_get_contents(__dir__."/../../files/news/".$datei);
									$cont	=	json_decode($json, true); ?>
									
									<div style="margin-bottom: 60px;" id="<?php xssEcho($time); ?>-box">
										<div class="card-block-header">
											<div style="float:left;">
												<h4 class="card-title"><i class="fa fa-newspaper-o"></i> <?php xssEcho($cont['title']); ?></h4>
											</div>
											<div style="float:right;">
												<?php echo date("d.m.Y (G:i)", $time); ?>
											</div>
											<h6 style="clear:both;" class="card-subtitle text-muted"><?php xssEcho($cont['subtitle']); ?></h6>
										</div>
										<hr class="hr-headline"/>
										<div class="editor" id="<?php xssEcho($time); ?>-editor">
											<?php echo $cont['content']; ?>
										</div>
										<?php if($LoggedIn && $user_right['right_hp_main'] == $mysql_keys['right_hp_main']) { ?>
											<div class="row mt-2">
												<div class="offset-md-6 offset-lg-8 col-lg-2 col-md-3 col-xs-12">
													<button style="width:100%;" id="<?php xssEcho($time); ?>" class="btn btn-secondary btn-sm edit-save"><i class="fa fa-edit" aria-hidden="true"></i> <?php echo $language['edit']; ?></button>
												</div>
												<div class="col-lg-2 col-md-3 col-xs-12">
													<button onClick="AreYouSure('<?php echo $language['delete_news']; ?>', '<?php echo urlencode(json_encode(array("deleteNews", $time))); ?>');" style="width:100%;" class="btn btn-danger btn-sm"><i class="fa fa-trash" aria-hidden="true"></i> <?php echo $language['delete']; ?></button>
												</div>
											</div>
											<div style="clear:both;"></div>
										<?php }; ?>
									</div>
									
								<?php $first  =	false;
								};
							};
						}
						else if(CUSTOM_NEWS_PAGE == "true")
						{
							include("../../config/custompages/custom_news.php");
						};
					?>
				</div>
			</div>
		</div>
	</div>
	
		<!--<div class="col-xs-12 main">
			<div class="page-on-middle">
				<div class="row m-b-40">
					<div class="col-xs-12 col-sm-12 col-xl-12">
						<div class="card-block-header">
							<h4 class="card-title"><i class="fa fa-edit"></i> <?php echo $language['write_news']; ?></h4>
						</div>
						<hr class="hr-headline"/>
						
						<textarea class="form-control" id="editor" rows="10" cols="80">
							Text...
						</textarea>
						<button onClick="writeNews();" class="btn btn-success mt-3" style="width:100%;"><i class="fa fa-paper-plane"></i> <?php echo $language['senden']; ?></button>
					</div>
				</div>
			</div>
		</div>-->
</div>

<!--<script src="editor/ckeditor.js"></script>-->
<script src="js/editor/ckeditor.js"></script>
<script src="js/editor/ckeditor-classic.js"></script>
<script src="js/webinterface/main.js"></script>
<script>
	/*
		Variables
	*/
	var editors			=	[],
		createEditor	=	null;
		permission		=	<?php echo ($LoggedIn && $user_right['right_hp_main'] == $mysql_keys['right_hp_main'] && $mysql_modul['write_news'] == "true" && CUSTOM_NEWS_PAGE == "false") ? "true" : "false"; ?>;
	
	/*
		Editors
	*/
	if(document.getElementById('create-editor'))
	{
		ClassicEditor
			.create( document.querySelector( '#create-editor' ) )
			.then( editor => {
				createEditor = editor;
			} )
			.catch( error => {
				console.error( error );
			});
	};
	
	$('.editor').each(function() {
		BalloonEditor
			.create( document.getElementById($(this).attr("id")), {
				ckfinder: {
					uploadUrl: 'php/functions/functionsUploadEditor.php'
				}
			})
			.then( editor => {
				editor.isReadOnly = true;
				editors.push(editor);
			} )
			.catch( error => {
				console.error( error );
			});
	});
	
	$('.edit-save').click(function() {
		var editor		=	getEditor($(this).attr("id")+"-editor");
		
		if(editor == null)
		{
			return;
		};
		
		if($(this).hasClass("btn-secondary"))
		{
			$(this).html('<i class="fa fa-save" aria-hidden="true"></i> <?php echo $language['save']; ?>');
			$(this).removeClass("btn-secondary");
			$(this).addClass("btn-success");
			
			$("#"+$(this).attr("id")+"-editor").css("background-color", "rgba(0,0,0,0.1)");
			$("#"+$(this).attr("id")+"-editor").css("border", "1px dashed rgb(27, 123, 80)");
			
			editor.isReadOnly 	= 	false;
		}
		else
		{
			$(this).html('<i class="fa fa-edit" aria-hidden="true"></i> <?php echo $language['edit']; ?>');
			$(this).removeClass("btn-success");
			$(this).addClass("btn-secondary");
			
			$("#"+$(this).attr("id")+"-editor").css("background-color", "");
			$("#"+$(this).attr("id")+"-editor").css("border", "0");
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsPost.php",
				data: {
					action:		'editNews',
					time:		$(this).attr("id"),
					content:	editor.getData()
				},
				success: function(data){
					if(data == "done")
					{
						editor.isReadOnly 	= 	true;
						setNotifySuccess(lang.news_edited);
					}
					else
					{
						setNotifyFailed(lang.news_edited_failed);
					};
				}
			});
		};
	});
	
	function getEditor(editorId)
	{
		var returnVal			=	null;
		editors.forEach(function(editor) {
			if(editor.element.id == editorId)
			{
				returnVal		=	editor;
			};
		});
		
		return returnVal;
	};
	
	/*
		Overlay button
	*/
	OverlayButton.setButtonClass("btn-secondary");
	OverlayButton.setIconClass("fa-plus");
	OverlayButton.setTooltip(lang.write_news);
	OverlayButton.on("click", function() {
		$('#modalCreateNews').modal('show');
	});
	OverlayButton.start();
	OverlayButton.setButton(permission);
	
	/*
		Validation
	*/
	validateOnChange('#newsTitle', {
		required: true
	}, '', lang.field_cant_be_empty);
</script>