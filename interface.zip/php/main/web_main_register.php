<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../functions/functions.php");
	require_once(__dir__."/../functions/functionsSql.php");

	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysqlModul = getModuls();

	/** 
		Could not load all settings
	*/
	if(!$mysqlModul['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};

	if($mysqlModul['data']['support_teamspeak'] != 'true') {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Modul support free register is disabled');
	};
	
	/**
		Check Session
	*/
	$LoggedIn = (checkSession()) ? true : false;
	if($LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You are already registred. Please logout if you want to create a new account!');
	};
?>

<div class="content-header color-header"><?php echo $language['register']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="in-sm bottom col-md-7 border-right widget">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fab fa-teamspeak"></i> <?php echo $language['local_register']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="form">
			<div class="row mr-0 ml-0">
				<label class="col-lg-4 form-label color-light"><?php echo $language['firstname']; ?>:</label>
				<div class="col-lg-8 col-xl-4">
					<div class="form-group">
						<input id="firstname" class="form-control form-control-sm" type="text" placeholder="Max">
						<small class="form-text text-muted"><?php echo $language['firstname_info']; ?></small>
					</div>
				</div>
			</div>
			<div class="row mr-0 ml-0">
				<label class="col-lg-4 form-label color-light"><?php echo $language['lastname']; ?>:</label>
				<div class="col-lg-8 col-xl-4">
					<div class="form-group">
						<input id="lastname" class="form-control form-control-sm" type="text" placeholder="Mustermann">
						<small class="form-text text-muted"><?php echo $language['lastname_info']; ?></small>
					</div>
				</div>
			</div>
			<div class="row mr-0 ml-0">
				<label class="col-lg-4 form-label color-light"><?php echo $language['mail']; ?>:</label>
				<div class="col-lg-8 col-xl-4">
					<div class="form-group">
						<input id="registerUser" class="form-control form-control-sm" type="mail" placeholder="max@mustermann.de">
						<small class="form-text text-muted"><?php echo $language['mail_help']; ?></small>
					</div>
				</div>
			</div>
			<div class="row mr-0 ml-0">
				<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
				<div class="col-lg-8 col-xl-4">
					<div class="form-group">
						<input id="registerPw" class="form-control form-control-sm" type="password" placeholder="****">
						<small class="form-text text-muted"><?php echo $language['password_help']; ?></small>
					</div>
				</div>
			</div>
		</div>
		<button onClick="registerAccount();" class="btn btn-success mt-3 w-100-percent action"><i class="fa fa-paper-plane"></i> <?php echo $language['register']; ?></button>
	</div>
	<div class="in-sm top col-md-5 widget">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fab fa-teamspeak"></i> <?php echo $language['account_linked']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col text-center">
				<button class="btn btn-danger" disabled><i class="fab fa-google mr-2"></i>Google</button>
				<div>Google Plus cancelled</div>
			</div>
			<div class="col text-center">
				<button id="registerFacebook" class="btn btn-secondary"><i class="fab fa-facebook-f mr-2"></i>Facebook</button>
			</div>
		</div>
	</div>
</div>

<div id="fb-root"></div>
<script src="js/webinterface/login.js"></script>
<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=<?php xssEcho(GRECAPTCHA_SECRET); ?>"></script>
<script>
	/**
		Register object
	*/
	var loginData	= {
		mail:			null,
		name:			null,
		pw:				null,
		lastname:		null,
		picture:		null,
		pictureEnds:	null,
		isBot:			true
	};
	
	/**
		Captcha
	*/
	function onloadCallback() {
		grecaptcha.ready(function() {
			grecaptcha.execute('<?php xssEcho(GRECAPTCHA_SECRET); ?>', {action: 'homepage'}).then(function(token) {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsReCaptchaPost.php",
					data: {
						response: token
					},
					success: function(data) {
						if(data.success && data.score > 0.7) {
							loginData.isBot = false;
						};
					}
				});
			});
		});
	};
	
	/**
		Facebook SDK
	*/
	window.fbAsyncInit = function() {
		FB.init({
			appId            : '138095353404106',
			autoLogAppEvents : true,
			xfbml            : true,
			version          : 'v2.9'
		});
	};
	
	(function() {
		var e = document.createElement('script');
		e.src = document.location.protocol + '//connect.facebook.net/en_US/all.js';
		e.async = true;
		document.getElementById('fb-root').appendChild(e);
	}());
	
	$('#registerFacebook').click(function() {
		FB.login(function(response) {
			if (response.authResponse) {
				FB.api('/me?fields=id,first_name,last_name,email,picture.width(100).height(100)', function(response) {
					loginData.mail = response.email;
					loginData.name = response.first_name;
					loginData.lastname = response.last_name;
					loginData.picture = response.picture.data.url;
					
					setExternRegister();
				});
			} else {
				new Notification({
					message : "User cancelled login or did not fully authorize!",
					icon: 'fas fa-user-plus',
					type : 'danger'
				}).show();
			};
		}, {
			scope: 'email'
		});
	});
	
	/**
		Register a account
	*/
	function registerAccount() {
		$('.action').prop("disabled", true);
		$('.grecaptcha-badge').closest('div').remove();
		
		if(loginData.isBot) {
			new Notification({
				message : "reCaptcha was not successfull!",
				icon: 'fas fa-user-plus',
				type : 'danger'
			}).show();
		};
		
		if(isDataValid('firstname') && isDataValid('lastname') && isDataValid('registerUser') && isDataValid('registerPw')) {
			if(loginData.picture !== null) {
				var picSplit = loginData.picture.split(".");
				loginData.pictureEnds = picSplit[picSplit.length - 1];
			};
			loginData.mail = $('#registerUser').val();
			loginData.pw = $('#registerPw').val();
			loginData.name = $('#firstname').val();
			loginData.lastname = $('#lastname').val();
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action: 'createUserModul',
					data: JSON.stringify(loginData)
				},
				success: function(data){
					info = JSON.parse(data);
					
					if(info.success) {
						loginUser(loginData.mail, loginData.pw);
					} else {
						new Notification({
							message : info.error,
							icon: 'fas fa-user-plus',
							type : 'danger'
						}).show();
					};
					$('.action').prop("disabled", false);
				}
			});
		} else {
			$('.action').prop("disabled", false);
		};
	};
	
	/**
		Extern Register
	*/
	function setExternRegister() {
		$('#registerUser').val(loginData.mail);
		$('#firstname').val(loginData.name);
		$('#lastname').val(loginData.lastname);
		
		if(isDataValid('registerUser')) {
			$('#registerUser').prop("disabled", true);
			$('#firstname').prop("disabled", true);
			$('#lastname').prop("disabled", true);
		} else {
			new Notification({
				message : "Authentication failed!",
				icon: 'fas fa-user-plus',
				type : 'danger'
			}).show();
		}
	};
	
	/**
		Validation
	*/
	validateOnChange('#registerUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#registerPw', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#firstname', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#lastname', {
		required: true
	}, '', lang.field_cant_be_empty);
</script>