<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../config/instance.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../functions/functions.php");
	require_once(__dir__."/../functions/functionsSql.php");
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysqlKeys = getKeys();
	$mysqlModul = getModuls();
	
	/**
		Check Session
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get support teamspeak if module is active
	*/
	if(!$mysqlModul['success'] || $mysqlModul['data']['free_ts3_server_application'] != 'true') {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Modul server requests is disabled');
	};
	
	/**
		Progress bar
	*/
	$progWidth = 100;
?>

<div class="content-header color-header"><?php echo $language['apply_for_server']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-7 border-right widget">
		<?php include_once(__dir__."/../../config/custompages/custom_server_request_info.php"); ?>
		<?php include_once(__dir__."/../../config/custompages/custom_server_request_offer.php"); ?>
	</div>
	<div class="col-md-5 widget">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-coins"></i> <?php echo $language['capacities']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<p class="color-light"><?php echo $language['server']; ?>: 12 / 12</p>
		<div class="progress mb-3">
			<div class="progress-danger" style="width: <?php echo $progWidth; ?>%;"></div>
		</div>
		<hr class="hr-headline mt-3"/>
		<?php if($progWidth >= 100 || !$LoggedIn) { ?>
			<p class="color-danger"><?php echo $language['entry_not_possible']; ?>.<br/><?php echo $language['reason']; ?>: <?php echo (!$LoggedIn) ? $language['login_needed'] : $language['requests_full']; ?></p>
		<?php }; ?>
		<button class="btn btn-success w-100-percent" <?php echo (!$LoggedIn || $progWidth >= 100) ? 'disabled' : ''; ?>><i class="fas fa-edit mr-2"></i><?php echo $language['apply_for_server']; ?></button>
	</div>
</div>

<script src="./js/webinterface/main.js"></script>
<script>
	validateOnChange('#wantServerLoginUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#wantServerLoginCreateUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#wantServerLoginCreatePw', {
		required: true,
		min: 6
	}, '', lang.change_pw1_failed);
	
	validateOnChange('#serverCreateCause', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#serverCreateWhy', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#serverCreateNeededSlots', {
		required: true
	}, '', lang.field_cant_be_empty);
	
	validateOnChange('#serverCreateServername', {
		required: true
	}, '', lang.servername_needed);
	validateOnChange('#serverCreatePort', {
		required: true,
		range: {
			min: 4,
			max: 5
		}
	}, '', lang.port_cant_be_used);
</script>