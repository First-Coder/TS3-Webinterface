<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../functions/functions.php");
	require_once(__dir__."/../functions/functionsSql.php");
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_modul	=	getModuls();
	
	/*
		Modul aktiviert?
	*/
	if($mysql_modul['free_ts3_server_application'] != "true")
	{
		reloadSite();
	};
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row m-b-40">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<?php include_once(__dir__."/../../config/custompages/custom_server_request.php"); ?>
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-edit"></i> <?php echo $language['apply_for_server']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				
				<div id="wantServerStep1">
					<div class="radio radio-secondary">
						<label>
							<input id="radioAccount" type="radio" name="radioAccount" value="1" checked><?php echo $language['i_have_an_acc_here']; ?>
						</label>
					</div>
					<div class="form-secondary" style="margin-left: 20px;">
						<div class="form-group">
							<label><?php echo $language['mail']; ?></label>
							<input id="wantServerLoginUser" type="mail" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
					</div>
					
					<div class="radio radio-secondary">
						<label>
							<input id="radioAccount" type="radio" name="radioAccount" value="1"><?php echo $language['i_have_no_acc_here']; ?>
						</label>
					</div>
					<div class="form-secondary" style="margin-left: 20px;">
						<div class="form-group">
							<label><?php echo $language['mail']; ?></label>
							<input id="wantServerLoginCreateUser" type="mail" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary" style="margin-left: 20px;">
						<div class="form-group">
							<label><?php echo $language['password']; ?></label>
							<input id="wantServerLoginCreatePw" type="password" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
					</div>
				</div>
				<div id="wantServerStep2" style="display:none;">
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['server_request_cause']; ?></label>
							<textarea id="serverCreateCause" class="form-control" rows="3"></textarea>
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['server_request_why']; ?></label>
							<textarea id="serverCreateWhy" class="form-control" rows="3"></textarea>
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['server_request_clients']; ?></label>
							<input id="serverCreateNeededSlots" type="number" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
					</div>
				</div>
				<div id="wantServerStep3" style="display:none;">
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['ts3_servername']; ?></label>
							<input id="serverCreateServername" type="text" class="form-control" value="<?php echo $ts3_server_create_default['servername']; ?>">
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['ts3_choose_port']; ?></label>
							<input id="serverCreatePort" type="number" class="form-control" placeholder="XXXXX">
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['ts3_max_clients']; ?></label>
							<input id="serverCreateSlots" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['slots']; ?>">
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['ts3_reservierte_slots']; ?></label>
							<input id="serverCreateReservedSlots" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['reserved_slots']; ?>">
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['password']; ?></label>
							<input id="serverCreatePassword" type="password" class="form-control" placeholder="<?php echo $ts3_server_create_default['password']; ?>">
							<small class="form-control-feedback"></small>
						</div>
					</div>
					<div class="form-secondary">
						<div class="form-group">
							<label><?php echo $language['ts3_welcome_message']; ?></label>
							<textarea id="serverCreateWelcomeMessage" class="form-control" rows="8"><?php echo $ts3_server_create_default['welcome_message']; ?></textarea> 
							<small class="form-control-feedback"></small>
						</div>
					</div>
				</div>
				<button class="btn btn-secondary w-100-percent mt-3" onClick="checkWantServer()" id="wantServerBttn"><i class="fa fa-fw fa-check"></i> <?php echo $language['next']; ?></button>
			</div>
		</div>
	</div>
</div>

<script src="./js/webinterface/main.js"></script>
<script>
	validateOnChange('#wantServerLoginUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#wantServerLoginCreateUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#wantServerLoginCreatePw', {
		required: true,
		min: 6
	}, '', lang.change_pw1_failed);
	
	validateOnChange('#serverCreateCause', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#serverCreateWhy', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#serverCreateNeededSlots', {
		required: true
	}, '', lang.field_cant_be_empty);
	
	validateOnChange('#serverCreateServername', {
		required: true
	}, '', lang.servername_needed);
	validateOnChange('#serverCreatePort', {
		required: true,
		range: {
			min: 4,
			max: 5
		}
	}, '', lang.port_cant_be_used);
</script>