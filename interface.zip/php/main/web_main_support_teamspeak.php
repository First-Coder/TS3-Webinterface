<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../functions/functions.php");
	require_once(__dir__."/../functions/functionsSql.php");
	require_once(__dir__.'/../functions/functionsTeamspeak.php');
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysqlModul = getModuls();
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/** 
		Could not load all settings
	*/
	if(!$settings['success'] || !$mysqlModul['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Get support teamspeak if module is active
	*/
	$supportTeamspeak = false;
	if($mysqlModul['success'] && $mysqlModul['data']['support_teamspeak'] == 'true' &&
		$mysqlModul['data']['support_teamspeak_instance'] != '' && $mysqlModul['data']['support_teamspeak_port'] != '') {
		$supportTeamspeak = getServerInfo($mysqlModul['data']['support_teamspeak_instance'], $mysqlModul['data']['support_teamspeak_port']);
	} else {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Modul support teamspeak is disabled');
	};
?>

<div class="content-header color-header"><?php echo $language['support_teamspeak']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-7 border-right widget">
		<div id="newTree" class="tree">
			<div class="treeLoading">
				<div>
					<h3><?php echo $language['tree_loading']; ?></h3>
					<i class="fas fa-spinner fa-spin fa-2x"></i>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-5 d-none d-md-block widget">
		<?php
			$success = true;
			$err = null;
			if($supportTeamspeak['success'] && !empty($supportTeamspeak['data'])) {
				$supportTeamspeak = $supportTeamspeak['data'];
			} else {
				$success = false;
				$err = $supportTeamspeak['error'][0];
			};
		?>
		<div class="header news-header">
			<h4 class="title color-header"><i class="fab fa-teamspeak"></i> <?php echo ($success) ? xssSafe($supportTeamspeak['virtualserver_name']) : $language['offline']; ?></h4>
			<h6 class="sub-title text-muted"><?php echo $language['support_teamspeak']; ?></h6>
		</div>
		<hr class="hr-headline mb-3"/>
		<?php if($success) { ?>
			<div class="row mb-3">
				<div class="col">
					<i class="fas fa-power-off w-20"></i> <?php echo $language['online_since']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-success"><?php echo convertSecondsToStrTime($supportTeamspeak['virtualserver_uptime']); ?></span>
				</div>
			</div>
			<div class="row mb-3">
				<div class="col">
					<i class="fas fa-users w-20"></i> <?php echo $language['client']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-primary"><?php echo ($supportTeamspeak['virtualserver_clientsonline'] - $supportTeamspeak['virtualserver_queryclientsonline']).' / '.$supportTeamspeak['virtualserver_maxclients'].' ('.(($supportTeamspeak['virtualserver_clientsonline'] - $supportTeamspeak['virtualserver_queryclientsonline'])/$supportTeamspeak['virtualserver_maxclients']).'%)'; ?>
				</div>
			</div>
			<div class="row mb-3">
				<div class="col">
					<i class="fas fa-code-branch w-20"></i> <?php echo $language['version']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-primary"><?php echo preg_replace("/\[.*/", "", $supportTeamspeak['virtualserver_version']).'@ '.$supportTeamspeak['virtualserver_platform']; ?></span>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<i class="fas fa-bolt w-20"></i> <?php echo $language['packagelost']; ?>
				</div>
				<div class="col text-right">
					<span class="badge badge-text badge-primary"><?php echo round($supportTeamspeak['virtualserver_total_packetloss_total'], 2).' %'; ?></span>
				</div>
			</div>
			<?php if(!empty($supportTeamspeak['virtualserver_hostbanner_gfx_url'])) { ?>
				<hr class="hr-headline mt-3"/>
				<?php if(!empty($supportTeamspeak['virtualserver_hostbanner_url'])) { ?>
					<a href="<?php echo $supportTeamspeak['virtualserver_hostbanner_url']; ?>">
						<img class="w-100-percent" src="<?php echo $supportTeamspeak['virtualserver_hostbanner_gfx_url']; ?>" />
					</a>
				<?php } else { ?>
					<img class="w-100-percent" src="<?php echo $supportTeamspeak['virtualserver_hostbanner_gfx_url']; ?>" />
				<?php }; ?>
			<?php }; ?>
			<hr class="hr-headline mt-3"/>
			<a href="ts3server://<?php echo $ts3_server[$mysqlModul['data']['support_teamspeak_instance']]['ip']; ?>?port=<?php echo $mysqlModul['data']['support_teamspeak_port']; ?>"><button class="btn btn-success w-100-percent"><i class="fas fa-sign-in-alt mr-2"></i><?php echo $language['connect']; ?></button></a>
		<?php } else { ?>
			<p class="color-danger"><?php echo $err; ?></p>
			<hr class="hr-headline mt-3"/>
		<?php }; ?>
	</div>
</div>

<script src="js/webinterface/teamspeak.js"></script>
<script>
	var instance = <?php echo $mysqlModul['data']['support_teamspeak_instance']; ?>;
	var port = <?php echo $mysqlModul['data']['support_teamspeak_port']; ?>;
	var treeInterval = <?php echo ($settings['data']['ts_tree_intervall'] / 1000); ?>;
	
	new TeamspeakTree({
		id: 'newTree',
		instance: instance,
		port: port,
		interval: treeInterval
	});
</script>