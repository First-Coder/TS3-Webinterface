 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTicket.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	$TicketInformations		=	array();
	$isAdmin				=	false;
	if($user_right['right_hp_ticket_system']['key'] != $mysql_keys['right_hp_ticket_system'])
	{
		$userInformations	=	getUserInformations($_SESSION['user']['id']);
		$TicketInformations	=	getTicketInformations($_SESSION['user']['id']);
	}
	else
	{
		$isAdmin			=	true;
		$TicketInformations	=	getTicketInformations($_SESSION['user']['id'], true);
	};
	
	/*
		Counter the tickets
	*/
	$ticketOpen				=	0;
	$ticketClosed			=	0;
	foreach($TicketInformations AS $text)
	{
		if($text['status'] == "open")
		{
			$ticketOpen++;
		}
		else
		{
			$ticketClosed++;
		};
	};
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-ticket"  aria-hidden="true"></i> <?php echo $language['tickets']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<div class="nav-tabs-vertical">
					<ul class="nav nav-tabs">
						<li class="nav-item">
							<a href="#" class="nav-link active" data-toggle="tab" data-target="#ticketOpen">
								<?php echo $language['open']; ?>
								<span class="tag tag-rounded tag-success" style="transform: translate3d(0, -10px, 0);"><?php echo $ticketOpen; ?></span>
							</a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#ticketClosed">
								<?php echo $language['closed']; ?>
								<span class="tag tag-rounded tag-danger" style="transform: translate3d(0, -10px, 0);"><?php echo $ticketClosed; ?></span>
							</a>
						</li>
						<?php if($isAdmin) { ?>
							<li class="nav-item">
								<a href="#" class="nav-link" data-toggle="tab" data-target="#ticketSettings"><?php echo $language['settings']; ?></a>
							</li>
						<?php } else { ?>
							<li class="nav-item">
								<a href="#" class="nav-link" data-toggle="tab" data-target="#ticketCreate"><?php echo $language['create_ticket']; ?></a>
							</li>
						<?php }; ?>
					</ul>
					<div class="tab-content w-100-percent form-secondary">
						<div role="tabpanel" class="tab-pane active" id="ticketOpen">
							<div class="row">
								<?php 
									if(!empty($TicketInformations))
									{
										foreach($TicketInformations AS $text)
										{
											if($text['status'] == "open") { ?>
												<div class="col-sm-12 col-md-6">
													<div class="card">
														<div>
															<div class="dashboard-profile">
																<div class="row">
																	<div class="col-md-12">
																		<img class="img-circle h-100 w-100" src="<?php echo getUserPicture($text['pk']); ?>" alt="face" />
																		<h5><?php echo getUsernameFromPk($text['pk']); ?></h5>
																	</div>
																</div>
															</div>
														</div>
														<div class="card-block">
															<ul class="list-group">
																<li class="list-group-item">
																	<i class="material-icons">error</i>
																	<div class="bmd-list-group-col">
																		<p class="list-group-item-heading"><?php echo $text['subject']; ?></p>
																		<p class="list-group-item-text"><?php echo $language['area']; ?>: <?php xssEcho($text['department']); ?></p>
																	</div>
																</li>
																<li class="list-group-item">
																	<i class="material-icons">access_time</i>
																	<div class="bmd-list-group-col">
																		<p class="list-group-item-heading"><?php echo changeTimestamp($text['dateAded']); ?></p>
																		<p class="list-group-item-text"><?php echo $language['create_on']; ?></p>
																	</div>
																</li>
																<li class="list-group-item">
																	<i class="material-icons">timelapse</i>
																	<div class="bmd-list-group-col">
																		<p class="list-group-item-heading"><?php echo changeTimestamp($text['dateActivity']); ?></p>
																		<p class="list-group-item-text"><?php echo $language['last_activity']; ?></p>
																	</div>
																</li>
															</ul>
															<button type="button" onClick="closeTicket('<?php echo $text['id']; ?>');" class="btn btn-danger btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
																<i class="material-icons f-s-18">close</i>
															</button>
															<button type="button" onClick="showTicket(<?php echo $text['id']; ?>);" class="btn btn-success btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
																<i class="material-icons f-s-18">edit</i>
															</button>
														</div>
													</div>
												</div>
											<?php };
										};
									};
								?>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="ticketClosed">
							<div class="row">
								<?php 
									if(!empty($TicketInformations))
									{
										foreach($TicketInformations AS $text)
										{
											if($text['status'] != "open") { ?>
												<div class="col-sm-12 col-md-6" id="MainTicket<?php echo $text['id']; ?>">
													<div class="card">
														<div>
															<div class="dashboard-profile">
																<div class="row">
																	<div class="col-md-12">
																		<img class="img-circle h-100 w-100" src="./images/dummy.jpg" alt="face" />
																		<h5><?php echo getUsernameFromPk($text['pk']); ?></h5>
																	</div>
																</div>
															</div>
														</div>
														<div class="card-block">
															<ul class="list-group">
																<li class="list-group-item">
																	<i class="material-icons">error</i>
																	<div class="bmd-list-group-col">
																		<p class="list-group-item-heading"><?php echo $text['subject']; ?></p>
																		<p class="list-group-item-text"><?php echo $language['area']; ?>: <?php xssEcho($text['department']); ?></p>
																	</div>
																</li>
																<li class="list-group-item">
																	<i class="material-icons">access_time</i>
																	<div class="bmd-list-group-col">
																		<p class="list-group-item-heading"><?php echo changeTimestamp($text['dateAded']); ?></p>
																		<p class="list-group-item-text"><?php echo $language['create_on']; ?></p>
																	</div>
																</li>
																<li class="list-group-item">
																	<i class="material-icons">av_timer</i>
																	<div class="bmd-list-group-col">
																		<p class="list-group-item-heading"><?php echo changeTimestamp($text['dateClosed']); ?></p>
																		<p class="list-group-item-text"><?php echo $language['closed']; ?></p>
																	</div>
																</li>
															</ul>
															<?php if($isAdmin && TICKET_CAN_BE_DELETED == "true") { ?>
																<button type="button" onClick="AreYouSure('<?php echo $language['delete_ticket']; ?>', '<?php echo urlencode(json_encode(array("deleteTicket", $text['id']))); ?>');" class="btn btn-danger btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
																	<i class="material-icons f-s-18">delete</i>
																</button>
															<?php }; ?>
															<button type="button" onClick="showTicket(<?php echo $text['id']; ?>);" class="btn btn-success btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
																<i class="material-icons f-s-18">remove_red_eyes</i>
															</button>
														</div>
													</div>
												</div>
											<?php };
										};
									};
								?>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="ticketSettings">
							<div class="card-block-header">
								<h5 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo $language['add_ticketarea']; ?></h5>
							</div>
							<div class="row">
								<div class="col-md-8 mt-2">
									<div class="form-group pt-0">
										<input id="ticketAddRoleText" type="text" class="form-control">
									</div>
								</div>
								<div class="col-md-4 mt-2 mb-3">
									<button onClick="addModerator();" class="btn btn-success btn-flat w-100-percent" type="button"><i class="fa fa-check" aria-hidden="true"></i> <?php echo $language['add']; ?></button>
								</div>
							</div>
							<div class="card-block-header mt-3">
								<h5 class="card-title"><i class="fa fa-edit" aria-hidden="true"></i> <?php echo $language['change_ticketarea']; ?></h5>
							</div>
							<div class="row">
								<?php 
									$get_option 		= 	file_get_contents(TICKETAREAS_PATH);
									$exp_get_option 	= 	explode("\n", $get_option);
									$skip_first			=	true;
									foreach ($exp_get_option as $i => $value)
									{ ?>
										<div class="col-md-6 mt-2 ticketEditRoleBox<?php echo $i; ?>">
											<div class="form-group pt-0">
												<input type="text" class="form-control" value="<?php xssEcho(trim($value)); ?>" id="ticketEditRoleText<?php echo $i; ?>" oldValue="<?php echo trim($value); ?>">
											</div>
										</div>
										<div class="col-md-3 mt-2 <?php echo ($skip_first) ? "col-xs-12 mb-3" : "col-xs-6"; ?> ticketEditRoleBox<?php echo $i; ?>">
											<button onClick="editModerator('<?php echo $i; ?>');" class="btn btn-success btn-flat w-100-percent" type="button"><i class="fa fa-check" aria-hidden="true"></i> <?php echo $language['change']; ?></button>
										</div>
										<?php if(!$skip_first) { ?>
											<div class="col-md-3 col-xs-6 mt-2 mb-3 ticketEditRoleBox<?php echo $i; ?>">
												<button onClick="deleteModerator('<?php echo $i; ?>');" class="btn btn-danger btn-flat w-100-percent" type="button"><i class="fa fa-trash" aria-hidden="true"></i> <?php echo strtolower($language['delete']); ?></button>
											</div>
										<?php }; ?>
									<?php $skip_first = false;
									};
								?>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane form-secondary" id="ticketCreate">
							<div class="card-block-header">
								<h5 class="card-title"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo $language['create_ticket']; ?></h5>
							</div>
							<div class="form-group w-100-percent">
								<label><?php echo $language['mail']; ?></label>
								<input type="text" class="form-control" value="<?php echo $_SESSION['user']['benutzer']; ?>" disabled>
							</div>
							<div class="form-group w-100-percent">
								<label><?php echo $language['firstname']; ?></label>
								<input type="text" class="form-control" value="<?php xssEcho($userInformations['vorname']); ?>" disabled>
							</div>
							<div class="form-group w-100-percent">
								<label><?php echo $language['lastname']; ?></label>
								<input type="text" class="form-control" value="<?php xssEcho($userInformations['nachname']); ?>" disabled>
							</div>
							<div class="form-group w-100-percent">
								<label><?php echo $language['subject']; ?></label>
								<input id="ticketBetreff" type="text" class="form-control">
							</div>
							<div class="form-group w-100-percent">
								<label><?php echo $language['area']; ?></label>
								<select id="ticketBereich" class="form-control">
									<?php 
										$get_option 	= 	file_get_contents(TICKETAREAS_PATH);
										$exp_get_option = 	explode("\n", $get_option);
										foreach ($exp_get_option as $value)
										{
											echo '<option value="'.trim($value).'">'.xssSafe(trim($value)).'</option>';
										};
									?>
								</select>
							</div>
							<div class="form-group w-100-percent">
								<label><?php echo $language['message']; ?></label>
								<textarea id="ticketMessage" class="form-control" rows="5"></textarea>
							</div>
							<button onClick="createTicket();" style="width:100%;" class="btn btn-success mt-3"><i class="fa fa-fw fa-paper-plane"></i> <?php echo $language['create_ticket']; ?></button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/ticket.js"></script>
<script>
	validateOnChange('#ticketBetreff', {
		required: true
	}, '', '');
	validateOnChange('#ticketMessage', {
		required: true
	}, '', '');
</script>