 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTicket.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Get homepage settings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Get all tickets
	*/
	$tickets = getTicketInformations($_SESSION['user']['id'], $user_right['data']['perm_profile_ticket_admin'] === $mysql_keys['perm_profile_ticket_admin']);
	
	/**
		Get all ticket areas
	*/
	$areas = getAreas();
	
	/**
		Got heading
	*/
	switch($LinkInformations[2]) {
		case 'closed':
			$heading = $language['closed'];
			break;
		case 'createTicket':
			$heading = $language['create_ticket'];
			break;
		case 'settings':
			$heading = $language['settings'];
			break;
		default:
			$heading = $language['open'];
			break;
	};
	
	/** 
		Could not load all settings
	*/
	if(!$tickets['success'] || !$areas['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	} else {
		$tickets = $tickets['data'];
		$areas = $areas['data'];
	};
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['tickets']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'open') ? "active" : ""; ?>" data-display="false">
				<a href="#open">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['open']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'closed') ? "active" : ""; ?>" data-display="false">
				<a href="#closed">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['closed']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'createTicket') ? "active" : ""; ?>" data-icon="fas fa-plus" data-ttip="<?php echo ucfirst($language['create']); ?>">
				<a href="#createTicket">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['create_ticket']; ?></span>
				</a>
			</li>
			<?php if($user_right['data']['perm_profile_ticket_settings'] == $mysql_keys['perm_profile_ticket_settings']) { ?>
				<li class="item <?php echo ($LinkInformations[2] == 'settings') ? "active" : ""; ?>">
					<a href="#settings">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['settings']; ?></span>
					</a>
				</li>
			<?php }; ?>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-display="<?php echo ($LinkInformations[2] == 'createTicket' || $LinkInformations[2] == 'settings') ? "true" : "false"; ?>" data-toggle="tooltip" data-placement="left" title="<?php echo ($LinkInformations[2] == 'createTicket') ? $language['create'] : $language['save']; ?>"><i class="<?php echo ($LinkInformations[2] == 'createTicket') ? 'fas fa-plus' : 'far fa-save'; ?>"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="open" class="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'open') ? "active" : ""; ?>">
					<?php
						if(!empty($tickets)) {
							foreach($tickets AS $ticket) {
								if($ticket['status'] !== 'open') {
									continue;
								}; ?>
								
								<div id="ticket-<?php echo $ticket['id']; ?>" class="ticket ticket-danger">
									<header>
										<h1><?php xssEcho($ticket['subject']); ?></h1>
										<div>
											<h5><?php echo $language['status']; ?></h5>
											<p><?php echo strtoupper($ticket['status']); ?></p>
										</div>
									</header>
									<content>
										<section class="preview">
											<div>
												<h5><?php echo $language['client']; ?></h5>
												<p><?php echo getUsernameFromPk($ticket['pk'])['data']; ?></p>
											</div>
											<div>
												<h5><?php echo $language['preview']; ?></h5>
												<p><?php echo strip_tags($ticket['msg']); ?></p>
											</div>
										</section>
										<section class="actions">
											<div>
												<h5><?php echo $language['area']; ?></h5>
												<p><?php xssEcho($ticket['department']); ?></p>
											</div>
											<div>
												<h5>ID</h5>
												<p><?php xssEcho($ticket['id']); ?></p>
											</div>
											<div>
												<h5><?php echo $language['create_on']; ?></h5>
												<p><?php echo $ticket['dateAded']; ?></p>
											</div>
											<div>
												<h5><?php echo $language['last_activity']; ?></h5>
												<p><?php echo $ticket['dateActivity']; ?></p>
											</div>
										</section>
										<section class="qr-code">
											<i class="fas fa-qrcode"></i>
											<button class="btn btn-flat btn-sm mt-2" onclick="showTicket('<?php echo $ticket['id']; ?>');"><i class="fas fa-pencil-alt mr-2"></i><?php echo $language['edit']; ?></button>
											<button class="btn btn-flat btn-sm btn-success" onClick="closeTicket('<?php echo $ticket['id']; ?>');"><i class="fas fa-times mr-2"></i><span><?php echo $language['close']; ?></span></button>
										</section>
									</content>
								</div>
							<?php };
						};
					?>
				</div>
				<div id="closed" class="<?php echo ($LinkInformations[2] == 'closed') ? "active" : ""; ?>">
					<?php
						if(!empty($tickets)) {
							foreach($tickets AS $ticket) {
								if($ticket['status'] === 'open') {
									continue;
								}; ?>
								
								<div id="ticket-<?php echo $ticket['id']; ?>" class="ticket ticket-success">
									<header>
										<h1><?php xssEcho($ticket['subject']); ?></h1>
										<div>
											<h5><?php echo $language['status']; ?></h5>
											<p><?php echo strtoupper($ticket['status']); ?></p>
										</div>
									</header>
									<content>
										<section class="preview">
											<div>
												<h5><?php echo $language['client']; ?></h5>
												<p><?php echo getUsernameFromPk($ticket['pk'])['data']; ?></p>
											</div>
											<div>
												<h5><?php echo $language['preview']; ?></h5>
												<p><?php echo strip_tags($ticket['msg']); ?></p>
											</div>
										</section>
										<section class="actions">
											<div>
												<h5><?php echo $language['area']; ?></h5>
												<p><?php xssEcho($ticket['department']); ?></p>
											</div>
											<div>
												<h5><?php echo $language['closed_on']; ?></h5>
												<p><?php echo $ticket['dateClosed']; ?></p>
											</div>
											<div>
												<h5><?php echo $language['last_activity']; ?></h5>
												<p><?php echo $ticket['dateActivity']; ?></p>
											</div>
										</section>
										<section class="qr-code">
											<i class="fas fa-qrcode"></i>
											<button class="btn btn-flat btn-sm mt-2" onclick="showTicket('<?php echo $ticket['id']; ?>');"><i class="fas fa-pencil-alt mr-2"></i><?php echo $language['edit']; ?></button>
											<?php if($settings['success'] && $settings['data']['delete_tickets'] === '0') { ?>
												<button class="btn btn-flat btn-sm btn-danger" onClick="deleteTicket('<?php echo $ticket['id']; ?>');"><i class="fas fa-trash-alt mr-2"></i><?php echo $language['delete']; ?></button>
											<?php }; ?>
										</section>
									</content>
								</div>
							<?php };
						};
					?>
				</div>
				<div id="createTicket" class="<?php echo ($LinkInformations[2] == 'createTicket') ? "active" : ""; ?>">
					<div class="alert alert-table form">
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['subject']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="ticket-subject" class="form-control form-control-sm" type="text" placeholder="My title">
									<small class="form-text text-muted"></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0 mb-3">
							<label class="col-lg-4 form-label color-light"><?php echo $language['area']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<select id="ticket-area" class="form-control form-control-sm">
									<?php foreach($areas AS $area) { ?>
										<option value="<?php xssEcho($area['area']); ?>"><?php xssEcho($area['area']); ?></option>
									<?php }; ?>
								</select>
							</div>
						</div>
						<div id="create-editor"></div>
					</div>
				</div>
				<?php if($user_right['data']['perm_profile_ticket_settings'] == $mysql_keys['perm_profile_ticket_settings']) { ?>
					<div id="settings" class="<?php echo ($LinkInformations[2] == 'settings') ? "active" : ""; ?>">
						<div class="tabs">
							<ul class="nav nav-tabs">
								<li class="nav-item">
									<a class="nav-link active" href="#areas" data-toggle="tab" role="tab"><?php echo $language['areas']; ?></a>
								</li>
							</ul>
							<div class="tab-content form">
								<div class="tab-pane fade show active" id="areas" role="tabpanel">
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['add_ticketarea']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="add-area" class="form-control form-control-sm" type="text" placeholder="Enter Area">
												<small class="form-text text-muted"><?php echo $language['delete_area_info']; ?></small>
											</div>
										</div>
									</div>
									<?php foreach($areas AS $area) { ?>
										<div class="row mr-0 ml-0">
											<label class="col-lg-4 form-label color-light"><?php echo $language['area']; ?>:</label>
											<div class="col-lg-8 col-xl-4">
												<div class="form-group">
													<input id="area-<?php echo $area['id']; ?>" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['delete_area']; ?>" value="<?php xssEcho($area['area']); ?>">
													<small class="form-text text-muted"><?php echo $language['delete_area_info']; ?></small>
												</div>
											</div>
										</div>
									<?php }; ?>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
			</div>
		</div>
	</div>
</div>

<script src="js/editor/summernote-bs4.js"></script>
<script src="js/webinterface/ticket.js"></script>
<script>
	/**
		Save changed settings in the database
	*/
	$('a#save-settings').click(function(e) {
		var el = $(this);
		var link = $('li.item.active > a').attr('href');
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		
		el.addClass('disabled');
		
		switch(link) {
			case '#settings':
				var data = {
					newArea: $('#add-area').val()
				};
				
				$('.tab-content > div.active input:not(#add-area)').each(function() {
					var el = $(this);
					data[el.attr('id').split('-')[1]] = el.val();
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTicketPost.php",
					data: {
						action: 'changeAreas',
						data: JSON.stringify(data)
					},
					success: function(data){
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.area_edited,
									icon: 'far fa-save',
									type : 'success'
								}).show();
								changeContent('web_ticket');
							}, 3000);
						} else {
							el.removeClass('disabled');
							new Notification({
								message : info.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
						};
					}
				});
				break;
			case '#createTicket':
				if(!isDataValid('ticket-subject')) {
					el.removeClass('disabled');
					return;
				};
				
				if($('#create-editor').summernote('isEmpty')) {
					new Notification({
						message : lang.instanz_add_empty,
						icon: 'fas fa-plus',
						type : 'danger'
					}).show();
					el.removeClass('disabled');
					return;
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTicketPost.php",
					data: {
						action: 'createTicket',
						subject: $('#ticket-subject').val(),
						area: $('#ticket-area').val(),
						msg: encodeURIComponent($('#create-editor').summernote('code'))
					},
					success: function(data){
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.ticket_create,
									icon: 'fas fa-plus',
									type : 'success'
								}).show();
								changeContent('web_ticket');
							}, 3000);
						} else {
							el.removeClass('disabled');
							new Notification({
								message : info.error,
								icon: 'fas fa-plus',
								type : 'danger'
							}).show();
						};
					}
				});
				break;
		};
	});
	
	/**
		Editor stuff
	*/
	var editorOptions = {
		placeholder: 'Describe here your problem',
		tabsize: 2,
		height: 150
	};
	if($('#create-editor').length) {
		$('#create-editor').summernote(editorOptions);
	};
	
	/**
		Validate check
	*/
	validateOnChange('#ticket-subject', {
		required: true
	}, '', lang.instanz_add_empty.replace("&uuml;", "\u00fc"));
</script>