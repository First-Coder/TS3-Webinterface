 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTicket.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	$TicketInformations		=	array();
	$isAdmin				=	false;
	if($user_right['right_hp_ticket_system']['key'] != $mysql_keys['right_hp_ticket_system'])
	{
		$TicketInformations	=	getTicketInformation($_POST['id']);
	}
	else
	{
		$isAdmin			=	true;
		$TicketInformations	=	getTicketInformation($_POST['id'], true);
	};
	$ticketStatus			=	($TicketInformations['status'] == "open") ? true : false;
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-ticket"  aria-hidden="true"></i> <?php xssEcho($TicketInformations['subject']); ?></h4>
					<h6 class="card-subtitle text-muted"><?php xssEcho($TicketInformations['department']); ?></h6>
				</div>
				<hr class="hr-headline"/>
				<div class="row">
					<div class="col-xs-12 col-md-4 col-lg-3">
						<ul class="list-group">
							<li class="list-group-item">
								<i class="material-icons">error</i>
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php echo ($ticketStatus) ? $language['open'] : $language['closed']; ?></p>
									<p class="list-group-item-text"><?php echo $language['status']; ?></p>
								</div>
							</li>
							<li class="list-group-item">
								<i class="material-icons">access_time</i>
								<div class="bmd-list-group-col">
									<p class="list-group-item-heading"><?php echo changeTimestamp($TicketInformations['dateAded']); ?></p>
									<p class="list-group-item-text"><?php echo $language['create_on']; ?></p>
								</div>
							</li>
							<?php if($ticketStatus) { ?>
								<li class="list-group-item">
									<i class="material-icons">timelapse</i>
									<div class="bmd-list-group-col">
										<p class="list-group-item-heading"><?php echo changeTimestamp($TicketInformations['dateActivity']); ?></p>
										<p class="list-group-item-text"><?php echo $language['last_activity']; ?></p>
									</div>
								</li>
							<?php } else { ?>
								<li class="list-group-item">
									<i class="material-icons">av_timer</i>
									<div class="bmd-list-group-col">
										<p class="list-group-item-heading"><?php echo changeTimestamp($TicketInformations['dateClosed']); ?></p>
										<p class="list-group-item-text"><?php echo $language['last_activity']; ?></p>
									</div>
								</li>
							<?php }; ?>
						</ul>
						<?php if($ticketStatus) { ?>
							<button onClick="closeTicket('<?php echo $TicketInformations['id']; ?>');" class="btn btn-sm btn-outline-danger mt-3 w-100-percent"><i class="fa fa-close" aria-hidden="true"></i> <?php echo $language['close_ticket']; ?></button>
						<?php }; ?>
						<button onClick="changeContent('web_ticket');" class="btn btn-sm btn-outline-info mt-2 mb-3 w-100-percent"><i class="fa fa-arrow-left" aria-hidden="true"></i> <?php echo $language['back']; ?></button>
					</div>
					<div class="col-xs-12 col-md-8 col-lg-9">
						<div class="chat-frame mb-3">
							<div class="message-wrapper <?php echo ($TicketInformations['pk'] == $_SESSION['user']['id']) ? "me" : "them"; ?>">
								<div class="text-wrapper">
									<b><?php echo getUsernameFromPk($TicketInformations['pk']); ?></b><br/>
									<p><?php xssEcho(urldecode($TicketInformations['msg'])); ?></p>
									<p class="mb-0 text-wrapper-date"><?php echo changeTimestamp($TicketInformations['dateAded']); ?></p>
								</div>
							</div>
							<?php foreach(view_answered($_POST['id']) AS $answer) { ?>
								<div class="message-wrapper <?php echo ($answer['pk'] == $_SESSION['user']['id']) ? "me" : "them"; ?>">
									<div class="text-wrapper">
										<b><?php echo $answer['moderator']; ?></b><br/>
										<p><?php xssEcho(urldecode($answer['msg'])); ?></p>
										<p class="mb-0 text-wrapper-date"><?php echo changeTimestamp($answer['dateAded']); ?></p>
									</div>
								</div>
							<?php }; ?>
						</div>
						<?php if($ticketStatus) { ?>
							<div class="row form-success">
								<div class="col-md-8 col-xs-9">
									<div class="form-group pt-0">
										<textarea id="answer<?php echo $_POST['id']; ?>" class="form-control" placeholder="Text..."></textarea>
									</div>
								</div>
								<div class="col-md-4 col-xs-3 mt-2">
									<button onClick="answerTicket('<?php echo $_POST['id']; ?>', '<?php echo $_SESSION['user']['benutzer']; ?>');" class="btn btn-success btn-flat w-100-percent"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
								</div>
							</div>
						<?php }; ?>
					</div> 
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/ticket.js"></script>
<script>
	$(".chat-frame").animate({ scrollTop: $(document).height() }, "fast");
</script>