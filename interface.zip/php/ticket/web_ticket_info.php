 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTicket.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Check if user is logged in
	*/
	if(!isset($_POST['id'])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'ID could not be found');
	};
	
	/**
		Get ticket informations
	*/
	$ticket = ($user_right['data']['right_hp_ticket_system'] != $mysql_keys['right_hp_ticket_system']) ? getTicketInformation($_POST['id']) : getTicketInformation($_POST['id'], true);
	
	/** 
		Could not load all settings
	*/
	if(!$ticket['success'] || empty($ticket['data'])) {
		redirectSite(REDIRECT_SERVER_ERROR);
	} else {
		$ticket = $ticket['data'];
	};
	
	/**
		Get client informations
	*/
	$client = getUserInformations($ticket['pk']);
	
	/** 
		Could not load all settings
	*/
	if(!$client['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	} else {
		$client = $client['data'];
	};
?>

<div class="ticket ticket-danger content">
	<header>
		<h1><?php xssEcho($ticket['subject']); ?> (#<?php echo $_POST['id']; ?>)</h1>
		<div>
			<h5><?php echo $language['status']; ?></h5>
			<p><?php echo strtoupper($ticket['status']); ?></p>
		</div>
	</header>
	<content>
		<section class="preview">
			<div>
				<h5><?php echo $language['client']; ?></h5>
				<p><?php echo getUsernameFromPk($ticket['pk'])['data']; ?></p>
			</div>
			<div>
				<h5><?php echo $language['firstname']; ?></h5>
				<p><?php xssEcho($client['firstname']); ?></p>
			</div>
			<div>
				<h5><?php echo $language['lastname']; ?></h5>
				<p><?php xssEcho($client['lastname']); ?></p>
			</div>
		</section>
		<section class="actions">
			<div>
				<h5><?php echo $language['area']; ?></h5>
				<p><?php xssEcho($ticket['department']); ?></p>
			</div>
			<div>
				<h5><?php echo $language['create_on']; ?></h5>
				<p><?php echo $ticket['dateAded']; ?></p>
			</div>
			<div>
				<h5><?php echo $language['last_activity']; ?></h5>
				<p><?php echo $ticket['dateActivity']; ?></p>
			</div>
		</section>
		<section class="qr-code">
			<i class="fas fa-qrcode"></i>
			<button class="btn btn-flat btn-sm mt-2" onclick="changeContent('web_ticket');"><i class="fas fa-chevron-left mr-2"></i><?php echo $language['back']; ?></button>
			<?php if($ticket['status'] === 'open') { ?>
				<button class="btn btn-flat btn-sm btn-success" onClick="closeTicket('<?php echo $ticket['id']; ?>');"><i class="fas fa-times mr-2"></i><?php echo $language['close']; ?></button>
			<?php }; ?>
		</section>
	</content>
	<content style="border-top: 1px solid #ccc;">
		<section>
			<div>
				<h5>Chat</h5>
				<div class="chat-frame mb-3">
					<div class="message-wrapper <?php echo ($ticket['pk'] == $_SESSION['user']['id']) ? "me" : "them"; ?>">
						<div class="text-wrapper">
							<b><?php echo getUsernameFromPk($ticket['pk'])['data']; ?></b><br/>
							<p><?php echo urldecode($ticket['msg']); ?></p>
							<p class="mb-0 text-wrapper-date"><?php echo changeTimestamp($ticket['dateAded']); ?></p>
						</div>
					</div>
					<?php
						$answers = getTicketAnswers($_POST['id'])['data'];
						
						if(!empty($answers)) {
							foreach($answers AS $answer) { ?>
								<div class="message-wrapper <?php echo ($answer['pk'] == $_SESSION['user']['id']) ? "me" : "them"; ?>">
									<div class="text-wrapper">
										<b><?php echo $answer['moderator']; ?></b><br/>
										<p><?php echo urldecode($answer['msg']); ?></p>
										<p class="mb-0 text-wrapper-date"><?php echo changeTimestamp($answer['dateAded']); ?></p>
									</div>
								</div>
							<?php };
						};
					?>
				</div>
			</div>
		</section>
	</content>
	<?php if($ticket['status'] === 'open') { ?>
		<content style="border-top: 1px solid #ccc;">
			<section>
				<div>
					<h5 class="mb-3"><?php echo $language['answer']; ?></h5>
					<div id="answer-editor"></div>
					<button class="btn btn-sm btn-success mt-3" onClick="answerTicket('<?php echo $_POST['id']; ?>', '<?php echo $_SESSION['user']['benutzer']; ?>', '<?php echo getUsernameFromPk($ticket['pk'])['data']; ?>', '<?php echo $ticket['subject']; ?>');"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['send_answer']; ?></button>
				</div>
			</section>
		</content>
	<?php }; ?>
</div>

<script src="js/editor/summernote-bs4.js"></script>
<script src="js/webinterface/ticket.js"></script>
<script>
	/**
		Frame slider
	*/
	$(".chat-frame").animate({ scrollTop: $(document).height() }, "fast");
	
	/**
		Editor stuff
	*/
	var editorOptions = {
		placeholder: 'Write here your answer',
		tabsize: 2,
		height: 150
	};
	if($('#answer-editor').length) {
		$('#answer-editor').summernote(editorOptions);
	};
</script>