 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	
	/**
		Get Teamspeak connection
	*/
	$tsAdmin = getTsAdminInstance($LinkInformations[2]);
	
	/** 
		Could not load all settings
	*/
	if(!$tsAdmin['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};

	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_edit_groups"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_edit_groups missing');
	};
	
	/**
		Get Teamspeak option tree
	*/
	$tsAdmin['data']->selectServer($LinkInformations[3], 'port', true, 'MyName');
	
	$channels = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelList("-topic -flags -voice -limits -icon"));
	$sgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->serverGroupList());
	$cgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelGroupList());
	$clients = $tsAdmin['data']->getElement('data', $tsAdmin['data']->clientDbList(0, '900000'));
	
	$channelTree = getChannelSelectTree($channels);
	$sgroup = getGroupSelectTree($sgroups, false);
	$cgroup = getGroupSelectTree($cgroups, true);
	$client = getClientSelectTree($clients);
	
	foreach($sgroups AS $group) {
		if ($group['type'] != '2' AND $group['type'] != '0') {
			$firstGroup = $group;
			break;
		};
	};
	
	// Permission check missing
	
	/**
		Got heading
	*/
	switch($LinkInformations[4]) {
		case 'virtualServer':
			$heading = $language['perm_tree_virtual_server'];
			break;
		case 'channel':
			$heading = $language['perm_tree_channel'];
			break;
		case 'group':
			$heading = $language['perm_tree_group'];
			break;
		case 'client':
			$heading = $language['perm_tree_client'];
			break;
		case 'filetransfer':
			$heading = $language['perm_tree_filetransfer'];
			break;
		default:
			$heading = $language['settings'];
			break;
	};
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['settings']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[4] == false || $LinkInformations[4] == 'mainSettings') ? "active" : ""; ?>">
				<a href="#mainSettings">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['settings']; ?></span>
				</a>
			</li>
			<li id="group-section" class="section group-item d-none"><h4><?php xssEcho($firstGroup['name']); ?></h4></li>
			<li class="item group-item d-none <?php echo ($LinkInformations[4] == 'virtualServer') ? "active" : ""; ?>">
				<a href="#virtualServer">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['perm_tree_virtual_server']; ?></span>
				</a>
			</li>
			<li class="item group-item d-none <?php echo ($LinkInformations[4] == 'channel') ? "active" : ""; ?>">
				<a href="#channel">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['perm_tree_channel']; ?></span>
				</a>
			</li>
			<li class="item group-item d-none <?php echo ($LinkInformations[4] == 'group') ? "active" : ""; ?>">
				<a href="#group">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['perm_tree_group']; ?></span>
				</a>
			</li>
			<li class="item group-item d-none <?php echo ($LinkInformations[4] == 'client') ? "active" : ""; ?>">
				<a href="#client">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['perm_tree_client']; ?></span>
				</a>
			</li>
			<li class="item group-item d-none <?php echo ($LinkInformations[4] == 'filetransfer') ? "active" : ""; ?>">
				<a href="#filetransfer">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['perm_tree_filetransfer']; ?></span>
				</a>
			</li>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-toggle="tooltip" data-placement="left" title="<?php echo $language['save']; ?>"><i class="far fa-save"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="mainSettings" class="<?php echo ($LinkInformations[4] == false || $LinkInformations[4] == 'mainSettings') ? "active" : ""; ?>">
					<div class="alert alert-table form">
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['group_choose']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['type']; ?>:</label>
							<div class="col-lg-8 col-xl-6">
								<select id="settings-type" class="form-control form-control-sm">
									<option value="sgroup"><?php echo $language['sgroup']; ?></option>
									<option value="cgroup"><?php echo $language['cgroup']; ?></option>
									<option value="client"><?php echo $language['client']; ?></option>
									<option value="channel"><?php echo $language['channel']; ?></option>
								</select>
								<small class="form-text text-muted"><?php echo $language['protokoll_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['group']; ?>:</label>
							<div class="col-lg-8 col-xl-6">
								<select id="settings-group" class="form-control form-control-sm">
									<?php echo $sgroup; ?>
								</select>
								<small class="form-text text-muted"><?php echo $language['protokoll_info']; ?></small>
							</div>
						</div>
						<hr/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['group_edit']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['name']; ?>:</label>
							<div class="col-lg-8 col-xl-6">
								<div class="form-group">
									<input id="settings-edit" class="form-control form-control-sm" type="text" value="<?php xssEcho($firstGroup['name']); ?>">
									<small class="form-text text-muted"><?php echo $language['group_edit_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['client']; ?>:</label>
							<div class="col-lg-8 col-xl-6">
								<div class="dropbox"></div>
							</div>
						</div>
					</div>
				</div>
				<div id="virtualServer" class="reset <?php echo ($LinkInformations[4] == 'virtualServer') ? "active" : ""; ?>">
					<div class="alert alert-table form form-inline2"></div>
				</div>
				<div id="channel" class="reset <?php echo ($LinkInformations[4] == 'channel') ? "active" : ""; ?>">
					<div class="alert alert-table form form-inline2"></div>
				</div>
				<div id="group" class="reset <?php echo ($LinkInformations[4] == 'group') ? "active" : ""; ?>">
					<div class="alert alert-table form form-inline2"></div>
				</div>
				<div id="client" class="reset <?php echo ($LinkInformations[4] == 'client') ? "active" : ""; ?>">
					<div class="alert alert-table form form-inline2"></div>
				</div>
				<div id="filetransfer" class="reset <?php echo ($LinkInformations[4] == 'filetransfer') ? "active" : ""; ?>">
					<div class="alert alert-table form form-inline2"></div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	
	/**
		Manage group tree
	*/
	;(function(window) {
		'use strict';
		
		/**
			Constructor
		*/
		function PermissionTree(options) {
			var $this = this;
			
			this.options = extend({ }, this.options);
			extend(this.options, options);
			this._init();
			
			$('#'+this.options.idType).on('change', function() {
				switch($(this).val()) {
					case 'sgroup':
						$('#'+$this.options.idGroup).html('<?php echo str_replace("'", "\'", $sgroup); ?>');
						break;
					case 'cgroup':
						$('#'+$this.options.idGroup).html('<?php echo str_replace("'", "\'", $cgroup); ?>');
						break;
					case 'channel':
						$('#'+$this.options.idGroup).html('<?php echo str_replace("'", "\'", $channelTree); ?>');
						break;
					case 'client':
						$('#'+$this.options.idGroup).html('<?php echo str_replace("'", "\'", $client); ?>');
						break;
				};
				$this._setTree();
			});
			
			$('#'+this.options.idGroup).on('change', function() {
				$this._setTree();
			});
			
			if(this.options.dropbox !== false) {
				$(this.options.dropbox).on('click', 'button', function(ev) {
					$this.options.onDropboxButton($(this));
				});
			};
		};
		
		/**
			Options from outside
		*/
		PermissionTree.prototype.options = {
			idType: 'settings-type',
			idGroup: 'settings-group',
			groupSection: 'group-section',
			groupItem: 'group-item',
			dropbox: '.dropbox',
			onDropboxButton: function() { return false; }
		}
		
		/**
			Init permission tree. Get all default keys and set them
		*/
		PermissionTree.prototype._init = function() {
			var htmlElements = {
				headline:
					'<div class="row mr-0 ml-0">\
						<h6 class="col-lg-12 color-light mt-2">%text%</h6>\
					</div>',
				hr:
					'<hr class="hr-headline"/>',
				input:
					'<div class="row mr-0 ml-0 mb-3">\
						<label class="col-lg-4 form-label color-light overflow-hidden">%headline%:</label>\
						<div class="col-lg-8">\
							<div class="form-group bmd-form-group bmd-form-group-sm">\
								<input id="%id%" class="form-control form-control-sm w-60-percent" type="text">\
								<span class="bmd-form-group is-filled">\
									<div class="switch">\
										<label data-toggle="tooltip" data-placement="top" title="'+lang.perm_tree_skip+'">\
											<input id="%id%-skip" type="checkbox">\
											&nbsp;\
										</label>\
									</div>\
								</span>\
								<span class="bmd-form-group is-filled">\
									<div class="switch">\
										<label data-toggle="tooltip" data-placement="top" title="'+lang.perm_tree_negiert+'">\
											<input id="%id%-negated" type="checkbox">\
											&nbsp;\
										</label>\
									</div>\
								</span>\
								<small class="form-text text-muted">%small%</small>\
							</div>\
						</div>\
					</div>',
				bool:
					'<div class="row mr-0 ml-0 mb-3">\
						<label class="col-lg-4 form-label color-light overflow-hidden">%headline%:</label>\
						<div class="col-lg-8">\
							<span class="bmd-form-group is-filled">\
								<div class="switch w-60-percent">\
									<label data-toggle="tooltip" data-placement="top" title="'+lang.perm_tree_value+'">\
										<input id="%id%" type="checkbox">\
										&nbsp;\
									</label>\
								</div>\
							</span>\
							<span class="bmd-form-group is-filled">\
								<div class="switch">\
									<label data-toggle="tooltip" data-placement="top" title="'+lang.perm_tree_skip+'">\
										<input id="%id%-skip" type="checkbox">\
										&nbsp;\
									</label>\
								</div>\
							</span>\
							<span class="bmd-form-group is-filled">\
								<div class="switch">\
									<label data-toggle="tooltip" data-placement="top" title="'+lang.perm_tree_negiert+'">\
										<input id="%id%-negated" type="checkbox">\
										&nbsp;\
									</label>\
								</div>\
							</span>\
							<small class="form-text text-muted">%small%</small>\
						</div>\
					</div>'
			};
			var ignoreNums = [2, 3, 4, 5];
			var $this = this;
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'getPermissionTree',
					port: port,
					instance: instance,
					type: '',
					group: ''
				},
				success: function(ret){
					var info = JSON.parse(ret);
					
					for(var row of info) {
						if(!row.pcount || ignoreNums.indexOf(row.num) >= 0) {
							continue;
						};
						
						var box = null;
						switch(row.num) {
							case 7:
								box = $('#virtualServer > div');
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_information));
								break;
							case 8:
								box = $('#virtualServer > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_administration));
								break;
							case 9:
								box = $('#virtualServer > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_settings));
								break;
							case 10:
								box = $('#channel > div');
								box.append(htmlElements.headline.replace('%text%', lang.general));
								break;
							case 11:
								box = $('#channel > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_information));
								break;
							case 12:
								box = $('#channel > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_create));
								break;
							case 13:
								box = $('#channel > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_edit));
								break;
							case 14:
								box = $('#channel > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_delete));
								break;
							case 15:
								box = $('#channel > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_access));
								break;
							case 16:
								box = $('#group > div');
								box.append(htmlElements.headline.replace('%text%', lang.general));
								break;
							case 17:
								box = $('#group > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_information));
								break;
							case 18:
								box = $('#group > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_create));
								break;
							case 19:
								box = $('#group > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_edit));
								break;
							case 20:
								box = $('#group > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_delete));
								break;
							case 21:
								box = $('#client > div');
								box.append(htmlElements.headline.replace('%text%', lang.general));
								break;
							case 22:
								box = $('#client > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_information));
								break;
							case 23:
								box = $('#client > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_admin));
								break;
							case 24:
								box = $('#client > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_basics));
								break;
							case 25:
								box = $('#client > div');
								box.append(htmlElements.hr);
								box.append(htmlElements.headline.replace('%text%', lang.perm_tree_edit));
								break;
							case 26:
								box = $('#filetransfer > div');
								box.append(htmlElements.headline.replace('%text%', lang.general));
								break;
						};
						
						for(var perm of row.permissions) {
							if(box === null) {
								continue;
							};
							
							var isSwitch = (perm.permname.charAt(0) === 'b');
							var headline = (perm.permname.includes('virtualserver') || perm.permname.includes('channel') || perm.permname.includes('group') || perm.permname.includes('client')) ? perm.permname.substr(perm.permname.indexOf('_', 2)+1) : perm.permname;
							if(isSwitch) {
								box.append(htmlElements.bool.replaceAll('%headline%', headline).replaceAll('%id%', perm.permname).replaceAll('%small%', perm.permdesc+' [Permission: '+perm.permname+']'));
							} else {
								box.append(htmlElements.input.replaceAll('%headline%', headline).replaceAll('%id%', perm.permname).replaceAll('%small%', perm.permdesc+' [Permission: '+perm.permname+']'));
							};
						};
					};
					$('[data-toggle="tooltip"]').tooltip();
					$this._setTree();
				}
			});
		}
		
		/**
			Set a new permission tree on the site
		*/
		PermissionTree.prototype._setTree = function() {
			if(!document.getElementById(this.options.idType) || !document.getElementById(this.options.idGroup)) {
				console.error('Elements idType and / or idGroup not found');
				return;
			};
			
			var data = getData(this.options.idType, this.options.idGroup);
			var $this = this;
			
			setNavigation(false, $this.options.groupItem);
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'getPermissionTree',
					port: port,
					instance: instance,
					type: data.type,
					group: data.group
				},
				success: function(ret){
					var info = JSON.parse(ret);
					var settings = $('#save-settings');
					var settingsEdit = $('#settings-edit');
					
					$($this.options.dropbox).html('');
					
					if(info.success) {
						if($this.options.dropbox !== false && data.type === 'sgroup') {
							PermissionTree.prototype._setClients();
						};
						
						$('.reset input').each(function() {
							var el = $(this);
							if(el.attr('type') === 'checkbox') {
								el.prop('checked', false);
							} else {
								el.val('');
							};
						});
						
						for(var perm of info.data) {
							var isSwitch = (perm.permsid.charAt(0) === 'b');
							if(isSwitch) {
								$('#'+perm.permsid).prop('checked', (perm.permvalue === '1'));
							} else {
								$('#'+perm.permsid).val(perm.permvalue);
							};
							$('#'+perm.permsid+'-skip').prop('checked', (perm.permskip === '1'));
							$('#'+perm.permsid+'-negated').prop('checked', (perm.permnegated === '1'));
						};
						
						if(data.type === 'sgroup' || data.type === 'cgroup') {
							settings.removeClass('disabled');
							settingsEdit.removeClass('disabled');
							settingsEdit.prop('disabled', false);
							settingsEdit.val($('#'+$this.options.idGroup).find(":selected").text());
							
							$('a[href="#mainSettings"]').closest('li').removeAttr('data-disabled');
						} else {
							settings.addClass('disabled');
							settingsEdit.addClass('disabled');
							settingsEdit.prop('disabled', true);
							settingsEdit.val('');
							
							$('a[href="#mainSettings"]').closest('li').attr('data-disabled', 'true');
						};
						
						setNavigation(true, $this.options.groupItem, $this.options.groupSection+' > h4', $('#'+$this.options.idGroup).find(":selected").html());
					} else {
						settings.addClass('disabled');
						settingsEdit.addClass('disabled');
						settingsEdit.prop('disabled', true);
						settingsEdit.val('');
						$('a[href="#mainSettings"]').closest('li').attr('data-disabled', 'true');
						
						new Notification({
							message : info.errors.join(),
							icon: 'fas fa-sync',
							type : 'danger'
						}).show();
					};
				}
			});
		};
		
		/**
			Set function into the dropbox
		*/
		PermissionTree.prototype._setClients = function() {
			var data = getData(this.options.idType, this.options.idGroup);
			var dropbox = $(this.options.dropbox);
			
			var newEl = '<div class="dropbox-table">';
			newEl += '<p>Loading...</p>';
			newEl += '</div>';
			dropbox.html('');
			dropbox.append(newEl);
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'getGroupMembers',
					port: port,
					instance: instance,
					type: $('#settings-type').val(),
					gid: $('#settings-group').val()
				},
				success: function(ret){
					var info = JSON.parse(ret);
					
					if(info.success) {
						dropbox.html('');
						
						for(var client of info.data) {
							if(client.client_nickname === undefined) {
								continue;
							};
							var newEl = '<div class="dropbox-table" clid="'+client.cldbid+'">';
							newEl += '<p><button class="btn mr-2"><i class="fas fa-trash"></i></button>'+escapeText(client.client_nickname)+'</p>';
							newEl += '</div>';
							
							dropbox.append(newEl);
						};
					} else {
						dropbox.html('<p class="text-center text-danger">'+info.errors.join()+'</p>');
					};
				}
			});
		};
		
		/**
			Read all Information from the site
			@param {string} idType
			@param {string} idGroup
		*/
		function getData(idType, idGroup) {
			return {
				type: $('#'+idType).val(),
				group: $('#'+idGroup).val()
			};
		};
		
		/**
			Set the client navigation
			@param {bool} val
			@param {string} name
			@param {string} section
			@param {string} item
		*/
		function setNavigation(val, item, section = null, name = "") {
			if(val) {
				$('#'+section).html(name);
				$('.'+item).removeClass('d-none');
			} else {
				$('.'+item).addClass('d-none');
			};
		};
		
		/**
			global namespaces
		*/
		window.PermissionTree = PermissionTree;
	})(window);
	new PermissionTree({
		onDropboxButton: function(el) {
			new AreUSure({
				label: lang.user_delete.replace("&ouml;", "\u00f6"),
				onConfirm: function() {
					var div = el.closest('div.dropbox-table');
					$.ajax({
						type: "POST",
						url: "./php/functions/functionsTeamspeakPost.php",
						data: {
							action: 'deleteServerGroupClient',
							port: port,
							instance: instance,
							gid: $('#settings-group').val(),
							id: div.attr('clid')
						},
						success: function(ret){
							var info = JSON.parse(ret);
							
							if(info.success) {
								div.remove();
								swal(lang.succeeded, lang.user_successful_deleted.replace("&ouml;", "\u00f6"), 'success');
							} else {
								swal(lang.aborted, info.errors.join(), 'error');
							};
						}
					});
				}
			});
		}
	});
	
	/**
		Save changed settings in the server
	*/
	$('a#save-settings').click(function(e) {
		var el = $(this);
		var link = $('li.item.active > a').attr('href');
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		el.addClass('disabled');
		
		switch(link) {
			case '#mainSettings':
				var val = $('#settings-edit').val();
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'setGroup',
						port: port,
						instance: instance,
						type: $('#settings-type').val(),
						gid: $('#settings-group').val(),
						name: val
					},
					success: function(ret){
						var info = JSON.parse(ret);
						
						if(info.success) {
							$('#settings-group').find(":selected").html(val);
							new Notification({
								message : lang.groupname_changed,
								icon: 'fab fa-trello',
								type : 'success'
							}).show();
						} else {
							new Notification({
								message : info.errors.join(),
								icon: 'fab fa-trello',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			default:
				var data = {};
				$('.right-side-content > .tab-content > .active input, .right-side-content > .tab-content > .active select, .right-side-content > .tab-content > .active textarea').each(function() {
					var el = $(this);
					var id = el.attr('id');
					var split = id.split('-');
					
					if(split.length === 1) {
						var val = (el.attr('type') === 'checkbox') ? (el.prop('checked')) ? '1' : false : (el.val() === '') ? false : el.val();
						data[id] = {
							val: val
						};
					} else {
						data[split[0]][split[1]] = (el.prop('checked')) ? '1' : '0';
					};
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'setGroupPermissions',
						port: port,
						instance: instance,
						type: $('#settings-type').val(),
						id: $('#settings-group').val(),
						data: JSON.stringify(data)
					},
					success: function(ret){
						var info = JSON.parse(ret);
						
						if(info.success) {
							new Notification({
								message : lang.permissions_set,
								icon: 'fab fa-trello',
								type : 'success'
							}).show();
						} else {
							new Notification({
								message : info.errors.join(),
								icon: 'fab fa-trello',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
		};
	});
</script>