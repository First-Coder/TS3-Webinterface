 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'] || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right		=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_web']['key'] != $mysql_keys['right_web'] || $user_right['right_web_server_create']['key'] != $mysql_keys['right_web_server_create'] || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite();
	};
	
	/*
		Search files in Folder wantserver/
	*/
	$wantServer = scandir(__DIR__."/../../files/wantServer/");
?>

<div id="otherContent" class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="row">
					<?php if(!empty($wantServer)) {
						foreach ($wantServer as $datei)
						{
							if($datei != "." && $datei != "..")
							{
								$information		=	explode("_", $datei);
								$information[1]		=	str_replace(".txt", "", $information[1]);
								echo '<div class="col-xs-12 col-md-6 col-xl-4">
										<div class="card lg-shadow">
											<div class="card-block with-icon header-shadow">
												<i class="fa fa-list" aria-hidden="true"></i>
												<h4 class="card-title">'.xssSafe($information[0]).'</h4>
												<p class="card-subtitle text-muted">'.$language['server_requests'].'</p>
											</div>
											<div class="card-block pt-0">
												<ul class="list-group">
													<li class="list-group-item">
														<i class="material-icons">compare_arrows</i>
														<div class="bmd-list-group-col">
															<p class="list-group-item-heading">'.xssSafe($information[1]).'</p>
															<p class="list-group-item-text">'.$language['port'].'</p>
														</div>
													</li>
													<li class="list-group-item">
														<i class="material-icons">access_time</i>
														<div class="bmd-list-group-col">
															<p class="list-group-item-heading">'.date("H:i:s - d.m.Y ", filemtime(__dir__."/../../files/wantServer/".$datei)).'</p>
															<p class="list-group-item-text">'.$language['create_on'].'</p>
														</div>
													</li>
												</ul>
												<button type="button" onClick="deleteWantServer(\''.$datei.'\');" class="btn btn-danger btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
													<i class="material-icons f-s-18">delete</i>
												</button>
												<button type="button" onClick="showServerRequest(\''.$datei.'\');" class="btn btn-success btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
													<i class="material-icons f-s-18">edit</i>
												</button>
											</div>
										</div>
									</div>';
							};
						};
					}; ?>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/teamspeak.js"></script>