 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/

	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/templates/teamspeak_create_template_default.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_modul = getModuls();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success']) {
		if($user_right['data']['perm_teamspeak_create_server'] != $mysql_keys['perm_teamspeak_create_server']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_teamspeak_create_server missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};

	/**
		Get support teamspeak if module is active
	*/
	if(!$mysql_modul['success'] || $mysql_modul['data']['free_ts3_server_application'] != 'true') {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Modul server requests is disabled');
	};

	/**
		Got heading
	*/
	switch($LinkInformations[2]) {
		case 'settings':
			$heading = $language['settings'];
			break;
		default:
			$heading = $language['server'];
			break;
	};
	
	/*
		Search files in Folder wantserver/
	*/
	$wantServer = scandir(__DIR__."/../../files/wantServer/");
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['server_requests']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'open') ? "active" : ""; ?>" data-display="false">
				<a href="#server">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['server']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'settings') ? "active" : ""; ?>">
				<a href="#settings">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['settings']; ?></span>
				</a>
			</li>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-display="<?php echo ($LinkInformations[2] == 'settings') ? "true" : "false"; ?>" data-toggle="tooltip" data-placement="left" title="<?php echo $language['save']; ?>"><i class="far fa-save"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="server" class="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'server') ? "active" : ""; ?>">
					<?php
						if(!empty($tickets)) {
							foreach($tickets AS $ticket) {
								if($ticket['status'] !== 'open') {
									continue;
								}; ?>
								
								<div id="ticket-<?php echo $ticket['id']; ?>" class="ticket ticket-danger">
									<header>
										<h1><?php xssEcho($ticket['subject']); ?></h1>
										<div>
											<h5><?php echo $language['status']; ?></h5>
											<p><?php echo strtoupper($ticket['status']); ?></p>
										</div>
									</header>
									<content>
										<section class="preview">
											<div>
												<h5><?php echo $language['client']; ?></h5>
												<p><?php echo getUsernameFromPk($ticket['pk'])['data']; ?></p>
											</div>
											<div>
												<h5><?php echo $language['preview']; ?></h5>
												<p><?php echo strip_tags($ticket['msg']); ?></p>
											</div>
										</section>
										<section class="actions">
											<div>
												<h5><?php echo $language['area']; ?></h5>
												<p><?php xssEcho($ticket['department']); ?></p>
											</div>
											<div>
												<h5>ID</h5>
												<p><?php xssEcho($ticket['id']); ?></p>
											</div>
											<div>
												<h5><?php echo $language['create_on']; ?></h5>
												<p><?php echo $ticket['dateAded']; ?></p>
											</div>
											<div>
												<h5><?php echo $language['last_activity']; ?></h5>
												<p><?php echo $ticket['dateActivity']; ?></p>
											</div>
										</section>
										<section class="qr-code">
											<i class="fas fa-qrcode"></i>
											<button class="btn btn-flat btn-sm mt-2" onclick="showTicket('<?php echo $ticket['id']; ?>');"><i class="fas fa-pencil-alt mr-2"></i><?php echo $language['edit']; ?></button>
											<button class="btn btn-flat btn-sm btn-success" onClick="closeTicket('<?php echo $ticket['id']; ?>');"><i class="fas fa-times mr-2"></i><span><?php echo $language['close']; ?></span></button>
										</section>
									</content>
								</div>
							<?php };
						};
					?>
				</div>
				<div id="settings" class="<?php echo ($LinkInformations[2] == 'settings') ? "active" : ""; ?>">
					<div class="tabs">
						<ul class="nav nav-tabs">
							<li class="nav-item">
								<a class="nav-link active" href="#areas" data-toggle="tab" role="tab"><?php echo $language['areas']; ?></a>
							</li>
						</ul>
						<div class="tab-content form">
							<div class="tab-pane fade show active" id="areas" role="tabpanel">
								<div class="row mr-0 ml-0">
									<label class="col-lg-4 form-label color-light"><?php echo $language['add_ticketarea']; ?>:</label>
									<div class="col-lg-8 col-xl-4">
										<div class="form-group">
											<input id="add-area" class="form-control form-control-sm" type="text" placeholder="Enter Area">
											<small class="form-text text-muted"><?php echo $language['delete_area_info']; ?></small>
										</div>
									</div>
								</div>
								<?php foreach($areas AS $area) { ?>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['area']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input id="area-<?php echo $area['id']; ?>" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['delete_area']; ?>" value="<?php xssEcho($area['area']); ?>">
												<small class="form-text text-muted"><?php echo $language['delete_area_info']; ?></small>
											</div>
										</div>
									</div>
								<?php }; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="otherContent" class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="row">
					<?php if(!empty($wantServer)) {
						foreach ($wantServer as $datei)
						{
							if($datei != "." && $datei != "..")
							{
								$information		=	explode("_", $datei);
								$information[1]		=	str_replace(".txt", "", $information[1]);
								echo '<div class="col-xs-12 col-md-6 col-xl-4">
										<div class="card lg-shadow">
											<div class="card-block with-icon header-shadow">
												<i class="fa fa-list" aria-hidden="true"></i>
												<h4 class="card-title">'.xssSafe($information[0]).'</h4>
												<p class="card-subtitle text-muted">'.$language['server_requests'].'</p>
											</div>
											<div class="card-block pt-0">
												<ul class="list-group">
													<li class="list-group-item">
														<i class="material-icons">compare_arrows</i>
														<div class="bmd-list-group-col">
															<p class="list-group-item-heading">'.xssSafe($information[1]).'</p>
															<p class="list-group-item-text">'.$language['port'].'</p>
														</div>
													</li>
													<li class="list-group-item">
														<i class="material-icons">access_time</i>
														<div class="bmd-list-group-col">
															<p class="list-group-item-heading">'.date("H:i:s - d.m.Y ", filemtime(__dir__."/../../files/wantServer/".$datei)).'</p>
															<p class="list-group-item-text">'.$language['create_on'].'</p>
														</div>
													</li>
												</ul>
												<button type="button" onClick="deleteWantServer(\''.$datei.'\');" class="btn btn-danger btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
													<i class="material-icons f-s-18">delete</i>
												</button>
												<button type="button" onClick="showServerRequest(\''.$datei.'\');" class="btn btn-success btn-flat bmd-btn-fab bmd-btn-fab-sm no-shadow pull-right">
													<i class="material-icons f-s-18">edit</i>
												</button>
											</div>
										</div>
									</div>';
							};
						};
					}; ?>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/teamspeak.js"></script>