 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');

	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_mass_actions"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_mass_actions missing');
	};

	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Get Teamspeak connection
	*/
	$tsAdmin = getTsAdminInstance($LinkInformations[2]);
	
	/** 
		Could not load all settings
	*/
	if(!$tsAdmin['success'] || !$settings['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Get Teamspeak option tree
	*/
	$tsAdmin['data']->selectServer($LinkInformations[3], 'port', true, $settings['data']['extern_name']);
	
	$channels = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelList("-topic -flags -voice -limits -icon"));
	$sgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->serverGroupList());
	$cgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelGroupList());
	
	$channelTree = getChannelSelectTree($channels);
	$sgroup = getGroupSelectTree($sgroups, false);
	$cgroup = getGroupSelectTree($cgroups, true);
?>

<div class="content-header color-header"><?php echo $language['server_mass_actions']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="widget form col">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-edit mr-2"></i> <?php echo $language['msg_poke']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col-md-6">
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['type']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm msg" data-id="type">
							<option value="msg" selected><?php echo $language['message']; ?></option>
							<option value="poke"><?php echo $language['poke']; ?></option>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['channel']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm msg" data-id="channel">
							<option value="none" selected><?php echo $language['all_channel']; ?></option>
							<?php echo $channelTree; ?>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['group']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm msg" data-id="group">
							<option value="all" selected><?php echo $language['all_groups']; ?></option>
							<optgroup label="<?php echo $language['sgroup']; ?>">
								<?php echo $sgroup; ?>
							</optgroup>
							<optgroup label="<?php echo $language['cgroup']; ?>">
								<?php echo $cgroup; ?>
							</optgroup>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-lg-4 form-label color-light"><?php echo $language['message']; ?>:</label>
					<div class="col-lg-8">
						<div class="form-group">
							<input class="form-control form-control-sm msg" data-id="message" type="text" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div style="padding-right: 15px;padding-left: 15px;">
					<label class="form-label color-light mb-2"><?php echo $language['client']; ?>:</label>
					<div class="dropbox msg" data-id="infobox">
						<div class="dropbox-table">
							<p class="text-center"><?php echo $language['catched_clients']; ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 mt-3">
				<button id="msg" class="btn btn-custom btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
			</div>
		</div>
		
		<div class="header news-header mt-4">
			<h4 class="title color-header"><i class="fas fa-arrows-alt mr-2"></i> <?php echo $language['move']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col-md-6">
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['from_channel']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm move" data-id="channel">
							<option value="none"><?php echo $language['all_channel']; ?></option>
							<?php echo $channelTree; ?>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['in_channel']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm move" data-id="inchannel">
							<?php echo $channelTree; ?>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['group']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm move" data-id="group">
							<option value="all" selected><?php echo $language['all_groups']; ?></option>
							<optgroup label="<?php echo $language['sgroup']; ?>">
								<?php echo $sgroup; ?>
							</optgroup>
							<optgroup label="<?php echo $language['cgroup']; ?>">
								<?php echo $cgroup; ?>
							</optgroup>
						</select>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div style="padding-right: 15px;padding-left: 15px;">
					<label class="form-label color-light mb-2"><?php echo $language['client']; ?>:</label>
					<div class="dropbox move" data-id="infobox">
						<div class="dropbox-table">
							<p class="text-center"><?php echo $language['catched_clients']; ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 mt-3">
				<button id="move" class="btn btn-custom btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
			</div>
		</div>
		
		<div class="header news-header mt-4">
			<h4 class="title color-header"><i class="fas fa-user-times mr-2"></i> <?php echo $language['kick']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col-md-6">
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['type']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm kick" data-id="type">
							<option value="server" selected><?php echo $language['serverkick']; ?></option>
							<option value="channel"><?php echo $language['channelkick']; ?></option>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['channel']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm kick" data-id="channel">
							<option value="none"><?php echo $language['all_channel']; ?></option>
							<?php echo $channelTree; ?>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['group']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm kick" data-id="group">
							<option value="all" selected><?php echo $language['all_groups']; ?></option>
							<optgroup label="<?php echo $language['sgroup']; ?>">
								<?php echo $sgroup; ?>
							</optgroup>
							<optgroup label="<?php echo $language['cgroup']; ?>">
								<?php echo $cgroup; ?>
							</optgroup>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-lg-4 form-label color-light"><?php echo $language['message']; ?>:</label>
					<div class="col-lg-8">
						<div class="form-group">
							<input class="form-control form-control-sm kick" data-id="message" type="text" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div style="padding-right: 15px;padding-left: 15px;">
					<label class="form-label color-light mb-2"><?php echo $language['client']; ?>:</label>
					<div class="dropbox kick" data-id="infobox">
						<div class="dropbox-table">
							<p class="text-center"><?php echo $language['catched_clients']; ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 mt-3">
				<button id="kick" class="btn btn-custom btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
			</div>
		</div>
		
		<div class="header news-header mt-4">
			<h4 class="title color-header"><i class="fas fa-ban mr-2"></i> <?php echo $language['ban']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col-md-6">
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['time']; ?>:</label>
					<div class="col-lg-8">
						<div class="form-group">
							<input class="form-control form-control-sm ban" data-id="time" type="number" placeholder="<?php echo $language['time_min']; ?>">
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['channel']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm ban" data-id="channel">
							<option value="none"><?php echo $language['all_channel']; ?></option>
							<?php echo $channelTree; ?>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['group']; ?>:</label>
					<div class="col-lg-8">
						<select class="form-control form-control-sm ban" data-id="group">
							<option value="all" selected><?php echo $language['all_groups']; ?></option>
							<optgroup label="<?php echo $language['sgroup']; ?>">
								<?php echo $sgroup; ?>
							</optgroup>
							<optgroup label="<?php echo $language['cgroup']; ?>">
								<?php echo $cgroup; ?>
							</optgroup>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-lg-4 form-label color-light"><?php echo $language['message']; ?>:</label>
					<div class="col-lg-8">
						<div class="form-group">
							<input class="form-control form-control-sm ban" data-id="message" type="text" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div style="padding-right: 15px;padding-left: 15px;">
					<label class="form-label color-light mb-2"><?php echo $language['client']; ?>:</label>
					<div class="dropbox ban" data-id="infobox">
						<div class="dropbox-table">
							<p class="text-center"><?php echo $language['catched_clients']; ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 mt-3">
				<button id="ban" class="btn btn-custom btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
			</div>
		</div>
	</div>
</div>

<div class="col-xs-12 main form-secondary">
	<div class="page-on-top">
		<div class="row mb-3 form-secondary">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				
				
				
				<!-- Ban -->
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-ban" aria-hidden="true"></i> <?php echo $language['ban']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<div class="row">
					<div class="col-lg-4 col-md-12">
						<div class="form-group mb-2">
							<input id="inputBanTime" type="number" class="form-control" placeholder="<?php echo $language['time_min']; ?>">
						</div>
					</div>
					<div class="col-lg-4 col-md-12">
						<div class="form-group mb-2">
							<select onChange="massactionsChangeBan(0);" id="selectBanChannel" class="form-control">
								<option value="none"><?php echo $language['all_channel']; ?></option>
								<optgroup label="<?php echo $language['channel']; ?>">
									<?php echo $channelTree; ?>
								</optgroup>
								<optgroup label="<?php echo $language['sub_channel']; ?>">
									<?php echo $subChannelTree; ?>
								</optgroup>
							</select>
						</div>
					</div>
					<div class="col-lg-4 col-md-12">
						<div class="form-group mb-2">
							<select onChange="massactionsChangeBan(0);" id="selectBanGroup" class="form-control">
								<option group="all" selected><?php echo $language['all_groups']; ?></option>
								<optgroup label="<?php echo $language['sgroup']; ?>">
									<?php echo $sgroup; ?>
								</optgroup>
								<optgroup label="<?php echo $language['cgroup']; ?>">
									<?php echo $cgroup; ?>
								</optgroup>
							</select>
						</div>
					</div>
					<div class="col-lg-8 col-md-8">
						<div class="form-group mb-2">
							<input id="inputMessageBan" type="text" class="form-control" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 mb-3">
						<div style="padding-top: 1.75rem;">
							<button onClick="massactionsChangeBan(1);" class="btn btn-flat btn-success w-100-percent"><i class="fa fa-paper-plane" aria-hidden="true"></i> <?php echo $language['senden']; ?></button>
						</div>
					</div>
					<div class="col-lg-12 col-md-12">
						<div class="jumbotron jumbotron-fluid">
							<div class="container">
								<p style="text-align:center;" id="infoBan"><?php echo $language['catched_clients']; ?></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/teamspeak.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	
	/**
		Massaction
	*/
	$('#myContent button').click(function() {
		var action = $(this).attr('id');
		var i = 0;
		
		$(this).prop('disabled', true);
		
		$('.dropbox.'+action+' > div').each(function() {
			var clid = $(this).attr('clid');
			var data = {
				action: action,
				clid: clid
			};
			
			switch(action) {
				case 'msg':
					if(data.message = $('.msg[data-id="message"]').val() == '') {
						return;
					};
					data.type = $('.msg[data-id="type"]').val();
					data.message = $('.msg[data-id="message"]').val();
					break;
				case 'move':
					data.channel = $('.move[data-id="inchannel"]').val();
					break;
				case 'kick':
					data.type = $('.kick[data-id="type"]').val();
					data.message = $('.kick[data-id="message"]').val();
					break;
				case 'ban':
					if(data.time = $('.ban[data-id="time"]').val() == '') {
						return;
					};
					data.time = $('.ban[data-id="time"]').val();
					data.message = $('.ban[data-id="message"]').val();
					break;
				default:
					return;
					break;
			};
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'setClient',
					instance: instance,
					port: port,
					data: JSON.stringify(data)
				},
				success: function(ret){
					var info = JSON.parse(ret);
					if(info.success) {
						$('.dropbox-table[clid="'+clid+'"]').addClass('text-success');
					} else {
						$('.dropbox-table[clid="'+clid+'"]').addClass('text-danger');
						new Notification({
							message : info.errors.join(),
							icon: 'fas fa-user',
							type : 'danger'
						}).show();
					};
					
					if(++i == $('.dropbox.'+action+' > div').length) {
						setTimeout(function() {
							$('.dropbox.'+action+' > div').removeClass('text-success').removeClass('text-danger');
							$('#'+action).prop('disabled', false);
						}, 3000);
					};
				}
			});
		});
	});
	
	/**
		Select changes
	*/
	$('select').on('change', function() {
		checkMassActions($(this).attr('class').split(/\s+/));
	});
	
	checkMassActions(['msg']);
	checkMassActions(['kick']);
	checkMassActions(['ban']);
	
	function checkMassActions(classes) {
		var data = {};
		if(classes.indexOf('msg') !== -1) {
			data.action = 'msg';
		} else if(classes.indexOf('move') !== -1) {
			data.action = 'move';
		} else if(classes.indexOf('kick') !== -1) {
			data.action = 'kick';
		} else if(classes.indexOf('ban') !== -1) {
			data.action = 'ban';
		};
		
		$('.'+data.action).each(function() {
			var el = $(this);
			data[el.attr('data-id')] = el.val();
		});
		
		var dropbox = $('.'+data.action+'[data-id="infobox"]');
		dropbox.html('<p class="text-center mt-2 mr-2 ml-2">Loading...</p>');
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getMassActionMember',
				port: port,
				instance: instance,
				option: 'get',
				data: JSON.stringify(data)
			},
			success: function(ret){
				var info = JSON.parse(ret);
				dropbox.html('');
				
				if(info.success) {
					if(info.data.length == 0) {
						var newEl = '<div class="dropbox-table">';
						newEl += '<p class="text-center">'+lang.catched_clients+'</p>';
						newEl += '</div>';
						dropbox.append(newEl);
					} else {
						for(var client of info.data) {
							var newEl = '<div class="dropbox-table mr-2 ml-2 mb-2" clid="'+client.clid+'">';
							newEl += '<p>'+escapeHtml(client.client_nickname)+'</p>';
							newEl += '</div>';
							dropbox.append(newEl);
						};
					};
				} else {
					new Notification({
						message : info.errors.join(),
						icon: 'fas fa-boxes',
						type : 'danger'
					}).show();
				};
			}
		});
	};
</script>