 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');

	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_token"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_token missing');
	};
	
	/**
		Get Teamspeak connection
	*/
	$tsAdmin = getTsAdminInstance($LinkInformations[2]);
	
	/** 
		Could not load all settings
	*/
	if(!$tsAdmin['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Get Teamspeak option tree
	*/
	$tsAdmin['data']->selectServer($LinkInformations[3], 'port', true, 'MyName');
	
	$channels = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelList("-topic -flags -voice -limits -icon"));
	$sgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->serverGroupList());
	$cgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelGroupList());
	
	$channelTree = getChannelSelectTree($channels);
	$sgroup = getGroupSelectTree($sgroups, false);
	$cgroup = getGroupSelectTree($cgroups, true);
?>

<div class="content-header color-header"><?php echo $language['server_token']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-7 border-right widget table-search-100 in-sm bottom">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-list-ul mr-2"></i> <?php echo $language['token_list']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<table id="channelTokenTable" data-ajax="ajaxRequest" data-card-view="true" data-classes="table-no-bordered table-hover table" data-striped="true" data-pagination="true" data-search="true">
			<thead>
				<tr>
					<th data-field="type"><?php echo $language['type']; ?></th>
					<th data-field="groupname"><?php echo $language['groupname']; ?></th>
					<th data-field="channel"><?php echo $language['channel']; ?></th>
					<th data-field="create_on"><?php echo $language['create_on']; ?></th>
					<th data-field="token"><?php echo $language['token']; ?></th>
					<th data-field="description"><?php echo $language['description']; ?></th>
					<th data-field="actions"></th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
	<div class="col-md-5 widget in-sm top form">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-edit mr-2"></i> <?php echo $language['token_create']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row mr-0 ml-0 mt-1 mb-3">
			<label class="col-lg-4 form-label color-light"><?php echo $language['type']; ?>:</label>
			<div class="col-lg-8">
				<select id="tokenChooseKindOfGroup" class="form-control form-control-sm">
					<option value="0" selected><?php echo $language['sgroup']; ?></option>
					<option value="1"><?php echo $language['cgroup']; ?></option>
				</select>
			</div>
		</div>
		<div class="row mr-0 ml-0 mt-1 mb-3">
			<label class="col-lg-4 form-label color-light"><?php echo $language['groupname']; ?>:</label>
			<div class="col-lg-8">
				<select id="tokenChooseGroup" class="form-control form-control-sm">
					<?php echo $sgroup; ?>
				</select>
			</div>
		</div>
		<div class="row mr-0 ml-0 mt-1 mb-3 d-none">
			<label class="col-lg-4 form-label color-light"><?php echo $language['channel']; ?>:</label>
			<div class="col-lg-8">
				<select id="tokenChooseChannel" class="form-control form-control-sm">
					<?php echo $channelTree; ?>
				</select>
			</div>
		</div>
		<div class="row mr-0 ml-0 mt-1">
			<label class="col-lg-4 form-label color-light"><?php echo $language['description']; ?>:</label>
			<div class="col-lg-8">
				<div class="form-group">
					<input id="tokenChooseDescription" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['message']; ?>">
				</div>
			</div>
		</div>
		<div class="row mr-0 ml-0 mt-1">
			<label class="col-lg-4 form-label color-light"><?php echo $language['how_much']; ?>:</label>
			<div class="col-lg-8">
				<div class="form-group">
					<input id="tokenChooseCount" class="form-control form-control-sm" type="number">
					<small class="form-text text-muted"></small>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<button onClick="createToken();" class="btn btn-success w-100-percent"><i class="fas fa-plus mr-2"></i><?php echo $language['create']; ?></button>
			</div>
		</div>
	</div>
</div>

<script src="js/bootstrap/bootstrap-table.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	var emptyList = lang.token_none;
	var groups = {
		sgroup: "<?php echo $sgroup; ?>",
		cgroup: "<?php echo $cgroup; ?>"
	};
	
	/**
		Token create navigation
	*/
	$('#tokenChooseKindOfGroup').on('change', function() {
		var val = $(this).val();
		var channel = $('#tokenChooseChannel').closest('.row');
		
		if(val == 0) {
			channel.addClass('d-none');
			$("#tokenChooseGroup").html(groups.sgroup);
		} else {
			channel.removeClass('d-none');
			$("#tokenChooseGroup").html(groups.cgroup);
		};
	});
	
	/**
		Token table
	*/
	$('#channelTokenTable').bootstrapTable({
		formatNoMatches: function () {
			return emptyList;
		}
	});
	
	function ajaxRequest(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getServerToken',
				port: port,
				instance: instance
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					for(var entry of info.data) {
						data.push({
							'type': (parseInt(entry.token_type) == 0) ? lang.sgroup : lang.cgroup,
							'groupname': escapeHtml(entry.groupname),
							'channel': (parseInt(entry.token_type) == 0) ? '' : 'test',
							'create_on': new Date(entry.token_created * 1000).format('d.m.Y - H:i:s'),
							'token': entry.token,
							'description': escapeHtml(entry.token_description),
							'actions': '<button class="btn btn-red btn-sm" onClick="deleteToken(\''+entry.token+'\');"><i class="fa fa-fw fa-trash mr-2"></i>'+lang.delete+'</button>'
						});
					};
				} else {
					emptyList = info.errors.join();
				};
				
				params.success({
					total: 100,
					rows: data
				});
			}
		});
	};
	
	/**
		Validation
	*/
	validateOnChange('#tokenChooseCount', {
		required: true,
		format: /^[1-9][0-9]*$/
	}, '', lang.field_cant_be_empty);
</script>
<script src="js/webinterface/teamspeak.js"></script>