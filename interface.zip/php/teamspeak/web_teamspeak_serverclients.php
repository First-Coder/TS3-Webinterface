 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};

	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');

	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');

	/**
		Permissionscheck
	*/
	$permClients = checkServerPerm(array("perm_ts_server_clients"), $LinkInformations[2], $LinkInformations[3]);
	$permDeleteClients = checkServerPerm(array("perm_ts_server_delete_clients"), $LinkInformations[2], $LinkInformations[3]);
	if(!$permClients && !$permDeleteClients) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_clients, perm_ts_server_delete_clients missing');
	};

	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Get Teamspeak connection
	*/
	$tsAdmin = getTsAdminInstance($LinkInformations[2]);
	
	/** 
		Could not load all settings
	*/
	if(!$tsAdmin['success'] || !$settings['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};

	/**
		Get Teamspeak servergroups
	*/

	$tsAdmin['data']->selectServer($LinkInformations[3], 'port', true, $settings['data']['extern_name']);

	$sgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->serverGroupList());
	$sgroup = getGroupSelectTree($sgroups, false);
?>

<div class="content-header color-header"><?php echo $language['server_clients']; ?></div>

<div class="row shadow-default-content mb-3">
	<?php if($permClients) { ?>
		<div class="col<?php echo ($permDeleteClients) ? '-lg-7' : ''; ?> col-lg border-right widget table-search-100 in-sm bottom">
			<div class="header news-header">
				<h4 class="title color-header"><i class="fas fa-list-ul mr-2"></i> <?php echo $language['all_registred_user']; ?></h4>
			</div>
			<hr class="hr-headline mb-3"/>
			<table id="clientsTable" data-ajax="ajaxRequest" data-card-view="true" data-classes="table-no-bordered table-hover table"
				data-striped="true" data-pagination="true" data-search="true">
				<thead>
					<tr>
						<th data-field="client"><?php echo $language['client']; ?></th>
						<th data-field="status"><?php echo $language['status']; ?></th>
						<th data-field="first_con"><?php echo $language['first_con']; ?></th>
						<th data-field="last_con"><?php echo $language['last_con']; ?></th>
						<th data-field="ip"><?php echo $language['ip_adress']; ?></th>
						<th data-field="connection"><?php echo $language['connections']; ?></th>
						<th data-field="description"><?php echo $language['description']; ?></th>
						<th data-field="client_id"><?php echo $language['client']; ?> ID</th>
						<th data-field="id"><?php echo $language['client']; ?> DB ID</th>
						<th data-field="actions"></th>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	<?php }; ?>
	<?php if($permDeleteClients) { ?>
		<div class="col<?php echo ($permClients) ? '-lg-5' : ''; ?> col-lg widget in-sm top form">
			<div class="header news-header">
				<h4 class="title color-header"><i class="fas fa-user-times mr-2"></i> <?php echo $language['delete_inactive_clients']; ?></h4>
			</div>
			<hr class="hr-headline mb-3"/>
			<div class="row mr-0 ml-0 mt-1">
				<label class="col-lg-4 form-label color-light"><?php echo $language['date']; ?>:</label>
				<div class="col-lg-8">
					<div class="form-group">
						<input id="datepickerInactiveClients" type="text" class="form-control">
						<small class="form-text text-muted"><?php echo $language['delete_inactive_clients_info']; ?></small>
					</div>
				</div>
			</div>
			<div class="row mr-0 ml-0 mt-1">
				<label class="col-lg-4 form-label color-light"><?php echo $language['execptions']; ?>:</label>
				<div class="col-lg-8">
					<div class="form-group">
						<select id="sgroupInactiveClients" class="custom-select" size="10" multiple >
							<?php echo $sgroup; ?>
						</select>
						<small class="form-text text-muted"><?php echo $language['execptions_clients_info']; ?></small>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<button onClick="deleteDBClient();" class="btn btn-danger w-100-percent"><i class="fas fa-trash mr-2"></i><?php echo $language['user_delete']; ?></button>
				</div>
			</div>
		</div>
	<?php }; ?>
</div>

<script src="js/other/moment.js"></script>
<script src="js/bootstrap/bootstrap-table.js"></script>
<script src="js/bootstrap/bootstrap-material-datetimepicker.js"></script>
<script src="js/webinterface/teamspeak.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	var emptyList = lang.no_entrys;
	
	/**
		Clienttable
	*/
	$('#clientsTable').bootstrapTable({
		formatNoMatches: function () {
			return emptyList;
		}
	});
	
	function ajaxRequest(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getServerClients',
				port: port,
				instance: instance
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					for(var entry of info.data) {
						data.push({
							'client': entry.client_nickname,
							'status': (entry.client_online) ? '<span class="text-success">'+lang.online+'</span>' : '<span class="text-danger">'+lang.offline+'</span>',
							'first_con': entry.client_created,
							'last_con': entry.client_lastconnected,
							'ip': entry.client_lastip,
							'connection': entry.client_totalconnections,
							'description': entry.client_description,
							'client_id': entry.client_unique_identifier,
							'id': entry.cldbid,
							'actions': '<button class="btn btn-red btn-sm" onClick="deleteDBClient(\''+entry.cldbid+'\');"><i class="fa fa-fw fa-trash mr-2"></i>'+lang.delete+'</button>'
						});
					};
				} else {
					emptyList = info.errors.join();
				};
				
				params.success({
					total: 100,
					rows: data
				});
			}
		});
	};
	
	$( document ).ready(function() {
		$('#datepickerInactiveClients').bootstrapMaterialDatePicker({
			time: false,
			clearButton: true,
			format: 'DD.MM.YYYY',
			maxDate : new Date()
		});
	});
</script>