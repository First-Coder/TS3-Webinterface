 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	
	/**
		Permissionscheck
	*/
	$permCreate = checkServerPerm(array("perm_ts_server_create_backups"), $LinkInformations[2], $LinkInformations[3]);
	$permUse = checkServerPerm(array("perm_ts_server_use_backups"), $LinkInformations[2], $LinkInformations[3]);
	$permDelete = checkServerPerm(array("perm_ts_server_delete_backups"), $LinkInformations[2], $LinkInformations[3]);
	if(!$permCreate && !$permUse && !$permDelete) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_create_backups, perm_ts_server_use_backups, perm_ts_server_delete_backups missing');
	};
?>

<div class="content-header color-header"><?php echo $language['server_backups']; ?></div>

<?php if($permCreate || $permUse) { ?>
	<div class="row shadow-default-content mb-3">
		<div class="col<?php echo ($permCreate) ? '-md-7' : ''; ?> border-right widget in-sm bottom form">
			<?php if($permUse) { ?>
				<div class="header news-header">
					<h4 class="title color-header"><i class="far fa-window-restore mr-2"></i> <?php echo $language['reset_server']; ?></h4>
				</div>
				<hr class="hr-headline mb-3"/>
				<p class="text-center"><?php echo $language['reset_server_info']; ?></p>
				<p id="resetToken" class="text-center text-danger d-none"><?php echo $language['token']; ?>: <span></span></p>
				<button onClick="resetServer();" class="btn btn-custom btn-red w-100-percent mt-1 mb-2"><i class="fas fa-reply-all mr-2"></i><?php echo $language['reset_server']; ?></button>
			<?php }; ?>
			<?php if($permCreate) { ?>
				<div class="header news-header">
					<h4 class="title color-header"><i class="fas fa-edit mr-2"></i> <?php echo $language['create_backup']; ?></h4>
				</div>
				<hr class="hr-headline mb-3"/>
				<p><?php echo $language['what_want_backup']; ?></p>
				<div class="radio mr-3 ml-3 mb-2">
					<label>
						<input type="radio" name="type" value="channel" checked>
						<?php echo $language['channel']; ?>
					</label>
				</div>
				<div class="radio mr-3 ml-3 mb-3">
					<label>
						<input type="radio" name="type" value="server">
						<?php echo $language['server']; ?>
					</label>
				</div>
				<p><?php echo $language['what_kind_channel_backup']; ?></p>
				<div class="radio mr-3 ml-3 mb-2">
					<label id="kind-1">
						<input type="radio" name="kind" value="name" checked>
						<p class="mb-0"><?php echo $language['just_channelname']; ?></p>
					</label>
				</div>
				<div class="radio mr-3 ml-3">
					<label id="kind-2">
						<input type="radio" name="kind" value="all">
						<p class="mb-0"><?php echo $language['channelname_and_settings']; ?></p>
					</label>
				</div>
				<div class="row mt-3 mr-0 ml-0">
					<label class="col-lg-2 form-label color-light"><?php echo $language['name']; ?>:</label>
					<div class="col-lg-10">
						<div class="form-group">
							<input id="backupName" class="form-control form-control-sm" type="text" value="">
							<small class="form-text text-muted"><?php echo $language['name_channel_backup']; ?></small>
						</div>
					</div>
				</div>
				<button onClick="createBackup();" class="btn btn-custom btn-green w-100-percent mt-1"><i class="fas fa-plus mr-2"></i><?php echo $language['create']; ?></button>
			<?php }; ?>
		</div>
		<?php if($permCreate) { ?>
			<div class="col-md-5 widget in-sm top">
				<div class="header news-header">
					<h4 class="title color-header"><i class="fas fa-upload mr-2"></i> <?php echo $language['backup_upload']; ?></h4>
				</div>
				<hr class="hr-headline mb-3"/>
				<div class="row">
					<div class="col">
						<form class="dropzone" drop-zone="" id="file-dropzone"></form>
					</div>
				</div>
			</div>
		<?php }; ?>
	</div>
<?php }; ?>

<div class="row shadow-default-content mb-3">
	<div class="col widget table-search-100">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-download mr-2"></i> <?php echo $language['backup_channel']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<table id="channelTable" data-ajax="ajaxRequestChannel" data-card-view="true" data-classes="table-no-bordered table-hover table" data-striped="true" data-pagination="true" data-search="true">
			<thead>
				<tr>
					<th data-field="id">Id</th>
					<th data-field="name"><?php echo $language['name']; ?></th>
					<th data-field="alias"><?php echo $language['alias']; ?></th>
					<th data-field="port"><?php echo $language['port']; ?></th>
					<th data-field="kind"><?php echo $language['type']; ?></th>
					<th data-field="created"><?php echo $language['create_on']; ?></th>
					<th data-field="actions"></th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</div>

<div class="row shadow-default-content mb-3">
	<div class="col widget table-search-100">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-download mr-2"></i> <?php echo $language['backup_server']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<table id="serverTable" data-ajax="ajaxRequestServer" data-card-view="true" data-classes="table-no-bordered table-hover table" data-striped="true" data-pagination="true" data-search="true">
			<thead>
				<tr>
					<th data-field="id">Id</th>
					<th data-field="name"><?php echo $language['name']; ?></th>
					<th data-field="alias"><?php echo $language['alias']; ?></th>
					<th data-field="port"><?php echo $language['port']; ?></th>
					<th data-field="kind"><?php echo $language['type']; ?></th>
					<th data-field="created"><?php echo $language['create_on']; ?></th>
					<th data-field="actions"></th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</div>

<script src="js/other/dropzone.js"></script>
<script src="js/bootstrap/bootstrap-table.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	var emptyList = lang.filelist_none;
	var permUse = stringToBool('<?php echo ($permUse) ? 'true' : 'false'; ?>');
	var permDelete = stringToBool('<?php echo ($permDelete) ? 'true' : 'false'; ?>');
	
	/**
		Manage input radio buttons
	*/
	$('input[name="type"]').on('change', function() {
		var input1 = $('#kind-1');
		var input2 = $('#kind-2');
		
		switch($(this).val()) {
			case 'channel':
				$('input', input1).attr('value', 'name');
				$('p', input1).text(lang.just_channelname);
				
				$('input', input2).attr('value', 'all');
				$('p', input2).text(lang.channelname_and_settings);
				break;
			case 'server':
				$('input', input1).attr('value', 'snapshot');
				$('p', input1).text(lang.snapshot);
				
				$('input', input2).attr('value', 'all');
				$('p', input2).html(lang.server_and_attachment);
				break;
		};
	});
	
	/**
		Manage backup process
	*/
	var steps = 0;
	$('table').on('click', 'button.activate-backup', function() {
		var id = $(this).attr('data-file');
		var $this = $(this);
		
		new AreUSure({
			label: lang.activate_backup,
			onConfirm: function() {
				var curTable = $this.closest('.bootstrap-table');
				
				$('.bootstrap-table button').prop('disabled', true);
				
				if(!$('.fixed-table-body table tr.no-records-found', curTable).length) {
					$('.fixed-table-body', curTable).append('\
						<div class="fixed-table-progress">\
							<div class="backup-progress-bar custom-progress-bar style-2">\
								<div class="progress" data-width="1">\
									<div class="bar-label">Uploading Backup. please wait...</div>\
									<div class="bar-label-percentage">60%</div>\
								</div>\
							</div>\
						</div>'
					);
					$('.backup-progress-bar').progress({
						speed: 2000,
						interactive:true,
						onFinish: function() {
							setTimeout(function() {
								$('.bootstrap-table button').prop('disabled', false);
								$('.fixed-table-progress').remove();
							}, 1500);
						}
					});
				 };
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsBackupPost.php",
					data: {
						action: 'prepare',
						instance: instance,
						port: port,
						backup: id
					},
					success: function(data) {
						var info = JSON.parse(data);
						console.log(info);
						if(info.success) {
							steps = info.data.steps;
							var curStep = info.data.currentStep;
							
							$('.backup-progress-bar').progress('update', (curStep++ / steps)*100);
							
							initBackup(curStep, id);
						} else {
							$('.backup-progress-bar').progress('update', 0, function() {
								setTimeout(function() {
									$('.fixed-table-progress').remove();
								}, 1500);
							});
							new Notification({
								message : info.error.join(),
								icon: 'fas fa-upload',
								type : 'danger'
							}).show();
						};
					}
				});
			}
		});
	});
	
	function initBackup(curStep, id) {
		if(curStep <= steps) {
			setAjaxStep(id, curStep, function(success) {
				if(success) {
					$('.backup-progress-bar').progress('update', ((curStep / steps)*100 > 100) ? 100 : (curStep++ / steps)*100);
					initBackup(curStep, id);
				} else {
					curStep = 0;
					$('.backup-progress-bar').progress('update', curStep, function() {
						setTimeout(function() {
							$('.fixed-table-progress').remove();
						}, 1500);
					});
				};
			});
		};
	};
	
	function setAjaxStep(id, curStep, cb) {
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsBackupPost.php",
			data: {
				action: 'upload',
				instance: instance,
				port: port,
				backup: id,
				step: curStep
			},
			async: false,
			success: function(data) {
				var info = JSON.parse(data);
				console.log(info);
				if(!info.success) {
					new Notification({
						message : info.errors.join(),
						icon: 'fas fa-upload',
						type : 'danger'
					}).show();
				};
				cb(info.success, id);
			}
		});
	};
	
	/**
		Manage tables
	*/
	$('#channelTable').bootstrapTable({
		formatNoMatches: function () {
			return emptyList;
		}
	});
	
	$('#serverTable').bootstrapTable({
		formatNoMatches: function () {
			return emptyList;
		}
	});
	
	function ajaxRequestChannel(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsPost.php",
			data: {
				action: 'getTeamspeakBackups',
				port: port,
				instance: instance
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					for(var entry of info.data) {
						if(entry.type !== 'channel') {
							continue;
						};
						
						var bttnActions = (permUse) ? '<button class="activate-backup btn btn-green btn-sm" data-file="'+entry.created+'"><i class="fas fa-check mr-2"></i>'+lang.activate+'</button>' : '';
						var bttnDelete = (permDelete) ? '<button class="btn btn-red btn-sm" onClick="deleteBackup(\'channelTable\', \''+entry.created+'\')"><i class="fas fa-trash mr-2"></i>'+lang.delete+'</button>' : '';

						data.push({
							'id': String(entry.created).trim(),
							'name': escapeHtml(entry.name),
							'alias': escapeHtml(entry.instance.alias)+' ('+entry.instance.id+')',
							'port': entry.port,
							'kind': (entry.kind === 'all') ? lang.channelname_and_settings : lang.just_channelname,
							'created': new Date(entry.created * 1000).format('d.m.Y - H:i:s'),
							'actions': 
								bttnActions+'\
								<a href="./php/functions/functionsDownload.php?action=downloadBackup&port='+port+'&instance='+instance+'&name='+entry.created+'.fcBackup">\
									<button class="btn btn-blue btn-sm"><i class="fas fa-download mr-2"></i>'+lang.download+'</button>\
								</a>\
								'+bttnDelete
						});
					};
				} else {
					emptyList = info.error;
				};
				
				params.success({
					total: 100,
					rows: data
				});
			}
		});
	};
	
	function ajaxRequestServer(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsPost.php",
			data: {
				action: 'getTeamspeakBackups',
				port: port,
				instance: instance
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					for(var entry of info.data) {
						if(entry.type !== 'server') {
							continue;
						};
						
						var bttnActions = (permUse) ? '<button class="activate-backup btn btn-green btn-sm" data-file="'+entry.created+'"><i class="fa fa-fw fa-trash mr-2"></i>'+lang.activate+'</button>' : '';
						var bttnDelete = (permDelete) ? '<button class="btn btn-red btn-sm" onClick="deleteBackup(\'serverTable\', \''+entry.created+'\')"><i class="fa fa-fw fa-trash mr-2"></i>'+lang.delete+'</button>' : '';

						data.push({
							'id': String(entry.created).trim(),
							'name': escapeHtml(entry.name),
							'alias': escapeHtml(entry.instance.alias)+' ('+entry.instance.id+')',
							'port': entry.port,
							'kind': (entry.kind === 'all') ? lang.server_and_attachment : lang.snapshot,
							'created': new Date(entry.created * 1000).format('d.m.Y - H:i:s'),
							'actions': 
								bttnActions+'\
								<a href="./php/functions/functionsDownload.php?action=downloadBackup&port='+port+'&instance='+instance+'&name='+entry.created+'.fcBackup">\
								<button class="btn btn-blue btn-sm"><i class="fa fa-fw fa-trash mr-2"></i>'+lang.download+'</button>\
								</a>\
								'+bttnDelete
						});
					};
				} else {
					emptyList = info.error;
				};
				
				params.success({
					total: 100,
					rows: data
				});
			}
		});
	};
	
	/**
		Validation
	*/
	validateOnChange('#backupName', {
		required: true,
	}, '', lang.field_cant_be_empty);
	
	
	
	
	
	
	
	
	
	
	Dropzone.autoDiscover = false;
	
	$('#file-dropzone').dropzone({
		url: "./php/functions/functionsUploadBackup.php",
		method: "POST",
		acceptedFiles: '.json',
		dictDefaultMessage: lang.backup_upload_info,
		destination: "/files/backups",
		accept: function(file, done)
		{
			done();
		},
		success: function(file, data) {
			if(data == "done")
			{
				setNotifySuccess(lang.upload_successful);
			}
			else
			{
				setNotifyFailed(data);
			};
		}
	});
	
	
	
	
</script>
<script src="js/webinterface/teamspeak.js"></script>