 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/templates/teamspeak_create_template_default.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success']) {
		if($user_right['data']['perm_teamspeak_create_server'] != $mysql_keys['perm_teamspeak_create_server']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_teamspeak_create_server missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Got templates
	*/
	$templates = [];
	$path = __dir__.'/../../config/templates/';
	if($folder = opendir($path)) {
		while(($file = readdir($folder)) !== false) {
			if(strpos($file, '.php') === false || strpos($file, 'teamspeak_create_') === false || $file === 'teamspeak_create_template_default.php') {
				continue;
			};
			
			if(@include($path.$file)) {
				$templates[] = $ts3_server_create_template;
			};
		};
	};
	
	/**
		Got heading
	*/
	if($LinkInformations[2] !== false && intval($LinkInformations[2]) != false) {
		$heading = $language['unknown'];
		foreach($templates AS $template) {
			if($template['id'] === $LinkInformations[2]) {
				$heading = $template['templatename'];
				break;
			};
		};
	} else {
		switch($LinkInformations[2]) {
			case 'tsCreateComplain':
				$heading = $language['complaintsettings'];
				break;
			case 'tsCreateHost':
				$heading = $language['hostsettings'];
				break;
			case 'tsCreateAntiFlood':
				$heading = $language['anti_flood_settings'];
				break;
			case 'tsCreateTransfer':
				$heading = $language['transfersettings'];
				break;
			case 'tsCreateProtocol':
				$heading = $language['protokolsettings'];
				break;
			case 'templateDefault':
				$heading = $language['default_template'];
				break;
			case 'templateCreate':
				$heading = $language['create_template'];
				break;
			default:
				$heading = $language['main_settings'];
				break;
		};
	};
	
	/**
		Get Porst of instance 0
	*/
	$ports = [];
	$list = getServerList(0);
	if($list['success']) {
		foreach($list['data'] AS $server) {
			$ports[] = $server['virtualserver_port'];
		};
	};
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['create_server']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'tsCreateMain') ? "active" : ""; ?>" data-icon="fas fa-plus" data-ttip="<?php echo $language['create']; ?>">
				<a href="#tsCreateMain">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['main_settings']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'tsCreateComplain') ? "active" : ""; ?>" data-display="false">
				<a href="#tsCreateComplain">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['complaintsettings']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'tsCreateHost') ? "active" : ""; ?>" data-display="false">
				<a href="#tsCreateHost">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['hostsettings']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'tsCreateAntiFlood') ? "active" : ""; ?>" data-display="false">
				<a href="#tsCreateAntiFlood">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['anti_flood_settings']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'tsCreateTransfer') ? "active" : ""; ?>" data-display="false">
				<a href="#tsCreateTransfer">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['transfersettings']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'tsCreateProtocol') ? "active" : ""; ?>" data-display="false">
				<a href="#tsCreateProtocol">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['protokolsettings']; ?></span>
				</a>
			</li>
			
			<li class="section"><h4><?php echo $language['templates']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[2] == 'templateDefault') ? "active" : ""; ?>">
				<a href="#templateDefault">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['default_template']; ?></span>
				</a>
			</li>
			<li class="item <?php echo ($LinkInformations[2] == 'templateCreate') ? "active" : ""; ?>" data-icon="fas fa-plus" data-ttip="<?php echo $language['create']; ?>">
				<a href="#templateCreate">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['create_template']; ?></span>
				</a>
			</li>
			<?php foreach($templates AS $template) { ?>
				<li class="item <?php echo ($LinkInformations[2] === $template['id']) ? "active" : ""; ?>">
					<a href="#<?php echo $template['id']; ?>">
						<i class="fas fa-circle"></i>
						<span><?php echo $template['templatename']; ?></span>
					</a>
				</li>
			<?php }; ?>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-display="<?php echo ($LinkInformations[2] != 'tsCreateMain' && $LinkInformations[2] != 'templateDefault' && $LinkInformations[2] != 'templateCreate' && (intval($LinkInformations[2]) == false && !empty($LinkInformations[2]))) ? "false" : "true"; ?>" data-toggle="tooltip" data-placement="left" title="<?php echo $language['create']; ?>"><i class="<?php echo (intval($LinkInformations[2]) == false && $LinkInformations[2] != 'templateDefault') ? 'fas fa-plus' : 'far fa-save'; ?>"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="tsCreateMain" class="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'tsCreateMain') ? "active" : ""; ?>">
					<div id="createdServer" class="alert form shadow-alert-green" style="display: none;">
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['server_created']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['server_id']; ?>:</label>
							<span id="sid" class="col-lg-8 col-xl-4"></span>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['token']; ?>:</label>
							<span id="token" class="col-lg-8 col-xl-4"></span>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
							<span id="port" class="col-lg-8 col-xl-4"></span>
						</div>
					</div>
					
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-light" style="height: auto;">
							<i class="fas fa-info-circle"></i>
							<span><?php echo $language['ts3_lizenz_info']; ?></span>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['in_instance']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['instance']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<select id="instance-create" onChange="getPortsFromInstance('instance-create', 'port-create', true);" class="form-control form-control-sm">
									<?php foreach($ts3_server AS $instanz=>$server) {
										if($server['alias'] != '') {
											echo '<option value="' . $instanz . '">' . $server['alias'] . '</option>';
										} else {
											echo '<option value="' . $instanz . '">' . $server['ip'] . '</option>';
										};
									}; ?>
								</select>
								<small class="form-text text-muted"><?php echo $language['in_instance_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['used_ports']; ?>:</label>
							<span id="port-create" class="col-lg-8 col-xl-4 color-danger">
								<?php foreach($ports AS $i=>$port) {
									echo ($i >= (count($ports) - 1)) ? $port : $port.', ';
								}; ?>
							</span>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_choose_port']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_port-create" class="form-control form-control-sm" type="number" placeholder="<?php echo $language['random_port']; ?>">
									<small class="form-text text-muted"><?php echo $language['ts3_choose_port_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_servername']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_name-create" class="form-control form-control-sm" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_name']; ?>">
									<small class="form-text text-muted"><?php echo $language['ts3_servername_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_max_clients']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_maxclients-create" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_maxclients']; ?>">
									<small class="form-text text-muted"><?php echo $language['ts3_max_clients_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reservierte_slots']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_reserved_slots-create" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_reserved_slots']; ?>">
									<small class="form-text text-muted"><?php echo $language['ts3_reservierte_slots_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_password-create" class="form-control form-control-sm" type="password" placeholder="****">
									<small class="form-text text-muted"><?php echo $language['password_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_welcome_message']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<textarea id="virtualserver_welcomemessage-create" class="form-control form-control-sm" rows="4"><?php echo $ts3_server_create_default['virtualserver_welcomemessage']; ?></textarea>
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['templates']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['use_template']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="" type="checkbox" class="switch-disable" data-disable="server-create-disable" <?php echo (empty($templates)) ? 'disabled' : ''; ?>>
										&nbsp;
									</label>
								</div>
								<small class="form-text text-muted"><?php echo $language['template_teamspeak_info']; ?></small>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['template']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<select id="template-create" class="form-control form-control-sm server-create-disable" disabled>
									<?php if(empty($templates)) {
										echo '<option selected>'.$language['no_template'].'</option>';
									} else {
										foreach($templates AS $template) {
											echo '<option value="'.$template['id'].'">'.$template['templatename'].'</option>';
										};
									}; ?>
								</select>
								<small class="form-text text-muted"><?php echo $language['template_teamspeak_info2']; ?></small>
							</div>
						</div>
						<!--<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['soon']; ?></h6>
						</div>-->
					</div>
				</div>
				<div id="tsCreateComplain" class="<?php echo ($LinkInformations[2] == 'tsCreateComplain') ? "active" : ""; ?> tsCreateMain">
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-danger server-create-disable d-none" style="height: auto;">
							<i class="fas fa-exclamation"></i>
							<span><?php echo $language['ts3_template_info']; ?></span>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_count']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_autoban_count-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_complain_autoban_count']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_duration']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_autoban_time-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_complain_autoban_time']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_delete_after']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_remove_time-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_complain_remove_time']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="tsCreateHost" class="<?php echo ($LinkInformations[2] == 'tsCreateHost') ? "active" : ""; ?> tsCreateMain">
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-danger server-create-disable d-none" style="height: auto;">
							<i class="fas fa-exclamation"></i>
							<span><?php echo $language['ts3_template_info']; ?></span>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message_show']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<select id="virtualserver_hostmessage_mode-create" class="form-control form-control-sm server-create-disable" data-opposite="true">
									<option value="0" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 0) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_1']; ?></option>
									<option value="1" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 1) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_2']; ?></option>
									<option value="2" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 2) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_3']; ?></option>
									<option value="3" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 3) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_4']; ?></option>
								</select>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_url-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbanner_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostmessage-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostmessage']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_gfx_url-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbanner_gfx_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_interval']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_gfx_interval-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbanner_gfx_interval']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_buttton_gfx_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_gfx_url-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbutton_gfx_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_tooltip']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_tooltip-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbutton_tooltip']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_url-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbutton_url']; ?>">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="tsCreateAntiFlood" class="<?php echo ($LinkInformations[2] == 'tsCreateAntiFlood') ? "active" : ""; ?> tsCreateMain">
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-danger server-create-disable d-none" style="height: auto;">
							<i class="fas fa-exclamation"></i>
							<span><?php echo $language['ts3_template_info']; ?></span>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reduce_points']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_tick_reduce-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_tick_reduce']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_needed_command_block-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_needed_command_block']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block_ip']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_needed_ip_block-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_needed_ip_block']; ?>">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="tsCreateTransfer" class="<?php echo ($LinkInformations[2] == 'tsCreateTransfer') ? "active" : ""; ?> tsCreateMain">
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-danger server-create-disable d-none" style="height: auto;">
							<i class="fas fa-exclamation"></i>
							<span><?php echo $language['ts3_template_info']; ?></span>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_limit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_max_upload_total_bandwidth-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_max_upload_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_max_upload_total_bandwidth']; ?>">
									<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_kontigent']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_upload_quota-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_upload_quota'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_upload_quota']; ?>">
									<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_limit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_max_download_total_bandwidth-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_max_download_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_max_download_total_bandwidth']; ?>">
									<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_kontigent']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_download_quota-create" class="form-control form-control-sm server-create-disable" data-opposite="true" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_download_quota'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_download_quota']; ?>">
									<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="tsCreateProtocol" class="<?php echo ($LinkInformations[2] == 'tsCreateProtocol') ? "active" : ""; ?> tsCreateMain">
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-danger server-create-disable d-none" style="height: auto;">
							<i class="fas fa-exclamation"></i>
							<span><?php echo $language['ts3_template_info']; ?></span>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_client']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_client-create" type="checkbox" class="server-create-disable" data-opposite="true" <?php echo ($ts3_server_create_default['virtualserver_log_client'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_query']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_query-create" type="checkbox" class="server-create-disable" data-opposite="true" <?php echo ($ts3_server_create_default['virtualserver_log_query'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_channel']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_channel-create" type="checkbox" class="server-create-disable" data-opposite="true" <?php echo ($ts3_server_create_default['virtualserver_log_channel'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_rights']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_permissions-create" type="checkbox" class="server-create-disable" data-opposite="true" <?php echo ($ts3_server_create_default['virtualserver_log_permissions'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_server']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_server-create" type="checkbox" class="server-create-disable" data-opposite="true" <?php echo ($ts3_server_create_default['virtualserver_log_server'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_transfer']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_filetransfer-create" type="checkbox" class="server-create-disable" data-opposite="true" <?php echo ($ts3_server_create_default['virtualserver_log_filetransfer'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="templateDefault" class="<?php echo ($LinkInformations[2] == 'templateDefault') ? "active" : ""; ?>">
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-light" style="height: auto;">
							<i class="fas fa-info-circle"></i>
							<span><?php echo $language['default_template_info']; ?></span>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['main_settings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_servername']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_name-template-default" class="form-control form-control-sm" type="text" value="<?php echo $ts3_server_create_default['virtualserver_name']; ?>">
									<small class="form-text text-muted"><?php echo $language['ts3_servername_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_max_clients']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_maxclients-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_maxclients']; ?>">
									<small class="form-text text-muted"><?php echo $language['ts3_max_clients_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reservierte_slots']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_reserved_slots-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_reserved_slots']; ?>">
									<small class="form-text text-muted"><?php echo $language['ts3_reservierte_slots_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_welcome_message']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<textarea id="virtualserver_welcomemessage-template-default" class="form-control form-control-sm" rows="4"><?php echo $ts3_server_create_default['virtualserver_welcomemessage']; ?></textarea>
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['complaintsettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_count']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_autoban_count-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_complain_autoban_count']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_duration']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_autoban_time-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_complain_autoban_time']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_delete_after']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_remove_time-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_complain_remove_time']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['hostsettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message_show']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<select id="virtualserver_hostmessage_mode-template-default" class="form-control form-control-sm">
									<option value="0" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 0) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_1']; ?></option>
									<option value="1" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 1) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_2']; ?></option>
									<option value="2" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 2) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_3']; ?></option>
									<option value="3" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 3) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_4']; ?></option>
								</select>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_url-template-default" class="form-control form-control-sm" type="text" value="<?php echo $ts3_server_create_default['virtualserver_hostbanner_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostmessage-template-default" class="form-control form-control-sm" type="text" value="<?php echo $ts3_server_create_default['virtualserver_hostmessage']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_gfx_url-template-default" class="form-control form-control-sm" type="text" value="<?php echo $ts3_server_create_default['virtualserver_hostbanner_gfx_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_interval']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_gfx_interval-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_hostbanner_gfx_interval']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_buttton_gfx_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_gfx_url-template-default" class="form-control form-control-sm" type="text" value="<?php echo $ts3_server_create_default['virtualserver_hostbutton_gfx_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_tooltip']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_tooltip-template-default" class="form-control form-control-sm" type="text" value="<?php echo $ts3_server_create_default['virtualserver_hostbutton_tooltip']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_url-template-default" class="form-control form-control-sm" type="text" value="<?php echo $ts3_server_create_default['virtualserver_hostbutton_url']; ?>">
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['anti_flood_settings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reduce_points']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_tick_reduce-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_tick_reduce']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_needed_command_block-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_needed_command_block']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block_ip']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_needed_ip_block-template-default" class="form-control form-control-sm" type="number" value="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_needed_ip_block']; ?>">
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['transfersettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_limit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_max_upload_total_bandwidth-template-default" class="form-control form-control-sm" type="number" value="<?php echo ($ts3_server_create_default['virtualserver_max_upload_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_max_upload_total_bandwidth']; ?>">
									<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_kontigent']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_upload_quota-template-default" class="form-control form-control-sm" type="number" value="<?php echo ($ts3_server_create_default['virtualserver_upload_quota'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_upload_quota']; ?>">
									<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_limit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_max_download_total_bandwidth-template-default" class="form-control form-control-sm" type="number" value="<?php echo ($ts3_server_create_default['virtualserver_max_download_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_max_download_total_bandwidth']; ?>">
									<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_kontigent']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_download_quota-template-default" class="form-control form-control-sm" type="number" value="<?php echo ($ts3_server_create_default['virtualserver_download_quota'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_download_quota']; ?>">
									<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['protokolsettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_client']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_client-template-default" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_client'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_query']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_query-template-default" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_query'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_channel']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_channel-template-default" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_channel'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_rights']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_permissions-template-default" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_permissions'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_server']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_server-template-default" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_server'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_transfer']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_filetransfer-template-default" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_filetransfer'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="templateCreate" class="<?php echo ($LinkInformations[2] == 'templateCreate') ? "active" : ""; ?>">
					<div class="alert alert-table form">
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['main_settings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['name']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="templatename-create-template" class="form-control form-control-sm" type="text" placeholder="My new template">
									<small class="form-text text-muted"><?php echo $language['name_template_info']; ?></small>
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['complaintsettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_count']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_autoban_count-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_complain_autoban_count']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_duration']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_autoban_time-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_complain_autoban_time']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_delete_after']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_complain_remove_time-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_complain_remove_time']; ?>">
									<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['hostsettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message_show']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<select id="virtualserver_hostmessage_mode" class="form-control form-control-sm">
									<option value="0" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 0) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_1']; ?></option>
									<option value="1" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 1) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_2']; ?></option>
									<option value="2" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 2) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_3']; ?></option>
									<option value="3" <?php if ($ts3_server_create_default['virtualserver_hostmessage_mode'] == 3) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_4']; ?></option>
								</select>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_url-create-template" class="form-control form-control-sm" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbanner_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostmessage-create-template" class="form-control form-control-sm" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostmessage']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_gfx_url-create-template" class="form-control form-control-sm" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbanner_gfx_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_interval']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbanner_gfx_interval-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbanner_gfx_interval']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_buttton_gfx_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_gfx_url-create-template" class="form-control form-control-sm" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbutton_gfx_url']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_tooltip']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_tooltip-create-template" class="form-control form-control-sm" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbutton_tooltip']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_url']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_hostbutton_url-create-template" class="form-control form-control-sm" type="text" placeholder="<?php echo $ts3_server_create_default['virtualserver_hostbutton_url']; ?>">
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['anti_flood_settings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reduce_points']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_tick_reduce-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_tick_reduce']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_needed_command_block-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_needed_command_block']; ?>">
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block_ip']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_antiflood_points_needed_ip_block-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo $ts3_server_create_default['virtualserver_antiflood_points_needed_ip_block']; ?>">
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['transfersettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_limit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_max_upload_total_bandwidth-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_max_upload_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_max_upload_total_bandwidth']; ?>">
									<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_kontigent']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_upload_quota-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_upload_quota'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_upload_quota']; ?>">
									<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_limit']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_max_download_total_bandwidth-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_max_download_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_max_download_total_bandwidth']; ?>">
									<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_kontigent']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="virtualserver_download_quota-create-template" class="form-control form-control-sm" type="number" placeholder="<?php echo ($ts3_server_create_default['virtualserver_download_quota'] === 18446744073709551615) ? $language['unlimited'] : $ts3_server_create_default['virtualserver_download_quota']; ?>">
									<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
								</div>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['protokolsettings']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_client']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_client-create-template" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_client'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_query']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_query-create-template" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_query'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_channel']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_channel-create-template" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_channel'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_rights']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_permissions-create-template" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_permissions'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_server']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_server-create-template" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_server'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_transfer']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="switch">
									<label>
										<input id="virtualserver_log_filetransfer-create-template" type="checkbox" <?php echo ($ts3_server_create_default['virtualserver_log_filetransfer'] == 1) ? 'checked' : ''; ?>>
										&nbsp;
									</label>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php foreach($templates AS $template) { ?>
					<div id="<?php echo $template['id']; ?>" class="<?php echo ($LinkInformations[2] === $template['id']) ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['main_settings']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light">ID:</label>
								<span class="col-lg-8 col-xl-4 template-id"><?php echo $template['id']; ?></span>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['name']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="templatename-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="text" value="<?php echo $template['templatename']; ?>">
										<small class="form-text text-muted"><?php echo $language['name_template_info']; ?></small>
									</div>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['complaintsettings']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_count']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_complain_autoban_count-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo $template['virtualserver_complain_autoban_count']; ?>">
										<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_duration']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_complain_autoban_time-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo $template['virtualserver_complain_autoban_time']; ?>">
										<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_delete_after']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_complain_remove_time-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo $template['virtualserver_complain_remove_time']; ?>">
										<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
									</div>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['hostsettings']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message_show']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<select id="virtualserver_hostmessage_mode-template-<?php echo $template['id']; ?>" class="form-control form-control-sm">
										<option value="0" <?php if ($template['virtualserver_hostmessage_mode'] == 0) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_1']; ?></option>
										<option value="1" <?php if ($template['virtualserver_hostmessage_mode'] == 1) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_2']; ?></option>
										<option value="2" <?php if ($template['virtualserver_hostmessage_mode'] == 2) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_3']; ?></option>
										<option value="3" <?php if ($template['virtualserver_hostmessage_mode'] == 3) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_4']; ?></option>
									</select>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbanner_url-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="text" value="<?php echo $template['virtualserver_hostbanner_url']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostmessage-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="text" value="<?php echo $template['virtualserver_hostmessage']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbanner_gfx_url-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="text" value="<?php echo $template['virtualserver_hostbanner_gfx_url']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_interval']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbanner_gfx_interval-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo $template['virtualserver_hostbanner_gfx_interval']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_buttton_gfx_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbutton_gfx_url-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="text" value="<?php echo $template['virtualserver_hostbutton_gfx_url']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_tooltip']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbutton_tooltip-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="text" value="<?php echo $template['virtualserver_hostbutton_tooltip']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbutton_url-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="text" value="<?php echo $template['virtualserver_hostbutton_url']; ?>">
									</div>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['anti_flood_settings']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reduce_points']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_antiflood_points_tick_reduce-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo $template['virtualserver_antiflood_points_tick_reduce']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_antiflood_points_needed_command_block-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo $template['virtualserver_antiflood_points_needed_command_block']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block_ip']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_antiflood_points_needed_ip_block-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo $template['virtualserver_antiflood_points_needed_ip_block']; ?>">
									</div>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['transfersettings']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_limit']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_max_upload_total_bandwidth-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo ($template['virtualserver_max_upload_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $template['virtualserver_max_upload_total_bandwidth']; ?>">
										<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_kontigent']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_upload_quota-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo ($template['virtualserver_upload_quota'] === 18446744073709551615) ? $language['unlimited'] : $template['virtualserver_upload_quota']; ?>">
										<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_limit']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_max_download_total_bandwidth-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo ($template['virtualserver_max_download_total_bandwidth'] === 18446744073709551615) ? $language['unlimited'] : $template['virtualserver_max_download_total_bandwidth']; ?>">
										<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_kontigent']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_download_quota-template-<?php echo $template['id']; ?>" class="form-control form-control-sm" type="number" value="<?php echo ($template['virtualserver_download_quota'] === 18446744073709551615) ? $language['unlimited'] : $template['virtualserver_download_quota']; ?>">
										<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
									</div>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<h6 class="col-lg-12 color-light mt-2"><?php echo $language['protokolsettings']; ?></h6>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_client']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_client-template-<?php echo $template['id']; ?>" type="checkbox" <?php echo ($template['virtualserver_log_client'] == 1) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_query']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_query-template-<?php echo $template['id']; ?>" type="checkbox" <?php echo ($template['virtualserver_log_query'] == 1) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_channel']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_channel-template-<?php echo $template['id']; ?>" type="checkbox" <?php echo ($template['virtualserver_log_channel'] == 1) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_rights']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_permissions-template-<?php echo $template['id']; ?>" type="checkbox" <?php echo ($template['virtualserver_log_permissions'] == 1) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_server']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_server-template-<?php echo $template['id']; ?>" type="checkbox" <?php echo ($template['virtualserver_log_server'] == 1) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_transfer']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_filetransfer-template-<?php echo $template['id']; ?>" type="checkbox" <?php echo ($template['virtualserver_log_filetransfer'] == 1) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<hr class="hr-headline"/>
							<div class="row mr-0 ml-0">
								<button class="btn btn-sm col-12 btn-flat btn-danger delete-button"><i class="fas fa-trash mr-2"></i><?php echo $language['template_delete']; ?></button>
							</div>
						</div>
					</div>
				<?php }; ?>
			</div>
		</div>
	</div>
</div>

<script>
	/**
		Delete server template
	*/
	$('.tab-content > div button.delete-button').click(function() {
		var id = ($('.tab-content > div.active .template-id').length) ? $('.tab-content > div.active .template-id').text() : false;
		
		if(id === false) {
			return;
		};
		
		new AreUSure({
			label: lang.template_delete.replace("&ouml;", "\u00f6"),
			onConfirm: function() {
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'deleteTemplate',
						id: id
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								swal(lang.succeeded, lang.template_delete_success, 'success');
								changeContent('web_teamspeak_server_create');
							}, 3000);
						} else {
							swal(lang.aborted, info.error, 'error');
							el.removeClass('disabled');
						};
					}
				});
			}
		});
	});

	/**
		Save changed settings
	*/
	$('a#save-settings').click(function(e) {
		var el = $(this);
		var link = $('li.item.active > a').attr('href');
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		
		el.addClass('disabled');
		
		switch(link) {
			case '#tsCreateMain':
				var data = {};
				var instance = null;
				var template = false;
				
				$('.tab-content > #tsCreateMain select').each(function() {
					var el = $(this);
					var val = el.val();
					var id = el.attr('id');
					
					if(id === 'instance-create') {
						instance = val;
					} else if(!el.prop('disabled')) {
						template = val;
					};
				});
				
				$('.tab-content > #tsCreateMain input, .tab-content > #tsCreateMain textarea').each(function() {
					var el = $(this);
					var val = el.val();
					var id = el.attr('id').split('-')[0];
					
					if(el.attr('type') !== 'checkbox') {
						data[id] = val;
					};
				});
				
				if(template === false) {
					$('.tab-content > .tsCreateMain input, .tab-content > .tsCreateMain textarea, .tab-content > .tsCreateMain select').each(function() {
						var el = $(this);
						var val = el.val();
						var id = el.attr('id').split('-')[0];
						
						if(el.attr('type') === 'checkbox') {
							val = (el.prop('checked')) ? '1' : '0';
						};
						
						data[id] = val;
					});
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'createServer',
						instance: instance,
						template: template,
						data: JSON.stringify(data)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							new Notification({
								message : lang.server_create_success,
								icon: 'fas fa-plus',
								type : 'success'
							}).show();
							
							var box = $('#createdServer');
							$('#sid', box).text(info.data.sid);
							$('#token', box).text(info.data.token);
							$('#port', box).text(info.data.virtualserver_port);
							box.slideDown('slow', function() {
								el.removeClass('disabled');
							});
						} else {
							new Notification({
								message : (info.errors !== undefined) ? info.errors[0] : info.error[0],
								icon: 'fas fa-plus',
								type : 'danger'
							}).show();
							el.removeClass('disabled');
						};
					}
				});
				break;
			case '#templateDefault':
				var data = {};
				$('.tab-content > div.active input, .tab-content > div.active select, .tab-content > div.active textarea').each(function() {
					var el = $(this);
					var val = el.val();
					var id = el.attr('id').split('-')[0];
					
					if(el.attr('type') === 'checkbox') {
						val = (el.prop('checked')) ? '1' : '0';
					};
					
					data[id] = val;
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'updateDefaultTemplate',
						data: JSON.stringify(data)
					},
					success: function(data) {
						console.log(data);
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.template_update_success,
									icon: 'far fa-save',
									type : 'success'
								}).show();
								changeContent('web_teamspeak_server_create');
							}, 3000);
						} else {
							new Notification({
								message : info.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
							el.removeClass('disabled');
						};
					}
				});
				break;
			default:
			case '#templateCreate':
				var id = ($('.tab-content > div.active .template-id').length) ? $('.tab-content > div.active .template-id').text() : false;
				var data = {};
				var status = true;
				$('.tab-content > div.active input, .tab-content > div.active select, .tab-content > div.active textarea').each(function() {
					var el = $(this);
					var id = el.attr('id').split('-')[0];
					var val = el.val();
					
					if(el.attr('type') === 'checkbox') {
						val = (el.prop('checked')) ? '1' : '0';
					};
					
					if(id === 'templatename') {
						status = (val != '');
						(status) ? isSuccess('#'+$(this).attr('id'), '') : isError('#'+$(this).attr('id'), lang.field_cant_be_empty);
					};
					
					data[id] = val;
				});
				
				if(!status) {
					el.removeClass('disabled');
					return;
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'updateTemplate',
						id: id,
						data: JSON.stringify(data)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.template_update_success,
									icon: 'far fa-save',
									type : 'success'
								}).show();
								changeContent('web_teamspeak_server_create');
							}, 3000);
						} else {
							new Notification({
								message : info.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
							el.removeClass('disabled');
						};
					}
				});
				break;
		};
	});
</script>