 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys			=	getKeys();
	$mysql_modul		=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right		=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_web']['key'] != $mysql_keys['right_web'] || $user_right['right_web_server_create']['key'] != $mysql_keys['right_web_server_create'] || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite();
	};
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header"><h4 class="card-title"><i class="fa fa-paint-brush" aria-hidden="true"></i> <?php echo $language['create_server']; ?></h4></div>
				<h6 class="card-subtitle text-muted"><?php echo $language['ts3_lizenz_info']; ?></h6>
				<hr class="hr-headline"/>
				<div class="nav-tabs-vertical">
					<ul class="nav nav-tabs">
						<li class="nav-item">
							<a href="#" class="nav-link active" data-toggle="tab" data-target="#createMainSettings"><?php echo $language['main_settings']; ?></a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#createComplaintsettings"><?php echo $language['complaintsettings']; ?></a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#createHostsettings"><?php echo $language['hostsettings']; ?></a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#createAntoFloodSettings"><?php echo $language['anti_flood_settings']; ?></a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#createTransfersettings"><?php echo $language['transfersettings']; ?></a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#createProtokolsettings"><?php echo $language['protokolsettings']; ?></a>
						</li>
						<li class="nav-item">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#createExtensions"><?php echo $language['extensions']; ?></a>
						</li>
					</ul>
					<div class="tab-content w-100-percent form-secondary">
						<div role="tabpanel" class="tab-pane active" id="createMainSettings">
							<div class="form-group mb-2">
								<label><?php echo $language['masterserver_instanz']; ?></label>
								<select id="serverCreateWhichInstanz" class="form-control">
									<?php
										foreach($ts3_server AS $instanz=>$server)
										{
											if($server['alias'] != '')
											{
												echo '<option value="' . $instanz . '">' . $server['alias'] . '</option>';
											}
											else
											{
												echo '<option value="' . $instanz . '">' . $server['ip'] . '</option>';
											};
										};
									?>
								</select>
								<span class="bmd-help"><?php echo $language['in_instance_info']; ?></span>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_servername']; ?></label>
								<input id="serverCreateServername" type="text" class="form-control" placeholder="<?php echo $ts3_server_create_default['servername']; ?>">
								<span class="bmd-help"><?php echo $language['ts3_servername_info']; ?></span>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_choose_port']; ?></label>
								<input id="serverCreatePort" type="number" class="form-control" placeholder="<?php echo $language['random_port']; ?>">
								<span class="bmd-help"><?php echo $language['ts3_choose_port_info']; ?></span>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_max_clients']; ?></label>
								<input id="serverCreateSlots" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['slots']; ?>">
								<span class="bmd-help"><?php echo $language['ts3_max_clients_info']; ?></span>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_reservierte_slots']; ?></label>
								<input id="serverCreateReservedSlots" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['reserved_slots']; ?>">
								<span class="bmd-help"><?php echo $language['ts3_reservierte_slots_info']; ?></span>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['password']; ?></label>
								<input id="serverCreatePassword" type="password" class="form-control" placeholder="<?php echo $ts3_server_create_default['password']; ?>">
								<span class="bmd-help"><?php echo $language['password_info']; ?></span>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_welcome_message']; ?></label>
								<textarea id="serverCreateWelcomeMessage" class="form-control" rows="8"><?php echo $ts3_server_create_default['welcome_message']; ?></textarea>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="createComplaintsettings">
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_autoban_count']; ?></label>
								<input id="serverCreateAutobanCount" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['auto_ban_count']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_autoban_duration']; ?></label>
								<div class="input-group">
									<input id="serverCreateAutobanDuration" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['auto_ban_count']; ?>">
									<span class="input-group-addon no-focus">
										<?php echo $language['seconds']; ?>
									</span>
								</div>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_autoban_delete_after']; ?></label>
								<div class="input-group">
									<input id="serverCreateAutobanDeleteAfter" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['remove_time']; ?>">
									<span class="input-group-addon no-focus">
										<?php echo $language['seconds']; ?>
									</span>
								</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="createHostsettings">
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_message_show']; ?></label>
								<select id="serverCreateHosttype" class="form-control">
									<option value="0" <?php if ($ts3_server_create_default['host_message_show'] == 0) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_1']; ?></option>
									<option value="1" <?php if ($ts3_server_create_default['host_message_show'] == 1) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_2']; ?></option>
									<option value="2" <?php if ($ts3_server_create_default['host_message_show'] == 2) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_3']; ?></option>
									<option value="3" <?php if ($ts3_server_create_default['host_message_show'] == 3) {echo 'selected';}?>><?php echo $language['ts3_host_message_show_4']; ?></option>
								</select>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_url']; ?></label>
								<input id="serverCreateHostUrl" type="text" class="form-control" placeholder="<?php echo $ts3_server_create_default['host_url']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_message']; ?></label>
								<input id="serverCreateHostMessage" type="text" class="form-control" placeholder="<?php echo $ts3_server_create_default['host_message']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_banner_url']; ?></label>
								<input id="serverCreateHostBannerUrl" type="text" class="form-control" placeholder="<?php echo $ts3_server_create_default['host_banner_url']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_banner_interval']; ?></label>
								<input id="serverCreateHostBannerInterval" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['host_banner_int']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_buttton_gfx_url']; ?></label>
								<input id="serverCreateHostButtonGfxUrl" type="text" class="form-control" placeholder="<?php echo $ts3_server_create_default['host_button_gfx']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_button_tooltip']; ?></label>
								<input id="serverCreateHostButtonTooltip" type="text" class="form-control" placeholder="<?php echo $ts3_server_create_default['host_button_tip']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_host_button_url']; ?></label>
								<input id="serverCreateHostButtonUrl" type="text" class="form-control" placeholder="<?php echo $ts3_server_create_default['host_button_url']; ?>">
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="createAntoFloodSettings">
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_reduce_points']; ?></label>
								<input id="serverCreateReducePoints" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['points_tick_reduce']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_points_block']; ?></label>
								<input id="serverCreatePointsBlock" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['points_needed_block_cmd']; ?>">
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_points_block_ip']; ?></label>
								<input id="serverCreatePointsBlockIp" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['points_needed_block_ip']; ?>">
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="createTransfersettings">
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_upload_limit']; ?></label>
								<div class="input-group">
									<input id="serverCreateUploadLimit" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['upload_bandwidth_limit']; ?>">
									<span class="input-group-addon no-focus">
										<?php echo $language['byte_s']; ?>
									</span>
								</div>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_upload_kontigent']; ?></label>
								<div class="input-group">
									<input id="serverCreateUploadKontigent" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['upload_quota']; ?>">
									<span class="input-group-addon no-focus">
										<?php echo $language['mbyte']; ?>
									</span>
								</div>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_download_limit']; ?></label>
								<div class="input-group">
									<input id="serverCreateDownloadLimit" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['download_bandwidth_limit']; ?>">
									<span class="input-group-addon no-focus">
										<?php echo $language['byte_s']; ?>
									</span>
								</div>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_download_kontigent']; ?></label>
								<div class="input-group">
									<input id="serverCreateDownloadKontigent" type="number" class="form-control" placeholder="<?php echo $ts3_server_create_default['download_quota']; ?>">
									<span class="input-group-addon no-focus">
										<?php echo $language['mbyte']; ?>
									</span>
								</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="createProtokolsettings">
							<div class="row">
								<div class="col-xs-7">
									<?php echo $language['ts3_protokol_client']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="serverCreateProtokolClient" type="checkbox" <?php if($ts3_server_create_default['virtualserver_log_client'] == 1) { echo 'checked'; } ?>><span><?php echo ($ts3_server_create_default['virtualserver_log_client'] == 1) ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-7">
									<?php echo $language['ts3_protokol_query']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="serverCreateProtokolQuery" type="checkbox" <?php if($ts3_server_create_default['virtualserver_log_query'] == 1) { echo 'checked'; } ?>><span><?php echo ($ts3_server_create_default['virtualserver_log_query'] == 1) ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-7">
									<?php echo $language['ts3_protokol_channel']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="serverCreateProtokolChannel" type="checkbox" <?php if($ts3_server_create_default['virtualserver_log_channel'] == 1) { echo 'checked'; } ?>><span><?php echo ($ts3_server_create_default['virtualserver_log_channel'] == 1) ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-7">
									<?php echo $language['ts3_protokol_rights']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="serverCreateProtokolRights" type="checkbox" <?php if($ts3_server_create_default['virtualserver_log_permissions'] == 1) { echo 'checked'; } ?>><span><?php echo ($ts3_server_create_default['virtualserver_log_permissions'] == 1) ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-7">
									<?php echo $language['ts3_protokol_server']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="serverCreateProtokolServer" type="checkbox" <?php if($ts3_server_create_default['virtualserver_log_server'] == 1) { echo 'checked'; } ?>><span><?php echo ($ts3_server_create_default['virtualserver_log_server'] == 1) ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-7">
									<?php echo $language['ts3_protokol_transfer']; ?>
								</div>
								<div class="col-xs-5">
									<div class="switch switch-success">
										<label>
											<input id="serverCreateProtokolTransfer" type="checkbox" <?php if($ts3_server_create_default['virtualserver_log_filetransfer'] == 1) { echo 'checked'; } ?>><span><?php echo ($ts3_server_create_default['virtualserver_log_filetransfer'] == 1) ? $language['active'] : $language['deactive']; ?></span>
										</label>
									</div>
								</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="createExtensions">
							<div class="form-group mb-2">
								<label><?php echo $language['ts3_servercopy']; ?></label>
								<select onChange="serverCreateChangePort();" id="serverCreateServerCopy" class="form-control">
									<option value="nope" selected><?php echo $language['ts3_no_copy']; ?></option>
									<?php for ($i = 0; $i < count($ts3_server); $i++) { ?>
										<option value="<?php echo $i; ?>">
											<?php if($ts3_server[$i]['alias'] != '') {
													echo $ts3_server[$i]['alias'];
												} else {
													echo $ts3_server[$i]['ip']; 
												} ?>
										</option>
									<?php }; ?>
								</select>
							</div>
							<div class="form-group mb-2">
								<label><?php echo $language['port']; ?></label>
								<select id="serverCreateServerCopyPort" class="form-control">
									<option value="nope" selected><?php echo $language['ts3_no_copy']; ?></option>
								</select>
							</div>
						</div>
					</div>
				</div>
				<button id="createServer" onClick="createServer();" class="btn btn-success w-100-percent mt-3" type="button"><i class="fa fa-fw fa-check" aria-hidden="true"></i> <?php echo $language['create_server']; ?></button>
			</div>
		</div>
	</div>
</div>

<script>
	var ts3_server_create_default 	= 	<?php echo json_encode($ts3_server_create_default); ?>;
	
	$('.switch').click(function() {
		var input					=	$(this).find("input").is(":checked");
		var element					=	$(this).find("span").last();
		
		if(input)
		{
			element.text(lang.active);
		}
		else
		{
			element.text(lang.deactive);
		};
	});
</script>
<script src="js/webinterface/teamspeak.js"></script>