 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	
	/**
		Get server informations
	*/
	$info = getServerInfo($LinkInformations[2], $LinkInformations[3]);
	
	/**
		Get Teamspeak connection
	*/
	$tsAdmin = getTsAdminInstance($LinkInformations[2]);

	/**
	 	Permissionscheck
	 */
	if(($user_right === false || $user_right['data']['perm_teamspeak_access_server'] != $mysql_keys['perm_teamspeak_access_server'])
		&& !checkClientHasInstance($_SESSION['user']['id'], $LinkInformations[2]) && !hasServerPerm($LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_* missing');
	};
	
	/** 
		Could not load all settings
	*/
	if(!$settings['success'] || !$info['success'] || !$tsAdmin['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Get Teamspeak option tree
	*/
	$tsAdmin['data']->selectServer($LinkInformations[3], 'port', true, 'MyName');
	$channels = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelList("-topic -flags -voice -limits -icon"));
	$sgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->serverGroupList());
	$cgroups = $tsAdmin['data']->getElement('data', $tsAdmin['data']->channelGroupList());
	
	$optionsTree = getChannelSelectTree($channels);
?>

<!-- Modal: Clientinfo -->
<div class="modal fade" id="modalInfo" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content modal-custom">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				&times;
			</button>
			<div class="modal-body form">
				<div class="header">
					<h1 class="modal-headline"></h1>
					<h2></h2>
				</div>
				<hr/>
				<table class="table">
					<thead>
						<tr>
							<th class="no-pic" data-display="table-cell"><?php echo $language['picture']; ?></th>
							<th class="w-60-percent"><?php echo $language['informations']; ?></th>
						</tr>
					</thead>
					<tbody class="sm-font">
						<tr class="no-pic" data-display="table-row">
							<td rowspan="7"><img class="client-image" src=""/></td>
						</tr>
						<tr>
							<td>
								<div class="d-flex justify-content-between">
									<span><?php echo $language['away']; ?>:</span>
									<i class="client_away"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="d-flex justify-content-between">
									<span><?php echo $language['away_since']; ?>:</span>
									<i class="client_idle_time"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="d-flex justify-content-between">
									<span><?php echo $language['client_commander']; ?>:</span>
									<i class="client_is_channel_commander"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="d-flex justify-content-between">
									<span><?php echo $language['record']; ?>:</span>
									<i class="client_is_recording"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="d-flex justify-content-between">
									<span><?php echo $language['mikrofon']; ?>:</span>
									<i class="client_input_muted"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="d-flex justify-content-between">
									<span><?php echo $language['headset']; ?>:</span>
									<i class="client_output_muted"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<div class="d-flex justify-content-between">
									<span><?php echo $language['ts3_teamspeak_plattform']; ?>:</span>
									<i class="client_platform"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<div class="d-flex justify-content-between">
									<span><?php echo $language['connections']; ?>:</span>
									<i class="client_totalconnections"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<div class="d-flex justify-content-between">
									<span><?php echo $language['version']; ?>:</span>
									<i class="client_version"></i>
								</div>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<div class="d-flex justify-content-between">
									<span><?php echo $language['description']; ?>:</span>
									<i class="client_description"></i>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Modal: Servergroups -->
<div class="modal fade" id="modalSgroups" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content modal-custom">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				&times;
			</button>
			<div class="modal-body form">
				<div class="header">
					<h1 class="modal-headline"><?php echo $language['sgroups']; ?></h1>
					<h2></h2>
				</div>
				<hr/>
				<table id="clientSgroup" data-card-view="false" data-classes="table-no-bordered table" data-striped="true" data-pagination="true">
					<thead>
						<tr>
							<th data-field="icon"><?php echo $language['icons']; ?></th>
							<th data-field="name"><?php echo $language['name']; ?></th>
							<th data-field="actions"></th>
							<th data-field="id" data-visible="false"></th>
						</tr>
					</thead>
					<tbody>
						<?php
							foreach($sgroups AS $key=>$sg_value) {
								if($sg_value['type'] != '2' && $sg_value['type'] != '0') {
									$btnClass = "btn-red";
									$iconClass = "ban";
									$textClass = $language['blocked'];
									$iconid = $sg_value['iconid'];
									$imgTag = "";
									
									if($iconid < 0) {
										$iconid = sprintf('%u', $iconid & 0xffffffff);
									};
									
									if($iconid != 0) {
										$icon_src = getTeamspeakBaumIcon($ts3_server[$LinkInformations[2]]['ip'], "icon_".$iconid, $LinkInformations[3]);
										$imgTag = ($icon_src != "") ? "<img class=\"ml-2 mr-2\" src=\"".$icon_src."\" width=\"16\" height=\"16\">" : "";
									};
									
									echo "<tr>
											<td class=\"text-center\">
												".$imgTag."
											</td>
											<td>
												".xssSafe($sg_value['name'])."
											</td>
											<td>
												<button id=\"" . $sg_value['sgid'] . "\" data-group=\"sgroup\" class=\"w-100-percent btn btn-sm ".$btnClass."\"></button>
											</td>
											<td></td>
										</tr>";
								};
							};
						?>
					</tbody>
				</table>
				<div class="header mt-3">
					<h1 class="modal-headline"><?php echo $language['cgroup']; ?></h1>
					<h2></h2>
				</div>
				<hr/>
				<table id="clientCgroup" data-card-view="false" data-classes="table-no-bordered table" data-striped="true" data-pagination="true">
					<thead>
						<tr>
							<th data-field="icon"><?php echo $language['icons']; ?></th>
							<th data-field="name"><?php echo $language['name']; ?></th>
							<th data-field="actions"></th>
							<th data-field="id" data-visible="false"></th>
						</tr>
					</thead>
					<tbody>
						<?php
							if(!empty($cgroups)) {
								foreach($cgroups AS $key=>$cg_value) {
									if ($cg_value['type'] != '2' && $cg_value['type'] != '0') {
										$btnClass = "btn-red";
										$iconClass = "ban";
										$textClass = $language['blocked'];
										$iconid = $cg_value['iconid'];
										$imgTag = "";
										
										if($iconid < 0) {
											$iconid = sprintf('%u', $iconid & 0xffffffff);
										};
										
										if($iconid != 0) {
											$icon_src = getTeamspeakBaumIcon($ts3_server[$LinkInformations[2]]['ip'], "icon_".$iconid, $LinkInformations[3]);
											$imgTag = ($icon_src != "") ? "<img class=\"ml-2 mr-2\" src=\"".$icon_src."\" width=\"16\" height=\"16\">" : "";
										};
										
										echo "<tr>
												<td class=\"text-center\">
													".$imgTag."
												</td>
												<td>
													".xssSafe($cg_value['name'])."
												</td>
												<td>
													<button id=\"" . $cg_value['cgid'] . "\" data-group=\"cgroup\" class=\"w-100-percent btn btn-sm ".$btnClass."\"></button>
												</td>
												<td></td>
											</tr>";
									};
								};
							};
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- Modal: Channel / Client actions -->
<div class="modal fade" id="modalActions" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content modal-custom">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				&times;
			</button>
			<div class="modal-body form">
				<div class="header">
					<h1 class="modal-headline"></h1>
					<h2></h2>
				</div>
				<hr/>
				<h2 class="headline"><?php echo $language['msg_poke']; ?></h2>
				<div class="row mr-2 ml-2 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['type']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select class="form-control msg" data-id="type">
								<option value="msg" selected><?php echo $language['message']; ?></option>
								<option value="poke"><?php echo $language['poke']; ?></option>
							</select>
						</div>
					</div>
				</div>
				<div class="row mr-2 ml-2 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['message']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input data-id="message" class="form-control form-control-sm msg" type="text" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
				</div>
				<button id="msg" type="button" class="btn btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
				<hr/>
				<h2 class="headline"><?php echo $language['move']; ?></h2>
				<div class="row mr-2 ml-2 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['where']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select data-id="inchannel" class="form-control move">
								<?php echo $optionsTree; ?>
							</select>
						</div>
					</div>
				</div>
				<button id="move" type="button" class="btn btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
				<hr/>
				<h2 class="headline"><?php echo $language['kick']; ?></h2>
				<div class="row mr-2 ml-2 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['where']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select class="form-control kick" data-id="type">
								<option value="server" selected><?php echo $language['serverkick']; ?></option>
								<option value="channel"><?php echo $language['channelkick']; ?></option>
							</select>
						</div>
					</div>
				</div>
				<div class="row mr-2 ml-2 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['reason']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input class="form-control form-control-sm kick" data-id="message" type="text" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
				</div>
				<button id="kick" type="button" class="btn btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
				<hr/>
				<h2 class="headline"><?php echo $language['ban']; ?></h2>
				<div class="row mr-2 ml-2 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['time_min']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input data-id="time" class="form-control form-control-sm ban" type="number" placeholder="<?php echo $language['unlimited']; ?>">
						</div>
					</div>
				</div>
				<div class="row mr-2 ml-2 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['reason']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input data-id="message" class="form-control form-control-sm ban" type="text" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
				</div>
				<button id="ban" type="button" class="btn btn-green w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
			</div>
		</div>
	</div>
</div>

<!-- Modal: Create channel -->
<div class="modal fade" id="modalChannelCreate" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg">
		<div class="modal-content modal-custom">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				&times;
			</button>
			<div class="modal-body pb-0 form">
				<div class="header">
					<h1><?php echo $language['create_channel']; ?></h1>
					<h2></h2>
				</div>
				<hr/>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_create_channel_in']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select id="cpid" class="form-control">
								<option value="0" selected><?php echo $language['at_the_end']; ?></option>
								<?php echo getChannelSelectTree($channels, false); ?>
							</select>
							<small class="form-text text-muted"><?php echo $language['ts3_create_channel_in_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['channel_name']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input id="channel_name" class="form-control form-control-sm" type="text" placeholder="My Channelname">
							<small class="form-text text-muted"><?php echo $language['channel_name_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['topic']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input id="channel_topic" class="form-control form-control-sm" type="text" placeholder="My Topic">
							<small class="form-text text-muted"><?php echo $language['topic_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_discreption']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input id="channel_description" class="form-control form-control-sm" type="text" placeholder="My Channel description">
							<small class="form-text text-muted"><?php echo $language['ts3_channel_discreption_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_codec']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select id="channel_codec" class="form-control">
								<option value="0">Speex Narrowband (8 kHz)</option>
								<option value="1">Speex Wideband (16 kHz)</option>
								<option value="2" selected>Speex Ultra-Wideband (32 kHz)</option>
								<option value="3">CELT Mono (48 kHz)</option>
								<option value="4">Opus Voice</option>
								<option value="5">Opus Musik</option>
							</select>
							<small class="form-text text-muted"><?php echo $language['ts3_channel_codec_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_codec_quality']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select id="channel_codec_quality" class="form-control">
								<option value="0" selected>0</option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
							</select>
							<small class="form-text text-muted"><?php echo $language['ts3_channel_codec_quality_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_max_clients']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input id="channel_maxclients" class="form-control form-control-sm" type="number" value="-1">
							<small class="form-text text-muted"><?php echo $language['ts3_channel_max_clients_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_clients_family']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input id="channel_maxfamilyclients" class="form-control form-control-sm" type="number" value="-1">
							<small class="form-text text-muted"><?php echo $language['ts3_channel_clients_family_in']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_type']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select id="channel_typ" class="form-control">
								<option value="1" selected><?php echo $language['permanent']; ?></option>
								<option value="2"><?php echo $language['semi_permanent']; ?></option>
								<option value="3"><?php echo $language['ts3_channel_default']; ?></option>
							</select>
							<small class="form-text text-muted"><?php echo $language['ts3_channel_type_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_clients_fam']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<select id="channel_flag_maxfamilyclients_inherited" class="form-control">
								<option value="0" selected>0</option>
								<option value="1">1</option>
							</select>
							<small class="form-text text-muted"><?php echo $language['ts3_channel_clients_fam_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_talk_power']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input id="channel_needed_talk_power" class="form-control form-control-sm" type="number" value="0">
							<small class="form-text text-muted"><?php echo $language['ts3_channel_talk_power_info']; ?></small>
						</div>
					</div>
				</div>
				<div class="row mr-0 ml-0 mt-1">
					<label class="col-12 form-label color-light pr-0 pl-0 pb-0 text-left"><?php echo $language['ts3_channel_phonetic_name']; ?>:</label>
					<div class="col-12">
						<div class="form-group">
							<input id="channel_name_phonetic" class="form-control form-control-sm" type="text">
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button onClick="createChannel();" type="button" class="btn btn-green"><i class="fas fa-plus mr-2"></i><?php echo $language['create_channel']; ?></button>
			</div>
		</div>
	</div>
</div>

<div class="content-header color-header"><?php echo $language['server_overview']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-7 border-right widget">
		<div id="newTree" class="tree">
			<div class="treeLoading">
				<div>
					<h3><?php echo $language['tree_loading']; ?></h3>
					<i class="fas fa-spinner fa-spin fa-2x"></i>
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-5 d-none d-md-block widget form">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fab fa-teamspeak mr-2"></i> <?php echo $language['informations']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row mb-3">
			<div class="col">
				<i class="fas fa-power-off w-20"></i> <?php echo $language['online_since']; ?>
			</div>
			<div class="col text-right">
				<span class="badge badge-text badge-<?php echo ($info['data']['virtualserver_status'] === 'online') ? 'success' : 'danger'; ?> servertimeup"><?php echo ($info['data']['virtualserver_status'] === 'online') ? convertSecondsToStrTime($info['data']['virtualserver_uptime']) : $language['offline']; ?></span>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col">
				<i class="fas fa-users w-20"></i> <?php echo $language['client']; ?>
			</div>
			<div class="col text-right">
				<span class="badge badge-text badge-primary serverclients"><?php echo ($info['data']['virtualserver_clientsonline'] - $info['data']['virtualserver_queryclientsonline']).' / '.$info['data']['virtualserver_maxclients'].' ('.round(($info['data']['virtualserver_clientsonline'] - $info['data']['virtualserver_queryclientsonline'])/$info['data']['virtualserver_maxclients'], 2).'%)'; ?>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col">
				<i class="fas fa-code-branch w-20"></i> <?php echo $language['version']; ?>
			</div>
			<div class="col text-right">
				<span class="badge badge-text badge-primary"><?php echo preg_replace("/\[.*/", "", $info['data']['virtualserver_version']).'@ '.$info['data']['virtualserver_platform']; ?></span>
			</div>
		</div>
		<div class="row mb-3">
			<div class="col">
				<i class="fas fa-key w-20"></i> <?php echo $language['password']; ?>
			</div>
			<div class="col text-right">
				<span class="badge badge-text badge-primary serverpassword"><?php echo (empty($info['virtualserver_password'])) ? $language['no'] : $language['yes']; ?></span>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<i class="fas fa-bolt w-20"></i> <?php echo $language['packagelost']; ?>
			</div>
			<div class="col text-right">
				<span class="badge badge-text badge-primary"><?php echo round($info['data']['virtualserver_total_packetloss_total'], 2).' %'; ?></span>
			</div>
		</div>
		<?php if(!empty($info['data']['virtualserver_hostbanner_gfx_url'])) { ?>
			<hr class="hr-headline mt-3"/>
			<?php if(!empty($info['data']['virtualserver_hostbanner_url'])) { ?>
				<a href="<?php echo $info['data']['virtualserver_hostbanner_url']; ?>">
					<img class="w-100-percent" src="<?php echo $info['data']['virtualserver_hostbanner_gfx_url']; ?>" />
				</a>
			<?php } else { ?>
				<img class="w-100-percent" src="<?php echo $info['data']['virtualserver_hostbanner_gfx_url']; ?>" />
			<?php }; ?>
		<?php }; ?>
		<hr class="hr-headline mt-3"/>
		<a href="ts3server://<?php echo $ts3_server[xssSafe($LinkInformations[2])]['ip']; ?>?port=<?php xssEcho($LinkInformations[3]); ?>"><button class="btn btn-success w-100-percent"><i class="fas fa-sign-in-alt mr-2"></i><?php echo $language['connect']; ?></button></a>
		<?php if(checkServerPerm(array("perm_ts_server_create_channel"), $LinkInformations[2], $LinkInformations[3])) { ?>
			<button id="modalCreateChannel" type="button" class="btn w-100-percent"><i class="fas fa-plus mr-2"></i><?php echo $language['create_channel']; ?></button>
		<?php }; ?>

		<?php if(checkServerPerm(array("perm_ts_server_message_poke"), $LinkInformations[2], $LinkInformations[3])) { ?>
			<div class="header news-header mt-3">
				<h4 class="title color-header"><i class="fas fa-font mr-2"></i> <?php echo $language['server_message']; ?></h4>
			</div>
			<hr class="hr-headline mb-3"/>
			<div class="row mr-0 ml-0 mt-1">
				<label class="col-lg-2 form-label color-light"><?php echo $language['message']; ?>:</label>
				<div class="col-lg-10">
					<div class="form-group">
						<input id="poke-msg" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['message']; ?>">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col">
					<div class="btn-group w-100-percent">
						<button class="btn btn-success w-100-percent" id="server-message"><i class="fas fa-font mr-2"></i><?php echo $language['message']; ?></button>
						<button class="btn btn-success w-100-percent" id="server-poke"><i class="far fa-hand-point-up mr-2"></i><?php echo $language['poke']; ?></button>
					</div>
				</div>
			</div>
		<?php }; ?>

		<?php if(checkServerPerm(array("perm_ts_server_mass_actions"), $LinkInformations[2], $LinkInformations[3])) { ?>
			<div class="header news-header mt-3">
				<h4 class="title color-header"><i class="fas fa-users mr-2"></i> <?php echo $language['mass_actions']; ?></h4>
			</div>
			<hr class="hr-headline mb-3"/>
			<div class="row mr-0 ml-0 mt-1">
				<div class="w-100-percent dropbox"></div>
			</div>
			<div class="row mr-0 ml-0 mt-1">
				<label class="col-lg-2 form-label color-light"><?php echo $language['actions']; ?>:</label>
				<div class="col-lg-10">
					<select id="actions-type" class="form-control form-control-sm" disabled>
						<option value="none"><?php echo $language['none']; ?></option>
						<option value="msg"><?php echo $language['message']; ?></option>
						<option value="move"><?php echo $language['move']; ?></option>
						<option value="kick"><?php echo $language['kick']; ?></option>
						<option value="ban"><?php echo $language['ban']; ?></option>
					</select>
				</div>
			</div>
			<div id="actions-box-1" class="row mr-0 ml-0 mt-1 d-none actions">
				<label class="col-lg-2 form-label color-light"></label>
				<div class="col-lg-10">
					<select class="form-control form-control-sm"></select>
				</div>
			</div>
			<div id="actions-box-2" class="row mr-0 ml-0 mt-1 d-none actions">
				<label class="col-lg-2 form-label color-light"></label>
				<div class="col-lg-10">
					<div class="form-group">
						<input class="form-control form-control-sm" type="text">
					</div>
				</div>
			</div>
			<div id="actions-box-3" class="row mr-0 ml-0 mt-1 d-none actions">
				<label class="col-lg-2 form-label color-light"></label>
				<div class="col-lg-10">
					<div class="form-group">
						<input class="form-control form-control-sm" type="text">
					</div>
				</div>
			</div>
			<div id="actions-button" class="row d-none actions mt-2">
				<div class="col">
					<button class="btn btn-success w-100-percent"><i class="fas fa-paper-plane mr-2"></i><?php echo $language['senden']; ?></button>
				</div>
			</div>
		<?php }; ?>
	</div>
</div>
<div class="row shadow-default-content mb-3">
	<div class="col widget">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fab fa-teamspeak mr-2"></i> <?php echo $language['teamspeak_tree']; ?> Iframe</h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="form-group">
			<?php
				if(isSet($_SERVER['HTTP_REFERER'])) {
					$iframeLink = str_replace("index", "iframeServerView", explode("?", $_SERVER['HTTP_REFERER'])[0]);
				} else {
					$linkPrefix = ($_SERVER['HTTPS'] == "on") ? "https://" : "http://";
					$linkPath = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
					$iframeLink = $linkPrefix.str_replace("index", "iframeServerView", $linkPath);
				};
				$iframeText = "&#60;iframe allowtransparency=\"true\" src=\"".$iframeLink."?port=".$info['data']['virtualserver_port']."&instanz=".xssSafe($LinkInformations[2])."&color=666&bodybgcolor=fff&spinbgcolor=fff&fontsize=1em\" style=\"height:100%;width:100%\" scrolling=\"auto\" frameborder=\"0\"&#62;Your Browser will not show Iframes&#60;/iframe&#62;";
			?>
			<div class="row mb-3">
				<div class="col-xs-12 col-sm-6">
					<div class="form-group mb-2">
						<label><?php echo $language['text_color']; ?></label>
						<input onkeyup="onChangeTreamspeakTreeIframe('2', 'iframeTreeTextColor');" id="iframeTreeTextColor" type="text" class="form-control" value="666">
						<span class="bmd-help"><?php echo $language['text_color_info']; ?></span>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6">
					<div class="form-group mb-2">
						<label><?php echo $language['text_size']; ?></label>
						<input onkeyup="onChangeTreamspeakTreeIframe('5', 'iframeTreeTextSize');" id="iframeTreeTextSize" type="text" class="form-control" value="1em">
						<span class="bmd-help"><?php echo $language['text_size_info']; ?></span>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6">
					<div class="form-group mb-2">
						<label><?php echo $language['bg_color']; ?></label>
						<input onkeyup="onChangeTreamspeakTreeIframe('3', 'iframeTreeBgColor');" id="iframeTreeBgColor" type="text" class="form-control" value="fff">
						<span class="bmd-help"><?php echo $language['bg_color_info']; ?></span>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6">
					<div class="form-group mb-2">
						<label><?php echo $language['bg_spin_color']; ?></label>
						<input onkeyup="onChangeTreamspeakTreeIframe('4', 'iframeTreeSpinColor');" id="iframeTreeSpinColor" type="text" class="form-control" value="fff">
						<span class="bmd-help"><?php echo $language['bg_spin_color_info']; ?></span>
					</div>
				</div>
			</div>
			<pre id="iframeText" onClick="SelectText('iframeText');"><code id="iframeTextCode"><?php echo $iframeText; ?></code></pre>
			<div class="widget-item w-100-percent">
				<div class="btn-group">
					<button class="btn btn-green" onClick="window.open().document.write($('#iframeText').text());"><i class="fas fa-link mr-2"></i><?php echo $language['example']; ?></button>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/teamspeak.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	var sid = <?php echo $info['data']['virtualserver_id']; ?>;
	var treeInterval = <?php echo ($settings['data']['ts_tree_intervall'] / 1000); ?>;
	var emptyList = lang.no_entrys;
	var permChannelCreate = stringToBool('<?php echo (checkServerPerm(array("perm_ts_server_create_channel"), $LinkInformations[2], $LinkInformations[3])) ? 'true' : 'false'; ?>');
	var permDeleteChannel = stringToBool('<?php echo (checkServerPerm(array("perm_ts_server_delete_channel"), $LinkInformations[2], $LinkInformations[3])) ? 'true' : 'false'; ?>');
	var permMassActions = stringToBool('<?php echo (checkServerPerm(array("perm_ts_server_mass_actions"), $LinkInformations[2], $LinkInformations[3])) ? 'true' : 'false'; ?>');

	/**
		Clientview tables
	*/
	$('#clientSgroup').bootstrapTable({
		formatNoMatches: function () {
			return emptyList;
		}
	});
	
	$('#clientCgroup').bootstrapTable({
		formatNoMatches: function () {
			return emptyList;
		}
	});
	
	/**
		Server message / poke
	*/
	$('#server-message, #server-poke').click(function() {
		var msg = $('#poke-msg').val();
		
		if(msg == '') {
			return;
		};
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'serverMessage',
				instance: instance,
				sid: sid,
				port: port,
				poke: ($(this).attr('id') == 'server-poke') ? true : false,
				message: encodeURIComponent(msg)
			},
			success: function(data) {
				var json = JSON.parse(data);
				
				if(json.success) {
					new Notification({
						message : lang.servermessage_done,
						icon: 'far fa-hand-point-up',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : json.error,
						icon: 'far fa-hand-point-up',
						type : 'danger'
					}).show();
				};
			}
		});
	});
	
	/**
		Modal configuration
	*/
	var textBlocked = '<i class="fas fa-ban mr-2"></i><span>'+lang.blocked+'</span>';
	var textUnblocked = '<i class="fas fa-check mr-2"></i><span>'+lang.unblocked+'</span>';

	var myclient = null;

	var sgroups = [];
	var cgroup = null;

	$('#modalInfo').on('show.bs.modal', function (event) {
		console.log(myclient);

		var active = $('.treeContent > .active .nick_cid').text();
		var headline = $('#modalInfo .modal-body > .header > h1');
		
		headline.attr("data-cid", active);
		headline.attr("data-cldbid", $('.treeContent > .active').attr("cldbid"));

		$('#modalInfo .modal-body > .header > h1').text($('.treeContent > .active > .treeTable p').text());
		$('#modalInfo .modal-body > .header > h2').text($('.treeContent > div[cid="'+active+'"] > .treeTable > p').text());

		if(myclient.client_avatar !== false) {
			$('#modalInfo .modal-body img.client-image').attr("src", "data:image/png;base64,"+myclient.client_avatar);
			$('#modalInfo .modal-body .no-pic').each(function() {
				var el = $(this);
				var display = el.attr("data-display");
				el.css("display", display);
			});
		} else {
			$('#modalInfo .modal-body .no-pic').css("display", "none");
		};

		var time = convertSecondsToArrayTime(myclient.client_idle_time);
		console.log(time);
		$('#modalInfo .modal-body .client_away').text((myclient.client_away === "0") ? lang.no : lang.yes);
		$('#modalInfo .modal-body .client_idle_time').text(time.hours+"h "+time.minutes+"m "+time.seconds);
		$('#modalInfo .modal-body .client_is_channel_commander').text((myclient.client_is_channel_commander === "0") ? lang.no : lang.yes);
		$('#modalInfo .modal-body .client_is_recording').text((myclient.client_is_recording === "0") ? lang.no : lang.yes);
		$('#modalInfo .modal-body .client_input_muted').text((myclient.client_input_muted === "0") ? lang.on : lang.off);
		$('#modalInfo .modal-body .client_output_muted').text((myclient.client_output_muted === "0") ? lang.on : lang.off);
		$('#modalInfo .modal-body .client_platform').text(myclient.client_platform);
		$('#modalInfo .modal-body .client_totalconnections').text(myclient.client_totalconnections);
		$('#modalInfo .modal-body .client_version').text(myclient.client_version.split('[')[0]);
		$('#modalInfo .modal-body .client_description').text(myclient.client_description);
		
		
	});
	
	$('#modalSgroups').on('show.bs.modal', function (event) {
		var active = $('.treeContent > .active .nick_cid').text();
		var headline = $('#modalSgroups .modal-body > .header > h1');
		
		headline.attr("data-cid", active);
		headline.attr("data-cldbid", $('.treeContent > .active').attr("cldbid"));

		$('#modalSgroups .modal-body > .header > h2').text($('.treeContent > .active > .treeTable p').text());
		$('#modalSgroups .modal-body > .header > h2').attr("data-cid", );
		$('#modalSgroups .modal-body table#clientSgroup button').each(function() {
			$(this).removeClass('btn-green').addClass('btn-red').html(textBlocked);
			for(var group of sgroups) {
				$(`#modalSgroups .modal-body table button#${group}[data-group="sgroup"]`).removeClass('btn-red').addClass('btn-green').html(textUnblocked);
			};
		});
		$('#modalSgroups .modal-body table#clientCgroup button').each(function() {
			$(this).removeClass('btn-green').addClass('btn-red').html(textBlocked);
			if($(this).attr("id") === cgroup) {
				$(`#modalSgroups .modal-body table button#${cgroup}[data-group="cgroup"]`).removeClass('btn-red').addClass('btn-green').html(textUnblocked);
			};
		});
	});

	$('#modalSgroups').on('page-change.bs.table', function () {
		$('#modalSgroups .modal-body table#clientSgroup button').each(function() {
			$(this).removeClass('btn-green').addClass('btn-red').html(textBlocked);
			for(var group of sgroups) {
				$(`#modalSgroups .modal-body table button#${group}[data-group="sgroup"]`).removeClass('btn-red').addClass('btn-green').html(textUnblocked);
			};
		});
		$('#modalSgroups .modal-body table#clientCgroup button').each(function() {
			$(this).removeClass('btn-green').addClass('btn-red').html(textBlocked);
			if($(this).attr("id") === cgroup) {
				$(`#modalSgroups .modal-body table button#${cgroup}[data-group="cgroup"]`).removeClass('btn-red').addClass('btn-green').html(textUnblocked);
			};
		});
	});

	$('#modalSgroups .modal-body table').on("click", "button", function() {
		var el = $(this);
		var headline = $('#modalSgroups .modal-body > .header > h1');
		var type = (el.closest("table").attr("id") === "clientSgroup") ? "sgroup" : "cgroup";
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'setGroupMember',
				instance: instance,
				port: port,
				type: type,
				gid: $(this).attr("id"),
				cldbid: headline.attr("data-cldbid"),
				cid: headline.attr("data-cid"),
				value: $(this).hasClass("btn-red")
			},
			success: function(data) {
				var json = JSON.parse(data);
				
				if(json.success) {
					if(type === "sgroup") {
						if(el.hasClass("btn-red")) {
							el.removeClass("btn-red").addClass("btn-green").html(textUnblocked);
						} else {
							el.removeClass("btn-green").addClass("btn-red").html(textBlocked);
						};
					} else {
						$('#modalSgroups .modal-body table#clientCgroup button').removeClass("btn-green").addClass("btn-red").html(textBlocked);
						$('#modalSgroups .modal-body table#clientCgroup button[id="'+el.attr("id")+'"]').removeClass("btn-red").addClass("btn-green").html(textUnblocked);
					};

					new Notification({
						message : lang.user_action_successfull,
						icon: 'far fa-user',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : json.errors,
						icon: 'far fa-user',
						type : 'danger'
					}).show();
				};
			}
		});
	});
	
	$('#modalActions .modal-body').on("click", "button", function(e) {
		var body = $('#modalActions .modal-body');
		var headline = $('#modalActions .modal-body .modal-headline');
		var isChannel = headline.attr("cid") !== undefined;
		var id = (isChannel) ? headline.attr("cid") : headline.attr("clid");
		var data = {
			action: $(this).attr("id")
		};
		var clients = (isChannel) ? [] : [ id ];

		switch($(this).attr("id")) {
			case "msg":
				if((data.message = $('.msg[data-id="message"]', body).val()) == '') {
					return;
				};
				data.type = $('.msg[data-id="type"]', body).val();
				break;
			case "move":
				data.channel = $('.move[data-id="inchannel"]', body).val();
				break;
			case "kick":
				data.type = $('.kick[data-id="type"]', body).val();
				data.message = $('.kick[data-id="message"]', body).val();
				break;
			case "ban":
				if((data.time = $('.ban[data-id="time"]', body).val()) == '') {
					data.time = 0;
				};
				data.message = $('.ban[data-id="message"]', body).val();
				break;
			default:
				console.error(`Undefined ID in modal actions ${$(this).attr("id")}`);
				break;
		};

		if(isChannel) {
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'getMassActionMember',
					port: port,
					instance: instance,
					option: 'get',
					data: JSON.stringify({
						channel: id,
						group: "all"
					})
				},
				async: false,
				success: function(ret){
					var info = JSON.parse(ret);
					
					if(info.success) {
						for(var client of info.data) {
							clients.push(client.clid);
						};
					} else {
						new Notification({
							message : info.errors.join(),
							icon: 'fas fa-user',
							type : 'danger'
						}).show();
					};
				}
			});
		};

		for(var client of clients) {
			data.clid = client;
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'setClient',
					instance: instance,
					port: port,
					data: JSON.stringify(data)
				},
				success: function(ret){
					var info = JSON.parse(ret);
					if(info.success) {
						new Notification({
							message : lang.user_action_successfull,
							icon: 'fas fa-user',
							type : 'success'
						}).show();
					} else {
						new Notification({
							message : info.errors.join(),
							icon: 'fas fa-user',
							type : 'danger'
						}).show();
					};
				}
			});
		};
	});
	
	$('#modalActions').on('show.bs.modal', function (event) {
		$('#modalActions .modal-body > .header > h2').text($('.treeContent > .active > .treeTable p').text());
		
		var active = $('.treeContent > .active');
		var headline = $('#modalActions .modal-body > .header > h1');
		if(active.hasClass('treeClient')) {
			headline.html(lang.client_actions);
			headline.attr('clid', active.attr('clid'));
			headline.removeAttr('cid');
		} else {
			headline.html(lang.channel_actions);
			headline.attr('cid', active.attr('cid'));
			headline.removeAttr('clid');
		};
	});
	
	$('#modalCreateChannel').click(function() {
		var modal = $('#modalChannelCreate');
		modal.find('.modal-footer > button').removeAttr('cpid');
		$('#modalChannelCreate').modal('show');
	});
	
	$('#modalChannelCreate').on('show.bs.modal', function (event) {
		var modal = $('#modalChannelCreate');
		var attr = modal.find('.modal-footer > button').attr('cpid');
		
		if (typeof attr !== typeof undefined && attr !== false) {
			$('#cpid').closest('div.row').addClass('d-none');
			$('#modalChannelCreate .modal-body > .header > h2').text($('.treeContent > .active > .treeTable p').text());
		} else {
			$('#cpid').closest('div.row').removeClass('d-none');
			$('#modalChannelCreate .modal-body > .header > h2').text($('.treeHeader > p').text());
		};
	});
	
	/**
		Teamspeak tree
	*/
	var channelInfo = '';

	if(permChannelCreate) {
		channelInfo += '<div class="col">';
		channelInfo += '<button class="btn btn-sm btn-green w-100-percent" data-action="create"><i class="fas fa-plus mr-2"></i>'+lang.create_channel+'</button>';
		channelInfo += '</div>';
	};
	
	if(permDeleteChannel) {
		channelInfo += '<div class="col">';
		channelInfo += '<button class="btn btn-sm btn-red w-100-percent" data-action="delete"><i class="fas fa-trash-alt mr-2"></i>'+lang.delete+'</button>';
		channelInfo += '</div>';
	};
	
	if(permMassActions) {
		channelInfo += '<div class="col">';
		channelInfo += '<button class="btn btn-sm btn-blue w-100-percent" data-action="actions-channel"><i class="fas fa-users mr-2"></i>'+lang.actions+'</button>';
		channelInfo += '</div>';
	};
	
	var clientInfo = '<div class="col-md-6 col-sm-12">';
	clientInfo += '<button class="btn btn-sm btn-red w-100-percent" data-action="kick"><i class="fas fa-user-times mr-2"></i>'+lang.serverkick+'</button>';
	clientInfo += '</div>';
		
	clientInfo += '<div class="col-md-6 col-sm-12">';
	clientInfo += '<button class="btn btn-sm btn-blue w-100-percent" data-action="actions-client"><i class="fas fa-user mr-2"></i>'+lang.actions+'</button>';
	clientInfo += '</div>';

	clientInfo += '<div class="col-md-6 col-sm-12">';
	clientInfo += '<button class="btn btn-sm btn-green w-100-percent" data-action="sgroups"><i class="fas fa-key mr-2"></i>'+lang.sgroups+'</button>';
	clientInfo += '</div>';

	clientInfo += '<div class="col-md-6 col-sm-12">';
	clientInfo += '<button class="btn btn-sm btn-blue w-100-percent" data-action="info"><i class="fas fa-info mr-2"></i>'+lang.informations+'</button>';
	clientInfo += '</div>';
	
	new TeamspeakTree({
		id: 'newTree',
		instance: instance,
		port: port,
		interval: treeInterval,
		draggable: true,
		dropbox: '.dropbox',
		channelInfoAfterContent: channelInfo,
		clientInfoAfterContent: clientInfo,
		onDrop: function() {
			$('select#actions-type').prop('disabled', false);
		},
		onRemoveAll: function() {
			$('select#actions-type').prop('disabled', true);
			$('select#actions-type').prop('selectedIndex',0);
			$('.actions').addClass('d-none');
		}
	});
	
	$('#newTree').on('click', '.treeContent button', function() {
		var el = $(this);
		
		switch(el.attr('data-action')) {
			case 'sgroups':
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'getClient',
						port: port,
						instance: instance,
						clid: $('.treeContent > .treeClient.active').attr('clid')
					},
					success: function(ret){
						var info = JSON.parse(ret);
						if(info.success) {
							sgroups = info.data.client_servergroups.split(",");
							cgroup = info.data.client_channel_group_id;
							
							$('#modalSgroups').modal('show');
						} else {
							new Notification({
								message : info.errors.join(),
								icon: 'fas fa-user',
								type : 'danger'
							}).show();
						};
					}
				});
				break;
			case 'info':
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'getClient',
						port: port,
						instance: instance,
						clid: $('.treeContent > .treeClient.active').attr('clid')
					},
					success: function(ret){
						var info = JSON.parse(ret);
						if(info.success) {
							myclient = info.data;
							$('#modalInfo').modal('show');
						} else {
							new Notification({
								message : info.errors.join(),
								icon: 'fas fa-user',
								type : 'danger'
							}).show();
						};
					}
				});
				break;
			case 'actions-channel':
				$('#modalActions').modal('show');
				break;
			case 'actions-client':
				$('#modalActions').modal('show');
				break;
			case 'delete':
				new AreUSure({
					label: lang.delete_channel.replace("&ouml;", "\u00f6"),
					onConfirm: function() {
						var channel = el.closest('div.active');
						$.ajax({
							type: "POST",
							url: "./php/functions/functionsTeamspeakPost.php",
							data: {
								action: 'deleteChannel',
								instance: instance,
								sid: sid,
								cid: channel.attr('cid')
							},
							success: function(data){
								var info = JSON.parse(data);
								
								if(info.success) {
									channel.remove();
									swal(lang.succeeded, lang.channel_deleted.replace("&ouml;", "\u00f6"), 'success');
								} else {
									swal(lang.aborted, info.errors.join(), 'error');
								};
							}
						});
					}
				});
				break;
			case 'create':
				var modal = $('#modalChannelCreate');
				modal.find('.modal-footer > button').attr('cpid', el.closest('div.active').attr('cid'));
				
				$('#modalChannelCreate').modal('show');
				break;
			case 'kick':
				new AreUSure({
					label: lang.kick_client,
					onConfirm: function() {
						var client = el.closest('.treeClient');
						var clid = client.attr('clid');
						var data = {
							action: 'kick',
							clid: clid,
							type: 'server',
							message: ''
						};
						
						$.ajax({
							type: "POST",
							url: "./php/functions/functionsTeamspeakPost.php",
							data: {
								action: 'setClient',
								instance: instance,
								port: port,
								data: JSON.stringify(data)
							},
							success: function(data){
								var info = JSON.parse(data);
								
								if(info.success) {
									client.remove();
									swal(lang.succeeded, lang.kick_client_success, 'success');
								} else {
									swal(lang.aborted, info.errors.join(), 'error');
								};
							}
						});
					}
				});
				break;
		};
	});
	
	/**
		Teamspeak massactions
	*/
	$('#actions-type').on('change', function() {
		var el = $(this);
		var box1 = $('#actions-box-1');
		var box2 = $('#actions-box-2');
		var box3 = $('#actions-box-3');
		
		$('input', box2).val('');
		$('input', box3).val('');
		
		switch(el.val()) {
			case 'none':
				$('.actions').addClass('d-none');
				break;
			case 'msg':
				$('label', box1).text(lang.type+':');
				$('select', box1).html('<option value="msg">'+lang.message+'</option><option value="poke">'+lang.poke+'</option>');
				box1.removeClass('d-none');
				
				$('label', box2).text(lang.message+':');
				$('input', box2).attr('placeholder', lang.message);
				$('input', box2).attr('type', 'text');
				box2.removeClass('d-none');
				box3.addClass('d-none');
				break;
			case 'move':
				$('label', box1).text(lang.where+':');
				$('select', box1).html('<?php echo str_replace("'", "\'", $optionsTree); ?>');
				box1.removeClass('d-none');
				box2.addClass('d-none');
				box3.addClass('d-none');
				break;
			case 'kick':
				$('label', box1).text(lang.type+':');
				$('select', box1).html('<option value="server">'+lang.serverkick+'</option><option value="channel">'+lang.channelkick+'</option>');
				box1.removeClass('d-none');
				
				$('label', box2).text(lang.reason+':');
				$('input', box2).attr('placeholder', lang.reason);
				$('input', box2).attr('type', 'text');
				box2.removeClass('d-none');
				box3.addClass('d-none');
				break;
			case 'ban':
				box1.addClass('d-none');
				
				$('label', box2).text(lang.duration+':');
				$('input', box2).attr('placeholder', lang.time_min);
				$('input', box2).attr('type', 'number');
				box2.removeClass('d-none');
				
				$('label', box3).text(lang.reason+':');
				$('input', box3).attr('placeholder', lang.reason);
				box3.removeClass('d-none');
				break;
		};
		
		if(el.val() !== '0') {
			$('#actions-button').removeClass('d-none');
		};
	});
	
	$('#actions-button button').click(function() {
		var action = $('#actions-type').val();
		
		if(action === 'none') {
			return;
		};
		
		$('.dropbox > div').each(function() {
			var clid = $(this).attr('clid');
			var data = {
				action: action,
				clid: clid
			};
			
			switch(action) {
				case 'msg':
					if(data.message = $('#actions-box-2 input').val() == '') {
						return;
					};
					data.type = $('#actions-box-1 select').val();
					data.message = $('#actions-box-2 input').val();
					break;
				case 'move':
					data.channel = $('#actions-box-1 select').val();
					break;
				case 'kick':
					data.type = $('#actions-box-1 select').val();
					data.message = $('#actions-box-2 input').val();
					break;
				case 'ban':
					if(data.time = $('#actions-box-2 input').val() == '') {
						return;
					};
					data.time = $('#actions-box-2 input').val();
					data.message = $('#actions-box-3 input').val();
					break;
				default:
					return;
					break;
			};
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsTeamspeakPost.php",
				data: {
					action: 'setClient',
					instance: instance,
					port: port,
					data: JSON.stringify(data)
				},
				success: function(ret){
					var info = JSON.parse(ret);
					if(info.success) {
						$('.dropbox-table[clid="'+clid+'"]').remove();
					} else {
						new Notification({
							message : info.errors.join(),
							icon: 'fas fa-user',
							type : 'danger'
						}).show();
					};
				}
			});
		});
	});
	
	/**
		Teamspeak Iframes
	*/
	function onChangeTreamspeakTreeIframe(index, id) {
		var iFrameSplit = $('#iframeText').text().split('"'),
			iFrameElement = iFrameSplit[3],
			iFrameElements = iFrameElement.split('&'),
			newElement = "",
			newCode = "";
		
		for(var element in iFrameElements) {
			if(element == index) {
				newElement += iFrameElements[index].split('=')[0] + "=" + $("#"+id).val();
				if(element != 5) {
					newElement += "&";
				};
			} else {
				newElement += iFrameElements[element] + "&";
			};
		};
		
		for(var element in iFrameSplit) {
			if(element == 3) {
				newCode += newElement + '"';
			} else {
				newCode += iFrameSplit[element] + '"';
			};
		};
		$('#iframeTextCode').text(newCode);
	};
	
	/**
		Validation
	*/
	validateOnChange('#channel_name', {
		required: true,
	}, '', lang.field_cant_be_empty);
</script>