 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');

	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_icons"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_icons missing');
	};

	/**
		Get server informations
	*/
	$info = getServerInfo($LinkInformations[2], $LinkInformations[3]);
	
	/** 
		Could not load all settings
	*/
	if(!$info['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Load the icons
	*/
	$allicons = [];
	$handler = @opendir(__dir__.'/../../images/ts_icons/'.$ts3_server[$LinkInformations[2]]['ip'].'-'.$info['data']['virtualserver_port'].'/');
	if($handler) {
		while($file = readdir($handler)) {
			if($file!='.' && $file!='..') {
				$icon_id = str_replace("icon_", "", $file);
				$allicons[$file]['name'] = $icon_id;
				$allicons[$file]['id'] = sprintf('%u', $icon_id & 0xffffffff);
				$allicons[$file]['info'] = getimagesize(__dir__.'/../../images/ts_icons/'.$ts3_server[$LinkInformations[2]]['ip'].'-'.$info['data']['virtualserver_port'].'/'.$file);
			};
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
?>

<div class="content-header color-header"><?php echo $language['server_icons']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-7 border-right widget table-search-100 in-sm bottom">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-list-ul mr-2"></i> <?php echo $language['icon_avalible']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<table id="fileTable" data-card-view="false" data-classes="table-no-bordered table-hover table"
			data-striped="true" data-pagination="true" data-search="true" data-click-to-select="true">
			<thead>
				<tr>
					<th data-field="picture" data-align="center"><?php echo $language['picture']; ?></th>
					<th data-field="id" data-align="center" data-halign="left"><?php echo $language['icon_id']; ?></th>
					<th data-field="actions" data-align="center" data-halign="left"><?php echo $language['actions']; ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if(!empty($allicons)) {
					foreach($allicons AS $value) {
						$filename = __dir__.'/../../images/ts_icons/'.$ts3_server[$LinkInformations[2]]['ip'].'-'.$info['data']['virtualserver_port'].'/icon_'.$value['name'];
						$imgbinary = fread(fopen($filename, "r"), filesize($filename));
						echo '<tr>
								<td><img src="data:image/png;base64,'.base64_encode($imgbinary).'" width="16" height="16" alt="Icon Image"></td>
								<td>'.$value['name'].'</td>
								<td>
									<a href="./php/functions/functionsDownload.php?action=downloadIconFromIconlist&port='.$info['data']['virtualserver_port'].'&instance='.$LinkInformations[2].'&filename='.$value['name'].'">
										<button class="btn btn-green btn-flat btn-sm mr-2"><i class="fa fa-download"></i> <font class="hidden-md-down">'.$language['download'].'</font>
									</a>
									<button class="btn btn-red btn-flat btn-sm" onClick="deleteIcon(\''.$value['name'].'\')"><i class="fa fa-trash"></i> <font class="hidden-md-down">'.$language['delete'].'</font>
								</td>
							</tr>';
					};
				}; ?>
			</tbody>
		</table>
	</div>
	<div class="col-md-5 widget in-sm top">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-upload mr-2"></i> <?php echo $language['icon_upload']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row">
			<div class="col">
				<form class="dropzone" drop-zone="" id="file-dropzone"></form>
			</div>
		</div>
	</div>
</div>

<script src="js/other/dropzone.js"></script>
<script src="js/bootstrap/bootstrap-table.js"></script>
<script src="js/webinterface/teamspeak.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	
	/**
		Initial Bootstrap table
	*/
	$('#fileTable').bootstrapTable({
		formatNoMatches: function () {
			return lang.filelist_none;
		}
	});
	
	/**
		Dropzone init
	*/
	Dropzone.autoDiscover = false;
	$('#file-dropzone').dropzone({
		url: "./php/functions/functionsUploadIcon.php",
		method: "POST",
		acceptedFiles: 'image/*',
		destination: "/images/ts_icons",
		dictDefaultMessage: lang.icon_upload_info,
		init: function() {
			this.on('thumbnail', function(file) {
				if ( file.width > 16 || file.height > 16 ) {
					file.rejectDimensions();
				} else {
					file.acceptDimensions();
				};
			});
		},
		accept: function(file, done) {
			file.acceptDimensions = done;
			file.rejectDimensions = function() {
				done(lang.icon_upload_size)
			};
		}
	});
</script>