 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	
	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_protocol"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_protocol missing');
	};
?>

<div class="content-header color-header"><?php echo $language['server_protokoll']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col widget table-search-100">
		<table id="table-protocol" data-ajax="ajaxRequest" data-striped="true" data-pagination="true" data-search="true" data-classes="table-no-bordered table-hover table">
			<thead>
				<tr>
					<th data-field="date"><?php echo $language['date']; ?></th>
					<th data-field="level"><?php echo $language['level']; ?></th>
					<th data-field="type" class="d-none d-lg-block"><?php echo $language['type']; ?></th>
					<th data-field="message"><?php echo $language['message']; ?></th>
				</tr>
			</thead>
		</table>
	</div>
</div>

<script src="js/bootstrap/bootstrap-table.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	
	/**
		Table
	*/
    $('#table-protocol').bootstrapTable({
		formatNoMatches: function () {
			return lang.no_entrys;
		}
	});
	
	function ajaxRequest(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getQueryLog',
				port: port,
				instance: instance
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					for(var entry of info.data) {
						var split = entry.l.split('|');
						data.push({
							'date': split[0].split('.')[0].trim(),
							'level': split[1].trim(),
							'type': split[2].trim(),
							'message': escapeHtml(split[4].trim())
						});
					};
					params.success({
						total: 100,
						rows: data
					});
				} else {
					console.error(data.errors);
				};
			}
		});
	};
</script>