 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	
	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_bans"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_bans missing');
	};
?>

<div class="content-header color-header"><?php echo $language['server_bans']; ?></div>

<div class="row shadow-default-content mb-3">
	<div class="col-md-7 border-right widget table-search-100 in-sm bottom">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-list-ul mr-2"></i> <?php echo $language['bans_list']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<table id="banTable" data-ajax="ajaxRequest" data-card-view="true" data-classes="table-no-bordered table-hover table" data-striped="true" data-pagination="true" data-search="true">
			<thead>
				<tr>
					<th data-field="name"><?php echo $language['name']; ?></th>
					<th data-field="id"><?php echo $language['ban_id']; ?></th>
					<th data-field="ip"><?php echo $language['ip_adress']; ?></th>
					<th data-field="uniquie_id"><?php echo $language['uniquie_id']; ?></th>
					<th data-field="admin"><?php echo $language['banlist_admin']; ?></th>
					<th data-field="reason"><?php echo $language['reason']; ?></th>
					<th data-field="create_on"><?php echo $language['create_on']; ?></th>
					<th data-field="duration"><?php echo $language['duration']; ?></th>
					<th data-field="actions"></th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
	<div class="col-md-5 widget in-sm top form">
		<div class="header news-header">
			<h4 class="title color-header"><i class="fas fa-user-edit mr-2"></i> <?php echo $language['ban_create']; ?></h4>
		</div>
		<hr class="hr-headline mb-3"/>
		<div class="row mr-0 ml-0 mt-1 mb-2">
			<label class="col-lg-2 form-label color-light"><?php echo $language['type']; ?>:</label>
			<div class="col-lg-10">
				<select id="banType" class="form-control form-control-sm">
					<option value="name" selected><?php echo $language['ban_name']; ?></option>
					<option value="ip"><?php echo $language['ban_ip']; ?></option>
					<option value="uid"><?php echo $language['ban_unique_id']; ?></option>
					<option value="myid"><?php echo $language['my_teamspeak']; ?></option>
				</select>
			</div>
		</div>
		<div class="row mr-0 ml-0 mt-1">
			<label class="col-lg-2 form-label color-light"><?php echo $language['client']; ?>:</label>
			<div class="col-lg-10">
				<div class="form-group">
					<input id="banInput" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['ban_name_uid_ip']; ?>">
					<small class="form-text text-muted"></small>
				</div>
			</div>
		</div>
		<div class="row mr-0 ml-0 mt-1">
			<label class="col-lg-2 form-label color-light"><?php echo $language['reason']; ?>:</label>
			<div class="col-lg-10">
				<div class="form-group">
					<input id="banReason" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['message']; ?>">
				</div>
			</div>
		</div>
		<div class="row mr-0 ml-0 mt-1">
			<label class="col-lg-2 form-label color-light"><?php echo $language['time']; ?>:</label>
			<div class="col-lg-10">
				<div class="form-group">
					<input id="banTime" class="form-control form-control-sm" type="number" placeholder="<?php echo $language['ban_time']; ?>">
					<small class="form-text text-muted"></small>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<button onClick="createBan();" class="btn btn-danger w-100-percent"><i class="fas fa-ban mr-2"></i><?php echo $language['ban']; ?></button>
			</div>
		</div>
	</div>
</div>

<script src="js/bootstrap/bootstrap-table.js"></script>
<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	var emptyList = lang.no_entrys;
	
	/**
		Bantable
	*/
	$('#banTable').bootstrapTable({
		formatNoMatches: function () {
			return emptyList;
		}
	});
	
	function ajaxRequest(params) {
		var data = [];
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'getServerBans',
				port: port,
				instance: instance
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					for(var entry of info.data) {
						data.push({
							'name': escapeHtml(entry.name),
							'id': entry.banid,
							'ip': entry.ip,
							'uniquie_id': entry.uid,
							'admin': escapeHtml(entry.invokername),
							'reason': escapeHtml(entry.reason),
							'create_on': new Date(entry.created * 1000).format('d.m.Y - H:i:s'),
							'duration': (parseInt(entry.duration) <= 0) ? lang.unlimited : convertSecondsToStrTime(parseInt(entry.duration)),
							'actions': '<button class="btn btn-red btn-sm" onClick="deleteBan(\''+entry.banid+'\');"><i class="fa fa-fw fa-trash mr-2"></i>'+lang.delete+'</button>'
						});
					};
				} else {
					emptyList = info.errors.join();
				};
				
				params.success({
					total: 100,
					rows: data
				});
			}
		});
	};
	
	/**
		Validation
	*/
	validateOnChange('#banInput', {
		required: true,
	}, '', lang.field_cant_be_empty);
	validateOnChange('#banTime', {
		required: true,
	}, '', lang.field_cant_be_empty);
</script>
<script src="js/webinterface/teamspeak.js"></script>