 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	
	/**
		Get server informations
	*/
	$info = getServerInfo($LinkInformations[2], $LinkInformations[3]);
	
	/** 
		Could not load all settings
	*/
	if(!$info['success']) {
		redirectSite(REDIRECT_SERVER_ERROR);
	};

	/**
	Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_edit"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_edit missing');
	};
	
	/**
		Got heading
	*/
	switch($LinkInformations[4]) {
		case 'tsEditComplain':
			$heading = $language['complaintsettings'];
			break;
		case 'tsEditHost':
			$heading = $language['hostsettings'];
			break;
		case 'tsEditAntiFlood':
			$heading = $language['anti_flood_settings'];
			break;
		case 'tsEditTransfer':
			$heading = $language['transfersettings'];
			break;
		case 'tsEditProtocol':
			$heading = $language['protokolsettings'];
			break;
		default:
			$heading = $language['main_settings'];
			break;
	};
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['settings']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[4] == false || $LinkInformations[4] == 'tsEditMain') ? "active" : ""; ?>">
				<a href="#tsEditMain">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['main_settings']; ?></span>
				</a>
			</li>
			<?php if(!checkServerPerm(array("perm_ts_server_edit_complain"), $LinkInformations[2], $LinkInformations[3])) { ?>
				<li class="item <?php echo ($LinkInformations[4] == 'tsEditComplain') ? "active" : ""; ?>">
					<a href="#tsEditComplain">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['complaintsettings']; ?></span>
					</a>
				</li>
			<?php }; ?>
			<?php if(!checkServerPerm(array("perm_ts_server_edit_host"), $LinkInformations[2], $LinkInformations[3])) { ?>
				<li class="item <?php echo ($LinkInformations[4] == 'tsEditHost') ? "active" : ""; ?>">
					<a href="#tsEditHost">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['hostsettings']; ?></span>
					</a>
				</li>
			<?php }; ?>
			<?php if(!checkServerPerm(array("perm_ts_server_edit_antiflood"), $LinkInformations[2], $LinkInformations[3])) { ?>
				<li class="item <?php echo ($LinkInformations[4] == 'tsEditAntiFlood') ? "active" : ""; ?>">
					<a href="#tsEditAntiFlood">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['anti_flood_settings']; ?></span>
					</a>
				</li>
			<?php }; ?>
			<?php if(!checkServerPerm(array("perm_ts_server_edit_transfer"), $LinkInformations[2], $LinkInformations[3])) { ?>
				<li class="item <?php echo ($LinkInformations[4] == 'tsEditTransfer') ? "active" : ""; ?>">
					<a href="#tsEditTransfer">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['transfersettings']; ?></span>
					</a>
				</li>
			<?php }; ?>
			<?php if(!checkServerPerm(array("perm_ts_server_edit_protocol"), $LinkInformations[2], $LinkInformations[3])) { ?>
				<li class="item <?php echo ($LinkInformations[4] == 'tsEditProtocol') ? "active" : ""; ?>">
					<a href="#tsEditProtocol">
						<i class="fas fa-circle"></i>
						<span><?php echo $language['protokolsettings']; ?></span>
					</a>
				</li>
			<?php }; ?>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-toggle="tooltip" data-placement="left" title="<?php echo $language['save']; ?>"><i class="far fa-save"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="tsEditMain" class="<?php echo ($LinkInformations[4] == false || $LinkInformations[4] == 'tsEditMain') ? "active" : ""; ?>">
					<div class="alert alert-table form">
						<?php if(!checkServerPerm(array("perm_ts_server_edit_name"), $LinkInformations[2], $LinkInformations[3])) { ?>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_servername']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_name" class="form-control form-control-sm" type="text" placeholder="<?php xssEcho($info['data']['virtualserver_name']); ?>">
										<small class="form-text text-muted"><?php echo $language['ts3_servername_info']; ?></small>
									</div>
								</div>
							</div>
						<?php }; ?>
						<?php if(!checkServerPerm(array("perm_ts_server_edit_port"), $LinkInformations[2], $LinkInformations[3])) { ?>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_port" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_port']; ?>">
										<small class="form-text text-muted"><?php echo $language['ts3_choose_port_info']; ?></small>
									</div>
								</div>
							</div>
						<?php }; ?>
						<?php if(!checkServerPerm(array("perm_ts_server_edit_clients"), $LinkInformations[2], $LinkInformations[3])) { ?>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_max_clients']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_maxclients" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_maxclients']; ?>">
										<small class="form-text text-muted"><?php echo $language['ts3_max_clients_info']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reservierte_slots']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_reserved_slots" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_reserved_slots']; ?>">
										<small class="form-text text-muted"><?php echo $language['ts3_reservierte_slots_info']; ?></small>
									</div>
								</div>
							</div>
						<?php }; ?>
						<?php if(!checkServerPerm(array("perm_ts_server_edit_password"), $LinkInformations[2], $LinkInformations[3])) { ?>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_password" class="form-control form-control-sm" type="password" value="<?php xssEcho($info['data']['virtualserver_password']); ?>">
										<small class="form-text text-muted"><?php echo $language['password_info']; ?></small>
									</div>
								</div>
							</div>
						<?php }; ?>
						<?php if(!checkServerPerm(array("perm_ts_server_edit_welcome"), $LinkInformations[2], $LinkInformations[3])) { ?>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_welcome_message']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<textarea id="virtualserver_welcomemessage" class="form-control form-control-sm" rows="4"><?php xssEcho($info['data']['virtualserver_welcomemessage']); ?></textarea>
									</div>
								</div>
							</div>
						<?php }; ?>
					</div>
				</div>
				<?php if(!checkServerPerm(array("perm_ts_server_edit_complain"), $LinkInformations[2], $LinkInformations[3])) { ?>
					<div id="tsEditComplain" class="<?php echo ($LinkInformations[4] == 'tsEditComplain') ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_count']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_complain_autoban_count" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_complain_autoban_count']; ?>">
										<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_duration']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_complain_autoban_time" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_complain_autoban_time']; ?>">
										<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_autoban_delete_after']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_complain_remove_time" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_complain_remove_time']; ?>">
										<small class="form-text text-muted"><?php echo $language['seconds']; ?></small>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
				<?php if(!checkServerPerm(array("perm_ts_server_edit_host"), $LinkInformations[2], $LinkInformations[3])) { ?>
					<div id="tsEditHost" class="<?php echo ($LinkInformations[4] == 'tsEditHost') ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message_show']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<select id="virtualserver_hostmessage_mode" class="form-control form-control-sm">
										<option value="0" <?php echo ($info['data']['virtualserver_hostmessage_mode'] == '0') ? 'selected' : ''; ?>><?php echo $language['ts3_host_message_show_1']; ?></option>
										<option value="1" <?php echo ($info['data']['virtualserver_hostmessage_mode'] == '1') ? 'selected' : ''; ?>><?php echo $language['ts3_host_message_show_2']; ?></option>
										<option value="2" <?php echo ($info['data']['virtualserver_hostmessage_mode'] == '2') ? 'selected' : ''; ?>><?php echo $language['ts3_host_message_show_3']; ?></option>
										<option value="3" <?php echo ($info['data']['virtualserver_hostmessage_mode'] == '3') ? 'selected' : ''; ?>><?php echo $language['ts3_host_message_show_4']; ?></option>
									</select>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbanner_url" class="form-control form-control-sm" type="text" placeholder="<?php xssEcho($info['data']['virtualserver_hostbanner_url']); ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_message']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostmessage" class="form-control form-control-sm" type="text" placeholder="<?php xssEcho($info['data']['virtualserver_hostmessage']); ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbanner_gfx_url" class="form-control form-control-sm" type="text" placeholder="<?php xssEcho($info['data']['virtualserver_hostbanner_gfx_url']); ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_banner_interval']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbanner_gfx_interval" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_hostbanner_gfx_interval']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_buttton_gfx_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbutton_gfx_url" class="form-control form-control-sm" type="text" placeholder="<?php xssEcho($info['data']['virtualserver_hostbutton_gfx_url']); ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_tooltip']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbutton_tooltip" class="form-control form-control-sm" type="text" placeholder="<?php xssEcho($info['data']['virtualserver_hostbutton_tooltip']); ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_host_button_url']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_hostbutton_url" class="form-control form-control-sm" type="text" placeholder="<?php xssEcho($info['data']['virtualserver_hostbutton_url']); ?>">
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
				<?php if(!checkServerPerm(array("perm_ts_server_edit_antiflood"), $LinkInformations[2], $LinkInformations[3])) { ?>
					<div id="tsEditAntiFlood" class="<?php echo ($LinkInformations[4] == 'tsEditAntiFlood') ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_reduce_points']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_antiflood_points_tick_reduce" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_antiflood_points_tick_reduce']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_antiflood_points_needed_command_block" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_antiflood_points_needed_command_block']; ?>">
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_points_block_ip']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_antiflood_points_needed_ip_block" class="form-control form-control-sm" type="number" placeholder="<?php echo $info['data']['virtualserver_antiflood_points_needed_ip_block']; ?>">
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
				<?php if(!checkServerPerm(array("perm_ts_server_edit_transfer"), $LinkInformations[2], $LinkInformations[3])) { ?>
					<div id="tsEditTransfer" class="<?php echo ($LinkInformations[4] == 'tsEditTransfer') ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_limit']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_max_upload_total_bandwidth" class="form-control form-control-sm" type="number" placeholder="<?php echo ($info['data']['virtualserver_max_upload_total_bandwidth'] == 18446744073709551615) ? $language['unlimited'] : $info['data']['virtualserver_max_upload_total_bandwidth']; ?>">
										<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_upload_kontigent']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_upload_quota" class="form-control form-control-sm" type="number" placeholder="<?php echo ($info['data']['virtualserver_upload_quota'] == 18446744073709551615) ? $language['unlimited'] : $info['data']['virtualserver_upload_quota']; ?>">
										<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_limit']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_max_download_total_bandwidth" class="form-control form-control-sm" type="number" placeholder="<?php echo ($info['data']['virtualserver_max_download_total_bandwidth'] == 18446744073709551615) ? $language['unlimited'] : $info['data']['virtualserver_max_download_total_bandwidth']; ?>">
										<small class="form-text text-muted"><?php echo $language['byte_s']; ?></small>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_download_kontigent']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="form-group">
										<input id="virtualserver_download_quota" class="form-control form-control-sm" type="number" placeholder="<?php echo ($info['data']['virtualserver_download_quota'] == 18446744073709551615) ? $language['unlimited'] : $info['data']['virtualserver_download_quota']; ?>">
										<small class="form-text text-muted"><?php echo $language['mbyte']; ?></small>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
				<?php if(!checkServerPerm(array("perm_ts_server_edit_protocol"), $LinkInformations[2], $LinkInformations[3])) { ?>
					<div id="tsEditProtocol" class="<?php echo ($LinkInformations[4] == 'tsEditProtocol') ? "active" : ""; ?>">
						<div class="alert alert-table form">
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_client']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_client" type="checkbox" <?php echo ($info['data']['virtualserver_log_client']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_query']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_query" type="checkbox" <?php echo ($info['data']['virtualserver_log_query']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_channel']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_channel" type="checkbox" <?php echo ($info['data']['virtualserver_log_channel']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_rights']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_permissions" type="checkbox" <?php echo ($info['data']['virtualserver_log_permissions']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_server']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_server" type="checkbox" <?php echo ($info['data']['virtualserver_log_server']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
							<div class="row mr-0 ml-0">
								<label class="col-lg-4 form-label color-light"><?php echo $language['ts3_protokol_transfer']; ?>:</label>
								<div class="col-lg-8 col-xl-4">
									<div class="switch">
										<label>
											<input id="virtualserver_log_filetransfer" type="checkbox" <?php echo ($info['data']['virtualserver_log_filetransfer']) ? 'checked' : ''; ?>>
											&nbsp;
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php }; ?>
			</div>
		</div>
	</div>
</div>

<script>
	/**
		Definitions
	*/
	var instance = <?php echo $LinkInformations[2]; ?>;
	var port = <?php echo $LinkInformations[3]; ?>;
	
	/**
		Save changed settings in the server
	*/
	$('a#save-settings').click(function(e) {
		var el = $(this);
		var name = null;
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		el.addClass('disabled');
		
		var data = {};
		$('.right-side-content > .tab-content > .active input, .right-side-content > .tab-content > .active select, .right-side-content > .tab-content > .active textarea').each(function() {
			var el = $(this);
			var val = el.val();
			var id = el.attr('id');
			
			if(val === '' && id !== 'virtualserver_password') {
				return;
			};
			
			if(id === 'virtualserver_name') {
				name = val;
			};
			
			if(el.attr('type') === 'checkbox') {
				data[el.attr('id')] = (el.prop('checked')) ? '1' : '0';
			} else {
				data[el.attr('id')] = el.val();
			};
		});
		
		if($.isEmptyObject(data)) {
			return;
		};
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'setServerSettings',
				port: port,
				instance: instance,
				data: JSON.stringify(data)
			},
			success: function(ret){
				var info = JSON.parse(ret);
				
				if(info.success) {
					if(name !== null) {
						$('#navTsServerName span').html(name);
					};

					if(data.virtualserver_port !== undefined) {
						changeContent('web_teamspeak_server');
					};
					
					new Notification({
						message : lang.server_successfull_edit,
						icon: 'fas fa-pencil-alt',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : info.errors.join(),
						icon: 'fas fa-pencil-alt',
						type : 'danger'
					}).show();
				};
				el.removeClass('disabled');
			}
		});
	});
</script>