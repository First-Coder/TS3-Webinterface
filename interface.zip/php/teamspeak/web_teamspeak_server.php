 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');

	/**
		JavaScript Data
	*/
	$onlineServer = [];
?>

<div class="content-header color-header"><?php echo $language['serverlist']; ?></div>

<div class="mb-3 shadow-default-content big-card">
	<div class="row m-0 big-card-content">
		<?php if($user_right['data']['perm_teamspeak_global_msg_poke'] == $mysql_keys['perm_teamspeak_global_msg_poke']) { ?>
			<div class="col-md-6 col-xs-12 col-sm-12 widget border-right form messagepoke">
				<div class="header">
					<div class="title text-name"><?php echo $language['global_msg_poke']; ?></div>
				</div>
				<div class="row mr-0 ml-0 mb-3">
					<label class="col-lg-4 form-label color-light"><?php echo $language['instance']; ?>:</label>
					<div class="col-lg-8 col-xl-4">
						<select id="poke-msg-instance" class="form-control form-control-sm">
							<option value="all"><?php echo $language['to_all_instanz']; ?></option>
							<?php if(isset($ts3_server)) {
									foreach($ts3_server AS $instance => $values) { ?>
										<option value="<?php echo $instance; ?>"><?php xssEcho($values['alias']); ?></option>
								<?php };
							}; ?>
						</select>
					</div>
				</div>
				<div class="row mr-0 ml-0">
					<label class="col-lg-4 form-label color-light"><?php echo $language['message']; ?>:</label>
					<div class="col-lg-8 col-xl-4">
						<div class="form-group">
							<input id="poke-msg" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['message']; ?>">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="widget-item w-100-percent">
						<div class="btn-group">
							<button class="btn btn-green" data-attribute="false"><i class="fas fa-font mr-2"></i><?php echo $language['message']; ?></button>
							<button class="btn btn-green" data-attribute="true"><i class="far fa-hand-point-up mr-2"></i><?php echo $language['poke']; ?></button>
						</div>
					</div>
				</div>
			</div>
		<?php }; ?>
		<div class="col-md-<?php echo ($user_right['data']['perm_teamspeak_global_msg_poke'] == $mysql_keys['perm_teamspeak_global_msg_poke']) ? '6' : '12'; ?> col-xs-12 col-sm-12 widget form">
			<div class="header">
				<div class="title text-name"><?php echo $language['settings']; ?></div>
			</div>
			<div class="row mr-0 ml-0">
				<label class="col-lg-4 form-label color-light"><?php echo $language['message']; ?>:</label>
				<div class="col-lg-8 col-xl-4">
					<div class="form-group">
						<input id="shutdown-msg" class="form-control form-control-sm" type="text" placeholder="<?php echo $language['message']; ?>">
						<small class="form-text text-muted"><?php echo $language['shutdown_message_info']; ?></small>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php if(isset($ts3_server)) {
	foreach($ts3_server AS $num=>$instance) {
		if(($user_right === false || $user_right['data']['perm_teamspeak_access_server'] != $mysql_keys['perm_teamspeak_access_server']) && !checkClientHasInstance($_SESSION['user']['id'], $num)) {
			echo $instance['alias'];
			continue;
		};

		$serverlist = getServerList($num);
		if($serverlist['success']) {
			foreach($serverlist['data'] AS $s=>$server) {
				if(!hasServerPerm($num, $server['virtualserver_port'])) {
					unset($serverlist['data'][$s]);
				};
			};
		};
		
		$data = ($serverlist['success']) ? $serverlist['data'] : $serverlist['error']; ?>
		<div class="mb-3 shadow-default-content big-card" data-instance="<?php echo $num; ?>">
			<div class="big-card-header" data-status="<?php echo ($serverlist['success'] && $data[0]['virtualserver_status'] == 'online') ? 'online' : 'offline'; ?>">
				<div>
					<span>
						<?php if($serverlist['success']) {
							$onlineServer[$num] = $data;
							$server = $data[0];
							$info = getServerInfo($num, $server['virtualserver_port'])['data']; ?>
							<i class="fab fa-<?php echo ($info['virtualserver_platform'] == 'Linux') ? 'linux' : 'windows'; ?>"></i></span>
						<?php } else { ?>
							<i class="fab fa-teamspeak"></i></span>
						<?php }; ?>
					<h3><?php xssEcho(empty($instance['alias']) ? $instance['ip'] : $instance['alias']); ?></h3>
				</div>
				<div style="display: <?php echo ($serverlist['success'] && count($data) > 1) ? 'flex' : 'none'; ?>;">
					<button class="btn btn-grey btn-grey-left" data-action="prev"><i class="fas fa-angle-left"></i></button>
					<button class="btn btn-grey btn-grey-right" data-action="next"><i class="fas fa-angle-right"></i></button>
				</div>
			</div>
			<?php if($serverlist['success']) { ?>
				<div class="row m-0 big-card-content">
					<div class="col-sm-6 col-lg-4 widget border-right">
						<div class="header">
							<div class="title text-name"><?php xssEcho($server['virtualserver_name']); ?></div>
							<div class="subtitle"><i class="fas fa-globe mr-2"></i><?php xssEcho($instance['ip']); ?>:<span class="text-port"><?php echo $server['virtualserver_port']; ?></span></div>
						</div>
						<div class="row row-center h-95-percent">
							<div class="col">
								<img class="w-100-percent" src="<?php xssEcho($info['virtualserver_hostbanner_gfx_url']); ?>" />
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-lg-4 widget border-right">
						<div class="header">
							<div class="title"><?php echo $language['client']; ?></div>
							<div class="subtitle"><i class="fas fa-users mr-2"></i><?php echo $language['user_instanz_statistik']; ?></div>
						</div>
						<div class="row row-center h-95-percent">
							<div class="col">
								<div id="chart-client-<?php echo $num; ?>">
									<div class="chart-inside chart-blue-light-color"></div>
								</div>
							</div>
							<div class="col">
								<div class="chart-legend">
									<div>
										<span class="chart-bullet chart-blue-light"></span>
										<span class="chart-bullet-text"><?php echo $language['used']; ?></span>
									</div>
									<div>
										<span class="chart-bullet chart-grey"></span>
										<span class="chart-bullet-text"><?php echo $language['free']; ?></span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 widget">
						<div class="color-content-body widget-item">
							<div class="row row-center">
								<div class="col">
									<h3 class="color-header"><?php echo $language['client']; ?></h3>
								</div>
								<div class="col text-right text-clients">
									<?php if(isset($server['virtualserver_clientsonline'])) {
										echo ($server['virtualserver_clientsonline']-$server['virtualserver_queryclientsonline']).' / '.$server['virtualserver_maxclients'];
									} else {
										echo '-';
									}; ?>
								</div>
							</div>
						</div>
						<div class="color-content-body widget-item">
							<div class="row row-center">
								<div class="col">
									<h3 class="color-header"><?php echo $language['online_since']; ?></h3>
								</div>
								<div class="col text-right text-uptime">
									<?php echo convertSecondsToStrTime((isset($server['virtualserver_uptime'])) ? $server['virtualserver_uptime'] : 0, false); ?>
								</div>
							</div>
						</div>
						<div class="color-content-body widget-item">
							<div class="row row-center">
								<div class="col">
									<h3 class="color-header"><?php echo $language['server_id']; ?></h3>
								</div>
								<div class="col text-right text-sid">
									<?php echo $server['virtualserver_id']; ?>
								</div>
							</div>
						</div>
						<div class="color-content-body widget-item">
							<div class="start-stop btn-group <?php echo(checkServerPerm(array("perm_ts_server_start_stop"), $num, $server['virtualserver_port'])) ? '' : 'd-none'; ?>">
								<button class="btn btn-green" data-action="start"><i class="fas fa-play mr-2"></i><?php echo $language['server_start']; ?></button>
								<button class="btn btn-red" data-action="stop"><i class="fas fa-stop mr-2"></i><?php echo $language['server_stop']; ?></button>
							</div>
							<div class="btn-group">
								<?php if($user_right['data']['perm_teamspeak_delete_server'] == $mysql_keys['perm_teamspeak_delete_server']) { ?>
									<button class="btn btn-red" data-action="delete"><i class="fas fa-trash-alt mr-2"></i><?php echo $language['delete_server']; ?></button>
								<?php }; ?>
								<button class="btn btn-blue" data-action="view"><i class="fas fa-eye mr-2"></i><?php echo $language['details']; ?></button>
							</div>
							<p id="info-<?php echo $num; ?>" class="text-center mb-0 mt-3 text-muted"></p>
						</div>
					</div>
				</div>
			<?php } else { ?>
				<div class="row m-0 big-card-content">
					<p class="col text-danger"><?php echo $data[0]; ?></p>
				</div>
			<?php }; ?>
		</div>
	<?php };
}; ?>

<script src="js/chart/chartist.js"></script>
<script>
	/**
		Message / Poke
	*/
	$('.messagepoke button').click(function() {
		if($('#poke-msg').val() === '') {
			return;
		};
		
		$('.messagepoke button').prop('disabled', true);
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action: 'instanceMessagePoke',
				instance: $('#poke-msg-instance').val(),
				poke: $(this).attr('data-attribute'),
				message: encodeURIComponent($('#poke-msg').val())
			},
			success: function(data) {
				$('.messagepoke button').prop('disabled', false);
				var info = JSON.parse(data);
				
				if(info.success) {
					new Notification({
						message : lang.server_msg_poke_done,
						icon: 'far fa-hand-point-up',
						type : 'success'
					}).show();
				} else {
					new Notification({
						message : info.errors,
						icon: 'far fa-hand-point-up',
						type : 'danger'
					}).show();
				};
			}
		});
	});
	
	/**
		Serverlist object
	*/
	;(function(window) {
		'use strict';
		
		/**
			Constructor
		*/
		function Serverlist(options) {
			var firstLoad = 0;
			var maxTrys = 3;
			var chartClient = null;
			var text = {
				info: null,
				interval: null,
				timer: 0
			};
			var clients = {
				allClients: 0,
				currentClients: 0
			};
			var selected = {
				id: 0,
				server: null
			};
			var percent = 0;
			var el = $('div[data-instance="'+options.instance+'"');
			var $this = this;
			
			this.options = extend({ }, this.options);
			extend(this.options, options);
			_init();
			
			/**
				Constructor initial
			*/
			function _init() {
				if(!document.getElementById("chart-client-"+$this.options.instance)) {
					console.error('Serverlist elements not found.');
					return;
				};
				
				_setAllClients($this.options.serverlist);
				
				selected.server = $this.options.serverlist[0];
				clients.currentClients = (parseInt(selected.server.virtualserver_clientsonline) - parseInt(selected.server.virtualserver_queryclientsonline));
				percent = Math.round((clients.currentClients / clients.allClients) * 100);
				
				if(isNaN(percent)) {
					percent = 0;
				};
				
				$("#chart-client-"+$this.options.instance+" > div").text(percent+"%");
				chartClient = new Chartist.Pie(
					"#chart-client-"+$this.options.instance, {
						series: [{
							value: clients.currentClients,
							className: 'chart-blue-light'
						}, {
							value: (clients.allClients - clients.currentClients),
							className: 'chart-grey'
						}]
					}, {
						donut: true,
						donutWidth:17,
						showLabel: false
					}).on('draw', function(data) {
						if(data.type === 'slice') {
							var pathLength = data.element._node.getTotalLength();
							data.element.attr((firstLoad > 1) ? { } : { 'stroke-dasharray': pathLength + 'px ' + pathLength + 'px' });
							
							var animationDefinition = {
								'stroke-dashoffset': {
									id: 'anim' + data.index,
									dur: 1000,
									from: -pathLength + 'px',
									to:  '0px',
									easing: Chartist.Svg.Easing.easeOutQuint,
									fill: 'freeze'
								}
							};

							if(data.index !== 0) {
								animationDefinition['stroke-dashoffset'].begin = 'anim' + (data.index - 1) + '.end';
							};
							
							data.element.attr((firstLoad > 1) ? { } : { 'stroke-dashoffset': -pathLength + 'px' });

							data.element.animate((firstLoad > 1) ? { } : animationDefinition, false);
							firstLoad++;
						}
					});
					
				_initRefresh();
				_initButtons();
			};
			
			/**
				Button handlers
			*/
			function _initButtons() {
				$('[data-action="prev"]', el).click(function() {
					_changeServerCard(false);
				});
				
				$('[data-action="next"]', el).click(function() {
					_changeServerCard(true);
				});
				
				$('.btn-group > button', el).click(function() {
					var action = $(this).attr('data-action');
					
					switch(action) {
						case 'start':
							$.ajax({
								type: "POST",
								url: "./php/functions/functionsTeamspeakPost.php",
								data: {
									action: 'startTeamspeakServer',
									instance: $this.options.instance,
									sid: selected.server.virtualserver_id,
									port: selected.server.virtualserver_port
								},
								success: function(data){
									var info = JSON.parse(data);
									
									if(info.success) {
										text.timer = 0;
									} else {
										new Notification({
											message : (info.error === undefined) ? info.errors[0] : info.error,
											icon: 'fas fa-play',
											type : 'danger'
										}).show();
									};
								}
							});
							break;
						case 'stop':
							$.ajax({
								type: "POST",
								url: "./php/functions/functionsTeamspeakPost.php",
								data: {
									action: 'stopTeamspeakserver',
									instance: $this.options.instance,
									sid: selected.server.virtualserver_id,
									message: $('#shutdown-msg').val(),
									port: selected.server.virtualserver_port
								},
								success: function(data){
									var info = JSON.parse(data);
									
									if(info.success) {
										text.timer = 0;
									} else {
										new Notification({
											message : (info.error === undefined) ? info.errors[0] : info.error,
											icon: 'fas fa-stop',
											type : 'danger'
										}).show();
									};
								}
							});
							break;
						case 'delete':
							new AreUSure({
								label: lang.delete_server.replace("&ouml;", "\u00f6"),
								onConfirm: function() {
									$.ajax({
										type: "POST",
										url: "./php/functions/functionsTeamspeakPost.php",
										data: {
											action: 'deleteTeamspeakserver',
											instance: $this.options.instance,
											sid: selected.server.virtualserver_id,
											port: selected.server.virtualserver_port
										},
										success: function(data){
											var info = JSON.parse(data);
											
											if(info.success) {
												$this.options.serverlist.splice(checkArrayForKey($this.options.serverlist, 'virtualserver_id', selected.server.virtualserver_id), 1);
												if($this.options.serverlist.length <= 0) {
													$('[data-instance="'+$this.options.instance+'"').remove();
													_destroy();
												} else {
													_changeServerCard();
												};
												swal(lang.succeeded, lang.server_deleted.replace("&ouml;", "\u00f6"), 'success');
											} else {
												new Notification({
													message : (info.error === undefined) ? info.errors[0] : info.error,
													icon: 'fas fa-trash-alt',
													type : 'danger'
												}).show();
											};
										}
									});
								}
							});
							break;
						case 'view':
							var server = $this.options.serverlist[checkArrayForKey($this.options.serverlist, 'virtualserver_id', selected.server.virtualserver_id)];
							changeContent('web_teamspeak_serverview', true, false, $this.options.instance, server.virtualserver_port, server.virtualserver_name);
							break;
					};
				});
			};
			
			/**
				Function to return the number of the element. False if no match found
				@param {Array} array
				@param {int} key
				@param {int} val
				@return {int}
			*/
			function checkArrayForKey(array, key, val) {
				for(var object in array) {
					if(array[object][key] == val) {
						return object;
					};
				};
				return false;
			}
			
			/**
				Change server card
				@param {bool} next
			*/
			function _changeServerCard(next = true) {
				$('.big-card-header button').prop('disabled', true);
				if(next) {
					if(++selected.id > ($this.options.serverlist.length - 1)) {
						selected.id = 0;
					};
				} else {
					if(--selected.id < 0) {
						selected.id = $this.options.serverlist.length - 1;
					};
				};
				_changeServer();
			};
			
			/**
				Change serverlist server
			*/
			function _changeServer() {
				text.timer = -1;
				text.info.text(lang.refresh_in+'-');
				selected.server = $this.options.serverlist[selected.id];
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsTeamspeakPost.php",
					data: {
						action: 'getTeamspeakInfo',
						instance: $this.options.instance,
						port: selected.server.virtualserver_port
					},
					success: function(data){
						var info = JSON.parse(data);
						
						if(info.success) {
							var data = info.data;
							firstLoad = 0;
							_refreshChart(data);
							
							if(isNaN(percent)) {
								percent = 0;
							};
							
							$('.text-clients', el).text((parseInt(data.virtualserver_clientsonline) - parseInt(data.virtualserver_queryclientsonline))+' / '+data.virtualserver_maxclients);
							$('.text-uptime', el).text(convertSecondsToStrTime(parseInt(data.virtualserver_uptime), false));
							$('.text-sid', el).text(data.virtualserver_id);
							$('.text-name', el).text(data.virtualserver_name);
							$('.text-port', el).text(data.virtualserver_port);
							
							$('.big-card-header', el).attr('data-status', (data.virtualserver_status == 'online') ? 'online' : 'offline');
							$('.chart-inside', el).text(percent+'%');
							$('.big-card-content img', el).attr('src', data.virtualserver_hostbanner_gfx_url);

							(data.virtualserver_start_stop) ?  $('.start-stop', el).removeClass('d-none') : $('.start-stop', el).addClass('d-none');
							
							flashText($('.text-clients', el));
							flashText($('.text-uptime', el));
							flashText($('.text-sid', el));
							
							$('.big-card-header button').prop('disabled', false);
							text.timer = 61;
						} else {
							if(maxTrys > 0) {
								maxTrys--;
								if(--selected.id < 0) {
									selected.id = $this.options.serverlist.length - 1;
								};
								_changeServer();
								return;
							};
							
							maxTrys = 3;
							var error = (info.error === undefined) ? lang.default_error : info.error;
							
							$('.big-card-header', el).attr('data-status', 'offline');
							$('.big-card-header span > i', el).removeClass('fa-linux fa-windows').addClass('fa-teamspeak'); 
							$('.big-card-content', el).replaceWith('<div class="row m-0"><p class="col text-danger">'+error+'</p></div>');
							console.error('Cant update serverlist '+$this.options.instance+': '+error);
						};
					}
				});
			};
			
			/**
				Refresh serverlist object
			*/
			function _initRefresh() {
				if(!document.getElementById('info-'+$this.options.instance)) {
					console.error('Infotext not found');
					_destroy();
					return;
				};
				
				text.timer = 60;
				text.info = $("#info-"+$this.options.instance);
				text.info.text(lang.refresh_in+'60s');
				text.interval = setInterval(_refreshText, 1000);
			};
			
			/**
				Refresh serverlist text
			*/
			function _refreshText() {
				if(!document.getElementById('info-'+$this.options.instance)) {
					_destroy();
					return;
				};
				
				if(text.timer > 0) {
					--text.timer;
					text.info.text(lang.refresh_in+text.timer+'s');
				} else if(text.timer == 0) {
					--text.timer;
					$.ajax({
						type: "POST",
						url: "./php/functions/functionsTeamspeakPost.php",
						data: {
							action: 'getServerList',
							instance: $this.options.instance
						},
						success: function(data){
							var info = JSON.parse(data);
							
							if(info.success) {
								var data = info.data;
								_setAllClients(data);
								
								$('[data-action="prev"], [data-action="next"]', el).attr('display', (data.length > 1) ? 'flex' : 'none');
								
								$.ajax({
									type: "POST",
									url: "./php/functions/functionsTeamspeakPost.php",
									data: {
										action: 'getTeamspeakInfo',
										instance: $this.options.instance,
										port: selected.server.virtualserver_port
									},
									success: function(data){
										var info = JSON.parse(data);
										
										if(info.success) {
											var data = info.data;
											_refreshChart(data);
											
											if(isNaN(percent)) {
												percent = 0;
											};
											
											$('.text-clients', el).text((parseInt(data.virtualserver_clientsonline) - parseInt(data.virtualserver_queryclientsonline))+' / '+data.virtualserver_maxclients);
											$('.text-uptime', el).text(convertSecondsToStrTime(parseInt(data.virtualserver_uptime), false));
											$('.text-sid', el).text(data.virtualserver_id);
											
											$('.big-card-header', el).attr('data-status', (data.virtualserver_status == 'online') ? 'online' : 'offline');
											$('.col > .header > .title.text-name', el).text(data.virtualserver_name);
											$('.chart-inside', el).text(percent+'%');
											$('.big-card-content img', el).attr('src', data.virtualserver_hostbanner_gfx_url);
											
											flashText($('.text-clients', el));
											flashText($('.text-uptime', el));
											flashText($('.text-sid', el));
											
											text.timer = 61;
										} else {
											$('.big-card-header', el).attr('data-status', 'offline');
											$('.big-card-header span > i', el).removeClass('fa-linux fa-windows').addClass('fa-teamspeak'); 
											$('.big-card-content', el).replaceWith('<div class="row m-0"><p class="col text-danger">'+info.error+'</p></div>');
											console.error('Cant update serverlist '+$this.options.instance+': '+info.error);
										};
									}
								});
							} else {
								$('.big-card-header', el).attr('data-status', 'offline');
								$('.big-card-header span > i', el).removeClass('fa-linux fa-windows').addClass('fa-teamspeak'); 
								$('.big-card-content', el).replaceWith('<div class="row m-0"><p class="col text-danger">'+info.error+'</p></div>');
								console.error('Cant update serverlist '+$this.options.instance+': '+info.error);
							};
						}
					});
				};
			};
			
			/**
				Refresh serverlist diagramm
				@param {Object} server
			*/
			function _refreshChart(server) {
				selected.server = server;
				clients.currentClients = (parseInt(selected.server.virtualserver_clientsonline) - parseInt(selected.server.virtualserver_queryclientsonline));
				percent = Math.round((clients.currentClients / clients.allClients) * 100);
				
				var newData = [{
					value: clients.currentClients,
					className: 'chart-blue-light'
				}, {
					value: (clients.allClients - clients.currentClients),
					className: 'chart-grey'
				}];
				chartClient.update({series: newData});
			};
			
			/**
				Set all clients
				@param {Object} list
			*/
			function _setAllClients(list) {
				clients.allClients = 0;
				for(var server in list) {
					if(list[server].virtualserver_maxclients === undefined) {
						continue;
					};
					clients.allClients += parseInt(list[server].virtualserver_maxclients);
				};
			};
			
			/**
				Destroy the object
			*/
			function _destroy() {
				clearInterval(text.interval);
				$this.options.onDestroy($this.options.instance);
			};
		}
		
		/**
			Options from outside
		*/
		Serverlist.prototype.options = {
			instance: 0,
			serverlist: { },
			onDestroy: function() { return false; }
		}
		
		/**
			global namespaces
		*/
		window.Serverlist = Serverlist;
	})(window);
	
	/**
		Create serverlist objects
	*/
	var list = JSON.parse('<?php echo json_encode($onlineServer); ?>');
	var slist = {};
	for(var num in list) {
		slist[num] = new Serverlist({
			instance: num,
			serverlist: list[num],
			onDestroy: function(instance) {
				delete(slist[instance]);
			}
		});
	};
</script>
<script src="js/webinterface/teamspeak.js"></script>