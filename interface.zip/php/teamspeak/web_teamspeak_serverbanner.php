 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys				=	getKeys();
	$mysql_modul			=	getModuls();
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Get Link information
	*/
	$LinkInformations	=	getLinkInformations();
	
	if(empty($LinkInformations) || $mysql_modul['webinterface'] != 'true')
	{
		reloadSite(RELOAD_TO_MAIN);
	};
	
	/*
		Teamspeak Functions
	*/
	$tsAdmin = new ts3admin($ts3_server[$LinkInformations['instanz']]['ip'], $ts3_server[$LinkInformations['instanz']]['queryport']);
	
	if($tsAdmin->getElement('success', $tsAdmin->connect()))
	{
		$tsAdmin->login($ts3_server[$LinkInformations['instanz']]['user'], $ts3_server[$LinkInformations['instanz']]['pw']);
		$tsAdmin->selectServer($LinkInformations['sid'], 'serverId', true);
		
		$server		= 	$tsAdmin->serverInfo();
		$banlist	=	$tsAdmin->banList();
		
		if(((!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_view') || !isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_banner'))
				&& $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server']) || $user_right['right_web']['key'] != $mysql_keys['right_web'])
		{
			reloadSite(RELOAD_TO_SERVERVIEW);
		};
	}
	else
	{
		reloadSite(RELOAD_TO_MAIN);
	};
	
	/*
		Main Image
	*/
	$mainImage					=	"./images/ts_banner/default_banner.png";
	
	/*
		Get Fonts
	*/
	$fonts						=	"";
	foreach (scandir(__dir__."/../../fonts/") as $datei)
	{
		if(strpos($datei, ".ttf") !== false && strpos($datei, "fontawesome") === false)
		{
			$fonts				.=	'<option value="'.$datei.'" selected>'.str_replace(".ttf", "", $datei).'</option>';
		};
	};
	
	/*
		Get Default Bannerimages
	*/
	$defaultImages				=	"";
	foreach (scandir(__dir__."/../../images/ts_banner/") as $datei)
	{
		if(strpos($datei, ".png") !== false && strpos($datei, "default_banner") !== false)
		{
			$defaultImages		.=	'<option value="'.$datei.'">'.str_replace(".png", "", $datei).'</option>';
		};
	};
	
	/*
		Useable elements
	*/
	$subDraggableElements = [
		'x' 					=>	0,
		'y' 					=> 	0,
		'fontfile' 				=> 	'',
		'fontsize'				=>	16,
		'color'					=>	'',
		'text'					=>	''
	];
	$draggableElements = [
        '%status%' 				=> 	$subDraggableElements,
		'%sid%' 				=> 	$subDraggableElements,
		'%sport%' 				=> 	$subDraggableElements,
		'%platform%' 			=> 	$subDraggableElements,
		'%servername%' 			=> 	$subDraggableElements,
		'%serverversion%' 		=> 	$subDraggableElements,
		'%packetloss_floored%' 	=> 	$subDraggableElements,
		'%ping_floored%' 		=> 	$subDraggableElements,
		'%packetloss_00%' 		=> 	$subDraggableElements,
		'%maxclients%' 			=> 	$subDraggableElements,
		'%clientsonline%' 		=> 	$subDraggableElements,
		'%channelcount%' 		=> 	$subDraggableElements,
		'%packetloss%' 			=> 	$subDraggableElements,
		'%ping%' 				=> 	$subDraggableElements,
		'%realclients%' 		=> 	$subDraggableElements,
		'%nickname%' 			=> 	$subDraggableElements,
		'%timeHi%' 				=> 	$subDraggableElements,
		'%timeHis%' 			=> 	$subDraggableElements,
		'%date%' 				=> 	$subDraggableElements
    ];
	
	/*
		Get Elementinformations
	*/
	$settingsFile				=	__dir__."/../../images/ts_banner/".$LinkInformations['instanz']."_".$server['data']['virtualserver_port']."_settings.json";
	$active						=	"default_banner.png";
	$folder						=	"./images/ts_banner/";
	if(file_exists($settingsFile))
	{
		$settings				=	json_decode(file_get_contents($settingsFile));
		$active					=	str_replace($folder, "", $settings->settings->bgimage);
	};
?>

<div class="col-xs-12 main form-secondary">
	<div class="page-on-top">
		<div class="row mb-3">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-link" aria-hidden="true"></i> <?php echo $language['serverbanner_link']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<?php
					if(isSet($_SERVER['HTTP_REFERER']))
					{
						$serverBannerLink		=	str_replace("index", "iframeServerBanner", explode("?", $_SERVER['HTTP_REFERER'])[0]);
					}
					else
					{
						$linkPrefix		=	($_SERVER['HTTPS'] == "on") ? "https://" : "http://";
						$linkPath		=	$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
						$serverBannerLink		=	$linkPrefix.str_replace("index", "iframeServerBanner", $linkPath);
					};
					$iframeText		=	$serverBannerLink."?port=".$server['data']['virtualserver_port']."&instanz=".$LinkInformations['instanz'];
				?>
				<pre id="linkText" class="mb-4" onClick="SelectText('linkText');"><code id="linkTextCode"><?php echo $iframeText; ?></code></pre>
				
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-file-image-o" aria-hidden="true"></i> <?php echo $language['choose_serverbanner']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<div class="nav-tabs mb-3">
					<ul class="nav nav-tabs">
						<li class="nav-item nav-50 ml-0">
							<a href="#" class="nav-link active" data-toggle="tab" data-target="#collapsServerbanner"><?php echo $language['serverbanner']; ?></a>
						</li>
						<li class="nav-item nav-50 ml-0">
							<a href="#" class="nav-link" data-toggle="tab" data-target="#collapsUploadServerbanner"><?php echo $language['upload_serverbanner']; ?></a>
						</li>
					</ul>
					<div class="tab-content w-100-percent form-secondary">
						<div role="tabpanel" class="tab-pane active" id="collapsServerbanner">
							<div class="row">
								<?php
									if ($handle = opendir(__dir__.'/../../images/ts_banner/'))
									{
										while (false !== ($entry = readdir($handle)))
										{
											if ($entry != "." && $entry != ".." && strpos($entry, "default_banner") !== false)
											{
												if($active == $entry)
												{
													echo 	'<div id="'.explode(".", $entry)[0].'" class="col-xs-12 col-sm-6 col-md-3 mb-3 active choose-serverbanner" onClick="setServerBanner(\''.explode(".", $entry)[0].'\');">
																<img class="img-fluid" src="'.$folder.$entry.'"/>
															</div>';
												}
												else
												{
													echo 	'<div id="'.explode(".", $entry)[0].'" class="col-xs-12 col-sm-6 col-md-3 mb-3 grayscale-1 choose-serverbanner" onClick="setServerBanner(\''.explode(".", $entry)[0].'\');">
																<img class="img-fluid" src="'.$folder.$entry.'"/>
															</div>';
												};
											};
										};
										closedir($handle);
									};
								?>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane" id="collapsUploadServerbanner">
							<div class="row">
								<div class="col-lg-12 col-md-12">
									<form class="dropzone" drop-zone="" id="file-dropzone"></form>
								</div>
							</div>
							<p style="text-align: center;"><?php echo $language['upload_serverbanner_info']; ?></p>
						</div>
					</div>
				</div>
				
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-pencil" aria-hidden="true"></i> <?php echo $language['create_serverbanner']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<div class="row">
					<div class="col-xs-12 mb-3" id="serverbanner-pre-section">
						<div id="serverbanner-section" style="background-image: url('<?php echo $folder.$active; ?>');margin: 0px auto;
						max-width: 900px;background-size: contain;background-repeat: no-repeat;">
							<img src="<?php echo $folder.$active; ?>" style="visibility: hidden;" class="img-fluid"/>
						</div>
					</div>
					<div class="col-xs-12 addElement">
						<hr/>
						<select id="selectElement" class="mb-3 form-control w-100-percent" onChange="changeElement();">
							<option value="disabled" selected disabled style="display: none;">Text w&auml;hlen</option>
							<option value="%custom%">custom_text</option>
							<?php
								foreach($draggableElements AS $element => $content)
								{
									if(!array_key_exists($element, $settings->data))
									{
										echo '<option value='.$element.'>'.str_replace("%", "", $element).'</option>';
									};
								};
							?>
						</select>
						<hr/>
					</div>
					<?php
						foreach($settings->custom AS $element => $data)
						{
							$text		=	str_replace("-", "_", $element);
							echo '
									<div id="'.$text.'" class="col-xs-12 ml-2 mr-2 addElement" element="%custom%">
										<h6 class="mt-2"><b>'.$text.'</b></h6>
										<div class="row">
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['textsize'].'</label>
													<input id="'.$text.'_fontsize" class="form-control" type="number" value="'.$data->fontsize.'" onChange="updateInput(\''.$text.'\', true);" style="height: 38px;"/>
												</div>
											</div>
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['font'].'</label>
													<select id="'.$text.'_font" class="form-control">
														'.$fonts.'
													</select>
												</div>
											</div>
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['color'].'</label>
													<div id="'.$text.'_colorpicker" class="input-group colorpicker-component">
														<input id="'.$text.'_color" type="text" value="'.$data->color.'" class="form-control" onChange="updateInput(\''.$text.'\', false);" />
														<span class="input-group-addon"><i></i></span>
													</div>
												</div>
											</div>
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['name'].'</label>
													<input id="'.$text.'_text" type="text" class="form-control" value="'.xssSafe($data->text).'" />
												</div>
											</div>
											<div class="col-xs-12">
												<button onClick="deleteElement(\''.$text.'\');" class="btn btn-flat btn-danger w-100-percent mb-2"><i class="fa fa-trash" aria-hidden="true"></i> '.$language['delete'].'</button>
											</div>
										</div>
									</div>
							';
						};
						
						foreach($settings->data AS $element => $data)
						{
							$text		=	str_replace("%", "", $element);
							echo '
									<div id="'.$text.'" class="col-xs-12 ml-2 mr-2 addElement">
										<h6 class="mt-2"><b>'.$text.'</b></h6>
										<div class="row">
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['textsize'].'</label>
													<input id="'.$text.'_fontsize" class="form-control" type="number" value="'.$data->fontsize.'" onChange="updateInput(\''.$text.'\', true);" style="height: 38px;"/>
												</div>
											</div>
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['font'].'</label>
													<select id="'.$text.'_font" class="form-control">
														'.$fonts.'
													</select>
												</div>
											</div>
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['color'].'</label>
													<div id="'.$text.'_colorpicker" class="input-group colorpicker-component">
														<input id="'.$text.'_color" type="text" value="'.$data->color.'" class="form-control" onChange="updateInput(\''.$text.'\', false);" />
														<span class="input-group-addon"><i></i></span>
													</div>
												</div>
											</div>
											<div class="col-xs-12 col-md-6">
												<div class="form-group mb-2">
													<label>'.$language['name'].'</label>
													<input id="'.$text.'_text" type="text" class="form-control" disabled />
												</div>
											</div>
											<div class="col-xs-12">
												<button onClick="deleteElement(\''.$text.'\');" class="btn btn-flat btn-danger w-100-percent mb-2"><i class="fa fa-trash" aria-hidden="true"></i> '.$language['delete'].'</button>
											</div>
										</div>
									</div>
							';
						};
					?>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="js/bootstrap/bootstrap-colorpicker.js"></script>
<script src="js/other/draggabilly.pkgd.js"></script>
<script>
	/*
		Vars
	*/
	var customItems			=	0;
		settingsData		=	<?php echo json_encode($settings->data); ?>,
		settingsCustom		=	<?php echo json_encode($settings->custom); ?>,
		offsetLeft			=	$('#serverbanner-section').offset().left - $('#serverbanner-pre-section').offset().left - 15,
		windowSize			=	$('#serverbanner-section').css("width").replace("px", "") / 900,
		windowSizeH			=	$('#serverbanner-section').css("height").replace("px", "") / 450,
		port 				= 	'<?php echo $server['data']['virtualserver_port']; ?>',
		instanz				=	'<?php echo $LinkInformations['instanz']; ?>';
	
	/*
		Draggable Object
	*/
	function draggie(element)
	{
		var dragElement 	= 	element;
		var draggable		=	$('#'+dragElement).draggabilly({ containment: true });
		var draggie 		= 	draggable.data('draggabilly');
		
		draggable.on( 'dragMove', function() {
			var newX		=	Math.round(draggie.position.x * windowSize) - offsetLeft,
				newY		=	Math.round(draggie.position.y * windowSizeH);
			
			if(newX < 0)
			{
				newX		=	0;
			};
			if(newX > 900)
			{
				newX		=	900;
			};
			
			if(newY < 0)
			{
				newY		=	0;
			};
			if(newY > 450)
			{
				newY		=	450;
			};
			
			$(this).attr("left", newX);
			$(this).attr("top", newY);
			
			OverlayButton.setButton(true);
		});
	};
	
	/*
		Window resize
	*/
	window.onresize = function(event) {
		offsetLeft			=	$('#serverbanner-section').offset().left - $('#serverbanner-pre-section').offset().left - 15;
		
		$('#serverbanner-section div').each(function()
		{
			$(this).css("left", Math.round(($(this).attr("left") * windowSize) + offsetLeft));
			$(this).css("top", Math.round($(this).attr("top") * windowSizeH));
			$(this).css("font-size", Math.round($(this).attr("size") * windowSize));
			
			
			console.log($(this).attr("top"));
			console.log(windowSizeH);
		});
	};
	
	/*
		Set serverbanner elements
	*/
	for(var element in settingsData)
	{
		setElement(element, element.replace(/%/g, ""), true)
	};
	
	for(var element in settingsCustom)
	{
		setElement(element, element.replace(/-/g, "_"), false);
		customItems		=	element.split("-")[2];
	};
	
	function setElement(element, text, isSettingsData = true)
	{
		var settings	=	(isSettingsData) ? settingsData : settingsCustom,
			newElement	=	'<div id="'+text+'_example" size="'+settings[element].fontsize+'" left="'+Math.round(settings[element].x)+'" top="'+(settings[element].y - settings[element].fontsize)+'" style="float: left;position: absolute;left: '+(settings[element].x + offsetLeft)+'px;top: '+(settings[element].y - settings[element].fontsize)+'px">'+text+'</div>';
		
		$('#serverbanner-section').append(newElement);
		
		new draggie(text+'_example');
	};
	
	/*
		Settings colorpicker
	*/
	$('.colorpicker-component').colorpicker();
	
	/*
		Change Color or Size of a element
	*/
	function updateInput(id, isFontsize = false)
	{
		var valueSize	=	($("#"+id+"_fontsize").val() <= 40) ? $("#"+id+"_fontsize").val() : "40",
			valueColor	=	$("#"+id+"_color").val();
		
		updateElement(id+'_example', valueSize, valueColor);
	};
	
	/*
		Add new element to the banner
	*/
	function changeElement()
	{
		var value		=	$("#selectElement").val(),
			valueText	=	$("#selectElement option[value='"+value+"']").text(),
			isCustom	=	(value == "%custom%") ? "" : "disabled",
			valueSize	=	"16",
			valueColor	=	"#00AABB";
		
		$("#selectElement").val("disabled");
		
		if(value != "%custom%")
		{
			$("#selectElement option[value='"+value+"']").remove();
		}
		else
		{
			customItems++;
			valueText	+=	"_"+customItems;
		};
		
		
		$('\
		<div id="'+valueText+'" class="col-xs-12 ml-2 mr-2 addElement" element="'+value+'">\
			<h6 class="mt-2"><b>'+valueText+'</b></h6>\
			<div class="row">\
				<div class="col-xs-12 col-md-6">\
					<div class="form-group mb-2">\
						<label><?php echo $language['textsize']; ?></label>\
						<input id="'+valueText+'_fontsize" class="form-control" type="number" value="'+valueSize+'" onChange="updateInput(\''+valueText+'\', true);" style="height: 38px;"/>\
					</div>\
				</div>\
				<div class="col-xs-12 col-md-6">\
					<div class="form-group mb-2">\
						<label><?php echo $language['font']; ?></label>\
						<select id="'+valueText+'_font" class="form-control">\
							<?php echo $fonts; ?>\
						</select>\
					</div>\
				</div>\
				<div class="col-xs-12 col-md-6">\
					<div class="form-group mb-2">\
						<label><?php echo $language['color']; ?></label>\
						<div id="'+valueText+'_colorpicker" class="input-group colorpicker-component">\
							<input id="'+valueText+'_color" type="text" value="'+valueColor+'" class="form-control" onChange="updateInput(\''+valueText+'\', false);" />\
							<span class="input-group-addon"><i></i></span>\
						</div>\
					</div>\
				</div>\
				<div class="col-xs-12 col-md-6">\
					<div class="form-group mb-2">\
						<label><?php echo $language['name']; ?></label>\
						<input id="'+valueText+'_text" type="text" class="form-control" '+isCustom+' />\
					</div>\
				</div>\
				<div class="col-xs-12">\
					<button onClick="deleteElement(\''+valueText+'\');" class="btn btn-flat btn-danger w-100-percent mb-2"><i class="fa fa-trash" aria-hidden="true"></i> <?php echo $language['delete']; ?></button>\
				</div>\
			</div>\
		</div>\
		').insertAfter(".addElement:last-child");
		
		$("#serverbanner-section").append('<div id="'+valueText+'_example" left="0" top="0" style="float: left;position: absolute;">'+valueText+'</div>');
		
		$('#'+valueText+'_colorpicker').colorpicker();
		
		$('#'+valueText+'_example').css("left", offsetLeft + 15);
		$('#'+valueText+'_example').css("top", 0);
		new draggie(valueText+'_example');
		
		updateElement(valueText+'_example', valueSize, valueColor);
	};
	
	/*
		Delete element from the banner
	*/
	function deleteElement(id)
	{
		$("#"+id).remove();
		$("#"+id+"_example").remove();
		$("#selectElement").append('<option value="%'+id+'%">'+id+'</option>');
		
		OverlayButton.setButton(true);
	};
	
	/*
		Set inputchanges
	*/
	function updateElement(id, fontSize, fontColor)
	{
		$('#'+id).css("color", fontColor).css("font-size", fontSize+"px");
		$('#'+id).attr("size", fontSize);
	};
	
	/*
		Change the serverbanner image
	*/
	function setServerBanner(id)
	{
		$('.choose-serverbanner').addClass("grayscale-1");
		$('.choose-serverbanner').removeClass("active");
		
		$('#'+id).addClass("active");
		$('#'+id).removeClass("grayscale-1");
		
		$('#serverbanner-section').css("background-image", "url('<?php echo $folder; ?>"+id+".png')");
	};
	
	/*
		Overlay button
	*/
	OverlayButton.setButtonClass("btn-secondary");
	OverlayButton.setIconClass("fa-save");
	OverlayButton.setTooltip(lang.save);
	OverlayButton.on("click", function() {
		createBanner();
	});
	OverlayButton.start();
	OverlayButton.setButton(false);
	
	$('#collapsServerbanner .choose-serverbanner').click(function()
	{
		OverlayButton.setButton(true);
	});
	$('input, select').change(function()
	{
		OverlayButton.setButton(true);
	});
	$('input').on('input',function()
	{
		OverlayButton.setButton(true);
	});
	
	/*
		Create Banner
	*/
	function createBanner()
	{
		var imageParts	=	$('.choose-serverbanner.active img').attr("src").split("/");
		var bgimage		=	imageParts[imageParts.length - 1];
		var data 		=
			{
				"settings":
				{
					"bgimage": "./images/ts_banner/"+bgimage
				},
				"custom": {},
				"data": <?php echo json_encode($draggableElements); ?>
			};
		
		for(var element in data["data"])
		{
			var queryElement						=	element.replace(/%/g, "");
			
			if(document.getElementById(queryElement))
			{
				data["data"][element].x				=	Math.round($("#"+queryElement+"_example").attr("left"));
				data["data"][element].y				=	Math.round($("#"+queryElement+"_example").attr("top")) + parseInt($("#"+queryElement+"_example").attr("size"));
				
				var colorElements					=	$("#"+queryElement+"_example").css("color").replace("rgb(", "").replace(")", "").split(",");
				data["data"][element].color			=	rgbToHex(parseInt(colorElements[0].trim()), parseInt(colorElements[1].trim()), parseInt(colorElements[2].trim()));
				data["data"][element].fontfile		=	"./fonts/"+$("#"+queryElement+"_font").val();
				data["data"][element].fontsize		=	$("#"+queryElement+"_example").attr("size");
				data["data"][element].text			=	$("#"+queryElement+"_text").val();
			}
			else
			{
				delete data["data"][element];
			};
		};
		
		$('.addElement[element="%custom%"]').each(function()
		{
			var element								=	$(this).attr("id"),
				objectElement						=	element.replace(/_/g, "-");
			
			data["custom"][objectElement]			=	{};
			data["custom"][objectElement].x			=	Math.round($("#"+element+"_example").attr("left"));
			data["custom"][objectElement].y			=	Math.round($("#"+element+"_example").attr("top")) + parseInt($("#"+element+"_example").attr("size"));
			
			var colorElements						=	$("#"+element+"_example").css("color").replace("rgb(", "").replace(")", "").split(",");
			data["custom"][objectElement].color		=	rgbToHex(parseInt(colorElements[0].trim()), parseInt(colorElements[1].trim()), parseInt(colorElements[2].trim()));
			data["custom"][objectElement].fontfile	=	"./fonts/"+$("#"+element+"_font").val();
			data["custom"][objectElement].fontsize	=	$("#"+element+"_example").attr("size");
			data["custom"][objectElement].text		=	$("#"+element+"_text").val();
		});
		
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'createBanner',
				instanz:	instanz,
				port:		port,
				data:		JSON.stringify(data)
			},
			success: function(data)
			{
				if(data == "done")
				{
					setNotifySuccess(lang.serverbanner_created);
					OverlayButton.setButton(false);
				}
				else
				{
					setNotifyFailed(data);
				};
			}
		});
	};
	
	function componentToHex(c)
	{
		var hex = c.toString(16);
		return hex.length == 1 ? "0" + hex : hex;
	};

	function rgbToHex(r, g, b)
	{
		return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
	};
</script>