<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsMusicBot.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Has the Client the Permission
	*/
	if($user_right['success']) {
		if($user_right['data']['perm_bot_create_bot'] != $mysql_keys['perm_bot_create_bot']) {
			redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_bot_create_bot missing');
		};
	} else {
		redirectSite(REDIRECT_SERVER_ERROR);
	};
	
	/**
		Got heading
	*/
    switch($LinkInformations[2]) {
        case "botSave":
            $heading = $language['save_bot'];
            break;
		default:
			if($LinkInformations[2] === false || $LinkInformations[2] == "botCreateMain") {
				$heading = $language['create_bot'];
			} else {
				$heading = "ID: ".explode("-", $LinkInformations[2])[1];
			};
            break;
    };

	/**
	 	Get Botlist
	 */
	 $serverlist = [];
	 foreach($music_server AS $num=>$instance) {
		if(!isset($serverlist[$num])) { $serverlist[$num] = []; };
		$serverlist[$num]['list'] = getBotList($num);
		$serverlist[$num]['instance'] = $instance;
		$serverlist[$num]['instance']['i'] = $num;
		$serverlist[$num]['templates'] = [];

		if($serverlist[$num]['list']['success']) {
			foreach($serverlist[$num]['list']['data'] AS $server) {
				$serverlist[$num]['templates'][] = $server->Name;
			};
		};
	};
	print_r($serverlist);
?>

<div class="row widget-menu">
	<div class="col-md-4 left-side pl-0 pr-0">
		<ul>
			<li class="section"><h4><?php echo $language['botmanagment']; ?></h4></li>
			<li class="item <?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'botCreateMain') ? "active" : ""; ?>" data-icon="fas fa-plus" data-ttip="<?php echo $language['create']; ?>">
				<a href="#botCreateMain">
					<i class="fas fa-circle"></i>
					<span><?php echo $language['create_bot']; ?></span>
				</a>
			</li>
			<li class="section"><h4><?php echo $language['unsaved_bots']; ?></h4></li>
			<?php foreach($serverlist AS $i) {
				if(!$i['list']['success']) { continue; };

				foreach($i['list']['data'] AS $bot) {
					if(empty($bot->Name)) { ?>
						<li class="item <?php echo ($LinkInformations[2] == "bot-".$bot->Id) ? "active" : ""; ?>" data-icon="far fa-save" data-ttip="<?php echo $language['save']; ?>">
							<a href="#bot-<?php echo $bot->Id; ?>">
								<i class="fas fa-circle"></i>
								<span>ID: <?php echo $bot->Id; ?></span>
							</a>
						</li>
					<?php };
				};
			}; ?>
		</ul>
	</div>
	<div class="col-md-8 right-side">
		<div class="header-content">
			<a href="#"><i class="fas fa-ellipsis-h"></i></a>
			<h3 class="color-header"><?php echo $heading; ?></h3>
			<a href="#" id="save-settings" data-toggle="tooltip" data-placement="left" title="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'botCreateMain') ? $language['create'] : $language['save']; ?>"><i class="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'botCreateMain') ? 'fas fa-plus' : 'far fa-save'; ?>"></i></a>
		</div>
		<div class="right-side-content">
			<div class="tab-content">
				<div id="botCreateMain" class="<?php echo ($LinkInformations[2] == false || $LinkInformations[2] == 'botCreateMain') ? "active" : ""; ?>">
					<div class="alert alert-table form">
						<div class="alert-table mb-3 color-light" style="height: auto;">
							<i class="fas fa-info-circle"></i>
							<span><?php echo $language['ts3_lizenz_info']; ?></span>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['in_instance']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['instance']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<select id="instance-create" class="form-control form-control-sm">
									<?php foreach($music_server AS $instanz=>$server) {
										if($server['alias'] != '') {
											echo '<option value="' . $instanz . '">' . $server['alias'] . '</option>';
										} else {
											echo '<option value="' . $instanz . '">' . $server['ip'] . '</option>';
										};
									}; ?>
								</select>
								<small class="form-text text-muted"><?php echo $language['in_instance_info']; ?></small>
							</div>
						</div>
						<hr class="hr-headline"/>
						<div class="row mr-0 ml-0">
							<h6 class="col-lg-12 color-light mt-2"><?php echo $language['informations']; ?></h6>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['ip_adress']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="ip-connect" class="form-control form-control-sm" type="text">
									<small class="form-text text-muted"><?php echo $language['ip_adress_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="port-connect" class="form-control form-control-sm" type="number" value="9987">
									<small class="form-text text-muted"><?php echo $language['port_info']; ?></small>
								</div>
							</div>
						</div>
						<div class="row mr-0 ml-0">
							<label class="col-lg-4 form-label color-light"><?php echo $language['password']; ?>:</label>
							<div class="col-lg-8 col-xl-4">
								<div class="form-group">
									<input id="password-connect" class="form-control form-control-sm" type="password">
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php foreach($serverlist AS $i) {
					if(!$i['list']['success']) { continue; };
					
					foreach($i['list']['data'] AS $bot) {
						if(empty($bot->Name)) { ?>
							<div id="bot-<?php echo $bot->Id; ?>" class="<?php echo ($LinkInformations[2] == 'bot-'.$bot->Id) ? "active" : ""; ?>">
								<div class="alert alert-table form">
									<div class="row mr-0 ml-0">
										<h6 class="col-lg-12 color-light mt-2"><?php echo $language['in_instance']; ?></h6>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light">ID:</label>
										<span class="col-lg-8 col-xl-4 color-success">
											<?php echo $bot->Id; ?>
										</span>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['instance']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<select disabled class="form-control form-control-sm in-instance">
												<?php echo '<option value="' . $i['instance']['i'] . '">' . xssSafe($i['instance']['alias']) . '</option>'; ?>
											</select>
											<small class="form-text text-muted"><?php echo $language['in_instance_info']; ?></small>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['used_bots']; ?>:</label>
										<span class="col-lg-8 col-xl-4 color-danger">
											<?php if(!empty($i['templates'])) {
												foreach($i['templates'] AS $a=>$template) {
													echo ($a >= (count($template) - 1)) ? $template : $template.', ';
												};
											}; ?>
										</span>
									</div>
									<hr class="hr-headline"/>
									<div class="row mr-0 ml-0">
										<h6 class="col-lg-12 color-light mt-2"><?php echo $language['informations']; ?></h6>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['template']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input class="form-control form-control-sm template" type="text">
												<small class="form-text text-muted"><?php echo $language['ts3_choose_port_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['ip_adress']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input class="form-control form-control-sm ip-address" disabled type="text" value="<?php xssEcho(explode(":", $bot->Server)[0]); ?>">
												<small class="form-text text-muted"><?php echo $language['ip_adress_info']; ?></small>
											</div>
										</div>
									</div>
									<div class="row mr-0 ml-0">
										<label class="col-lg-4 form-label color-light"><?php echo $language['port']; ?>:</label>
										<div class="col-lg-8 col-xl-4">
											<div class="form-group">
												<input class="form-control form-control-sm port" disabled type="number" value="<?php xssEcho(explode(":", $bot->Server)[1]); ?>">
												<small class="form-text text-muted"><?php echo $language['port_info']; ?></small>
											</div>
										</div>
									</div>
								</div>
							</div>
						<?php };
					};
				}; ?>
			</div>
		</div>
	</div>
</div>

<script>
	/**
		Save changed settings
	*/
	$('a#save-settings').click(function(e) {
		var el = $(this);
		var link = $('li.item.active > a').attr('href');
		e.preventDefault();
		
		if(el.hasClass('disabled')) {
			return;
		};
		
		el.addClass('disabled');
		
		switch(link) {
			case '#botCreateMain':
				var data = {};
				var instance = null;
				var template = false;
				
				$('.tab-content > #botCreateMain select').each(function() {
					var el = $(this);
					var val = el.val();
					var id = el.attr('id');
					
					if(id === 'instance-create') {
						instance = val;
					};
				});
				
				$('.tab-content > #botCreateMain input').each(function() {
					var el = $(this);
					var val = el.val();
					var id = el.attr('id').split('-')[0];
					
					if(el.attr('type') !== 'checkbox') {
						data[id] = val;
					};
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsMusicBotPost.php",
					data: {
						action: 'connectTeamspeakBot',
						instance: instance,
						ip: data.ip,
						port: data.port,
						password: data.password
					},
					success: function(data){
						var info = JSON.parse(data);
						if(info.success) {
							new Notification({
								message : lang.musicbot_created,
								icon: 'far fa-edit',
								type : 'success'
							}).show();
							changeContent('web_musicbot_server_create');
						} else {
							new Notification({
								message : info.error[0],
								icon: 'far fa-edit',
								type : 'danger'
							}).show();
						};
						el.removeClass('disabled');
					}
				});
				break;
			case '#templateDefault':
				var data = {};
				$('.tab-content > div.active input, .tab-content > div.active select, .tab-content > div.active textarea').each(function() {
					var el = $(this);
					var val = el.val();
					var id = el.attr('id').split('-')[0];
					
					if(el.attr('type') === 'checkbox') {
						val = (el.prop('checked')) ? '1' : '0';
					};
					
					data[id] = val;
				});
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'updateDefaultTemplate',
						data: JSON.stringify(data)
					},
					success: function(data) {
						console.log(data);
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.template_update_success,
									icon: 'far fa-save',
									type : 'success'
								}).show();
								changeContent('web_teamspeak_server_create');
							}, 3000);
						} else {
							new Notification({
								message : info.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
							el.removeClass('disabled');
						};
					}
				});
				break;
			default:
			case '#templateCreate':
				var id = ($('.tab-content > div.active .template-id').length) ? $('.tab-content > div.active .template-id').text() : false;
				var data = {};
				var status = true;
				$('.tab-content > div.active input, .tab-content > div.active select, .tab-content > div.active textarea').each(function() {
					var el = $(this);
					var id = el.attr('id').split('-')[0];
					var val = el.val();
					
					if(el.attr('type') === 'checkbox') {
						val = (el.prop('checked')) ? '1' : '0';
					};
					
					if(id === 'templatename') {
						status = (val != '');
						(status) ? isSuccess('#'+$(this).attr('id'), '') : isError('#'+$(this).attr('id'), lang.field_cant_be_empty);
					};
					
					data[id] = val;
				});
				
				if(!status) {
					el.removeClass('disabled');
					return;
				};
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsPost.php",
					data: {
						action: 'updateTemplate',
						id: id,
						data: JSON.stringify(data)
					},
					success: function(data) {
						var info = JSON.parse(data);
						
						if(info.success) {
							setTimeout(function() {
								new Notification({
									message : lang.template_update_success,
									icon: 'far fa-save',
									type : 'success'
								}).show();
								changeContent('web_teamspeak_server_create');
							}, 3000);
						} else {
							new Notification({
								message : info.error,
								icon: 'far fa-save',
								type : 'danger'
							}).show();
							el.removeClass('disabled');
						};
					}
				});
				break;
		};
	});
</script>