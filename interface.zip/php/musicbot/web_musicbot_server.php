 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsMusicBot.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		JavaScript Data
	*/
	$onlineServer = [];
?>

<div class="content-header color-header"><?php echo $language['serverlist']; ?></div>

<?php foreach($music_server AS $num=>$instance) {
	$serverlist = getBotList($num);
	$data = ($serverlist['success']) ? $serverlist['data'] : $serverlist['error'];
	
	if($serverlist['success']) {
		$onlineServer[$num] = $data;
		$server = $data[0];
		if(isset($server->Id)) {
			$info = executeBotCommand($num, $server->Id, '/bot/info/client');
			print_r(executeBotCommand($num, $server->Id, '/song'));
		} else {
			$info = false;
		};
	}; ?>
	<div class="mb-3 shadow-default-content big-card" data-instance="<?php echo $num; ?>">
		<div class="big-card-header" data-status="<?php echo ($serverlist['success'] && $server->Status == 2) ? 'online' : 'offline'; ?>">
			<div>
				<span><i class="fas fa-robot"></i></span>
				<h3><?php xssEcho(empty($instance['alias']) ? $instance['ip'] : $instance['alias']); ?></h3>
			</div>
			<div style="display: <?php echo ($serverlist['success'] && count($data) > 1) ? 'flex' : 'none'; ?>;">
				<button class="btn btn-grey btn-grey-left" data-action="prev"><i class="fas fa-angle-left"></i></button>
				<button class="btn btn-grey btn-grey-right" data-action="next"><i class="fas fa-angle-right"></i></button>
			</div>
		</div>
		<?php if($serverlist['success']) { ?>
			<div class="row m-0 big-card-content">
				<div class="col widget border-right">
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['template']; ?></h3>
							</div>
							<div class="col text-right text-template">
								<?php xssEcho($server->Name); ?>
							</div>
						</div>
					</div>
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['server_ip']; ?></h3>
							</div>
							<div class="col text-right text-server">
								<?php xssEcho($server->Server); ?>
							</div>
						</div>
					</div>
				</div>
				<div class="col widget border-right">
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['name']; ?></h3>
							</div>
							<div class="col text-right text-name">
								<?php xssEcho(($info['success']) ? $info['data']->Name : $info['error'][0]); ?>
							</div>
						</div>
					</div>
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['version']; ?></h3>
							</div>
							<div class="col text-right text-clients">
								<?php echo ($info['success']) ? preg_replace("/\[.*/", "", $info['data']->ClientVersion).'@ '.$info['data']->ClientPlatform : $info['error'][0]; ?>
							</div>
						</div>
					</div>
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['connections']; ?></h3>
							</div>
							<div class="col text-right text-clients">
								<?php echo ($info['success']) ? $info['data']->TotalConnections : $info['error'][0]; ?>
							</div>
						</div>
					</div>
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['channel_id']; ?></h3>
							</div>
							<div class="col text-right text-clients">
								<?php echo ($info['success']) ? $info['data']->ChannelId : $info['error'][0]; ?>
							</div>
						</div>
					</div>
				</div>
				<div class="col widget">
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['status']; ?></h3>
							</div>
							<div class="col text-right text-clients">
								<?php switch($server->Status) {
									case 2:
										echo $language['online'];
										break;
									case 0:
										echo $language['offline'];
										break;
									default:
										echo $language['unknown'];
										break;
								}; ?>
							</div>
						</div>
					</div>
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header">ID</h3>
							</div>
							<div class="col text-right text-clients">
								<?php echo ($info['success']) ? $server->Id : $info['error'][0]; ?>
							</div>
						</div>
					</div>
					<div class="color-content-body widget-item">
						<div class="row row-center">
							<div class="col">
								<h3 class="color-header"><?php echo $language['client_database_id']; ?></h3>
							</div>
							<div class="col text-right text-clients">
								<?php echo ($info['success']) ? $info['data']->DatabaseId : $info['error'][0]; ?>
							</div>
						</div>
					</div>
					<div class="color-content-body widget-item">
						<div class="btn-group">
							<button class="btn btn-green" data-action="start"><i class="fas fa-play mr-2"></i><?php echo $language['server_start']; ?></button>
							<button class="btn btn-red" data-action="stop"><i class="fas fa-stop mr-2"></i><?php echo $language['server_stop']; ?></button>
						</div>
						<div class="btn-group">
							<button class="btn btn-red" <?php echo ($info['success']) ? "" : "disabled"; ?>><i class="fas fa-trash-alt mr-2"></i><?php echo $language['delete_server']; ?></button>
							<button class="btn btn-blue" <?php echo ($info['success']) ? "" : "disabled"; ?>><i class="fas fa-eye mr-2"></i><?php echo $language['details']; ?></button>
						</div>
					</div>
				</div>
			</div>
			<div class="row m-0 big-card-content">
				<div class="col widget border-top">
					<ul class="nav nav-tabs bot-tabs" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" data-toggle="tab" href="#music" role="tab"><i class="far fa-play-circle d-block mb-3"></i><span class="d-block">Music</span></span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#plugins" role="tab"><i class="fas fa-puzzle-piece d-block mb-3"></i><span class="d-block">Plugins</span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#settings" role="tab"><i class="fas fa-cogs d-block mb-3"></i><span class="d-block">Contact</span></a>
						</li>
					</ul>
					<div class="tab-content bot-tabs-content">
					<div class="tab-pane fade show active form" id="music" role="tabpanel">
						<div class="music-player">
							<div class="top">
								<i class="fas fa-bars"></i>
								<i class="fas fa-search"></i>
							</div>
							<div class="middle">
								<div class="row m-0">
									<div class="col-md-6 col-xs-12">
										<div class="details">
											<div></div>
											<h2>My Song Name</h2>
											<h3>Künstler</h3>
										</div>
									</div>
									<div class="col-md-6 col-xs-12 playlist p-0">
										Test
									</div>
								</div>
								<div class="bars">
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
									<div></div>
								</div>
							</div>
							<div class="bottom">
								<div class="options">
									<i class="fas fa-random active"></i>
									<i class="fas fa-random"></i>
								</div>
								<div class="playbar">
									<div class="inner"></div>
									<div class="times">
										<span>0:00</span>
										<span>3:45</span>
									</div>
								</div>
								<div class="controls">
									<i class="fas fa-step-backward"></i>
									<i class="fas fa-play-circle"></i>
									<i class="fas fa-step-forward"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="plugins" role="tabpanel">test2</div>
					<div class="tab-pane fade" id="settings" role="tabpanel">test3</div>
					</div>
				</div>
			</div>
		<?php } else { ?>
			<div class="row m-0 big-card-content">
				<p class="col text-danger"><?php echo $data[0]; ?></p>
			</div>
		<?php }; ?>
	</div>
<?php }; ?>

<script src="js/chart/chartist.js"></script>
<script>
	/**
		Serverlist object
	*/
	;(function(window) {
		'use strict';
		
		/**
			Constructor
		*/
		function Botlist(options) {
			var maxTrys = 3;
			var selected = {
				id: 0,
				server: null
			};
			var el = $('div[data-instance="'+options.instance+'"');
			var $this = this;
			
			this.options = extend({ }, this.options);
			extend(this.options, options);
			_init();
			
			/**
				Constructor initial
			*/
			function _init() {
				selected.server = $this.options.botlist[0];
				_initButtons();
			};
			
			/**
				Button handlers
			*/
			function _initButtons() {
				$('[data-action="prev"]', el).click(function() {
					$('.big-card-header button').prop('disabled', true);
					if(--selected.id < 0) {
						selected.id = $this.options.botlist.length - 1;
					};
					_changeServer();
				});
				
				$('[data-action="next"]', el).click(function() {
					$('.big-card-header button').prop('disabled', true);
					if(++selected.id > ($this.options.botlist.length - 1)) {
						selected.id = 0;
					};
					_changeServer();
				});
				
				$('.btn-group > button', el).click(function() {
					var action = $(this).attr('data-action');
					
					switch(action) {
						case 'start':
							if($('.big-card-header', el).attr('data-status') === "online") {
								new Notification({
									message : lang.server_is_running,
									icon: 'fas fa-play',
									type : 'danger'
								}).show();
								return;
							};

							$.ajax({
								type: "POST",
								url: "./php/functions/functionsMusicBotPost.php",
								data: {
									action: 'startTeamspeakBot',
									instance: $this.options.instance,
									template: selected.server.Name
								},
								success: function(data){
									var info = JSON.parse(data);
									
									if(info.success) {
										$('.big-card-header', el).attr('data-status', 'online');
										selected.server = info.data;
									} else {
										new Notification({
											message : info.error[0],
											icon: 'fas fa-play',
											type : 'danger'
										}).show();
										console.error('Cant start server '+$this.options.instance+': '+info.error[0]);
									};
								}
							});
							break;
						case 'stop':
							$.ajax({
								type: "POST",
								url: "./php/functions/functionsMusicBotPost.php",
								data: {
									action: 'stopTeamspeakBot',
									instance: $this.options.instance,
									bid: selected.server.Id
								},
								success: function(data){
									var info = JSON.parse(data);
									console.log(info);
									if(info.success) {
										$('.big-card-header', el).attr('data-status', 'offline');
									} else {
										new Notification({
											message : info.error[0],
											icon: 'fas fa-stop',
											type : 'danger'
										}).show();
										console.error('Cant stop server '+$this.options.instance+': '+info.error[0]);
									};
								}
							});
							break;
					};
				});
			};
			
			/**
				Change serverlist server
			*/
			function _changeServer() {
				selected.server = $this.options.botlist[selected.id];
				
				$.ajax({
					type: "POST",
					url: "./php/functions/functionsMusicBotPost.php",
					data: {
						action: 'getBotInfo',
						instance: $this.options.instance,
						bid: selected.server.Id
					},
					success: function(data){
						var info = JSON.parse(data);
						console.log(info);
						//return;
						if(info.success) {
							var data = info.data;
							
							$('.text-template', el).text(data.Name);
							$('.text-server', el).text(data.Ip);
							$('.text-name', el).text(data.Name);
							
							/*$('.big-card-header', el).attr('data-status', (data.virtualserver_status == 'online') ? 'online' : 'offline');
							$('.col > .header > .title.text-name', el).text(data.virtualserver_name);
							$('.chart-inside', el).text(percent+'%');
							$('.big-card-content img', el).attr('src', data.virtualserver_hostbanner_gfx_url);*/
							
							flashText($('.text-template', el));
							flashText($('.text-server', el));
							flashText($('.text-name', el));
							
							$('.big-card-header button').prop('disabled', false);
						} else {
							if(maxTrys > 0) {
								maxTrys--;
								if(--selected.id < 0) {
									selected.id = $this.options.serverlist.length - 1;
								};
								_changeServer();
								return;
							};
							
							maxTrys = 3;
							var error = (info.error === undefined) ? lang.default_error : info.error;
							
							$('.big-card-header', el).attr('data-status', 'offline');
							$('.big-card-content', el).replaceWith('<div class="row m-0"><p class="col text-danger">'+error+'</p></div>');
							console.error('Cant update serverlist '+$this.options.instance+': '+error);
						};
					}
				});
			};
		}
		
		/**
			Options from outside
		*/
		Botlist.prototype.options = {
			instance: 0,
			serverlist: { }
		}
		
		/**
			global namespaces
		*/
		window.Botlist = Botlist;
	})(window);
	
	/**
		Create botlist objects
	*/
	var list = JSON.parse('<?php echo json_encode($onlineServer); ?>');
	for(var num in list) {
		new Botlist({
			instance: num,
			botlist: list[num]
		});
	};
</script>
<script src="js/webinterface/teamspeak.js"></script>