<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Fehlerheader
	*/
	header("HTTP/1.0 404 Not Found");
	
	/*
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../../php/functions/functions.php");
	
	/*
		Check the Prefix
	*/
	$phpself				=	explode("/", $_SERVER['PHP_SELF']);
	$redirectUrl			=	explode("/", $_SERVER['REDIRECT_URL']);
	$count					=	-2;
	$countStart				=	false;
	$prefix					=	"";
	
	foreach($redirectUrl AS $index => $content)
	{
		if($phpself[$index] == "php" && !$countStart)
		{
			$countStart 	=	true;
		};
		
		if($countStart && strpos($content, ".") === false && $content != "")
		{
			$prefix			.=	"../";
		};
	};
?>

<!DOCTYPE HTML SYSTEM>
<html lang="en" class="custom-bg">
	<head>
		<title><?php echo xssSafe(HEADING)." -- Teamspeak3 Control Panel -- 404 Error -- Site not found"; ?></title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=0.8, minimum-scale=0.8, maximum-scale=0.8, shrink-to-fit=no">
		<meta name="author" content="First Coder: L.Gmann">
		
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Courgette|Kreon">
		
		<link rel="stylesheet" type="text/css" href="<?php echo $prefix; ?>css/other/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $prefix; ?>css/other/dropzone.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $prefix; ?>css/bootstrap/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo $prefix; ?>css/style.css" />
		
		<script src="<?php echo $prefix; ?>js/jquery/jquery.min.js"></script>
		<script src="<?php echo $prefix; ?>js/other/tether.js"></script>
		<script src="<?php echo $prefix; ?>js/other/functions.js"></script>
		<script src="<?php echo $prefix; ?>js/other/navigation.js"></script>
		<script src="<?php echo $prefix; ?>js/bootstrap/bootstrap-material-design.iife.js"></script>
	</head>
	<body>
		<!-- Header -->
		<nav class="navbar">
			<span class="navbar-brand nav-title"><?php xssEcho(HEADING); ?></span>
			<ul class="nav nav-inline navbar-left" style="text-align: right;">
				<li class="nav-item">
					<a class="nav-link" href="<?php echo (!empty($prefix)) ? $prefix."/" : ""; ?>index.php">
						<i class="material-icons">chevron_left</i> <span class="nav-linktext"><?php echo $language['back']; ?></span>
					</a>
				</li>
			</ul>
		</nav>
		
		<!-- Content -->
		<div class="jumbotron-main">
			<div class="jumbotron jumbotron-fluid">
				<div class="container-fluid">
					<ol class="breadcrumb icon-home icon-angle-right no-bg showOnLogged breadline">
						<li>Unknown Page</li>
						<li>404 - Error</li>
					</ol>
				</div>
			</div>
		</div>
		
		<div class="col-xs-12 main">
			<div class="page-on-top">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-xl-12">
						<div class="card-block-header">
							<h4 class="card-title"><i class="fa fa-warning"></i> Ups......</h4>
							<h6 class="card-subtitle text-muted">404 Error | Page not Found</h6>
						</div>
						<hr class="hr-headline"/>
						<p><?php echo $language['site_not_found_info']; ?></p>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Footer -->
		<div id="footer" class="jumbotron-main">
			<div class="jumbotron jumbotron-fluid">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-4">
							<div class="footer-background">
								<ul class="list-group footer-color-light">
									<li class="list-group-item">
										<p class="list-group-item-heading footer-headline"><i class="fa fa-thumbs-up" aria-hidden="true"></i> <?php echo "Speziellen Dank"; ?></p>
									</li>
									<div class="footer-border ml-2 mr-2"></div>
									<li class="list-group-item">
										ghostrider
										<span class="tag tag-secondary tag-pill pull-xs-right">Projektmanager</span>
									</li>
									<li class="list-group-item">
										L. Gmann
										<span class="tag tag-secondary tag-pill pull-xs-right">Entwickler</span>
									</li>
									<li class="list-group-item">
										angeloccrr
										<span class="tag tag-secondary tag-pill pull-xs-right">Designer</span>
									</li>
									<li class="list-group-item">
										Splamy
										<span class="tag tag-secondary tag-pill pull-xs-right">Bot Entwickler</span>
									</li>
								</ul>
							</div>
						</div>
						<div class="offset-md-4 col-md-4" style="">
							<div class="footer-logo">
								<img style="width:300px;" src="https://first-coder.de/images/fcLogo.png"/>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
			$('body').bootstrapMaterialDesign();
		</script>
	</body>
</html>