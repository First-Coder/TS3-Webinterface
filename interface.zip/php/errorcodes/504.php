 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Set header for automated scripts
	*/
	//header("HTTP/1.0 504 Gateway Timeout");
?>

<div class="content-header color-header">504 - Gateway Timeout</div>

<div class="row shadow-default-content mb-3 widget errorcode">
	<div class="col-md-4 error-icon">
		<i class="far fa-sad-tear"></i>
	</div>
	<div class="col-md-8">
		<h4>504 - Gateway Timeout</h4>
		<p><?php echo $language['504_text_1']; ?></p>
		<p><?php echo $language['504_text_2']; ?></p>
	</div>
</div>