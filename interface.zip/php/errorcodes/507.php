 <?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Set header for automated scripts
	*/
	//header("HTTP/1.0 507 Insufficient Storage");
?>

<div class="content-header color-header">507 - Insufficient Storage</div>

<div class="row shadow-default-content mb-3 widget errorcode">
	<div class="col-md-4 error-icon">
		<i class="far fa-sad-tear"></i>
	</div>
	<div class="col-md-8">
		<h4>507 - Insufficient Storage</h4>
		<p><?php echo $language['507_text_1']; ?>:</p>
		<table class="table permission-table">
			<tbody>
				<?php if(file_exists("install")) { ?>
					<tr class="<?php echo (is_writable('install/')) ? "text-success" : "text-danger"; ?>">
						<td>/install/<p class="text-muted"><?php echo (is_writable('install/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
						<td class="icon"><i class="fa fa-<?php echo (is_writable('install/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
					</tr>
				<?php }; ?>
				<tr class="<?php echo (is_writable('config/config.php')) ? "text-success" : "text-danger"; ?>">
					<td>/config/config.php<p class="text-muted"><?php echo (is_writable('config/config.php')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('config/config.php')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('config/instance.php')) ? "text-success" : "text-danger"; ?>">
					<td>/config/instance.php<p class="text-muted"><?php echo (is_writable('config/instance.php')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('config/instance.php')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('files/')) ? "text-success" : "text-danger"; ?>">
					<td>/files/<p class="text-muted"><?php echo (is_writable('files/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('files/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('files/backups/')) ? "text-success" : "text-danger"; ?>">
					<td>/files/backups/<p class="text-muted"><?php echo (is_writable('files/backups/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('files/backups/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('images/')) ? "text-success" : "text-danger"; ?>">
					<td>/images/<p class="text-muted"><?php echo (is_writable('images/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('images/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('images/ts_icons/')) ? "text-success" : "text-danger"; ?>">
					<td>/images/ts_icons/<p class="text-muted"><?php echo (is_writable('images/ts_icons/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('images/ts_icons/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('images/ts_banner/')) ? "text-success" : "text-danger"; ?>">
					<td>/images/ts_banner/<p class="text-muted"><?php echo (is_writable('images/ts_banner/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('images/ts_banner/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('logs/')) ? "text-success" : "text-danger"; ?>">
					<td>/logs/<p class="text-muted"><?php echo (is_writable('logs/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('logs/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('logs/system.log')) ? "text-success" : "text-danger"; ?>">
					<td>/logs/system.log<p class="text-muted"><?php echo (is_writable('logs/system.log')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('logs/system.log')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr class="<?php echo (is_writable('logs/user.log')) ? "text-success" : "text-danger"; ?>">
					<td>/logs/user.log<p class="text-muted"><?php echo (is_writable('logs/user.log')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('logs/user.log')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
				<tr style="border-bottom: 0;" class="<?php echo (is_writable('updater/')) ? "text-success" : "text-danger"; ?>">
					<td>/updater/<p class="text-muted"><?php echo (is_writable('updater/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
					<td class="icon"><i class="fa fa-<?php echo (is_writable('updater/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>