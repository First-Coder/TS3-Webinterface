<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-key"></i> <?php echo $language['login']; ?></h4>
					<h6 class="card-subtitle text-muted">Teamspeak 3 Interface</h6>
				</div>
				<hr class="hr-headline"/>
				<div class="form-group">
					<label><?php echo $language['mail']; ?></label>
					<input id="loginUser" type="email" class="form-control">
					<small class="form-control-feedback"></small>
				</div>
				<div id="pwElement" class="form-group">
					<label><?php echo $language['password']; ?></label>
					<input id="loginPw" type="password" class="form-control">
					<small class="form-control-feedback"></small>
				</div>
				
				<button onClick="loginUser();" id="loginBtn" class="btn btn-success mt-3 w-100-percent"><i class="fa fa-paper-plane"></i> <?php echo $language['login']; ?></button>
				<?php if(USE_MAILS == "true") { ?>
					<button onClick="goToForgot();" id="forgotBtn" class="btn btn-outline-warning mt-2 w-100-percent"><i class="fa fa-question"></i> <?php echo $language['forgot_access']; ?></button>
				<?php }; ?>
			</div>
		</div>
	</div>
</div>

<script src="js/webinterface/login.js"></script>
<script>
	validateOnChange('#loginUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#loginPw', {
		required: true
	}, '', lang.field_cant_be_empty);
	
	/*
		Forget Password funtions
	*/
	var pwElement	=	$("#pwElement"),
		btnLogin	=	$("#loginBtn"),
		btnForgot	=	$("#forgotBtn");
	
	function goBack()
	{
		pwElement.css("visibility", "visible");
		
		btnLogin.removeClass("btn-warning");
		btnLogin.addClass("btn-success");
		btnLogin.html("<i class=\"fa fa-paper-plane\"></i> "+lang.login);
		btnLogin.attr("onClick", "loginUser();")
		
		btnForgot.removeClass("btn-outline-info");
		btnForgot.addClass("btn-outline-warning");
		btnForgot.html("<i class=\"fa fa-question\"</i> "+lang.forgot_access);
		btnForgot.attr("onClick", "goToForgot();");
	};
	
	function goToForgot()
	{
		pwElement.css("visibility", "hidden");
		
		btnLogin.removeClass("btn-success");
		btnLogin.addClass("btn-warning");
		btnLogin.html("<i class=\"fa fa-question\"></i> "+lang.forgot_access);
		btnLogin.attr("onClick", "forgotPassword();");
		
		btnForgot.removeClass("btn-outline-warning");
		btnForgot.addClass("btn-outline-info");
		btnForgot.html("<i class=\"fa fa-arrow-left\"</i> "+lang.back);
		btnForgot.attr("onClick", "goBack();");
	};
</script>