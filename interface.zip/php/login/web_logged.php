<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../config/instance.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../../php/functions/functions.php");
	require_once(__dir__."/../../php/functions/functionsSql.php");
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys				=	getKeys();
	
	/*
		Get Client Permissions
	*/
	$user_right				=	getUserRights('pk', $_SESSION['user']['id']);
?>

<?php $areaPermission		=	($user_right["right_hp_main"]["key"] == $mysql_keys["right_hp_main"] || $user_right["right_hp_ts3"]["key"] == $mysql_keys["right_hp_ts3"] ||
								$user_right["right_hp_user_edit"]["key"] == $mysql_keys["right_hp_user_edit"] || $user_right["right_hp_user_create"]["key"] == $mysql_keys["right_hp_user_create"] || 
								$user_right["right_hp_user_delete"]["key"] == $mysql_keys["right_hp_user_delete"] || $user_right["right_hp_mails"]["key"] == $mysql_keys["right_hp_mails"] ||
								$user_right["right_hp_logs"]["key"] == $mysql_keys["right_hp_logs"]); ?>
<div class="section-title settingsarea"><?php echo $language['global_settings']; ?></div>
<ul class="list-unstyled settingsarea">
	<li>
		<?php $permission	=	$user_right["right_hp_main"]["key"] == $mysql_keys["right_hp_main"]; ?>
		<button class="btn btn-flat adminSettings <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_admin_settings');closeSideMenu();return false;" : ""; ?>">
			<?php if(INTERFACE_VERSION != checkNewVersion(false) && $permission) { ?>
				<span class="tag tag-rounded tag-danger tag-sm">1</span>
			<?php }; ?>
			<span class="btn-title"><?php echo $language['settings']; ?></span>
			<i class="material-icons pull-left icon">settings</i>
		</button>
	</li>
	<li>
		<?php $permission	=	$user_right["right_hp_ts3"]["key"] == $mysql_keys["right_hp_ts3"]; ?>
		<button class="btn btn-flat adminInstanz <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_admin_instanz');closeSideMenu();return false;" : ""; ?>">
			<span class="tag tag-rounded tag-<?php echo (count($ts3_server) == 0 && $permission) ? "danger" : "success"; ?> tag-sm"><?php echo count($ts3_server); ?></span>
			<span class="btn-title"><?php echo $language['instances']; ?></span>
			<i class="material-icons pull-left icon">add_to_queue</i>
		</button>
	</li>
	<li>
		<?php $permission	=	($user_right["right_hp_user_edit"]["key"] == $mysql_keys["right_hp_user_edit"] || $user_right["right_hp_user_create"]["key"] == $mysql_keys["right_hp_user_create"] || $user_right["right_hp_user_delete"]["key"] == $mysql_keys["right_hp_user_delete"]); ?>
		<button class="btn btn-flat adminUser <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_admin_user');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['client']; ?></span>
			<i class="material-icons pull-left icon">people</i>
		</button>
	</li>
	<?php if(USE_MAILS == "true") { ?>
		<?php $permission	=	$user_right["right_hp_mails"]["key"] == $mysql_keys["right_hp_mails"]; ?>
		<li>
			<button class="btn btn-flat adminMail <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_admin_mail');closeSideMenu();return false;" : ""; ?>">
				<span class="btn-title"><?php echo $language['mail_settings']; ?></span>
				<i class="material-icons pull-left icon">inbox</i>
			</button>
		</li>
	<?php }; ?>
	<li>
		<?php $permission	=	$user_right["right_hp_logs"]["key"] == $mysql_keys["right_hp_logs"]; ?>
		<button class="btn btn-flat adminLogs <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_admin_logs');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['logs']; ?></span>
			<i class="material-icons pull-left icon">archive</i>
		</button>
	</li>
</ul>

<?php $areaPermission		=	($user_right["right_web"]["key"] == $mysql_keys["right_web"] || $user_right["right_web_server_create"]["key"] == $mysql_keys["right_web_server_create"]); ?>
<div class="section-title webinterfacearea <?php echo ($areaPermission) ? "": "no-display"; ?>"><?php echo $language['interface']; ?></div>
<ul class="list-unstyled webinterfacearea <?php echo ($areaPermission) ? "": "no-display"; ?>">
	<li>
		<?php $permission	=	$user_right["right_web"]["key"] == $mysql_keys["right_web"]; ?>
		<button class="btn btn-flat teamspeakServer <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_teamspeak_server');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['server']; ?></span>
			<i class="material-icons pull-left icon">list</i>
		</button>
	</li>
	<li>
		<?php $permission	=	$user_right["right_web_server_create"]["key"] == $mysql_keys["right_web_server_create"]; ?>
		<button class="btn btn-flat teamspeakServerCreate <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_teamspeak_server_create');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['create_server']; ?></span>
			<i class="material-icons pull-left icon">create</i>
		</button>
	</li>
	<?php if(count(scandir(__DIR__."/../../files/wantServer/")) > 2) { ?>
		<li id="naviWantServer">
			<button class="btn btn-flat teamspeakServerRequests <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeContent('web_teamspeak_server_requests');closeSideMenu();return false;" : ""; ?>">
				<span class="tag tag-rounded tag-success tag-sm tag-server-request"><?php echo (count(scandir(__DIR__."/../../files/wantServer/")) - 2); ?></span>
				<span class="btn-title"><?php echo $language['server_requests']; ?></span>
				<i class="material-icons pull-left icon">assignment</i>
			</button>
		</li>
	<?php }; ?>
</ul>

<div class="section-title"><?php echo $language['ticket_system']; ?></div>
<ul class="list-unstyled">
	<li>
		<button class="btn btn-flat" onClick="changeContent('web_ticket');closeSideMenu();return false;">
			<span class="btn-title"><?php echo $language['tickets']; ?></span>
			<i class="material-icons pull-left icon">sms</i>
		</button>
	</li>
</ul>