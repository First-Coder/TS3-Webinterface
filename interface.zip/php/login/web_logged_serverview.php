<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__dir__."/../../lang/lang.php");
	require_once(__dir__."/../../php/functions/functions.php");
	require_once(__dir__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys				=	getKeys();
	$mysql_modul			=	getModuls();
	
	/*
		Variables
	*/
	$LoggedIn				=	(checkSession()) ? true : false;
	$LinkInformations		=	getLinkInformations();
	
	/*
		Get Client Permissions
	*/
	$user_right				=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Teamspeak Functions
	*/
	$tsAdmin = new ts3admin($ts3_server[$LinkInformations['instanz']]['ip'], $ts3_server[$LinkInformations['instanz']]['queryport']);
	
	if($tsAdmin->getElement('success', $tsAdmin->connect()))
	{
		$tsAdmin->login($ts3_server[$LinkInformations['instanz']]['user'], $ts3_server[$LinkInformations['instanz']]['pw']);
		$tsAdmin->selectServer($LinkInformations['sid'], 'serverId', true);
		
		$server 			= 	$tsAdmin->serverInfo();
		
		getTeamspeakIcons($tsAdmin, $server['data']['virtualserver_port'], $ts3_server[$LinkInformations['instanz']]['ip'], $ts3_server[$LinkInformations['instanz']]['queryport'], $ts3_server[$LinkInformations['instanz']]['user'], $ts3_server[$LinkInformations['instanz']]['pw']);
	}
	else
	{
		reloadSite(RELOAD_TO_MAIN);
	};
?>

<div class="section-title"><?php xssEcho($server['data']['virtualserver_name']); ?></div>
<ul class="list-unstyled">
	<li>
		<button class="btn btn-flat" onClick="<?php echo "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_serverview');closeSideMenu();return false;"; ?>">
			<span class="btn-title"><?php echo $language['server_overview']; ?></span>
			<i class="material-icons pull-left icon">remove_red_eye</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_banner') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakBanner <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_serverbanner');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['serverbanner']; ?></span>
			<i class="material-icons pull-left icon">card_membership</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_protokoll') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakProtokol <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_serverprotokol');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['protokoll']; ?></span>
			<i class="material-icons pull-left icon">list</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_mass_actions') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakMassActions <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_servermassactions');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['mass_actions']; ?></span>
			<i class="material-icons pull-left icon">people</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_icons') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakIcons <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_servericons');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['icons']; ?></span>
			<i class="material-icons pull-left icon">picture_in_picture</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_clients') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakClients <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_serverclients');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['client']; ?></span>
			<i class="material-icons pull-left icon">people</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_bans') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakBans <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_serverbans');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['bans']; ?></span>
			<i class="material-icons pull-left icon">block</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_token') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakToken <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_servertoken');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['token']; ?></span>
			<i class="material-icons pull-left icon">vpn_key</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_file_transfer') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakFilelist <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_serverfilelist');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['filelist']; ?></span>
			<i class="material-icons pull-left icon">attach_file</i>
		</button>
	</li>
	<li>
		<?php
			if(!isPortPermission($user_right, $LinkInformations['instanz'], $server['data']['virtualserver_port'], 'right_web_server_backups') && $user_right['right_web_global_server']['key'] != $mysql_keys['right_web_global_server'])
			{
				$permission		=	false;
			}
			else
			{
				$permission		=	true;
			};
		?>
		<button class="btn btn-flat teamspeakBackup <?php echo ($permission) ? "" : "disabled"; ?>" onClick="<?php echo ($permission) ? "changeTeamspeakContent('".$LinkInformations['sid']."', '".$LinkInformations['instanz']."', 'web_teamspeak_serverbackups');closeSideMenu();return false;" : ""; ?>">
			<span class="btn-title"><?php echo $language['backups']; ?></span>
			<i class="material-icons pull-left icon">file_upload</i>
		</button>
	</li>
</ul>