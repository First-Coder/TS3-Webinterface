<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once(__dir__."/../../config/config.php");
	require_once(__dir__."/../../lang/lang.php");
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-xl-12 form-secondary">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-plus"></i> <?php echo $language['register']; ?></h4>
					<h6 class="card-subtitle text-muted">Teamspeak 3 Interface</h6>
				</div>
				<hr class="hr-headline"/>
				<label style="font-size: 14px;"><?php echo $language['register']; ?> via</label>
				<div class="row mb-3">
					<div class="col-sm-6" style="text-align: center;">
						<button id="registerGoogle" class="btn btn-secondary btn-flash" disabled><i class="fa fa-google-plus" aria-hidden="true"></i> Google</button>
					</div>
					<div class="col-sm-6" style="text-align: center;">
						<button id="registerFacebook" class="btn btn-secondary btn-flash"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</button>
					</div>
				</div>
				<hr class="hr-headline"/>
				<div class="form-group">
					<label><?php echo $language['firstname']; ?></label>
					<input id="firstname" type="text" class="form-control">
					<small class="form-control-feedback"></small>
				</div>
				<div class="form-group">
					<label><?php echo $language['lastname']; ?></label>
					<input id="lastname" type="text" class="form-control">
					<small class="form-control-feedback"></small>
				</div>
				<div class="form-group">
					<label><?php echo $language['mail']; ?></label>
					<input id="loginUser" type="mail" class="form-control">
					<small class="form-control-feedback"></small>
				</div>
				<div class="form-group">
					<label><?php echo $language['password']; ?></label>
					<input id="loginPw" type="password" class="form-control">
					<small class="form-control-feedback"></small>
				</div>
				
				<button onClick="registerAccount();" class="btn btn-success mt-3 w-100-percent"><i class="fa fa-paper-plane"></i> <?php echo $language['register']; ?></button>
			</div>
		</div>
	</div>
</div>

<div id="fb-root"></div>
<script src="js/webinterface/login.js"></script>
<script>
	var loginData	= {
						mail:			null,
						name:			null,
						pw:				null,
						lastname:		null,
						picture:		null,
						pictureEnds:	null,
						success:		false
					};
	
	/*
		Register
	*/
	function registerAccount()
	{
		if(isDataValid('firstname') && isDataValid('lastname') && isDataValid('loginUser') && isDataValid('loginPw'))
		{
			if(loginData.picture !== null)
			{
				var picSplit					=	loginData.picture.split(".");
				loginData.pictureEnds			=	picSplit[picSplit.length - 1];
			};
			loginData.mail					=	$('#loginUser').val();
			loginData.pw					=	$('#loginPw').val();
			loginData.name					=	$('#firstname').val();
			loginData.lastname				=	$('#lastname').val();
			
			$.ajax({
				type: "POST",
				url: "./php/functions/functionsSqlPost.php",
				data: {
					action:		'createUserExtern',
					data:		JSON.stringify(loginData)
				},
				success: function(data){
					if(data == 'done')
					{
						loginUser();
					}
					else
					{
						setNotifyFailed(data);
					};
				}
			});
		};
	};
	
	/*
		Extern Register
	*/
	function setExternRegister()
	{
		$('#loginUser').val(loginData.mail);
		$('#firstname').val(loginData.name);
		$('#lastname').val(loginData.lastname);
		if(isDataValid('loginUser'))
		{
			loginData.success				=	true;
			$('#loginUser').prop("disabled", true);
			$('#firstname').prop("disabled", true);
			$('#lastname').prop("disabled", true);
		}
		else
		{
			loginData.success				=	false;
			setNotifyFailed("Facebook or Google Mail failed!");
		}
	};
	
	/*
		Google SDK
	*/
	gapi.load('auth2', function()
	{
		auth2 = gapi.auth2.init({
			client_id: '103805008302-01nld4f3nmpf0d2kroctfc8n635q74oq.apps.googleusercontent.com'
		});
		
		auth2.attachClickHandler(document.getElementById('registerGoogle'), {},
			function(googleUser)
			{
				loginData.mail				=	googleUser.getBasicProfile().U3;
				loginData.name				=	googleUser.getBasicProfile().ofa;
				loginData.lastname			=	googleUser.getBasicProfile().wea;
				loginData.picture			=	googleUser.getBasicProfile().Paa;
				
				setExternRegister();
			},
			function(error)
			{
				setNotifyFailed(error.error);
			}
		);
	});
	
	/*
		Facebook SDK
	*/
	window.fbAsyncInit = function() {
		FB.init({
			appId            : '138095353404106',
			autoLogAppEvents : true,
			xfbml            : true,
			version          : 'v2.9'
		});
	};
	
	(function() {
		var e = document.createElement('script');
		e.src = document.location.protocol + '//connect.facebook.net/en_US/all.js';
		e.async = true;
		document.getElementById('fb-root').appendChild(e);
	}());
	
	$('#registerFacebook').click(function()
	{
		FB.login(function(response)
		{
			if (response.authResponse)
			{
				FB.api('/me?fields=id,first_name,last_name,email,picture.width(100).height(100)', function(response)
				{
					loginData.mail			=	response.email;
					loginData.name			=	response.first_name;
					loginData.lastname		=	response.last_name;
					loginData.picture		=	response.picture.data.url;
					
					setExternRegister();
				});
			}
			else
			{
				setNotifyFailed("User cancelled login or did not fully authorize!");
			}
		},
		{
			scope: 'email'
		});
	});
	
	/*
		Validationcheck
	*/
	validateOnChange('#loginUser', {
		required: true,
		email: true
	}, '', lang.change_user_failed);
	validateOnChange('#loginPw', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#firstname', {
		required: true
	}, '', lang.field_cant_be_empty);
	validateOnChange('#lastname', {
		required: true
	}, '', lang.field_cant_be_empty);
</script>