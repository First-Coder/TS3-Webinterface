<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row mb-3">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-warning"></i> SOAP <?php echo $language['deactive']; ?></h4>
				</div>
				<hr class="hr-headline"/>
				<p style="text-align: center;"><?php echo $language['soap_deactive']; ?></p>
			</div>
		</div>
	</div>
</div>

<script>
	OverlayButton.setButtonClass("btn-success");
	OverlayButton.setIconClass("fa-refresh");
	OverlayButton.setTooltip(lang.refresh);
	OverlayButton.on("click", function() {
		return location.reload();
	});
	OverlayButton.start();
	OverlayButton.setButton(true);
</script>