<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
?>

<div class="col-xs-12 main">
	<div class="page-on-top">
		<div class="row mb-3">
			<div class="col-xs-12 col-sm-12 col-xl-12">
				<div class="card-block-header">
					<h4 class="card-title"><i class="fa fa-info"></i> <?php echo $language['check_permissions']; ?></h4>
					<h6 class="card-subtitle text-muted"><?php echo $language['check_permissions_info']; ?></h6>
				</div>
				<hr class="hr-headline"/>
				<table class="table permission-table">
					<tbody>
						<?php if(file_exists("install")) { ?>
							<tr class="<?php echo (is_writable('install/')) ? "text-success" : "text-danger"; ?>">
								<td>/install/<p class="text-muted"><?php echo (is_writable('install/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
								<td class="icon"><i class="fa fa-<?php echo (is_writable('install/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
							</tr>
						<?php }; ?>
						<tr class="<?php echo (is_writable('config/config.php')) ? "text-success" : "text-danger"; ?>">
							<td>/config/config.php<p class="text-muted"><?php echo (is_writable('config/config.php')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('config/config.php')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('config/instance.php')) ? "text-success" : "text-danger"; ?>">
							<td>/config/instance.php<p class="text-muted"><?php echo (is_writable('config/instance.php')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('config/instance.php')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/<p class="text-muted"><?php echo (is_writable('files/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/backups/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/backups/<p class="text-muted"><?php echo (is_writable('files/backups/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/backups/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/backups/channelname/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/backups/channelname/<p class="text-muted"><?php echo (is_writable('files/backups/channelname/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/backups/channelname/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/backups/channelnamesettings/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/backups/channelnamesettings/<p class="text-muted"><?php echo (is_writable('files/backups/channelnamesettings/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/backups/channelnamesettings/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/backups/server/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/backups/server/<p class="text-muted"><?php echo (is_writable('files/backups/server/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/backups/server/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/news/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/news/<p class="text-muted"><?php echo (is_writable('files/news/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/news/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/ticket/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/ticket/<p class="text-muted"><?php echo (is_writable('files/ticket/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/ticket/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/ticket/ticketareas.txt')) ? "text-success" : "text-danger"; ?>">
							<td>/files/ticket/ticketareas.txt<p class="text-muted"><?php echo (is_writable('files/ticket/ticketareas.txt')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/ticket/ticketareas.txt')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('files/wantServer/')) ? "text-success" : "text-danger"; ?>">
							<td>/files/wantServer/<p class="text-muted"><?php echo (is_writable('files/wantServer/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('files/wantServer/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('images/')) ? "text-success" : "text-danger"; ?>">
							<td>/images/<p class="text-muted"><?php echo (is_writable('images/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('images/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('images/ts_icons/')) ? "text-success" : "text-danger"; ?>">
							<td>/images/ts_icons/<p class="text-muted"><?php echo (is_writable('images/ts_icons/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('images/ts_icons/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('images/ts_banner/')) ? "text-success" : "text-danger"; ?>">
							<td>/images/ts_banner/<p class="text-muted"><?php echo (is_writable('images/ts_banner/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('images/ts_banner/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('logs/')) ? "text-success" : "text-danger"; ?>">
							<td>/logs/<p class="text-muted"><?php echo (is_writable('logs/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('logs/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('logs/system.log')) ? "text-success" : "text-danger"; ?>">
							<td>/logs/system.log<p class="text-muted"><?php echo (is_writable('logs/system.log')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('logs/system.log')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr class="<?php echo (is_writable('logs/user.log')) ? "text-success" : "text-danger"; ?>">
							<td>/logs/user.log<p class="text-muted"><?php echo (is_writable('logs/user.log')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('logs/user.log')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
						<tr style="border-bottom: 0;" class="<?php echo (is_writable('updater/')) ? "text-success" : "text-danger"; ?>">
							<td>/updater/<p class="text-muted"><?php echo (is_writable('updater/')) ? $language['file_folder_has_permission'] : $language['file_folder_hasnt_permission']; ?></p></td>
							<td class="icon"><i class="fa fa-<?php echo (is_writable('updater/')) ? "check" : "ban"; ?>" aria-hidden="true"></i></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<script>
	OverlayButton.setButtonClass("btn-success");
	OverlayButton.setIconClass("fa-refresh");
	OverlayButton.setTooltip(lang.refresh);
	OverlayButton.on("click", function() {
		return location.reload();
	});
	OverlayButton.start();
	OverlayButton.setButton(true);
</script>