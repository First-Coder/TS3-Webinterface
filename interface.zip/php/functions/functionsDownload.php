<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	if($_GET['action'] == 'downloadFileFromFilelist') {
		require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	};
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/*
		Get Client Permissions
	*/
	// Permissioncheck missing
	
	/**
		Download a Icon from Teamspeakserver
	*/
	if($_GET['action'] == 'downloadIconFromIconlist' && $LoggedIn) {
		echo downloadIconFromIconlist($_GET['filename'], $_GET['port'], $_GET['instance']);
	} else if($_GET['action'] == 'downloadIconFromIconlist') {
		die("No Access!");
	};
	
	/**
		Download a File from a Teamspeakserver
	*/
	if($_GET['action'] == 'downloadFileFromFilelist' && $LoggedIn) {
		echo downloadFileFromFilelist($_GET['port'], $_GET['instance'], $_GET['path'], $_GET['filename'], $_GET['cid']);
	} else if($_GET['action'] == 'downloadFileFromFilelist') {
		die("No Access!");
	};
	
	/**
		Download a Backup from a Teamspeakserver
	*/
	if($_GET['action'] == 'downloadBackup' && $LoggedIn) {
		echo downloadBackup($_GET['name']);
	} else if($_GET['action'] == 'downloadBackup') {
		die("No Access!");
	};
	
	/**
		Function to Download a Icon from Server
	*/
	function downloadIconFromIconlist($id, $port, $instance) {
		global $ts3_server;
		
		$filename = '../../images/ts_icons/'.$ts3_server[$instance]['ip'].'-'.$port.'/icon_'.$id;
		
		header('Content-Disposition: attachment; filename="'.$id.'.png"');
		header('Content-Type: x-type/subtype');
		
		return fread(fopen($filename, "r"), filesize($filename));
	};
	
	/**
		Function to Download a Backup from Server
	*/
	function downloadBackup($name) {
		$dir = "../../files/backups/";
		
		if(!file_exists($dir.$name)) {
			die("File not found");
		};
		
		$content = json_decode(file_get_contents($dir.$name));
		
		header("Content-Type: application/json");
		header("Content-Disposition: attachment; filename=\"".$content->name.".fcBackup\"");
		
		return fread(fopen($dir.$name, "r"), filesize($dir.$name));
	};
?>