<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Start session
	*/
	session_start();
	
	/**
		Create Sql Connection
		@withError: return a string as error or just a boolean
		@return: returns the pdo sql connection class
	*/
	function getSqlConnection($withError = true) {
		if(SQL_Datenbank == "") {
			return ($withError) ? "No database selected" : false;
		};

		if(SQL_Mode === "sqlite") {
			$string = SQL_Mode.':sqlite.db';
		} else {
			$string = SQL_Mode.':host='.SQL_Hostname.';port='.SQL_Port.';dbname='.SQL_Datenbank.'';
			if(SQL_SSL != "0") {
				$string .= ';sslmode=require';
			};
		};
		
		try {
			$databaseConnection = new PDO($string, SQL_Username, SQL_Password);
			return ($withError) ? true : $databaseConnection;
		} catch (PDOException $e) {
			return ($withError) ? "Failed to get DB handle: " . $e->getMessage() . "\n" : false;
		};
	};
	
	/**
		Get Sql Homepagesettings
		@return: {Array} generateOutput()
	*/
	function getSqlHomepagesettings() {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$data = $databaseConnection->query('SELECT * FROM main_settings_homepage LIMIT 1');
			if($data->rowCount() > 0 || SQL_Mode === "sqlite") {
				return generateOutput(true, null, $data->fetch(PDO::FETCH_ASSOC));
			} else {
				return generateOutput(false, 'No settings found', null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get Sql Mailsettings
		@return {Array} generateOutput()
	*/
	function getSqlMailSettings() {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$data = $databaseConnection->query('SELECT * FROM main_mails');
			if($data->rowCount() > 0 || SQL_Mode === "sqlite") {
				return generateOutput(true, null, $data->fetchAll(PDO::FETCH_ASSOC));
			} else {
				return generateOutput(false, 'No settings found', null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get Sql Own Sites
		@return {Array} generateOutput()
	*/
	function getSqlOwnSites() {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$data = $databaseConnection->query('SELECT * FROM main_settings_own_sites');
			if($data->rowCount() > 0 || SQL_Mode === "sqlite") {
				$ret = [];
				foreach($data->fetchAll(PDO::FETCH_ASSOC) AS $row) {
					$ret[$row['id']] = [];
					$ret[$row['id']]['value'] = $row['value'];
					$ret[$row['id']]['icon'] = $row['icon'];
					$ret[$row['id']]['name'] = $row['name'];
				};
				return generateOutput(true, null, $ret);
			} else {
				return generateOutput(false, 'No settings found', null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Change the edited profile of a user
		@param {string} $pk
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function updateUser($pk, $data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $mysql_keys;
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if($pk == "") {
				$pk = $_SESSION['user']['id'];
			};
			
			if(empty($data->password)) {
				$_sql = "UPDATE main_clients mc JOIN main_clients_infos mci
						ON mc.pk_client=mci.fk_clients
						SET
							firstname=:firstname,
							lastname=:lastname,
							phone=:phone,
							homepage=:homepage,
							skype=:skype,
							steam=:steam,
							twitter=:twitter,
							facebook=:facebook,
							google=:google,
							user=:user
						WHERE mci.fk_clients=:pk";
				$exec = array(
					":firstname"=>urldecode($data->firstname),
					":lastname"=>urldecode($data->lastname),
					":phone"=>urldecode($data->phone),
					":homepage"=>urldecode($data->homepage),
					":skype"=>urldecode($data->skype),
					":steam"=>urldecode($data->steam),
					":twitter"=>urldecode($data->twitter),
					":facebook"=>urldecode($data->facebook),
					":google"=>urldecode($data->google),
					":user"=>$data->user,
					":pk"=>$pk
				);
			} else {
				$_sql = "UPDATE main_clients mc JOIN main_clients_infos mci
						ON mc.pk_client=mci.fk_clients
						SET
							firstname=:firstname,
							lastname=:lastname,
							phone=:phone,
							homepage=:homepage,
							skype=:skype,
							steam=:steam,
							twitter=:twitter,
							facebook=:facebook,
							google=:google,
							user=:user,
							password=:password
						WHERE mci.fk_clients=:pk";
				$exec = array(
					":firstname"=>urldecode($data->firstname),
					":lastname"=>urldecode($data->lastname),
					":phone"=>urldecode($data->phone),
					":homepage"=>urldecode($data->homepage),
					":skype"=>urldecode($data->skype),
					":steam"=>urldecode($data->steam),
					":twitter"=>urldecode($data->twitter),
					":facebook"=>urldecode($data->facebook),
					":google"=>urldecode($data->google),
					":user"=>$data->user,
					":password"=>password_hash($data->password, PASSWORD_BCRYPT, array("cost" => 10)),
					":pk"=>$pk
				);
			};
			
			$data = $databaseConnection->prepare(trim(preg_replace('/\s+/', ' ', $_sql)));
			if ($data->execute($exec)) {
				if($_SESSION['user']['id'] == $pk && !empty($data->user)) {
					$_SESSION['user']['benutzer'] = $data->user;
				};
				writeInLog($_SESSION['user']['benutzer'], "Profile ('".$id."') will be updated!", true);
				return generateOutput(true, null, null);
			}
			else {
				writeInLog(L_ERROR, "updateUser (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Change homepage main settings
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function updateSettings($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $mysql_keys;
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$_sql = "UPDATE main_settings_homepage
					SET
						donator=:donator,
						title=:title,
						extern_name=:extern_name,
						operator=:operator,
						address=:address,
						delete_tickets=:delete_tickets,
						ts_tree_intervall=:ts_tree_intervall,
						ts_get_db_clients=:ts_get_db_clients";
			$exec = array(
				":donator"=>$data->donator,
				":title"=>urldecode($data->title),
				":extern_name"=>urldecode($data->extern_name),
				":operator"=>urldecode($data->operator),
				":address"=>urldecode($data->address),
				":delete_tickets"=>$data->delete_tickets,
				":ts_tree_intervall"=>$data->ts_tree_intervall,
				":ts_get_db_clients"=>$data->ts_get_db_clients
			);
			
			$data = $databaseConnection->prepare(trim(preg_replace('/\s+/', ' ', $_sql)));
			if ($data->execute($exec)) {
				writeInLog($_SESSION['user']['benutzer'], "changed homepage mainsettings!", true);
				return generateOutput(true, null, null);
			}
			else {
				writeInLog(L_ERROR, "updateSettings (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};

	/**
		Change homepage mail settings
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function updateMails($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $mysql_keys;
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$_sql = "UPDATE main_mails SET mail_subject=:mail_subject, mail_preheader=:mail_preheader, mail_body=:mail_body WHERE id=:id";
			
			foreach($data AS $id => $content) {
				$exec = array(
					":mail_subject"=>$content->mail_subject,
					":mail_preheader"=>$content->mail_preheader,
					":mail_body"=>$content->mail_body,
					":id"=>$id
				);
				$update = $databaseConnection->prepare($_sql);
				if (!$update->execute($exec)) {
					writeInLog(L_ERROR, "updateMails (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			};
			writeInLog($_SESSION['user']['benutzer'], "changed homepage mailsettings!", true);
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Change homepage modules
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function updateModules($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $mysql_keys;
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$_sql = "UPDATE main_modul
					SET active = CASE modul
						WHEN 'free_register' THEN :free_register
						WHEN 'free_ts3_server_application' THEN :free_ts3_server_application
						WHEN 'splamy_musicbot' THEN :splamy_musicbot
						WHEN 'support_teamspeak' THEN :support_teamspeak
						WHEN 'support_teamspeak_instance' THEN :support_teamspeak_instance
						WHEN 'support_teamspeak_port' THEN :support_teamspeak_port
					END";
			$exec = array(
				":free_register"=>$data->free_register,
				":free_ts3_server_application"=>$data->free_ts3_server_application,
				":splamy_musicbot"=>$data->splamy_musicbot,
				":support_teamspeak"=>$data->support_teamspeak,
				":support_teamspeak_instance"=>$data->support_teamspeak_instance,
				":support_teamspeak_port"=>$data->support_teamspeak_port
			);
			
			$sql = $databaseConnection->prepare(trim(preg_replace('/\s+/', ' ', $_sql)));
			if ($sql->execute($exec)) {
				writeInLog($_SESSION['user']['benutzer'], "changed homepage moduls!", true);
				
				if($data->splamy_musicbot == "false") {
					return delPermGroup($databaseConnection, '_bot');
				} else {
					return generateOutput(true, null, null);
				};
			} else {
				writeInLog(L_ERROR, "updateModules (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Remove permissiongroups
		@param {Object} $databaseConnection
		@param {string} $group
		@return generateOutput
	*/
	function delPermGroup($databaseConnection, $group) {
		if(empty($group)) {
			return generateOutput(false, 'Need group attribute', null);
		};
		
		global $mysql_keys;
		
		$where = '';
		foreach($mysql_keys AS $key=>$value) {
			if(strpos($key, $group) === false) {
				continue;
			};
			
			if(empty($where)) {
				$where = "fk_rights='".$value."'";
			} else {
				$where .= "OR fk_rights='".$value."'";
			};
		};
		
		if(empty($where)) {
			return generateOutput(false, 'No keys found', null);
		};
		
		if($databaseConnection->exec("DELETE FROM main_clients_rights WHERE ".$where) === false) {
			writeInLog(L_ERROR, "delPermGroup (SQL Error):".$databaseConnection->errorInfo()[2]);
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
		
		return generateOutput(true, null, null);
	};
	
	/**
		Change homepage own sites
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function updateOwnSites($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $mysql_keys;
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			foreach($data AS $id=>$content) {
				if($content->icon === null) {
					$content->icon = '';
				};
				
				if($content->name === null) {
					$content->name = '';
				};
				
				$_sql = "UPDATE main_settings_own_sites SET value=:value, icon=:icon, name=:name WHERE id=:id";
				$exec = array(":value"=>$content->value, ":icon"=>$content->icon, ":name"=>$content->name, ":id"=>$id);
				
				$update = $databaseConnection->prepare($_sql);
				if ($update->execute($exec)) {
					writeInLog($_SESSION['user']['benutzer'], "changed own sites settings!", true);
				}
				else {
					writeInLog(L_ERROR, "updateOwnSites (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			};
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Change homepage language
		@param {string} $lang
		@return {Array} generateOutput()
	*/
	function updateLanguage($lang) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $mysql_keys;
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$data = $databaseConnection->prepare('UPDATE main_settings_homepage SET language=:lang');
			if ($data->execute(array(":lang"=>$lang))) {
				writeInLog($_SESSION['user']['benutzer'], "changed homepage language to ".$lang."!", true);
				return generateOutput(true, null, null);
			}
			else {
				writeInLog(L_ERROR, "updateLanguage (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get Sql User infortmations
		@param {string} $pk
		@return {Array} generateOutput()
	*/
	function getUserInformations($pk) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$_sql = "SELECT
						firstname,
						lastname,
						phone,
						homepage,
						skype,
						steam,
						twitter,
						facebook,
						google,
						last_login,
						user_blocked
					FROM main_clients_infos 
						join main_clients on main_clients_infos.fk_clients=main_clients.pk_client 
					WHERE fk_clients='".$pk."'";
			
			if(($data = $databaseConnection->query($_sql)) !== false) {
				if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
					$result = $data->fetch(PDO::FETCH_ASSOC);
					return generateOutput(true, null, $result);
				} else {
					writeInLog(5, "getUserInformations: User not found!");
					return generateOutput(true, null, []);
				};
			} else {
				writeInLog(L_ERROR, "getUserInformations (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Login into the interface
		@param {string} $_username
		@param {string} $password
		@return {Array} generateOutput()
	*/
	function loginUser($_username, $password) {
		global $language;
		
		if(!isset($_SESSION['login_try'])) {
			$_SESSION['login_try'] = '1';
		} else if($_SESSION['login_try'] == '3') {
			if((intval($_SESSION['login_try_time']) + 60) > time()) {
				return generateOutput(false, $language['user_is_blocked'], null);
			} else {
				$_SESSION['login_try'] = '1';
			};
		} else {
			switch($_SESSION['login_try']) {
				case '1':
					$_SESSION['login_try'] = '2';
					break;
				case '2':
					$_SESSION['login_try'] = '3';
					$_SESSION['login_try_time'] = time();
					break;
			};
		};
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$data = $databaseConnection->prepare("SELECT pk_client, user, last_login, user_blocked, firstname, lastname, password FROM main_clients m_client INNER JOIN main_clients_infos m_client_i ON (m_client.pk_client = m_client_i.fk_clients) WHERE m_client.user=:user LIMIT 1");
			
			if ($data->execute(array(":user"=>$_username))) {
				if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
					$result = $data->fetch(PDO::FETCH_ASSOC);

					if (!password_verify($password, $result['password'])) {
						return generateOutput(false, $language['user_or_pw_wrong'], null);
					};
					
					$_SESSION['user']['id'] = $result['pk_client'];
					$_SESSION['user']['benutzer'] = $result['user'];
					$_SESSION['user']['last_login'] = $result['last_login'];
					$_SESSION['user']['blocked'] = $result['user_blocked'];
					$_SESSION['login_try'] = '1';
					
					if($_SESSION['user']['blocked'] == 'true') {
						writeInLog($_SESSION['user']['benutzer'], "Try to login, but is blocked!", true);
						
						$_SESSION = array();
						if (ini_get("session.use_cookies")) {
							$params = session_get_cookie_params();
							setcookie(session_name(), '', time() - 42000, $params["path"],
								$params["domain"], $params["secure"], $params["httponly"]
							);
						};
						session_destroy();
						
						return generateOutput(false, $language['user_blocked_info'], null);
					} else {
						writeInLog($_SESSION['user']['benutzer'], "Is logging in!", true);
						
						$_SESSION['agent'] = md5($_SERVER['HTTP_USER_AGENT']);
						
						if($databaseConnection->exec("UPDATE main_clients SET last_login='". date("d.m.Y - H:i", time()) . "' WHERE pk_client='" . $_SESSION['user']['id'] . "'") === false) {
							writeInLog(L_ERROR, "loginUser (SQL Error):".$databaseConnection->errorInfo()[2]);
						};
						
						return generateOutput(true, $result, ['picture' => getUserPicture($result['pk_client']), 'firstname' => $result['firstname'], 'lastname' => $result['lastname']]);
					};
				} else {
					return generateOutput(false, $language['user_or_pw_wrong'], null);
				};
			} else {
				writeInLog(L_ERROR, "loginUser (SQL Error):".$data->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};

	/**
		Get mails with a specific permission key
		@param {string} $key
		@return generateOutput()
	*/
	function getPermissionMails($key) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$data = $databaseConnection->prepare("SELECT user FROM main_clients m_client INNER JOIN main_clients_rights m_client_r ON (m_client.pk_client = m_client_r.fk_clients) INNER JOIN main_rights m_rights ON (m_client_r.fk_rights = m_rights.pk_rights) WHERE m_rights.rights_name=:key");
			if ($data->execute(array(":key"=>$key))) {
				if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
					$result = $data->fetchAll(PDO::FETCH_ASSOC);
					$res = [];
					foreach($result AS $mail) {
						$res[] = $mail["user"];
					};
					return generateOutput(true, null, $res);
				} else {
					return generateOutput(true, null, []);
				};
			} else {
				writeInLog(L_ERROR, "getPermissionMails (SQL Error):".$data->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get news from the database
		@return generateOutput()
	*/
	function getNews() {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$query = $databaseConnection->query('SELECT * FROM main_news');
			if($query->rowCount() > 0) {
				$data = $query->fetchAll(PDO::FETCH_ASSOC);
				return generateOutput(true, null, $data);
			} else {
				return generateOutput(true, null, []);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get the mail over the pk
		@param {string} $pk
		@return generateOutput()
	*/
	function getUsernameFromPk($pk) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if (($data = $databaseConnection->query("SELECT user FROM  main_clients WHERE pk_client='".$pk."' LIMIT 1")) !== false) {
				if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
					return generateOutput(true, null, $data->fetch(PDO::FETCH_ASSOC)['user']);
				} else {
					return generateOutput(true, null, 'User not found!');
				};
			} else {
				writeInLog(L_ERROR, "getUsernameFromPk (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Create news and add there to the database
		@param {string} $title
		@param {string} $subtitle
		@param {string} $content
		@param {int} $time
		@return generateOutput()
	*/
	function createNews($title, $subtitle = null, $content, $time) {
		if(DEMO) {
			return generateOutput(true, null, rand());
		};
		
		global $language;
		$time = date('Y-m-d h:i:s', $time/1000);
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$insert = $databaseConnection->prepare('INSERT INTO main_news (title, sub_title, text, show_on) VALUES (:title, :subtitle, :content, :time)');
			if(!$insert->execute(array(":title"=>$title, ":subtitle"=>$subtitle, ":content"=>$content, ":time"=>$time))) {
				writeInLog(L_ERROR, "createNews (SQL Error):".$insert->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			} else {
				$query = $databaseConnection->prepare('SELECT id FROM main_news WHERE title=:title AND show_on=:time LIMIT 1');
				if(!$query->execute(array(":title"=>$title, ":time"=>$time))) {
					writeInLog(L_ERROR, "createNews (SQL Error):".$query->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				} else {
					if ($query->rowCount() > 0) {
						$row = $query->fetch(PDO::FETCH_ASSOC);
						return generateOutput(true, null, $row['id']);
					} else {
						return generateOutput(false, $language['news_created_failed'], null);
					};
				};
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Edit news and save it into the database
		@param {int} $id
		@param {string} $text
	*/
	function editNews($id, $text) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$update = $databaseConnection->prepare("UPDATE main_news SET text=:text WHERE id=:id");
			if(!$update->execute(array(":id"=>$id, ":text"=>$text))) {
				writeInLog(L_ERROR, "editNews (SQL Error):".$update->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			} else {
				return generateOutput(true, null, null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Delete news from the database
		@param {int} $id
	*/
	function deleteNews($id) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$delete = $databaseConnection->prepare("DELETE FROM main_news WHERE id=:id");
			if(!$delete->execute(array(":id"=>$id))) {
				writeInLog(L_ERROR, "deleteNews (SQL Error):".$delete->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			} else {
				return generateOutput(true, null, null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Forgot password
		@param {string} $username
		@return generateOutput()
	*/
	function forgetAccess($username) {
		global $language;

		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$select = $databaseConnection->prepare("SELECT pk_client FROM main_clients WHERE user=:user LIMIT 1");
			if($select->execute(array(":user"=>$username))) {
				if ($select->rowCount() > 0) {
					$result = $select->fetch(PDO::FETCH_ASSOC);
					$newPw = randomString(8);
					
					if($databaseConnection->exec('UPDATE main_clients SET password=\''.password_hash($newPw, PASSWORD_BCRYPT, array("cost" => 10)).'\' WHERE pk_client=\'' . $result['pk_client'] . '\'') === false) {
						writeInLog(L_ERROR, "forgetAccess (SQL Error):".$databaseConnection->errorInfo()[2]);
						return generateOutput(false, $language['log_err_sql_connection'], null);
					} else {
						return writeMail(
							(object)array(
								"id" => "forgot_password",
								"mail" => $username,
								"subject" => $language['forgot_access']
							), array(
								"%NEW_PASSWORD%" => $newPw
							)
						);
					};
				} else {
					return generateOutput(false, $language['user_does_not_exist'], null);
				};
			} else {
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		};
	};
	
	/**
		Delete all users in the interface / database and create a new administrator
		@param {string} $_username
		@param {string} $password
		@param {string} $firstname
		@param {string} $lastname
		@return generateOutput()
	*/
	function deleteAllUsers($_username, $password, $firstname, $lastname) {
		if(DEMO) {
			return generateOutput(true, null, guid());
		};
		
		global $language;
		
		if($_username != '' && $password != '') {
			if(($databaseConnection = getSqlConnection(false)) !== false) {
				$status = true;
				$status2 = true;
				
				if($databaseConnection->exec('TRUNCATE TABLE main_clients;') === false) {
					writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
					$status = false;
				};
				
				if($status) {
					if($databaseConnection->exec('TRUNCATE TABLE main_clients_rights;') === false) {
						writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status			=	false;
					};
					
					if($databaseConnection->exec('TRUNCATE TABLE main_clients_infos;') === false) {
						writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status			=	false;
					};
					
					if($databaseConnection->exec('TRUNCATE TABLE main_clients_rights_server_edit;') === false) {
						writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status			=	false;
					};
					
					if($databaseConnection->exec('TRUNCATE TABLE ticket_tickets;') === false) {
						writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status			=	false;
					};
					
					if($databaseConnection->exec('TRUNCATE TABLE ticket_answer;') === false) {
						writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status			=	false;
					};
					
					if($status) {
						writeInLog($_SESSION['user']['benutzer'], "Delete all users and create a new one called '".$_username."'!", true);
						
						$key = guid();
						$_passwort = password_hash($password, PASSWORD_BCRYPT, array("cost" => 10));
						
						$insert = $databaseConnection->prepare('INSERT INTO main_clients (pk_client, user, password, last_login, user_blocked) VALUES (\'' . $key . '\', :user, :password, \'' . date("d.m.Y - H:i", time()) . '\', \'false\')');
						if(!$insert->execute(array(":user"=>$_username, ":password"=>$_passwort))) {
							writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$insert->errorInfo()[2]);
							$status = false;
						};
						
						$insert = $databaseConnection->prepare('INSERT INTO main_clients_infos (fk_clients, firstname, lastname) VALUES (\'' . $key . '\', :fname, :lname)');
						if(!$insert->execute(array(":fname"=>$firstname, ":lname"=>$lastname))) {
							writeInLog(L_ERROR, "deleteAllUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
							$status = false;
						};
						
						$status2 = giveUserAllRights($databaseConnection, $key);
						
						if($status && $status2) {
							return generateOutput(true, null, $key);
						} else if($status2 == false) {
							return generateOutput(false, $language['permissions_couldnt_set'], null);
						};
					} else {
						return generateOutput(false, $language['database_couldnt_be_deleted'], null);
					};
				} else {
					return generateOutput(false, $language['database_couldnt_be_deleted'], null);
				};
			} else {
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, 'Username or password missing', null);
		};
	};

	/**
		Check if client has permissions over a teamspeak instance
		@param {string} $pk
		@param {int} $instance
		@return {bool}
	*/
	function checkClientHasInstance($pk, $instance) {
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$select = $databaseConnection->prepare("SELECT access_instance FROM main_clients_rights WHERE fk_clients=:pk AND access_instance=:instance LIMIT 1");
			if(!$select->execute(array(":pk"=>$pk, ":instance"=>$instance))) {
				writeInLog(L_ERROR, "checkClientHasInstance (SQL Error):".$select->errorInfo()[2]);
				return false;
			} else {
				return ($select->rowCount() > 0 && !empty($select->fetch(PDO::FETCH_ASSOC)));
			};
		} else {
			return false;
		};
		return false;
	};

	/**
		Change teamspeak virtualserverport in the database
		@param {int, string} $instance
		@param {int, string} $oPort
		@param {int, string} $nPort
		@return generateOutput
	*/
	function updateTeamspeakPort($instance, $oPort, $nPort) {
		global $language;

		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$select = $databaseConnection->prepare("SELECT fk_clients, fk_rights, access_ports FROM main_clients_rights WHERE access_instance=:instance");
			if(!$select->execute(array(":instance"=>$instance))) {
				writeInLog(L_ERROR, "updateTeamspeakPort (SQL Error):".$select->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			} else {
				if($select->rowCount() > 0) {
					$result = $select->fetchAll(PDO::FETCH_ASSOC);
					foreach($result AS $row) {
						if(strpos($row['access_ports'], $oPort) !== false) {
							$newPorts = str_replace($oPort, $nPort, $row['access_ports']);
							$update = $databaseConnection->prepare("UPDATE main_clients_rights SET access_ports=:port WHERE fk_clients=:client AND fk_rights=:right AND access_instance=:instance");
							if(!$update->execute(array(":port"=>$newPorts, ":client"=>$row['fk_clients'], ":right"=>$row['fk_rights'], ":instance"=>$instance))) {
								writeInLog(L_ERROR, "updateTeamspeakPort (SQL Error):".$update->errorInfo()[2]);
								return generateOutput(false, $language['log_err_sql_connection'], null);
							};
						};
					};
				};
			};
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};

	/**
		Delete teamspeak virtualserverport in the database
		@param {int, string} $instance
		@param {int, string} $port
		@return generateOutput
	*/
	function deleteTeamspeakPort($instance, $port) {
		global $language;

		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$select = $databaseConnection->prepare("SELECT fk_clients, fk_rights, access_ports FROM main_clients_rights WHERE access_instance=:instance");
			if(!$select->execute(array(":instance"=>$instance))) {
				writeInLog(L_ERROR, "deleteTeamspeakPort (SQL Error):".$select->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			} else {
				if($select->rowCount() > 0) {
					$result = $select->fetchAll(PDO::FETCH_ASSOC);
					foreach($result AS $row) {
						if(strpos($row['access_ports'], $port) !== false) {
							if($row['access_ports'] === $port.",") {
								$delete = $databaseConnection->prepare("DELETE FROM main_clients_rights WHERE fk_clients=:client AND fk_rights=:right AND access_instance=:instance");
								if(!$delete->execute(array(":client"=>$row['fk_clients'], ":right"=>$row['fk_rights'], ":instance"=>$instance))) {
									writeInLog(L_ERROR, "deleteTeamspeakPort (SQL Error):".$delete->errorInfo()[2]);
									return generateOutput(false, $language['log_err_sql_connection'], null);
								};
							} else {
								$newPorts = str_replace($port.",", "", $row['access_ports']);
								$update = $databaseConnection->prepare("UPDATE main_clients_rights SET access_ports=:port WHERE fk_clients=:client AND fk_rights=:right AND access_instance=:instance");
								if(!$update->execute(array(":port"=>$newPorts, ":client"=>$row['fk_clients'], ":right"=>$row['fk_rights'], ":instance"=>$instance))) {
									writeInLog(L_ERROR, "deleteTeamspeakPort (SQL Error):".$update->errorInfo()[2]);
									return generateOutput(false, $language['log_err_sql_connection'], null);
								};
							};
						};
					};
				};
			};
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Give a user all global permissions of the interface
		@param {Object} $databaseConnection
		@param {string} $pk
		@return {bool}
	*/
	function giveUserAllRights($databaseConnection, $pk) {
		global $mysql_keys;
		
		$status = true;
		
		foreach($mysql_keys as $key) {
			if($status) {
				if($databaseConnection->exec('INSERT INTO main_clients_rights (fk_clients, fk_rights) VALUES (\'' . $pk . '\', \'' . $key . '\')') === false) {
					writeInLog(L_ERROR, "giveUserAllRights (SQL Error):".$databaseConnection->errorInfo()[2]);
					$status = false;
				};
			};
		};

		writeInLog($_SESSION['user']['benutzer'], "Give global permissions to '".$pk."'!", true);
		return $status;
	};
	
	/**
		Change the global permission above a client
		@param {string} $pk
		@param {Object} $data
		@return: {Array} generateOutput()
	*/
	function setGlobePerm($pk, $data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $mysql_keys;
		global $language;
		
		$user_right = getUserRights('pk', $pk);
		if($user_right === false) {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			foreach($data AS $key => $bool) {
				if($bool && $user_right['data'][$key] != $mysql_keys[$key]) {
					if($databaseConnection->exec('INSERT INTO main_clients_rights (fk_clients, fk_rights) VALUES (\'' . $pk . '\', \'' . $mysql_keys[$key] . '\')') === false) {
						writeInLog(L_ERROR, "setGlobePerm (SQL Error):".$databaseConnection->errorInfo()[2]);
						return generateOutput(false, $language['log_err_sql_connection'], null);
					};
				} else if(!$bool && $user_right['data'][$key] == $mysql_keys[$key]) {
					if($databaseConnection->exec("DELETE FROM main_clients_rights WHERE fk_clients='" . $pk . "' AND fk_rights='" . $mysql_keys[$key] . "'") === false) {
						writeInLog(L_ERROR, "setGlobePerm (SQL Error):".$databaseConnection->errorInfo()[2]);
						return generateOutput(false, $language['log_err_sql_connection'], null);
					};
				};
			};
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};

	/**
		Write a mail
		@param {Object} $data
		@param {Array} $replace
		@return generateOutput()
	*/
	function writeMail($data, $replace = null) {
		require_once(__dir__."/../../config/config.php");
		require_once(__dir__."/functions.php");
		require_once(__dir__."/../classes/phpmailer.class.php");

		$settings = getSqlHomepagesettings();
		$mailsettings = getSqlMailSettings();
		$sqlMail = null;

		if(!$mailsettings['success'] || !$settings['success']) {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};

		foreach($mailsettings['data'] AS $m) {
			if($m['id'] !== $data->id) {
				continue;
			};
			$sqlMail = $m;
		};
		
		if($sqlMail === null) {
			return generateOutput(false, "Mail template not found!", null);
		};

		$mail = new PHPMailer();
		if(MAIL_SMTP == "true") {
			require_once(__dir__."/../classes/phpmailer.smtp.class.php");
			
			$mail->IsSMTP();
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = MAIL_SMTP_ENCRYPTION;
			
			$mail->Host = MAIL_SMTP_HOST;
			$mail->Port = MAIL_SMTP_PORT;
			$mail->Username = MAIL_SMTP_USERNAME;
			$mail->Password = MAIL_SMTP_PASSWORD;
			$mail->SMTPDebug = MAIL_SMTP_DEBUG;
		} else {
			// fix written by cjmwid
			if(isWindows()) {
				$mail->isMail();
			} else {
				$mail->isSendmail();
			};
		};
		$mail->setFrom(MAILADRESS, ($settings['success']) ? $settings['data']['title'] : "");
		$mail->AddAddress(($data->mail !== null) ? $data->mail : $_SESSION['user']['benutzer']);
		$mail->Subject = $data->subject;
		$mail->isHTML(true);

		$htmlBody = file_get_contents(__dir__."/../../config/templates/mail_template.html");
		$htmlBody = str_replace("%CONTENT%", ($data->body !== null) ? $data->body : $sqlMail['mail_body'], $htmlBody);
		
		$htmlBody = str_replace("%MAIL%", ($data->mail !== null) ? $data->mail : $_SESSION['user']['benutzer'], $htmlBody);
		$htmlBody = str_replace("%SUBJECT%", $data->subject, $htmlBody);
		$htmlBody = str_replace("%PREHEADER%", ($data->preheader !== null) ? $data->preheader : $sqlMail['mail_preheader'], $htmlBody);
		$htmlBody = str_replace("%TITLE%", $settings['data']['title'], $htmlBody);

		if($replace !== null && isset($replace)) {
			foreach($replace AS $search => $repl) {
				$htmlBody = str_replace($search, $repl, $htmlBody);
			};
		};
		
		$mail->Body = $htmlBody;
		
		if(!$mail->Send()) {
			return generateOutput(false, $mail->ErrorInfo, null);
		} else {
			return generateOutput(true, null, null);
		};
	};

	/**
		Change the server permission above a client
		@param {string} $pk
		@param {Object} $data
		@return: {Array} generateOutput()
	*/
	function setServerPerm($pk, $data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $language;
		
		$mysql_keys_server = getKeys("main_rights_server");
		$user_right = getUserRights('pk', $pk);
		if($user_right === false) {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			foreach($data AS $key => $bool) {
				if($key === 'instance' || $key === 'port') {
					continue;
				};

				$sql = $databaseConnection->prepare("SELECT access_instance, access_ports FROM main_clients_rights WHERE fk_clients=:pk AND access_instance=:instance AND fk_rights=:key LIMIT 1");
				if($sql->execute(array(":pk" => $pk, ":instance" => $data->instance, ":key" => $mysql_keys_server[$key]))) {
					if($bool) {
						if ($sql->rowCount() > 0) {
							$select = $sql->fetch(PDO::FETCH_ASSOC);
							if(strpos($select['access_ports'], $data->port) === false) {
								$update = $databaseConnection->prepare("UPDATE main_clients_rights SET access_ports=:ports WHERE fk_clients=:pk AND access_instance=:instance AND fk_rights=:key");
								if(!$update->execute(array(":pk" => $pk, ":key" => $mysql_keys_server[$key], ":instance" => $data->instance, ":ports" => $select['access_ports'].$data->port.","))) {
									writeInLog(L_ERROR, "setServerPerm (SQL Error):".$databaseConnection->errorInfo()[2]);
									return generateOutput(false, $language['log_err_sql_connection'], null);
								};
							};
						} else {
							$insert = $databaseConnection->prepare("INSERT INTO main_clients_rights (fk_clients, fk_rights, access_instance, access_ports) VALUES (:pk, :perm, :instance, :port)");
							if(!$insert->execute(array(":pk" => $pk, ":perm" => $mysql_keys_server[$key], ":instance" => $data->instance, ":port" => $data->port.","))) {
								writeInLog(L_ERROR, "setServerPerm (SQL Error):".$databaseConnection->errorInfo()[2]);
								return generateOutput(false, $language['log_err_sql_connection'], null);
							};
						};
					} else {
						if ($sql->rowCount() > 0) {
							$select = $sql->fetch(PDO::FETCH_ASSOC);
							
							if($select['access_ports'] === $data->port.',') {
								$delete = $databaseConnection->prepare("DELETE FROM main_clients_rights WHERE fk_clients=:pk AND fk_rights=:key AND access_instance=:instance");
								if(!$delete->execute(array(":pk" => $pk, ":key" => $mysql_keys_server[$key], ":instance" => $data->instance))) {
									writeInLog(L_ERROR, "setServerPerm (SQL Error):".$databaseConnection->errorInfo()[2]);
									return generateOutput(false, $language['log_err_sql_connection'], null);
								};
							} else {
								$update = $databaseConnection->prepare("UPDATE main_clients_rights SET access_ports=:ports WHERE fk_clients=:pk AND access_instance=:instance AND fk_rights=:key");
								if(!$update->execute(array(":pk" => $pk, ":key" => $mysql_keys_server[$key], ":instance" => $data->instance, ":ports" => str_replace($data->port.',', '', $select['access_ports'])))) {
									writeInLog(L_ERROR, "setServerPerm (SQL Error):".$databaseConnection->errorInfo()[2]);
									return generateOutput(false, $language['log_err_sql_connection'], null);
								};
							};
						};
					};
				} else {
					writeInLog(L_ERROR, "setServerPerm (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			};
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Block /Unblock the client
		@param {string} $pk
		@param {string} $blocked
	*/
	function setClientBlock($pk, $blocked) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if($databaseConnection->exec("UPDATE main_clients SET user_blocked='" . $blocked . "' WHERE pk_client='" . $pk . "'") === false) {
				writeInLog(L_ERROR, "setClientBlock (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Delete a client from the interface / database
		@param {string} $pk
		@return: {Array} generateOutput()
	*/
	function deleteUser($pk)
	{
		global $language;
		
		if($pk != '') {
			if(($databaseConnection = getSqlConnection(false)) !== false) {
				$status = true;
				
				if($databaseConnection->exec('DELETE FROM main_clients WHERE pk_client=\'' . $pk . '\';') === false) {
					writeInLog(L_ERROR, "deleteUser (SQL Error):".$databaseConnection->errorInfo()[2]);
					$status = false;
				};
				
				if($status) {
					if($databaseConnection->exec('DELETE FROM main_clients_rights WHERE fk_clients=\'' . $pk . '\';') === false) {
						writeInLog(L_ERROR, "deleteUser (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status = false;
					};
				};
				
				if($status) {
					if($databaseConnection->exec('DELETE FROM main_clients_infos WHERE fk_clients=\'' . $pk . '\';') === false) {
						writeInLog(L_ERROR, "deleteUser (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status = false;
					};
				};
				
				if($status) {
					if($databaseConnection->exec('DELETE FROM main_clients_rights_server_edit WHERE fk_clients=\'' . $pk . '\';') === false) {
						writeInLog(L_ERROR, "deleteUser (SQL Error):".$databaseConnection->errorInfo()[2]);
						$status = false;
					};
				};
				
				if($status) {
					writeInLog($_SESSION['user']['benutzer'], "Delete a Client with the pk '".$pk."'!", true);
					return generateOutput(true, null, null);
				} else {
					return generateOutput(false, $language['log_err_sql_connection'], null);;
				};
			} else {
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, 'PK is missing', null);
		};
	};
	
	/**
		Create a user in the database
		@param {string} $_username
		@param {string} $password
		@param {string} $firstname
		@param {string} $lastname
		@param {boolean} $cryptPw
		@return {Array} generateOutput()
	*/
	function createUser($_username, $password, $firstname, $lastname, $cryptPw = false) {
		global $language;
		
		if($_username != '' && $password != '') {
			if(($databaseConnection = getSqlConnection(false)) !== false) {
				$_passwort = ($cryptPw) ? $password : password_hash($password, PASSWORD_BCRYPT, array("cost" => 10));
				$data = $databaseConnection->prepare("SELECT * FROM main_clients WHERE user=:user");

				if ($data->execute(array(":user"=>$_username))) {
					if ($data->rowCount() == 0) {
						$newPk = guid();
						$status = true;
						$insert = $databaseConnection->prepare('INSERT INTO main_clients (pk_client, user, password, last_login, user_blocked) VALUES (\'' . $newPk . '\', :user, :password, \'' . date("d.m.Y - H:i", time()) . '\', \'false\')');
						
						if(!$insert->execute(array(":user"=>$_username, ":password"=>$_passwort))) {
							writeInLog(L_ERROR, "createUser (SQL Error):".$databaseConnection->errorInfo()[2]);
							$status = false;
						};
						
						if($databaseConnection->exec('INSERT INTO main_clients_infos (fk_clients) VALUES (\'' . $newPk . '\')') === false) {
							writeInLog(L_ERROR, "createUser (SQL Error):".$databaseConnection->errorInfo()[2]);
							$status = false;
						};
						
						if($status) {
							$data = $databaseConnection->prepare("UPDATE main_clients_infos SET firstname=:fname, lastname=:lname WHERE fk_clients=:pk");
							if ($data->execute(array(":fname"=>$firstname, ":lname"=>$lastname, ":pk"=>$newPk)) === false) {
								writeInLog(L_ERROR, "createUser (SQL Error):".$databaseConnection->errorInfo()[2]);
								return generateOutput(false, 'Could not edit the client name', null);
							} else {
								writeInLog($_SESSION['user']['benutzer'], "Create a Client called '".$_username."'!", true);
								return generateOutput(true, null, $newPk);
							};
						} else {
							return generateOutput(false, $language['user_could_not_created'], null);
						};
					} else {
						return generateOutput(false, $language['user_already_exists'], null);
					};
				} else {
					writeInLog(L_ERROR, "createUser (SQL Error):".$data->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			} else {
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, 'Missing username or password', null);
		};
	};

	/**
		Create a user in the database via modul
		@param {string} $_username
		@param {string} $password
		@param {string} $firstname
		@param {string} $lastname
		@param {boolean} $cryptPw
		@return {Array} generateOutput()
	*/
	function createUserModul($values = null) {
		global $language;
		
		if($values == null) {
			return generateOutput(false, "Data object is empty!");
		};
		
		$data = createUser($values->mail, $values->pw, $values->name, $values->lastname);
		
		if(!$data['success']) {
			return $data;
		};

		if($values->picture != null) {
			copy($values->picture, __dir__."/../../images/user/".$data['data']);
		};

		return generateOutput(true, null, $data['data']);
	};
	
	/**
		Delete a instance from the database and the instance file
		@param {int, string} $instance
		@return generateOutput()
	*/
	function deleteInstance($instance) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		require_once(__dir__.'/../../config/instance.php');
		global $language;
		
		if($instance === false) {
			return generateOutput(false, 'Instance value is missing', null);
		};
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$serverCount = count($ts3_server) - 1;
			
			if($databaseConnection->exec('DELETE FROM main_clients_rights WHERE access_instance!=\'\' AND access_instance!=\'not_needed\' AND access_instance=\'' . $instance . '\';') === false) {
				writeInLog(L_ERROR, "deleteInstance (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
			
			if($databaseConnection->exec('DELETE FROM main_clients_rights_server_edit WHERE access_instance!=\'\' AND access_instance=\'' . $instance . '\';') === false) {
				writeInLog(L_ERROR, "deleteInstance (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
			
			if($databaseConnection->exec('UPDATE main_clients_rights SET access_instance=' . $instance . ' WHERE access_instance!=\'\' AND access_instance!=\'not_needed\' AND access_instance=\'' . $serverCount . '\';') === false) {
				writeInLog(L_ERROR, "deleteInstance (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
			
			if($databaseConnection->exec('UPDATE main_clients_rights_server_edit SET access_instance=' . $instance . ' WHERE access_instance!=\'\' AND access_instance=\'' . $serverCount . '\';') === false) {
				writeInLog(L_ERROR, "deleteInstance (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
			
			$instanceFile = __dir__."/../../config/instance.php";
			$file = file($instanceFile);
			$new_file = [];
			$search_alias = '$ts3_server[' . $instance . '][\'alias\']';
			$search_ip = '$ts3_server[' . $instance . '][\'ip\']';
			$search_queryport = '$ts3_server[' . $instance . '][\'queryport\']';
			$search_user = '$ts3_server[' . $instance . '][\'user\']';
			$search_pw = '$ts3_server[' . $instance . '][\'pw\']';
			$search_protocol = '$ts3_server[' . $instance . '][\'protocol\']';
			
			if($instance < $serverCount) {
				for ($i = 0; $i < count($file); $i++) {
					if(strpos($file[$i], $search_alias)) {
						$new_file[$i] = "\t" . $search_alias . " = '" . $ts3_server[$serverCount]['alias'] . "';\n";
					} elseif (strpos($file[$i], $search_ip)) {
						$new_file[$i] = "\t" . $search_ip . " = '" . $ts3_server[$serverCount]['ip'] . "';\n";
					} elseif (strpos($file[$i], $search_queryport)) {
						$new_file[$i] = "\t" . $search_queryport . " = " . $ts3_server[$serverCount]['queryport'] . ";\n";
					} elseif (strpos($file[$i], $search_user)) {
						$new_file[$i] = "\t" . $search_user . " = '" . $ts3_server[$serverCount]['user'] . "';\n";
					} elseif (strpos($file[$i], $search_pw)) {
						$new_file[$i] = "\t" . $search_pw . " = '" . $ts3_server[$serverCount]['pw'] . "';\n";
					} elseif (strpos($file[$i], $search_protocol)) {
						$new_file[$i] = "\t" . $search_protocol . " = '" . $ts3_server[$serverCount]['pw'] . "';\n";
					} else {
						$new_file[$i] = $file[$i];
					};
				};
				
				for ($i = 0; $i < (count($ts3_server) <= 1) ? 7 : 8; $i++) {
					array_pop($new_file);
				};
				array_push($new_file, "?>");
			} else {
				for ($i = 0; $i < count($file); $i++) {
					if(strpos($file[$i], $search_alias)) {
						if(count($ts3_server) > 1) {
							unset($new_file[$i-1]);
						};
						$new_file = array_values($new_file);  
					};
					
					if(!(strpos($file[$i], $search_alias) || strpos($file[$i], $search_ip) || strpos($file[$i], $search_queryport) || strpos($file[$i], $search_user) || strpos($file[$i], $search_pw) || strpos($file[$i], $search_protocol))) {
						$new_file[$i] = $file[$i];
					};
				};
			};
			
			file_put_contents($instanceFile, "");
			file_put_contents($instanceFile, $new_file);
			
			writeInLog($_SESSION['user']['benutzer'], "Has deleted the instance \"".$instance."\"", true);
			
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get all User Information
	*/
	function getUsers() {
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if (($data = $databaseConnection->query("SELECT user, pk_client, last_login, user_blocked FROM main_clients")) !== false) {
				if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
					return $data->fetchAll(PDO::FETCH_ASSOC);
				};
			} else {
				writeInLog(L_ERROR, "getUsers (SQL Error):".$databaseConnection->errorInfo()[2]);
			};
		};
		return [];
	};
	
	/**
		Get all permission keys from the database
		@param {string} $database
		@return {Array} $returnArray
	*/
	function getKeys($database = "main_rights") {
		$returnData = array();
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if(($data = $databaseConnection->query("SELECT * FROM  ".$database)) !== false) {
				if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
					$result = $data->fetchAll(PDO::FETCH_ASSOC);
					foreach($result AS $keys)
					{
						$returnData[$keys['rights_name']] = $keys['pk_rights'];
					};
				} else {
					writeInLog(5, "getKeys: No Keys found!");
				};
			} else {
				writeInLog(L_ERROR, "getKeys (SQL Error):".$databaseConnection->errorInfo()[2]);
			};
		};
		return $returnData;
	};
	
	/**
		Get modulinformation over the database
		@return {Array} generateOutput()
	*/
	function getModuls() {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if(($data = $databaseConnection->query("SELECT * FROM  main_modul")) !== false) {
				if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
					$result = $data->fetchAll(PDO::FETCH_ASSOC);
					$data = [];
					foreach($result AS $keys) {
						$data[$keys['modul']] = $keys['active'];
					};
					return generateOutput(true, null, $data);
				} else {
					writeInLog(5, "getModuls: No Keys found!");
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			} else {
				writeInLog(L_ERROR, "getModuls (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get all permissions of a spezific user
		@param {string} $type
		@param {string} $key
		@param {string} $just
		@return {Array} generateOutput()
	*/
	function getUserRights($type, $key, $just = "global") {
		global $language;
		
		if($type =='pk' && $key != '') {
			$blocked = getUserInformations($key);
			if($blocked['success'] && !empty($blocked['data'])) {
				if($blocked['data']['user_blocked'] === 'true') {
					return generateOutput(false, 'Client is blocked!', null);
				};
			};
		};
		
		$mysql_keys = getKeys();
		$mysql_keys_server = getKeys("main_rights_server");
		
		if(($type =='pk' || $type == 'name') && $key != '') {
			if(($databaseConnection = getSqlConnection(false)) !== false) {
				if($type == 'name') {
					$_sql = "SELECT rights_name,pk_rights,access_instance,access_ports FROM main_clients m_client INNER JOIN main_clients_rights m_client_r ON (m_client.pk_client = m_client_r.fk_clients) INNER JOIN main_rights m_rights ON (m_client_r.fk_rights = m_rights.pk_rights) WHERE m_client_r.user='".$key."' UNION SELECT rights_name,pk_rights,access_instance,access_ports FROM main_clients m_client INNER JOIN main_clients_rights m_client_r ON (m_client.pk_client = m_client_r.fk_clients) INNER JOIN main_rights_server m_rights ON (m_client_r.fk_rights = m_rights.pk_rights) WHERE m_client_r.user='".$key."'";
				} else {
					$_sql = "SELECT rights_name,pk_rights,access_instance,access_ports FROM main_clients m_client INNER JOIN main_clients_rights m_client_r ON (m_client.pk_client = m_client_r.fk_clients) INNER JOIN main_rights m_rights ON (m_client_r.fk_rights = m_rights.pk_rights) WHERE m_client_r.fk_clients='".$key."' UNION SELECT rights_name,pk_rights,access_instance,access_ports FROM main_clients m_client INNER JOIN main_clients_rights m_client_r ON (m_client.pk_client = m_client_r.fk_clients) INNER JOIN main_rights_server m_rights ON (m_client_r.fk_rights = m_rights.pk_rights) WHERE m_client_r.fk_clients='".$key."'";
				};
				
				if(($data = $databaseConnection->query($_sql)) !== false) {
					if ($data->rowCount() > 0 || SQL_Mode === "sqlite") {
						$result = $data->fetchAll(PDO::FETCH_ASSOC);
						$data = [];
						
						switch($just) {
							case "ports":
								foreach($result AS $row) {
									if($row['access_instance'] != "not_needed") {
										$data[$row['rights_name']]['key'] = $row['pk_rights'];
										$data[$row['rights_name']][$row['access_instance']] = $row['access_ports'];
									};
								};
								foreach($mysql_keys_server AS $name=>$key) {
									if(!isSet($data[$name])) {
										$data[$name]['key'] = false;
									};
								};
								break;
							case "all":
								foreach($result AS $row) {
									if($row['access_instance'] != "not_needed") {
										$data[$row['rights_name']]['key'] = $row['pk_rights'];
										$data[$row['rights_name']][$row['access_instance']] = $row['access_ports'];
									};
								};
								foreach($mysql_keys_server AS $name=>$key) {
									if(!isSet($data[$name])) {
										$data[$name]['key'] = false;
									};
								};
								foreach($result AS $row) {
									if($row['access_instance'] == "not_needed") {
										$data[$row['rights_name']] = $row['pk_rights'];
									};
								};
								foreach($mysql_keys AS $name=>$key) {
									if(!isSet($data[$name])) {
										$data[$name] = false;
									};
								};
								break;
							default:
								foreach($result AS $row) {
									if($row['access_instance'] == "not_needed") {
										$data[$row['rights_name']] = $row['pk_rights'];
									};
								};
								foreach($mysql_keys AS $name=>$key) {
									if(!isSet($data[$name])) {
										$data[$name] = false;
									};
								};
								break;
						};
						
						return generateOutput(true, null, $data);
					} else {
						return generateOutput(true, null, null);
					};
				} else {
					writeInLog(L_ERROR, "getUserRights (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			} else {
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, '$key or $type are invalid', null);
		};
	};
?>