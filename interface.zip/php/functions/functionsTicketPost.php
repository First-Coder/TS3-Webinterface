<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("../../config/config.php");
	require_once("../../lang/lang.php");
	require_once("./functions.php");
	require_once("./functionsSql.php");
	require_once("./functionsTicket.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Get permission
	*/
	$user_right = false;
	if($LoggedIn) {
		$user_right = getUserRights('pk', $_SESSION['user']['id']);
		if(!$user_right['success']) {
			$user_right = false;
		};
	} else {
		echo json_encode(generateOutput(false, 'you need to logged in', null));
		return;
	};
	
	/**
		React to the ajax request with the correct function
	*/
	switch($_POST['action']) {
		case 'answerTicket':
			echo json_encode(answerTicket($_POST['id'], urldecode($_POST['msg'])));
			break;
		case 'closeTicket':
			if($user_right === false || $user_right['data']['perm_profile_ticket_admin'] != $mysql_keys['perm_profile_ticket_admin']) {
				echo json_encode(closeTicket($_POST['id'], false));
			} else {
				echo json_encode(closeTicket($_POST['id'], true));
			};
			break;
		case 'createTicket':
			echo json_encode(createTicket($_POST['subject'], urldecode($_POST['msg']), $_POST['area']));
			break;
		case 'deleteTicket':
			if($user_right === false || $user_right['data']['perm_profile_ticket_admin'] != $mysql_keys['perm_profile_ticket_admin']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteTicket($_POST['id']));
			};
			break;
		case 'changeAreas':
			if($user_right === false || $user_right['data']['perm_profile_ticket_settings'] != $mysql_keys['perm_profile_ticket_settings']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(changeAreas(json_decode($_POST['data'])));
			};
			break;
	};
?>