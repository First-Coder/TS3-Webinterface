<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Header configuration
	*/
	if (!isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
		header('HTTP/1.0 403 Forbidden');
		die('You are not allowed to access this file.');     
	};
	header('Content-type: application/json');
	
	/**
		POST Request
	*/
	$url = 'https://www.google.com/recaptcha/api/siteverify';
	$response = $_POST['response'];
	$secret = "6LclCIQUAAAAANy2rfUUw8nTWeM35fiLpE0O2lSs";
	$json = file_get_contents( $url  . '?secret=' . $secret . '&response=' . $response);
	
	echo $json; 
?>