<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id']);
	
	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_use_backups"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_use_backups missing');
	};
	
	/**
		Variables
	*/
	$filename = __dir__.'/../../files/backups/'.$_POST['backup'].'.fcBackup';
	$file = (file_exists($filename)) ? json_decode(file_get_contents($filename)) : null;
	$steps = array(
		'channel' => array(
			'name' => 3,
			'all' => 3
		),
		'server' => array(
			'snapshot' => 2,
			'all' => 3
		)
	);
	$ret = array(
		'currentStep' => 1,
		'steps' => $steps[$file->type][$file->kind]
	);
	
	/**
		Manage activate backups
	*/
	if($file === null) {
		echo json_encode(generateOutput(false, array('file not found!'), null));
		die();
	};
	
	if(isset($_POST['step'])) {
		$step = intval($_POST['step']);
		
		if($step > $ret['steps']) {
			echo json_encode(generateOutput(false, array('step is out of range!'), null));
			die();
		};
	};
	
	switch($_POST['action']) {
		case 'prepare':
			echo json_encode(generateOutput(true, null, $ret));
			die();
			break;
		case 'upload':
			$ts = getTsAdminInstance($_POST['instance']);
			if(!$ts['success']) {
				echo json_encode($ts);
				die();
			};
			$ts['data']->selectServer($_POST['port'], 'port', true, 'MyName');
			
			switch($step) {
				case 2:
					if($file->type === 'channel') {
						if($file->kind === 'name' || $file->kind === 'all') {
							$channels = $ts['data']->channelList("-flags");
							
							if(!$channels['success']) {
								echo json_encode($channels);
								die();
							};
							
							foreach(array_reverse($channels['data']) AS $key=>$value) {
								if($value['channel_flag_default'] != '1') {
									$del = $ts['data']->channelDelete($value['cid']);
									if(!$del['success']) {
										echo json_encode($del);
										die();
									};
								} else if(strpos($value['channel_name'], 'Auto delete after backup') === false) {
									$edit = $ts['data']->channelEdit($value['cid'], array('channel_name' => 'Auto delete after backup'));
									if(!$edit['success']) {
										echo json_encode($edit);
										die();
									};
								};
							};
							
							echo json_encode(generateOutput(true, null, null));
							die();
						};
					} else if($file->type === 'server' && ($file->kind === 'snapshot' || $file->kind === 'all')) {
						echo json_encode($ts['data']->serverSnapshotDeploy($file->snapshot, true));
						die();
					};
					break;
				case 3:
					if($file->type === 'channel') {
						if($file->kind === 'name' || $file->kind === 'all') {
							$newCids = [];
							$channels = $file->channels;
							
							// create main channels
							foreach(json_decode(file_get_contents($filename))->channels AS $channel) {
								if($channel->pid !== '0') {
									continue;
								};
								
								if($file->kind === 'name') {
									$create = $ts['data']->channelCreate(array('channel_name' => $channel->name, 'channel_flag_permanent' => '1'));
								} else {
									unset(
										$channel->pid,
										$channel->channel_flag_default
									);
									
									$create = $ts['data']->channelCreate((array)$channel);
								};
								
								if($create['success']) {
									$newCids[$channel->cid] = $create['data']['cid'];
								} else {
									echo json_encode($create);
									die();
								};
							};
							
							// create sub channels
							foreach(json_decode(file_get_contents($filename))->channels AS $channel) {
								if($channel->pid === null || $channel->pid === '0') {
									continue;
								};
								
								$cid = $channel->cid;
								if($file->kind === 'name') {
									$create = $ts['data']->channelCreate(array('channel_name' => $channel->name, 'cpid' => $newCids[$channel->pid], 'channel_flag_permanent' => '1'));
								} else {
									$channel->cpid = $newCids[$channel->pid];
									unset(
										$channel->pid,
										$channel->cid,
										$channel->channel_flag_default
									);
									
									$create = $ts['data']->channelCreate((array)$channel);
								};
								
								if($create['success']) {
									$newCids[$cid] = $create['data']['cid'];
								} else {
									echo json_encode($create);
									die();
								};
							};
							
							// set new default channel
							$channels = $ts['data']->channelList("-flags");
							
							if(!$channels['success']) {
								echo json_encode($channels);
								die();
							};
							
							foreach($channels['data'] AS $key=>$value) {
								if($value['channel_flag_default'] != '1') {
									continue;
								};
								
								foreach($file->channels AS $channel) {
									if($channel->default !== '1' && $channel->channel_flag_default !== '1') {
										continue;
									};
									
									$edit = $ts['data']->channelEdit($newCids[$channel->cid], array('channel_flag_default' => '1'));
									if(!$edit['success']) {
										echo json_encode($edit);
										die();
									};
								};
								
								$del = $ts['data']->channelDelete($value['cid']);
								if(!$del['success']) {
									echo json_encode($del);
									die();
								};
							};
							
							echo json_encode(generateOutput(true, null, null));
							die();
						};
					} else if($file->type === 'server') {
						
					};
					break;
				case 4:
					if($file->type === 'server') {
						
					};
					break;
				case 5:
					if($file->type === 'server') {
						
					};
					break;
				default:
					echo json_encode(generateOutput(false, array('step could not be found!'), null));
					die();
			};
			break;
	};
	
	echo json_encode(generateOutput(false, array('something went really wrong :/!'), null));
?>