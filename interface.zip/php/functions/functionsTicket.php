<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/functionsSql.php");
	
	/**
		Get areas
		@return generateOutput()
	*/
	function getAreas() {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if(($data = $databaseConnection->query("SELECT * FROM ticket_areas")) !== false) {
				return generateOutput(true, null, $data->fetchAll(PDO::FETCH_ASSOC));
			} else {
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Edit, delte, change areas
		@param {Object} $data
		@return generateOutput()
	*/
	function changeAreas($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			// new area
			if($data->newArea != "") {
				$insert = $databaseConnection->prepare("INSERT INTO ticket_areas (area) VALUES (:area)");
				if(!$insert->execute(array(":area"=>$data->newArea))) {
					writeInLog(L_ERROR, "changeAreas (SQL Error):".$insert->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			};
			unset($data->newArea);
			
			// edit or delete area
			foreach($data AS $id=>$area) {
				if($area != '') {
					$update = $databaseConnection->prepare("UPDATE ticket_areas SET area=:area WHERE id=:id");
					if(!$update->execute(array(":area"=>$area, ":id"=>$id))) {
						writeInLog(L_ERROR, "changeAreas (SQL Error):".$update->errorInfo()[2]);
						return generateOutput(false, $language['log_err_sql_connection'], null);
					};
				} else {
					$delete = $databaseConnection->prepare("DELETE FROM ticket_areas WHERE id=:id");
					if(!$delete->execute(array(":id"=>$id))) {
						writeInLog(L_ERROR, "changeAreas (SQL Error):".$delete->errorInfo()[2]);
						return generateOutput(false, $language['log_err_sql_connection'], null);
					};
				};
			};
			
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get all tickets where I have access to it 
		@param {string} $pk
		@param {bool} $admin
		@return {Array} generateOutput()
	*/
	function getTicketInformations($pk, $admin = false) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if(!$admin) {
				if(($data = $databaseConnection->query("SELECT * FROM ticket_tickets WHERE pk='$pk'")) !== false) {
					return generateOutput(true, null, $data->fetchAll(PDO::FETCH_ASSOC));
				} else {
					writeInLog(L_ERROR, "updateUser (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			} else {
				if(($data = $databaseConnection->query("SELECT * FROM ticket_tickets")) !== false) {
					return generateOutput(true, null, $data->fetchAll(PDO::FETCH_ASSOC));
				} else {
					writeInLog(L_ERROR, "updateUser (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get ticket information from a specific id
		@param {string} $id
		@param {bool} $admin
		@return {Array} generateOutput()
	*/
	function getTicketInformation($id, $admin = false) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if(!$admin) {
				if (($data = $databaseConnection->query("SELECT * FROM ticket_tickets WHERE pk='".$_SESSION['user']['id']."' AND id='".$id."' LIMIT 1")) !== false) {
					return generateOutput(true, null, $data->fetch(PDO::FETCH_ASSOC));
				} else {
					writeInLog(L_ERROR, "getTicketInformation (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			} else {
				if (($data = $databaseConnection->query("SELECT * FROM ticket_tickets WHERE id='".$id."' LIMIT 1")) !== false) {
					return generateOutput(true, null, $data->fetch(PDO::FETCH_ASSOC));
				} else {
					writeInLog(L_ERROR, "getTicketInformation (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				};
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Get all answers from a ticket
		@param {string} $id
		@return {Array} generateOutput()
	*/
	function getTicketAnswers($id) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			if (($data = $databaseConnection->query("SELECT * FROM ticket_answer WHERE ticketId='$id'")) !== false) {
				return generateOutput(false, null, $data->fetchAll(PDO::FETCH_ASSOC));
			} else {
				writeInLog(L_ERROR, "getTicketAnswers (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Create a new ticket in the database
		@param {string} $subject
		@param {string} $message
		@param {string} $department
		@return {Array} generateOutput()
	*/
	function createTicket($subject, $message, $department) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$pk = $_SESSION['user']['id'];
			$date = date('YmdHis');
			$data = $databaseConnection->prepare("SELECT status FROM ticket_tickets WHERE pk=:pk AND subject=:subject");
			
			if ($data->execute(array(":subject"=>$subject, ":pk"=>$pk))) {
				if ($data->rowCount() > 0) {
					return generateOutput(false, $language['ticket_subject_exists'], null);
				} else {
					$insert = $databaseConnection->prepare('INSERT INTO ticket_tickets (pk,subject,msg,department,status,dateAded,dateActivity) VALUES (:pk, :subject, :message, :department, \'open\', \'' . $date . '\', \'' . $date . '\')');
					if(!$insert->execute(array(":pk"=>$pk, ":subject"=>$subject, ":message"=>$message, ":department"=>$department))) {
						writeInLog(2, "createTicket (SQL Error):".$databaseConnection->errorInfo()[2]);
						return generateOutput(false, $language['log_err_sql_connection'], null);
					} else {
						$admins = getPermissionMails("perm_profile_ticket_settings");
						if($admins['success'] && !empty($admins['data'])) {
							foreach($admins['data'] AS $mail) {
								if($mail !== $_SESSION['user']['benutzer']) {
									$send = writeMail(
										(object)array(
											"id" => "create_ticket_admin",
											"mail" => $mail,
											"subject" => $language['create_ticket']
										), array(
											"%TICKET_NAME%" => $subject,
											"%DEPARTMENT%" => $department
										)
									);
									if(!$send['success']) {
										writeInLog(2, "createTicket:".$send['error']);
									};
								};
							};
						};

						return writeMail(
							(object)array(
								"id" => "create_ticket",
								"mail" => $_SESSION['user']['benutzer'],
								"subject" => $language['create_ticket']
							), array(
								"%TICKET_NAME%" => $subject,
								"%DEPARTMENT%" => $department
							)
						);
					};
				};
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Answer a ticket
		@param {string} $id
		@param {string} $message
		@param {string} $owner
		@param {string} $subject
		@return {Array} generateOutput()
	*/
	function answerTicket($id, $message, $owner, $subject) {
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$date = date('YmdHis');
			$insert = $databaseConnection->prepare('INSERT INTO ticket_answer (ticketId,pk,msg,moderator,dateAded) VALUES (:ticketId, :pk, :message, :moderator, \'' . $date . '\')');
			
			if(!$insert->execute(array(":ticketId"=>$id, ":pk"=>$_SESSION['user']['id'], ":message"=>$message, ":moderator"=>$_SESSION['user']['benutzer']))) {
				writeInLog(2, "addTicket (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			} else {
				$databaseConnection->exec("UPDATE ticket_tickets SET dateActivity='".$date."' WHERE id='".$id."'");

				$admins = getPermissionMails("perm_profile_ticket_settings");
				if($admins['success'] && !empty($admins['data'])) {
					foreach($admins['data'] AS $mail) {
						if($mail !== $owner) {
							$send = writeMail(
								(object)array(
									"id" => "answer_ticket",
									"mail" => $mail,
									"subject" => $language['ticket_answered']
								), array(
									"%TICKET_NAME%" => $subject,
									"%ANSWER%" => $_SESSION['user']['benutzer']
								)
							);
							if(!$send['success']) {
								writeInLog(2, "answerTicket:".$send['error']);
							};
						};
					};
				};

				return generateOutput(true, null, null);
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Close a ticket
		@param {string} $id
		@param {bool} $admin
		@return {Array} generateOutput()
	*/
	function closeTicket($id, $admin = false) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$date = date('YmdHis');
			$owner = getMailCreator($databaseConnection, $id);
			
			if($admin) {
				if($databaseConnection->exec("UPDATE ticket_tickets SET status='closed', dateClosed='".$date."' WHERE id='".$id."'") === false) {
					writeInLog(2, "closeTicket (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				} else {
					$admins = getPermissionMails("perm_profile_ticket_settings");
					if($admins['success'] && !empty($admins['data'])) {
						foreach($admins['data'] AS $mail) {
							if($mail !== $owner) {
								$send = writeMail(
									(object)array(
										"id" => "closed_ticket",
										"mail" => $mail,
										"subject" => $language['ticket_closed']
									), array(
										"%CLOSED_NAME%" => $owner,
										"%ID%" => $id
									)
								);
								if(!$send['success']) {
									writeInLog(2, "closeTicket:".$send['error']);
								};
							};
						};
					};

					return ($owner === false) ? 
						generateOutput(true, null, null) :
						writeMail(
							(object)array(
								"id" => "closed_ticket",
								"mail" => $owner,
								"subject" => $language['ticket_closed']
							), array(
								"%CLOSED_NAME%" => $owner,
								"%ID%" => $id
							)
						);
				};
			} else {
				if($databaseConnection->exec("UPDATE ticket_tickets SET status='closed', dateClosed='".$date."' WHERE pk='".$_SESSION['user']['id']."' AND id='".$id."'") === false) {
					writeInLog(2, "closeTicket (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				} else {
					return generateOutput(true, null, null);
				};
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	function getMailCreator($databaseConnection, $id) {
		$select = $databaseConnection->prepare("SELECT pk FROM  ticket_tickets WHERE id=:id LIMIT 1");
		if($select->execute(array(":id"=>$id))) {
			if ($select->rowCount() > 0) {
				$result = $select->fetch(PDO::FETCH_ASSOC);
				if(($mail = $databaseConnection->query("SELECT user FROM  main_clients WHERE pk_client='".$result['pk']."' LIMIT 1")) !== false) {
					if ($mail->rowCount() > 0) {
						return $mail->fetch(PDO::FETCH_ASSOC)['user'];
					};
				} else {
					writeInLog(2, "getMailCreator (SQL Error):".$databaseConnection->errorInfo()[2]);
				};
			};
		} else {
			writeInLog(2, "getMailCreator (SQL Error):".$databaseConnection->errorInfo()[2]);
		};

		return false;
	};
	
	/**
		Delete a ticket
		@param {string} $id
		@return generateOutput()
	*/
	function deleteTicket($id) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $language;
		
		if(($databaseConnection = getSqlConnection(false)) !== false) {
			$delete = $databaseConnection->prepare('DELETE FROM ticket_tickets WHERE id=:id');
			$delete2 = $databaseConnection->prepare('DELETE FROM ticket_answer WHERE ticketId=:id');
			if(!$delete->execute(array(":id"=>$id))) {
				writeInLog(2, "deleteTicket (SQL Error):".$databaseConnection->errorInfo()[2]);
				return generateOutput(false, $language['log_err_sql_connection'], null);
			} else {
				if(!$delete2->execute(array(":id"=>$id))) {
					writeInLog(2, "deleteTicket (SQL Error):".$databaseConnection->errorInfo()[2]);
					return generateOutput(false, $language['log_err_sql_connection'], null);
				} else {
					return generateOutput(true, null, null);
				};
			};
		} else {
			return generateOutput(false, $language['log_err_sql_connection'], null);
		};
	};
	
	/**
		Change timestamp to the time back
		@param {string} $date
		@return {string}
	*/
	function changeTimestamp($date) {
		$_date = $date;
		$new_date = date("Y-m-d H:i:s");
		$date = date_parse($date);
		
		if(!$date['year'] && !$date['month'] && !$date['day'] && !$date['hour'] && !$date['minute'] && !$date['second']) {
			return "Not closed";
		};
		
		$new_date = date_parse($new_date);
		
		$years_ago = $new_date["year"] - $date["year"];
		if($years_ago != 0) {
			if($years_ago == 1) {
				return $years_ago." year ago";
				exit();
			} else {
				return $years_ago." years ago";
				exit();
			};
		};
		
		if($new_date["month"] == $date["month"] and $new_date["day"] == $date["day"] and $new_date["hour"] == $date["hour"] and $new_date["minute"] <= ($date["minute"] + 1)){
			return "Just now";
		};
		
		$min_ago = $new_date["minute"] - $date["minute"];
		if($new_date["month"] == $date["month"] and $new_date["day"] == $date["day"] and $new_date["hour"] == $date["hour"]){
			return $min_ago." min ago";
		};
		
		$hour_ago = $new_date["hour"] - $date["hour"];
		if($new_date["month"] == $date["month"] and $new_date["day"] == $date["day"]) {
			if($hour_ago == 1) {
				return $hour_ago." hr ago";
			} else  {
				return $hour_ago." hrs ago";
			};
		};
		
		$day_ago = $new_date["day"] - $date["day"];
		if($new_date["month"] == $date["month"] and $day_ago <= 10) {
			if($day_ago == 1) {
				return $day_ago." day ago";
			} else {
				return $day_ago." days ago";
			};
		};
		
		$dateModified = strtotime($_date);
		$dateModified = date("M j, Y", $dateModified);
		return $dateModified;
	};
?>