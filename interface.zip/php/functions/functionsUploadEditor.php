<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once("../../config/config.php");
	require_once("functions.php");
	require_once("functionsSql.php");
	
	/*
		Get the Keys
	*/
	$mysql_keys			=	getKeys();
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	
	/*
		Is Client logged in?
	*/
	if($_SESSION['login'] != $mysql_keys['login_key'])
	{
		reloadSite();
	};
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Has the Client the Permission
	*/
	if($user_right['right_hp_main']['key'] != $mysql_keys['right_hp_main'])
	{
		reloadSite();
	};
	
	/*
		Upload file
	*/
	$newName	=	explode("/", $_FILES["upload"]["tmp_name"])[2].".".explode(".", $_FILES["upload"]["name"])[1];
	$array 		= 	array(
						"resourceType" => "Files",
						"uploaded"=> 1,
						"url"=> "images/editor/".$newName
					);
	
	// Filesize check
	if(getimagesize($_FILES["upload"]["tmp_name"]) === false || $_FILES["upload"]["size"] > 1000000 ||
		(exif_imagetype($_FILES["upload"]["tmp_name"]) != IMAGETYPE_GIF && exif_imagetype($_FILES["upload"]["tmp_name"]) != IMAGETYPE_BMP &&
		exif_imagetype($_FILES["upload"]["tmp_name"]) != IMAGETYPE_JPEG && exif_imagetype($_FILES["upload"]["tmp_name"]) != IMAGETYPE_PNG))
	{
		$array["uploaded"]		=	0;
	}
	else
	{
		move_uploaded_file($_FILES["upload"]["tmp_name"], __dir__."/../../images/editor/".$newName);
	};
	
	echo json_encode($array);
?>