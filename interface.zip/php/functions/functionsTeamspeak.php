<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/instance.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../classes/ts3admin.class.php");
	
	/**
		Get homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		Get a ts3admin instance
		@param {int, string} $instance
		@return {Object} ts3runtime
	*/
	function getTsAdminInstance($instance) {
		global $ts3_server;
		
		if(!isset($instance)) {
			return generateOutput(false, 'Instance is not given', null);
		};
		
		if($instance > (count($ts3_server) - 1)) {
			return generateOutput(false, 'Instance cant be found', null);
		};
		
		$tsAdmin = new ts3admin($ts3_server[$instance]['ip'], $ts3_server[$instance]['queryport'], ($ts3_server[$instance]['protocol'] == 'ssh') ? true : false);
		$connect = $tsAdmin->connect($ts3_server[$instance]['user'], $ts3_server[$instance]['pw']);
		if($connect['success']) {
			return generateOutput(true, null, $tsAdmin);
		} else {
			return generateOutput(false, $connect['errors'], null);
		};
	};
	
	/**
		Check a ts3admin instance
		@param {int, string} $instance
		@return {Object} ts3runtime
	*/
	function checkTS3Connection($instance){
		global $ts3_server;
		
		$tsAdmin = new ts3admin($ts3_server[$instance]['ip'], $ts3_server[$instance]['queryport'], ($ts3_server[$instance]['protocol'] == 'ssh') ? true : false);
		$connect = $tsAdmin->connect($ts3_server[$instance]['user'], $ts3_server[$instance]['pw']);
		if($connect['success']) {
			return generateOutput(true, null, $connect['data']);
		} else {
			return generateOutput(false, $connect['errors'], null);
		};
	};
	
	/**
		Function to get a serverinfo from a server
		@param {int, string} $instance
		@param {int, string} $port
		@return {Array} generateOutput()
	*/
	function getServerInfo($instance, $port) {
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true);
			$ret = $ts['data']->serverInfo();
			$ret['data']['virtualserver_start_stop'] = checkServerPerm(array("perm_ts_server_start_stop"), $instance, $port);
			return $ret;
		} else {
			return $ts;
		};
	};
	
	/** // deprecated
		Function to get a serverlist from a instance
		@param {int, string} $instance
		@return {Array} generateOutput()
	*/
	function getServerList($instance) {
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			return $ts['data']->serverlist();
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get the banlist from a server
		@param {int, string} $instance
		@param {int, string} $port
		@return {Array} generateOutput()
	*/
	function getServerBans($instance, $port) {
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true);
			return $ts['data']->banList();
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get the clientlist from a server
		@param {int, string} $instance
		@param {int, string} $port
		@return {Array} generateOutput()
	*/
	function getServerClients($instance, $port) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true);
			
			$clientList = $ts['data']->clientDbList(0, ($settings['success']) ? $settings['data']['ts_get_db_clients'] : '900000');
			$clientOnlineList = $ts['data']->clientList();
			
			if($clientList['success'] && $clientOnlineList['success']) {
				$data = [];
				foreach($clientList['data'] AS $client) {
					if($client['client_unique_identifier'] != 'ServerQuery') {
						$c['client_nickname'] = xssSafe($client['client_nickname']);
						$c['client_created'] = date('Y-m-d H:i:s', $client['client_created']);
						$c['client_lastconnected'] = date('Y-m-d H:i:s', $client['client_lastconnected']);
						$c['client_lastip'] = $client['client_lastip'];
						$c['client_totalconnections'] = $client['client_totalconnections'];
						$c['client_description'] = xssSafe($client['client_description']);
						$c['client_unique_identifier'] = $client['client_unique_identifier'];
						$c['cldbid'] = $client['cldbid'];
						$c['client_online'] = false;
						foreach($clientOnlineList['data'] AS $onlineClient) {
							if($onlineClient['client_database_id'] == $client['cldbid']) {
								$c['client_online'] = true;
								break;
							};
						};
						$data[] = $c;
					};
				};
				return generateOutput(true, null, $data);
			} else {
				return ($clientList['success']) ? $clientOnlineList : $clientList;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get the filelist from a server
		@param {int, string} $instance
		@param {int, string} $port
		@return {Array} generateOutput()
	*/
	function getServerFiles($instance, $port) {
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true);
			$channels = $ts['data']->channelList();
			if($channels['success']) {
				$ret = [];
				foreach($channels['data'] AS $channel) {
					$filelist = $ts['data']->getElement('data', $ts['data']->ftGetFileList($channel['cid'], "", "/"));
					if(!empty($filelist)) {
						$ret[$channel['cid']] = getServerSubFiles($ts['data'], $filelist, $channel['cid']);
						$ret[$channel['cid']]['channelInfo'] = $channel;
					};
				};
				return generateOutput(true, null, $ret);
			} else {
				return $channels;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Helper function to get files from a sub folder
	*/
	function getServerSubFiles($ts, $filelist, $cid, $path = '/') {
		$ret = [];
		foreach($filelist AS $file) {
			if(empty($file['path'])) {
				$file['path'] = $path;
			};
			
			if($file['size'] == 0) {
				foreach(getServerSubFiles($ts, $ts->getElement('data', $ts->ftGetFileList($cid, "", $path.$file['name'])), $cid, $path.$file['name']."/") AS $subFile) {
					if(!empty($subFile['cid'])) {
						unset($subFile['cid']);
					};
					
					if(substr($subFile['path'], -1) != "/") {
						$subFile['path'] .= "/";
					};
					$ret[] = $subFile;
				};
			} else {
				if(!empty($file['cid'])) {
					unset($file['cid']);
				};
				
				if(substr($file['path'], -1) != "/") {
					$file['path'] .= "/";
				};
				
				$ret[] = $file;
			};
		};
		return $ret;
	};
	
	/**
		Function to get all teamspeak ports from a specific instance
		@param {int, string} $instance
		@return {Array} generateOutput()
	*/
	function getTeamspeakPorts($instance) {
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$data = [];
			foreach($ts['data']->getElement('data', $ts['data']->serverList()) AS $i=>$server) {
				$data[$i] = $server['virtualserver_port'];
			};
			return generateOutput(true, null, $data);
		} else {
			return $ts;
		};
	};

	/**
		Get whole instance information
		@param {int, string} $instance
		@return {Array} generateOutput
	*/
	function getInstanceInfo($instance) {
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$data = [];
			$data['server'] = [];
			$data['clients'] = [];
			$data['clients']['Instance'] = [];
			$data['clients']['Instance']['clients'] = 0;
			$data['clients']['Instance']['online'] = 0;
			$data['hostinfo'] = $ts['data']->getElement('data', $ts['data']->hostInfo());
			$data['statistics']['server_online'] = null;
			$data['statistics']['server_traffic'] = null;

			$serverlist = $ts['data']->getElement('data', $ts['data']->serverlist());
			if(!empty($serverlist)) {
				foreach($serverlist AS $server) {
					if(!hasServerPerm($instance, $server['virtualserver_port'])) {
						continue;
					};

					$ts['data']->selectServer($server['virtualserver_port'], 'port', true);
					$serverinfo = $ts['data']->getElement('data', $ts['data']->serverRequestConnectionInfo());

					$data['server']['info'] = $server;
					$data['clients']['Instance']['clients'] += $server['virtualserver_maxclients'];
					$data['clients']['Instance']['online'] += $server['virtualserver_clientsonline'] - $server['virtualserver_queryclientsonline'];
					$data['clients'][$server['virtualserver_port']]['clients'] = $server['virtualserver_maxclients'];
					$data['clients'][$server['virtualserver_port']]['online'] = $server['virtualserver_clientsonline'] - $server['virtualserver_queryclientsonline'];

					if($data['statistics']['server_online'] === null) {
						$data['statistics']['server_online'] = $server;
					} else if($server['virtualserver_uptime'] > $data['statistics']['server_online']) {
						$data['statistics']['server_online'] = $server;
					};

					if($data['statistics']['server_traffic'] === null) {
						$data['statistics']['server_traffic'] = $server;
						$data['statistics']['server_traffic']['virtualserver_traffic'] = $serverinfo['connection_bytes_sent_total'] + $serverinfo['connection_bytes_received_total'];
					} else if(($serverinfo['connection_bytes_sent_total'] + $serverinfo['connection_bytes_received_total']) > ($data['hostinfo']['connection_bytes_sent_total'] + $data['hostinfo']['connection_bytes_received_total'])) {
						$data['statistics']['server_traffic'] = $server;
						$data['statistics']['server_traffic']['virtualserver_traffic'] = $serverinfo['connection_bytes_sent_total'] + $serverinfo['connection_bytes_received_total'];
					};
				};
			};

			return generateOutput(true, null, $data);
		} else {
			return $ts;
		};
	};

	/**
		Get whole instance clients
		@param {int, string} $instance
		@return {Array} generateOutput
	*/
	function getInstanceClients($instance) {
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$data = [];

			$serverlist = $ts['data']->getElement('data', $ts['data']->serverlist());
			if(!empty($serverlist)) {
				foreach($serverlist AS $server) {
					if(!hasServerPerm($instance, $server['virtualserver_port'])) {
						continue;
					};
					
					$ts['data']->selectServer($server['virtualserver_port'], 'port', true);
					$clients = $ts['data']->getElement('data', $ts['data']->clientDbList(0, '900000'));
					$clientOnlineList = $ts['data']->getElement('data', $ts['data']->clientList());

					foreach($clients AS $client) {
						if($client['client_unique_identifier'] != 'ServerQuery') {
							$c['client_nickname'] = xssSafe($client['client_nickname']);
							$c['client_created'] = date('Y-m-d H:i:s', $client['client_created']);
							$c['client_lastconnected'] = date('Y-m-d H:i:s', $client['client_lastconnected']);
							$c['client_lastip'] = $client['client_lastip'];
							$c['client_totalconnections'] = $client['client_totalconnections'];
							$c['client_description'] = xssSafe($client['client_description']);
							$c['client_unique_identifier'] = $client['client_unique_identifier'];
							$c['cldbid'] = $client['cldbid'];
							$c['client_online'] = false;
							foreach($clientOnlineList AS $onlineClient) {
								if($onlineClient['client_database_id'] == $client['cldbid']) {
									$c['client_online'] = true;
									break;
								};
							};
							$data[] = $c;
						};
					};
				};
			};

			return generateOutput(true, null, $data);
		} else {
			return $ts;
		};
	};
	
	/**
		Execute a command in the query console
		@param {int, string} $instance
		@param {string} $command
		@param {int} $selectedserver
		@return {Array} generateOutput()
	*/
	function commandQueryConsole($instance, $command, $selectedserver = -1) {
		if(DEMO) {
			return generateOutput(false, 'Console is in demo mode forbidden', null);
		};
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Exec a Querycommand: ".$command." to: ".$instanz."", true);
			
			if($selectedserver != -1) {
				$ts['data']->selectServer($selectedserver, 'serverId', true);
			};
			
			$returnData = $ts['data']->execOwnCommand(3, $command);
			if(!$returnData) {
				$returnDataErrors = "";
				for($i=0; $i+1==count($returnData['errors']); $i++) {
					$returnDataErrors .= $returnData['errors'][$i].". ";
				};
				return generateOutput(false, $returnDataErrors, null);
			} else {
				return generateOutput(true, null, $returnData['data']);
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Stop a Teamspeakserver
		@param {int, string} $instance
		@param {int, string} $sid
		@param {string} $message
		@return {Array} generateOutput()
	*/
	function stopTeamspeakServer($instance, $sid, $message = null) {
		if(DEMO) {
			return generateOutput(false, 'You cant stop server in demo mode', null);
		};
		
		writeInLog($_SESSION['user']['benutzer'], "Stop a Teamspeakserver instance: ".$instance." Sid: ".$sid, true);
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			return $ts['data']->serverStop($sid, $message);
		} else {
			return $ts;
		};
	};
	
	/**
		Start a Teamspeakserver
		@param {int, string} $instance
		@param {int, string} $sid
		@return {Array} generateOutput()
	*/
	function startTeamspeakServer($instance, $sid) {
		if(DEMO) {
			return generateOutput(false, 'You cant start server in demo mode', null);
		};
		
		writeInLog($_SESSION['user']['benutzer'], "Start a Teamspeakserver instance: ".$instance." Sid: ".$sid, true);
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			return $ts['data']->serverStart($sid);
		} else {
			return $ts;
		};
	};
	
	/**
		Create a Teamspeakserver
		@param {int, string} $instance
		@param {Array} $data
		@param {int, bool} $template
		@return {Array} generateOutput()
	*/
	function createServer($instance, $data, $template) {
		if(DEMO) {
			return generateOutput(true, null, array('sid' => 2, 'virtualserver_port' => 9988, 'token' => 'eKnFZQ9EK7G7MhtuQB6+N2B1PNZZ6OZL3ycDp2OW'));
		};
		
		require_once(__dir__.'/../../config/templates/teamspeak_create_template_default.php');
		if($template !== 'false') {
			require_once(__dir__.'/../../config/templates/teamspeak_create_template_'.$template.'.php');
			unset($ts3_server_create_template['templatename']);
			unset($ts3_server_create_template['id']);
		} else {
			$ts3_server_create_template = [];
		};
		
		$serverData = array_merge($ts3_server_create_default, $ts3_server_create_template, (array)$data);
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			return $ts['data']->serverCreate($serverData);
		} else {
			return $ts;
		};
	};
	
	/**
		Delete a TeamspeakServer
		@param {int, string} $instance
		@param {int, string} $sid
		@param {int, string} $port
	*/
	function deleteTeamspeakserver($instance, $sid, $port) {
		if(DEMO) {
			return generateOutput(false, 'You cant delete server in demo mode', null);
		};
		
		global $ts3_server;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Delete Teamspeak Server Instance: ".$instance." Sid: ".$sid, true);
			
			$delete = $ts['data']->serverDelete($sid);
			if($delete['success']) {
				return deleteTeamspeakPort($instance, $port);
			} else {
				return $delete;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Instance poke or message
		@param {int, string} $instance
		@param {bool} $poke
		@param {string} $message
		@return {Array} generateOutput()
	*/
	function instanceMessagePoke($instance, $poke = false, $message) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $ts3_server;
		
		if($instance === 'all') {
			$ret = generateOutput(true, null, null);
			foreach($ts3_server AS $i=>$instance) {
				$ts = getTsAdminInstance($i);
				if($ts['success']) {
					$val = ($poke) ? instancePoke($ts['data'], $message) : instanceMessage($ts['data'], $message);
					if(!$val['success']) {
						$ret = $val;
					};
				};
			};
			if($ret['success']) {
				writeInLog($_SESSION['user']['benutzer'], ($poke) ? "Client send a instance poke to instance ".$instance : "Client send a instance message to instance ".$instance, true);
			};
			return $ret;
		} else {
			$ts = getTsAdminInstance($instance);
			if($ts['success']) {
				writeInLog($_SESSION['user']['benutzer'], ($poke) ? "Client send a instance poke to instance ".$instance : "Client send a instance message to instance ".$instance, true);
				return ($poke) ? instancePoke($ts['data'], $message) : instanceMessage($ts['data'], $message);
			} else {
				return $ts;
			};
		};
	};
	
	/**
		Instances message
		@param {Object} $con
		@param {string} $message
		@return {Array} generateOutput()
	*/
	function instanceMessage($con, $message) {
		$message = str_replace("\\", "\\\\", $message);
		$send = $con->gm($message);
		
		if($send['success']) {
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, implode('.', $send['errors']), null);
		};
	};
	
	/**
		Instances poke
		@param {Object} $con
		@param {string} $message
		@return {Array} generateOutput()
	*/
	function instancePoke($con, $message) {
		global $settings;
		
		$servers = $con->serverList();
		$i = 0;
		
		if($servers['success']) {
			foreach($servers['data'] as $server) {
				
				$con->selectServer($server['virtualserver_port'], 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
				$clientlist = $con->clientList("-groups");
				
				if($clientlist['success']) {
					$i++;
					foreach($clientlist['data'] AS $key=>$value) {
						if($value['client_type'] != 1) {
							$client_poke = $con->clientPoke($value['clid'], $message);
						};
					};
				};
			};
			
			if(count($servers['data']) == $i) {
				writeInLog($_SESSION['user']['benutzer'], "Teamspeak Server Instanz Poke ".$instanz, true);
				return generateOutput(true, null, null);
			} else {
				return generateOutput(false, 'Could not poke all clients', null);
			};
		} else {
			return generateOutput(false, implode('.', $servers['errors']), null);
		};
	};
	
	/**
		Get sgroup or cgroup select tree
		@param {Array} $groups
		@param {bool} $isCgroup
		@return {string}
	*/
	function getGroupSelectTree($groups, $isCgroup = false) {
		$group = "";
		$groupType = ($isCgroup) ? "cgroup" : "sgroup";
		
		foreach($groups AS $key => $value) {
			$valueId = ($isCgroup) ? $value['cgid'] : $value['sgid'];
			if ($value['type'] != '2' AND $value['type'] != '0') {
				$group .= "<option group='" . $groupType . "' value='" . $valueId . "'>" . xssSafe($value['name']) . "</option>";
			};
		};
		
		return $group;
	};
	
	/**
		Get full channel select tree
		@param {Array} $channels
		@param {bool} $subChannels
		@return {string}
	*/
	function getChannelSelectTree($channels, $subChannels = true) {
		global $language;
		
		if(!$subChannels) {
			return getChannelTree($channels, false);
		};
		
		$channelTree = '<optgroup label="'.$language['channel'].'">';
		$channelTree .= getChannelTree($channels, false);
		$channelTree .= '</optgroup>';
		$channelTree .= '<optgroup label="'.$language['sub_channel'].'">';
		$channelTree .= getChannelTree($channels, true);
		$channelTree .= '</optgroup>';
		
		return $channelTree;
	};
	
	/**
		Get full client select tree
		@param {Array} $clients
		@return {string}
	*/
	function getClientSelectTree($clients) {
		$clientTree = '';
		foreach($clients AS $client) {
			if($client['client_unique_identifier'] != 'ServerQuery') {
				$clientTree .= "<option value='".$client['cldbid']."'>".xssSafe($client['client_nickname'])."</option>";
			};
		};
		return $clientTree;
	};
	
	/**
		Get channel select tree
		@param {Array} $channels
		@param {bool} $subChannels
		@return {string}
	*/
	function getChannelTree($channels, $subChannels = false) {
		$channelTree = "";
		
		if(!empty($channels)) {
			foreach($channels AS $key=>$value) {
				if (($value['pid'] == 0 && !$subChannels) || ($value['pid'] != 0 && $subChannels)) {
					if(preg_match("^\[(.*)spacer([\w\p{L}\d]+)?\]^u", $value['channel_name'], $treffer) AND $value['pid'] == 0) {
						$getspacer = explode($treffer[0], $value['channel_name']);
						$checkspacer = $getspacer[1][0].$getspacer[1][0].$getspacer[1][0];
						if($treffer[1] == "*" or strlen($getspacer[1]) == 3 AND $checkspacer==$getspacer[1]) {
							$spacer = '';
							for($i=0; $i<=50; $i++) {
								if(strlen($spacer) < 50) {
									$spacer	.=	$getspacer[1];
								} else {
									break;
								};
							};
							$channelTree .= "<option value='".$value['cid']."'>".xssSafe($spacer)."</option>";
						} else {
							$spacer = explode($treffer[0], $value['channel_name']);
							$channelTree .= "<option value='".$value['cid']."'>".xssSafe($spacer[1])."</option>";
						};
					} else {
						$channelTree .= "<option value='".$value['cid']."'>".xssSafe($value['channel_name'])."</option>";
					};
				};
			};
		};
		
		return $channelTree;
	};
	
	/**
		Server message / poke
		@param {string, int} $instance
		@param {string, int} $port
		@param {bool} $poke
		@param {string} $message
		@return {Array} generateOutput()
	*/
	function serverMessage($instance, $sid, $poke = false, $message) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Teamspeak Servermessage or Serverpoke Message: ".$message." Instance: ".$instance." Sid: ".$sid, true);
			$ts['data']->selectServer($sid, 'serverId', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			if($poke) {
				$clientlist = $ts['data']->clientList("-groups");
				$status = "";
				
				foreach($clientlist['data'] AS $key=>$value) {
					if($value['client_type'] != 1) {
						$client_poke = $ts['data']->clientPoke($value['clid'], $message);
						
						if($client_poke['success'] === false) {
							for($i = 0; $i+1 == count($client_poke['errors']); $i++) {
								$status .= $client_poke['errors'][$i]."<br />";
							};
						};
					};
				};
				
				if($status != '') {
					return generateOutput(false, $status, null);
				} else {
					return generateOutput(true, null, null);
				};
			} else {
				$message = str_replace("\\", "\\\\", $message);
				return $ts['data']->sendMessage(3, $sid, $message);
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Delete a teamspeak channel
		@param {string, int} $instance
		@param {string, int} $sid
		@param {string, int} $cid
		@return {Array} generateOutput()
	*/
	function deleteChannel($instance, $sid, $cid) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($sid, 'serverId', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->channelDelete($cid, 1);
		} else {
			return $ts;
		};
	};
	
	/**
		Create a teamspeak channel
		@param {string, int} $instance
		@param {string, int} $sid
		@param {object} $data
		@return {Array} generateOutput()
	*/
	function createChannel($instance, $sid, $data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($sid, 'serverId', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->channelCreate((array)$data);
		} else {
			return $ts;
		};
	};
	
	/**
		Delete a teamspeak icon
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $id
		@return {Array} generateOutput()
	*/
	function deleteIcon($instance, $port, $id) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $ts3_server;
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			$ts['data']->ftDeleteFile(0, '', array("/icon_".$id));
			
			writeInLog($_SESSION['user']['benutzer'], "Delete a Teamspeakicon (".$id.") Instanz: ".$instanz." Sid: ".$serverId."", true);
			
			return generateOutput(@unlink('../../images/ts_icons/'.$ts3_server[$instance]['ip'].'-'.$port.'/'."icon_".$id), null, null);
		} else {
			return $ts;
		};
	};
	
	/**
		Delete a teamspeak ban
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $id
		@return {Array} generateOutput()
	*/
	function deleteBan($instance, $port, $id) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Delete a Ban Banid: ".$banid." Instance: ".$instance." Port: ".$port, true);
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->banDelete($id);
		} else {
			return $ts;
		};
	};
	
	/**
		Get the Querylog from a spezific instance and port
		@param {string, int} $instance
		@param {string, int} $port
		@return {Array} generateOutput()
	*/
	function getQueryLog($instance, $port) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->logView(100, 1);
		} else {
			return $ts;
		};
	};
	
	/**
		Get tokenlist from a server
		@param {string, int} $instance
		@param {string, int} $port
		@param {bool} $details
		@return {Array} generateOutput()
	*/
	function getServerToken($instance, $port, $details = true) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			
			if($details) {
				$tokenlist = $ts['data']->privilegekeyList();
				if(!$tokenlist['success'] || empty($tokenlist['data'])) {
					return $tokenlist;
				} else {
					$channels = $ts['data']->getElement('data', $ts['data']->channelList("-topic -flags -voice -limits -icon"));
					$sgroups = $ts['data']->getElement('data', $ts['data']->serverGroupList());
					$cgroups = $ts['data']->getElement('data', $ts['data']->channelGroupList());
					
					foreach($tokenlist['data'] AS $i=>$token) {
						if($token['token_type'] == 1) {
							foreach($cgroups AS $cgroup2) {
								if($cgroup2['cgid'] == $token['token_id1']) {
									$tokenlist['data'][$i]['groupname'] = xssSafe($cgroup2['name']);
								};
							};
							foreach($channels AS $channel) {
								if($channel['cid'] == $token['token_id2']) {
									$tokenlist['data'][$i]['channel'] = xssSafe($channel['channel_name']);
								};
							};
						} else {
							foreach($sgroups AS $sgroup2) {
								if($sgroup2['sgid'] == $token['token_id1']) {
									$tokenlist['data'][$i]['groupname'] = xssSafe($sgroup2['name']);
								};
							};
						};
					};
					
					return $tokenlist;
				};
			} else {
				return $ts['data']->privilegekeyList();
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Create a Ban for a teamspeak server
		@param {string, int} $instance
		@param {string, int} $port
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function createBan($instance, $port, $data) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			writeInLog($_SESSION['user']['benutzer'], "Teamspeak Client Ban Type: ".$data->type." Message: ".$data->reason." Client: ".$data->input." Time: ".$data->time." Instanz: ".$instance." Port: ".$port, true);
			
			switch($data->type) {
				case 'name':
					return $ts['data']->banAddByName($data->input, $data->time*60, $data->reason);
					break;
				case 'ip':
					return $ts['data']->banAddByIp($data->input, $data->time*60, $data->reason);
					break;
				case 'uid':
					return $ts['data']->banAddByUid($data->input, $data->time*60, $data->reason);
					break;
				case 'myid':
					return $ts['data']->banAddByMyTeamspeak($data->input, $data->time*60, $data->reason);
					break;
				default:
					return generateOutput(false, 'Bantype unknown', null);
					break;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Delete a Token from a teamspeak server
		@param {string, int} $instance
		@param {string, int} $port
		@param {string} $token
		@return {Array} generateOutput()
	*/
	function deleteToken($instance, $port, $token) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->tokenDelete($token);
		} else {
			return $ts;
		};
	};
	
	/**
		Create a Tokens in a teamspeak server
		@param {string, int} $instance
		@param {string, int} $port
		@param {Object} $tokens
		@return {Array} generateOutput()
	*/
	function createToken($instance, $port, $tokens) {
		if(DEMO) {
			return generateOutput(false, array('Not Allowed in the demo mode!'), null);
		};
		
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			$data = [];
			for($i = 0;$i < $tokens->num;$i++) {
				$token = $ts['data']->getElement('data', $ts['data']->tokenAdd($tokens->kind, $tokens->group, ($tokens->kind == 0) ? 0 : $tokens->channel, $tokens->description));
				writeInLog($_SESSION['user']['benutzer'], "Create Token (".$token['token'].") Instance: ".$instance." Port: ".$port, true);
				$data[] = $token;
			};
			return generateOutput(true, null, $data);
		} else {
			return $ts;
		};
	};
	
	/**
		Reset a teamspeak server
		@param {string, int} $instance
		@param {string, int} $port
		@return {Array} generateOutput()
	*/
	function resetServer($instance, $port) {
		if(DEMO) {
			return generateOutput(false, array('Not Allowed in the demo mode!'), null);
		};
		
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Reset a Teamspeakserver Instance: ".$instanz." Port: ".$port, true);
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->permReset();
		} else {
			return $ts;
		};
	};
	
	/**
		Download a file from a server channel
		@param {string, int} $instance
		@param {string, int} $port
		@param {string} $path
		@param {string} $filename
		@param {string, int} $cid
		return generateOutput()
	*/
	function downloadFileFromFilelist($port, $instance, $path, $filename, $cid) {
		global $ts3_server;
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			$ft = $ts['data']->ftInitDownload($path.$filename, $cid);
			
			if($ft['success'] || empty($ft['data']['port'])) {
				$con_ft = @fsockopen($ts3_server[$instance]['ip'], $ft['data']['port'], $errnum, $errstr, 10);
				if($con_ft) {
					fputs($con_ft, $ft['data']['ftkey']);
					$data = '';
					while (!feof($con_ft))  {
						$data .= fgets($con_ft, 4096);
					};
					
					header('Content-Disposition: attachment; filename="'.$filename.'"');
					header('Content-Type: x-type/subtype');
					
					return $data;
				} else {
					writeInLog(2, $_SESSION['user']['benutzer'].": Could not init the Downloadconnection ; File: ".$filename." ;  Instance: ".$instance." Port: ".$port, true);
					return generateOutput(false, array('socket could not be opened!'), null);
				};
			} else {
				writeInLog(2, $_SESSION['user']['benutzer'].": Could not init the Download ; File: ".$filename." ;  Instance: ".$instance." Port: ".$port, true);
				return $ft;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Delete a file from a server channel
		@param {string, int} $instance
		@param {string, int} $port
		@param {string} $path
		@param {string, int} $cid
		return generateOutput()
	*/
	function deleteChannelFile($instance, $port, $path, $cid) {
		if(DEMO) {
			return generateOutput(false, array('Not Allowed in the demo mode!'), null);
		};
		
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Delete File From Server: ChannelId: ".$cid." ; Path: ".$path." ;  Instance: ".$instance." Port: ".$port, true);
			
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->ftDeleteFile($cid, "", array($path));
		} else {
			return $ts;
		};
	};
	
	/**
		Function to create teamspeak channel or server backup
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $backup
		@return {Array} generateOutput()
	*/
	function createBackup($instance, $port, $backup) {
		if(DEMO) {
			return generateOutput(false, array('Not Allowed in the demo mode!'), null);
		};
		
		global $ts3_server;
		global $settings;
		
		$time = time();
		$backup->created = $time;
		$backup->instance = array(
			'alias' => $ts3_server[$instance]['alias'],
			'id' => $instance
		);
		$backup->port = $port;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Create a Backup Typ: ".$backup->type." Kind: ".$backup->kind." Instance: ".$instanz." Port: ".$port, true);
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			
			switch($backup->type) {
				case 'channel':
					switch($backup->kind) {
						case 'name':
							$channels = $ts['data']->channelList('-flags');
							if($channels['success']) {
								$backup->channels = [];
								foreach($channels['data'] AS $channel) {
									$backup->channels[] = array(
										'name' => $channel['channel_name'],
										'default' => $channel['channel_flag_default'],
										'cid' => $channel['cid'],
										'pid' => $channel['pid']
									);
								};
								return generateOutput(file_put_contents(__dir__.'/../../files/backups/'.$time.'.fcBackup', json_encode($backup)) !== false, null, $time);
							} else {
								return $channels;
							};
							break;
						case 'all':
							$channels = $ts['data']->channelList();
							if($channels['success']) {
								foreach($channels['data'] AS $channel) {
									$info = $ts['data']->channelInfo($channel['cid']);
									if($info['success']) {
										unset(
											$info['data']['channel_flag_password'],
											$info['data']['channel_codec_latency_factor'],
											$info['data']['channel_security_salt'],
											$info['data']['channel_delete_delay'],
											$info['data']['channel_filepath'],
											$info['data']['channel_forced_silence'],
											$info['data']['channel_flag_private'],
											$info['data']['seconds_empty'],
											$info['data']['channel_order'],
											$info['data']['channel_icon_id']
										);
										$info['data']['cid'] = $channel['cid'];
										$info['data']['pid'] = $channel['pid'];
										
										$backup->channels[] = $info['data'];
									} else {
										return $info;
									};
								};
								return generateOutput(file_put_contents(__dir__.'/../../files/backups/'.$time.'.fcBackup', json_encode($backup)) !== false, null, $time);
							} else {
								return $channels;
							};
							break;
						default:
							return generateOutput(false, array('Backup kind not supported!'), null);
							break;
					};
					break;
				case 'server':
					switch($backup->kind) {
						case 'snapshot':
							$snapshot = $ts['data']->serverSnapshotCreate();
							if($snapshot['success']) {
								$backup->snapshot = $snapshot['data'];
								return generateOutput(file_put_contents(__dir__.'/../../files/backups/'.$time.'.fcBackup', json_encode($backup)) !== false, null, $time);
							} else {
								return $snapshot;
							};
							break;
						case 'all':
							
							break;
					}
					break;
				default:
					return generateOutput(false, array('Backup type not supported!'), null);
					break;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get a permission tree
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $type
		@param {string, int} $group
		@return {Array} generateOutput()
	*/
	function getPermissionTree($instance, $port, $type, $group) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			
			switch($type) {
				case 'sgroup':
					return $ts['data']->serverGroupPermList($group, true);
					break;
				case 'cgroup':
					return $ts['data']->channelGroupPermList($group, true);
					break;
				case 'client':
					return $ts['data']->clientPermList($group, true);
					break;
				case 'channel':
					return $ts['data']->channelPermList($group, true);
					break;
				default:
					return $ts['data']->permissionList(true);
					break;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to delete a database client from the server database
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $cldbid
		@param {string} $time
		@return {Array} generateOutput()
	*/
	function deleteDBClient($instance, $port, $cldbid, $sgroups, $time = '') {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			
			if(!empty($cldbid)) {
				writeInLog($_SESSION['user']['benutzer'], "Delete DB Client ID: ".$cldbid." Channel Instance: ".$instance." Port: ".$port, true);
				return $ts['data']->clientDbDelete($cldbid);
			} else {
				$clientList = $ts['data']->clientDbList(0, ($settings['success']) ? $settings['data']['ts_get_db_clients'] : '900000');
				$data = [];
				foreach($clientList['data'] AS $client) {
					if($client['client_unique_identifier'] != 'ServerQuery' && $client['client_lastconnected'] <= $time) {
						$skip = false;
						if($sgroups !== null && $sgroups !== "") {
							$client['client_sgroups'] = $ts['data']->getElement('data', $ts['data']->serverGroupsByClientID($client['cldbid']));
							foreach($client['client_sgroups'] AS $sgroup) {
								if(in_array($sgroup['sgid'], $sgroups)) {
									$skip = true;
									break;
								};
							};
						};
						
						if($skip) {
							continue;
						};

						$del = $ts['data']->clientDbDelete($client['cldbid']);
						if($del['success'] !== false) {
							writeInLog($_SESSION['user']['benutzer'], "Delete DB Client ID: ".$client['cldbid']." Instance: ".$instance." Port: ".$port, true);
							$data[] = $client['cldbid'];
						} else {
							return $del;
						};
					};
				};
				return generateOutput(true, null, $data);
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to edit a server
		@param {string, int} $instance
		@param {string, int} $port
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function setServerSettings($instance, $port, $data) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			writeInLog($_SESSION['user']['benutzer'], "Edit a Teamspeakserver (".$value.") Instance: ".$instance." Port: ".$port, true);
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');

			if(array_key_exists("virtualserver_port", (array)$data)) {
				$edit = $ts['data']->serverEdit((array)$data);
				if($edit['success']) {
					return updateTeamspeakPort($instance, $port, $data->virtualserver_port);
				} else {
					return $edit;
				};
			} else {
				return $ts['data']->serverEdit((array)$data);
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to rename a server- or channelgroup
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $type
		@param {string, int} $gid
		@param {string} $name
		@return {Array} generateOutput()
	*/
	function setGroup($instance, $port, $type, $gid, $name) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			switch($type) {
				case 'sgroup':
					writeInLog($_SESSION['user']['benutzer'], "Change Servergroup (".$gid.") to ".$name." Instance: ".$instance." Port: ".$port, true);
					return $ts['data']->serverGroupRename($gid, $name);
					break;
				case 'cgroup':
					writeInLog($_SESSION['user']['benutzer'], "Change Channelgroup (".$gid.") to ".$name." Instance: ".$instance." Port: ".$port, true);
					return $ts['data']->channelGroupRename($gid, $name);
					break;
				default:
					return generateOutput(false, array('Unknown type'), null);
					break;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to set server- or channelgroup permissions
		@param {string, int} $instance
		@param {string, int} $port
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function setGroupPermissions($instance, $port, $type, $id, $data) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			$add = [];
			$remove = [];
			
			foreach($data AS $perm => $values) {
				if($values->val === false) {
					$remove[] = $perm;
				} else {
					switch($type) {
						case 'sgroup':
							$add[$perm] = array($values->val, $values->skip, $values->negated);
							break;
						case 'cgroup':
							$add[$perm] = $values->val;
							break;
						case 'channel':
							$add[$perm] = $values->val;
							break;
						case 'client':
							$add[$perm] = array($values->val, $values->skip);
							break;
					};
				};
			};
			
			$adding = generateOutput(true, null, null);
			if(!empty($add)) {
				switch($type) {
					case 'sgroup':
						$adding = $ts['data']->serverGroupAddPerm($id, $add);
						break;
					case 'cgroup':
						$adding = $ts['data']->channelGroupAddPerm($id, $add);
						break;
					case 'channel':
						$adding = $ts['data']->channelAddPerm($id, $add);
						break;
					case 'client':
						$adding = $ts['data']->clientAddPerm($id, $add);
						break;
					default:
						return generateOutput(false, array('Unknown type!'), null);
						break;
				};
			};
			
			if($adding['success'] && !empty($remove)) {
				switch($type) {
					case 'sgroup':
						return $ts['data']->serverGroupDeletePerm($id, $remove);
						break;
					case 'cgroup':
						return $ts['data']->channelGroupDelPerm($id, $remove);
						break;
					case 'channel':
						return $ts['data']->channelDelPerm($id, $remove);
						break;
					case 'client':
						return $ts['data']->clientDelPerm($id, $remove);
						break;
				};
			} else {
				return $adding;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get the members of a server- or channelgroup
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $type
		@param {string, int} $gid
		@return {Array} generateOutput()
	*/
	function getGroupMembers($instance, $port, $type, $gid) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			switch($type) {
				case 'sgroup':
					return $ts['data']->serverGroupClientList($gid, true);
					break;
				case 'cgroup':
					return $ts['data']->channelGroupClientList(null, null, $gid);
					break;
				default:
					return generateOutput(false, array('Unknown type'), null);
					break;
			};
		} else {
			return $ts;
		};
	};

	/**
		Function to set a members server- or channelgroup
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $type
		@param {string, int} $gid
		@param {string, int} $cldbid
		@param {string, int} $cid
		@param {string} $value
		@return {Array} generateOutput()
	*/
	function setGroupMember($instance, $port, $type, $gid, $cldbid, $cid = null, $value) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			switch($type) {
				case 'sgroup':
					return ($value === "true") ? $ts['data']->serverGroupAddClient($gid, $cldbid) : $ts['data']->serverGroupDeleteClient($gid, $cldbid);
					break;
				case 'cgroup':
					return $ts['data']->channelGroupAddClient($gid, $cid, $cldbid);
					break;
				default:
					return generateOutput(false, array('Unknown type'), null);
					break;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to delete members of a servergroup
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $gid
		@param {string, int} $id
		@return {Array} generateOutput()
	*/
	function deleteServerGroupClient($instance, $port, $gid, $id) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			return $ts['data']->serverGroupDeleteClient($gid, $id);
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get or set mass actions
		@param {string, int} $instance
		@param {string, int} $port
		@param {string} $option
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function getMassActionMember($instance, $port, $option, $data) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ret = [];
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			$clients = $ts['data']->clientList("-groups -country");
			if($clients['success']) {
				switch($data->group) {
					case 'all':
						foreach($clients['data'] AS $client) {
							if($client['client_type'] == "1") {
								continue;
							};
							if((empty($data->channel) || $data->channel === 'none') || $client['client_channel_group_inherited_channel_id'] == $data->channel) {
								$ret[] = $client;
							};
						};
						break;
					default:
						foreach($clients['data'] AS $client) {
							if($client['client_type'] == "1") {
								continue;
							};
							if((empty($data->channel) || $data->channel === 'none') || $client['client_channel_group_inherited_channel_id'] == $data->channel) {
								if($client['client_channel_group_id'] == $data->group) {
									$ret[] = $client;
								} else {
									$sgroups = explode(",", $client['client_servergroups']);
									for($i = 0; $i < count($sgroups); $i++) {
										if($sgroups[$i] == $data->group) {
											$ret[] = $client;
										};
									};
								};
							};
						};
						break;
				};
				return generateOutput(true, null, $ret);
			} else {
				return $clients;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to set a client. Like kick, ban, move....
		@param {string, int} $instance
		@param {string, int} $port
		@param {Object} $data
		@return {Array} generateOutput()
	*/
	function setClient($instance, $port, $data) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			switch($data->action) {
				case 'msg':
					if($data->type === 'msg') {
						return $ts['data']->sendMessage(1, $data->clid, $data->message);
					} else {
						return $ts['data']->clientPoke($data->clid, $data->message);
					};
					break;
				case 'move':
					return $ts['data']->clientMove($data->clid, $data->channel);
					break;
				case 'kick':
					return $ts['data']->clientKick($data->clid, $data->type, $data->message);
					break;
				case 'ban':
					return $ts['data']->banClient($data->clid, $data->time*60, $data->message);
					break;
			};
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get client information
		@param {string, int} $instance
		@param {string, int} $port
		@param {string, int} $clid
		@return {Array} generateOutput()
	*/
	function getClient($instance, $port, $clid) {
		global $settings;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			$ts['data']->selectServer($port, 'port', true, ($settings['success']) ? $settings['data']['extern_name'] : 'TS3-Servewache');
			$client = $ts['data']->clientInfo($clid);
			
			if($client['success']) {
				$client['data']['client_avatar'] = $ts['data']->getElement('data', $ts['data']->clientAvatar($clientInfo['data']['client_unique_identifier']));
				return $client;
			} else {
				return $client;
			};
		} else {
			return $ts;
		};
	};
	
	
	
	
	/*
		Change the Client Channelgroup
	*/
	function TeamspeakServerClientChangeChannelGroup($cgid, $cid, $clid, $port, $instanz)
	{
		global $ts3_server;
		
		$tsAdmin = new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
			$tsAdmin->selectServer($port, 'port', true);
			$tsAdmin->setName(TS3_CHATNAME);
			
			$client_cgroup = $tsAdmin->setClientChannelGroup($cgid, $cid, $clid);
			if($client_cgroup['success'] === false)
			{
				for($i = 0; $i+1 == count($client_cgroup['errors']); $i++)
				{
					$status .= $client_cgroup['errors'][$i]."<br />";
				};
			}
			else
			{
				writeInLog($_SESSION['user']['benutzer'], "Teamspeak Client Change Channelgroup Sgroup: ".$cgid." Client: ".$clid." Instanz: ".$instanz." Port: ".$port, true);
				
				$status = "done";
			};
			
			$tsAdmin->logout();
			
			return $status;
		}
		else
		{
			return "No Connection";
		};
	};
	
	/*
		Remove a Client Servergroup
	*/
	function TeamspeakServerClientRemoveServerGroup($sgid, $clid, $port, $instanz, $permission)
	{
		global $ts3_server;
		
		$tsAdmin = new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
			$tsAdmin->selectServer($port, 'port', true);
			$tsAdmin->setName(TS3_CHATNAME);
			
			$client_sgroup = ($permission == "true") ? $tsAdmin->serverGroupAddClient($sgid, $clid) : $tsAdmin->serverGroupDeleteClient($sgid, $clid);
			if($client_sgroup['success'] === false)
			{
				for($i = 0; $i+1 == count($client_sgroup['errors']); $i++)
				{
					$status .= $client_sgroup['errors'][$i]."<br />";
				};
			}
			else
			{
				writeInLog($_SESSION['user']['benutzer'], "Teamspeak Client Change Servergroup Sgroup: ".$sgid." Client: ".$clid." Instanz: ".$instanz." Port: ".$port." Permission: ".$permission, true);
				
				$status = "done";
			};
			
			$tsAdmin->logout();
			
			return $status;
		}
		else
		{
			return "No Connection";
		};
	};
	
	/*
		Edit Teamspeakserver
	*/
	function TeamspeakServerEdit($right, $value, $instanz, $serverId, $port)
	{
		global $ts3_server;
		
		$tsAdmin = new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
			$tsAdmin->selectServer($serverId, 'serverId', true);
			
			$status				=	'';
			$server_edit 		=	$tsAdmin->serverEdit(array($right=>$value));
			
			if($server_edit['success'] === false)
			{
				for($i=0; $i+1==count($server_edit['errors']); $i++)
				{
					$status	.= 	$server_edit['errors'][$i]."<br />";
				};
			}
			else
			{
				if($right == 'virtualserver_port')
				{
					$status2					=		TeamspeakServerEditMySQLChange($port, $instanz, $value);
				}
				else
				{
					$status2					=		true;
				};	
				
				if($status == '')
				{
					if($status2)
					{
						writeInLog($_SESSION['user']['benutzer'], "Edit a Teamspeakserver (".$value.") Instanz: ".$instanz." Sid: ".$serverId."", true);
						
						$status					=		'done';
					}
					else
					{
						$status					=		'Serverport changed! But cant change the Port in the Database!';
					};
				};
			};
		}
		else
		{
			$status 						= 		'No Teamspeak Connection';
		};
		
		return $status;
	}
	
	
	
	/*
		Delete just one Teamspeak Channel from a spezific Teamspeakserver
	*/
	function deleteTeamspeakChannel($cid, $port, $instanz)
	{
		global $ts3_server;
		
		$tsAdmin 			= 	new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
			$tsAdmin->selectServer($port, 'port', true);
			$tsAdmin->channelDelete($cid);
			
			return true;
		}
		else
		{
			return false;
		};
	};
	
	/*
		Create a Teamspeak Channel in a spezific Teamspeakserver
	*/
	function createTeamspeakChannel($tsAdmin, $name, $default, $port, $instanz, $justData = false, $ownData)
	{
		$channelInfo								=	array();
		
		if(!$justData)
		{
			$data 									= 	array();
			$data['channel_name'] 					= 	$name;
			$data['channel_flag_permanent'] 		= 	'1';
			if($default)
			{
				$data['channel_flag_default'] 		= 	'1';
			};
			
			$channelInfo							=	$tsAdmin->channelCreate($data);
		}
		else
		{
			$channelInfo							=	$tsAdmin->channelCreate($ownData);
		};
		
		writeInLog($_SESSION['user']['benutzer'], "Create a Teamspeak Channel Name: ".$name." Port: ".$port, true);
		
		return $channelInfo['cid'];
	};
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
		Teamspeakserver Clientactions
	*/
	function TeamspeakServerClientAction($action, $message, $clid, $cid, $port, $instanz, $kickmode)
	{
		global $ts3_server;
		
		$tsAdmin = new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
			
			$tsServerID 				= 	$tsAdmin->serverIdGetByPort($port);
			$tsAdmin->selectServer($tsServerID['data']['server_id'], 'serverId', true);
			$tsAdmin->setName(TS3_CHATNAME);
			
			switch($action)
			{
				case "clientMsg":
					$actionStatus 		= 	$tsAdmin->sendMessage(1, $clid, $message);
					break;
				case "clientPoke":
					$actionStatus 		= 	$tsAdmin->clientPoke($clid, $message);
					break;
				case "clientMove":
					$actionStatus 		= 	$tsAdmin->clientMove($clid, $cid);
					break;
				case "clientKick":
					$actionStatus		=	$tsAdmin->clientKick($clid, $kickmode, $message);
					break;
				case "clientBan":
					$actionStatus		=	$tsAdmin->banClient($clid, $time*60, $message);
					break;
			};
			
			if($actionStatus['success'] === false)
			{
				for($i = 0; $i+1 == count($actionStatus['errors']); $i++)
				{
					$status 			.= 	$actionStatus['errors'][$i]."<br />";
				};
			}
			else
			{
				writeInLog($_SESSION['user']['benutzer'], "Teamspeak Client Message Message: ".$message." Instanz: ".$instanz." Port: ".$port, true);
				
				$status 				= 	"done";
			};
			
			$tsAdmin->logout();
			
			return $status;
		}
		else
		{
			return "No Connection";
		};
	};
	
	
	
	
	
	
	
	
	
	/*
		Get all Informations above a Teamspeakserver
	*/
	function TeamspeakInstanzServerlistInformations()
	{
		global $ts3_server;
		
		$informations	=	array();
		
		foreach($ts3_server AS $instanz => $values)
		{
			$tsAdmin 								= 	new ts3admin($values['ip'], $values['queryport']);
			
			if($tsAdmin->getElement('success', $tsAdmin->connect()))
			{
				$tsAdmin->login($values['user'], $values['pw']);
				
				$informations[$instanz]		=	array();
				
				$servers 					= 	$tsAdmin->serverList();
				
				foreach($servers['data'] as $server)
				{
					$informations[$instanz][$server['virtualserver_id']]['uptime']			=	(isset($server['virtualserver_uptime'])) ? true : false;
					$informations[$instanz][$server['virtualserver_id']]['online']			=	($server['virtualserver_status'] == 'online') ? true : false;
					$informations[$instanz][$server['virtualserver_id']]['clients']			=	(isSet($server['virtualserver_clientsonline'])) ? $server['virtualserver_clientsonline'] : '';
					$informations[$instanz][$server['virtualserver_id']]['maxclients']		=	(isSet($server['virtualserver_maxclients'])) ? $server['virtualserver_maxclients'] : '';
				};
				
				$tsAdmin->logout();
			};
		};
		
		return $informations;
	};
	
	/*
		Edit a Teamspeakinstance and return if the connection was successfull
	*/
	function editInstance($instanz, $what, $content)
	{
		global $ts3_server;
		
		if($instanz != '' && $what != '' && $content != '')
		{
			$new_file				=	array();
			$instanceFile			=	"../../config/instance.php";
			$file					=	file($instanceFile);
			$search					=	'$ts3_server[' . $instanz . '][\'' . $what . '\']';
			
			for ($i = 0; $i < count($file); $i++)
			{
				if(strpos($file[$i], $search) && $what != 'queryport')
				{
					$new_file[$i]		=	"\t" . $search . "\t\t= '" . $content . "';\n";
				}
				elseif (strpos($file[$i], $search))
				{
					$new_file[$i]		=	"\t" . $search . "\t= " . $content . ";\n";
				}
				else
				{
					$new_file[$i]		=	$file[$i];
				};
			};
			
			file_put_contents($instanceFile, "");
			file_put_contents($instanceFile, $new_file);
			
			switch($what)
			{
				case "ip":
					$ts3_server[$instanz]['ip']			=	$content;
					break;
				case "queryport":
					$ts3_server[$instanz]['queryport']	=	$content;
					break;
				case "user":
					$ts3_server[$instanz]['user']		=	$content;
					break;
				case "pw":
					$ts3_server[$instanz]['pw']			=	$content;
					break;
			};
			
			writeInLog($_SESSION['user']['benutzer'], "Has Edit the Instanz \"".$instanz."\"", true);
			
			$tsAdmin 					= 	new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
			if($tsAdmin->getElement('success', $tsAdmin->connect()))
			{
				$check_login			=	$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
				
				$tsAdmin->logout();
				
				if($check_login['success']!==false)
				{
					return 'done';
				}
				else
				{
					for($i=0; $i+1==count($check_login['errors']); $i++)
					{
						$returnValue		.=	$check_login['errors'][$i]."<br />";
					};
					return $returnValue;
				};
			}
			else
			{
				return "Connection failed!";
			};
		}
		else
		{
			return 'Invalid Parameter';
		};
	};
	
	/*
		Get Teamspeakslots and Teamspeak active slots from an Instanz
	*/
	function getTeamspeakslots($instanz)
	{
		global $ts3_server;
		
		$returnArray	=	array();
		$tsAdmin 		= 	new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
			
			$returnArray	=	getTeamspeakslotsArray($tsAdmin->getElement('data', $tsAdmin->serverList()), $instanz, false);
		};
		
		return $returnArray;
	};
	
	function getTeamspeakslotsArray($serverList, $instanz, $forceInfo = false)
	{
		global $ts3_server;
		global $mysql_keys;
		
		$user_right													=	getUserRights('pk', $_SESSION['user']['id']);
		
		if(count($serverList) > 3 && !$forceInfo)
		{
			$instanzName											=	$ts3_server[$instanz]['alias'];
			
			if($ts3_server[$instanz]['alias'] == "")
			{
				$instanzName										=	$ts3_server[$instanz]['ip'];
			};
			
			$returnArray											=	array();
			$returnArray[0]											=	array();
			$returnArray[0]['virtualserver_clientsonline']			=	0;
			$returnArray[0]['virtualserver_maxclients']				=	0;
			$returnArray[0]['instanz_name']							=	$instanzName;
			
			if(!empty($serverList))
			{
				foreach($serverList AS $server)
				{
					if(strpos($user_right['right_web_server_view'][$instanz], $server['virtualserver_port']) !== false || $user_right['right_web_global_server']['key'] == $mysql_keys['right_web_global_server'])
					{
						$returnArray[0]['virtualserver_clientsonline']	=	$returnArray[0]['virtualserver_clientsonline'] + ($server['virtualserver_clientsonline'] - $server['virtualserver_queryclientsonline']);
						$returnArray[0]['virtualserver_maxclients']		=	$returnArray[0]['virtualserver_maxclients'] + $server['virtualserver_maxclients'];
					};
				};
			};
			
			return $returnArray;
		}
		else
		{
			$newServerList											=	array();
			if(!empty($serverList))
			{
				foreach($serverList AS $server)
				{
					if(strpos($user_right['right_web_server_view'][$instanz], $server['virtualserver_port']) !== false || $user_right['right_web_global_server']['key'] == $mysql_keys['right_web_global_server'])
					{
						$server['virtualserver_clientsonline']			=	$server['virtualserver_clientsonline'] - $server['virtualserver_queryclientsonline'];
						$newServerList[]								=	$server;
					};
				};
			};
			return $newServerList;
		};
	};
	
	/*
		Returns the Serverid from a Serverport
	*/
	function getServerIdByPort($instanz, $port)
	{
		global $ts3_server;
		
		$tsAdmin = new ts3admin($ts3_server[$instanz]['ip'], $ts3_server[$instanz]['queryport']);
		
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[$instanz]['user'], $ts3_server[$instanz]['pw']);
			return $tsAdmin->serverIdGetByPort($port)['data']['server_id'];
		};
		
		return -1;
	};
	
	/**
		Get channel codec name
		@param {int} $codec
		@return {string}
	*/
	function getChannelCodec($codec) {
		$c = '';
		switch($codec) {
			case 0:
				$c = 'Speex Narrowband (8 kHz)';
				break;
			case 1:
				$c = 'Speex Wideband (16 kHz)';
				break;
			case 2:
				$c = 'Speex Ultra-Wideband (32 kHz)';
				break;
			case 3:
				$c = 'CELT Mono (48 kHz)';
				break;
			case 4:
				$c = 'Opus Voice';
				break;
			case 5:
				$c = 'Opus Musik';
				break;
		};
		return $c;
	};
	
	/**
		Get channel type
		@param {Array} $channel
		@return {string}
	*/
	function getChannelType($channel) {
		global $language;
		
		if($channel['channel_flag_permanent'] == '1') {
			return $language['permanent'];
		} else if($channel['channel_flag_semi_permanent'] == '1') {
			return $language['semi_permanent'];
		} else {
			return $language['temporary'];
		};
	};
	
	/**
		Function to get all information to create a teamspeak tree
		@param {int, string} $instance
		@param {int, string} $port
		@param {bool} $getIcons
		@return {Array} generateOutput()
	*/
	function getTeamspeakBaum($instance, $port, $getIcons) {
		global $ts3_server;
		global $language;
		
		$ts = getTsAdminInstance($instance);
		if($ts['success']) {
			// Select server
			$ts['data']->selectServer($port, 'port', true);
			
			// Load icons
			if($getIcons) {
				getTeamspeakIcons($ts, $ts3_server[$instance]['ip'], $port);
			};
			
			// Return array
			$tree = [];
			$tree['channels'] = [];
			$tree['subChannels'] = [];
			$tree['clients'] = [];
			
			// Get all information
			$alldata = [];
			$alldata['server'] = $ts['data']->getElement('data', $ts['data']->serverInfo());
			$alldata['channel'] = $ts['data']->getElement('data', $ts['data']->channelList("-topic -flags -voice -limits -icon"));
			$alldata['clients'] = $ts['data']->getElement('data', $ts['data']->clientList("-uid -away -voice -times -groups -info -icon -country -ip"));
			$alldata['sgroups'] = $ts['data']->getElement('data', $ts['data']->serverGroupList());
			$alldata['cgroups'] = $ts['data']->getElement('data', $ts['data']->channelGroupList());
			
			if($alldata['server']['virtualserver_icon_id'] < 0) {
				$alldata['server']['virtualserver_icon_id'] = sprintf('%u', $alldata['server']['virtualserver_icon_id'] & 0xffffffff);
			};
			
			// Temp vars
			$counter = 0;
			$counterSubchannels = 0;
			$counterClients = 0;
			
			// Save basic information
			$days = $alldata['server']['virtualserver_uptime'] / 86400;
			$hours = ($alldata['server']['virtualserver_uptime'] - (floor($days) * 86400)) / 3600;
			$minutes = ($alldata['server']['virtualserver_uptime'] - (floor($days) * 86400) - (floor($hours) * 3600)) / 60;
			$seconds = ($alldata['server']['virtualserver_uptime'] - (floor($days) * 86400) - (floor($hours) * 3600)) - (floor($minutes) * 60);
			
			$tree['serverstatus'] = $alldata['server']['virtualserver_status'];
			$tree['servername'] = xssSafe($alldata['server']['virtualserver_name']);
			$tree['servericon'] = getTeamspeakBaumIcon($ts3_server[$instance]['ip'], "icon_".$alldata['server']['virtualserver_icon_id'], $alldata['server']['virtualserver_port']);
			$tree['servertimeup'] = floor($days) . "d " . floor($hours) . "h " . floor($minutes) . "m " . floor($seconds) . "s";
			$tree['serverchannels'] = $alldata['server']['virtualserver_channelsonline'];
			$tree['serverpassword'] = ($alldata['server']['virtualserver_flag_password']) ? $language['yes'] : $language['no'];
			$tree['servermaxclients'] = $alldata['server']['virtualserver_maxclients'];
			$tree['serverclients'] = $alldata['server']['virtualserver_clientsonline'];
			$tree['serverqclients'] = $alldata['server']['virtualserver_queryclientsonline'];
			
			// Create channel, subchannel and clients array
			if(!empty($alldata['channel'])) {
				foreach($alldata['channel'] AS $key => $value) {
					if ($value['pid'] == 0) { // main channels
						$tree['channels'][$counter]['cid'] = $value['cid'];
						$tree['channels'][$counter]['pid'] = $value['pid'];
						
						$tree['channels'][$counter]['channelname'] = xssSafe($value['channel_name']);
						$tree['channels'][$counter]['channel_flag_password'] = $value['channel_flag_password'];
						$tree['channels'][$counter]['channel_flag_default'] = $value['channel_flag_default'];
						$tree['channels'][$counter]['channel_codec'] = getChannelCodec(intval($value['channel_codec']));
						$tree['channels'][$counter]['channel_needed_talk_power'] = $value['channel_needed_talk_power'];
						$tree['channels'][$counter]['channel_flag_permanent'] = $value['channel_flag_permanent'];
						$tree['channels'][$counter]['channel_type'] = getChannelType($value);
						$tree['channels'][$counter]['channel_topic'] = xssSafe($value['channel_topic']);
						$tree['channels'][$counter]['channel_maxclients'] = $value['channel_maxclients'];
						
						
						if(preg_match("^\[(.*)spacer([\w\p{L}\d]+)?\]^u", $value['channel_name'], $treffer) && $value['pid'] == 0 && $value['channel_flag_permanent'] == 1) {
							$tree['channels'][$counter]['spacer'] = true;
							$getspacer = explode($treffer[0], $value['channel_name']);
							$checkspacer = $getspacer[1][0].$getspacer[1][0].$getspacer[1][0];
							
							// main channel with unlimited spacer
							if($treffer[1]=="*" or strlen($getspacer[1]) == 3 AND $checkspacer == $getspacer[1]) {
								$spacer = '';
								for($i=0; $i<=500; $i++) {
									if(strlen($spacer) < 500) {
										$spacer	.=	$getspacer[1];
									} else {
										break;
									};
								};
								$tree['channels'][$counter]['channelname'] = $spacer;
								$tree['channels'][$counter]['align'] = 'left';
								
							} elseif($treffer[1]=="c") { // center spacer
								$spacer = explode($treffer[0], xssSafe($value['channel_name']));
								$tree['channels'][$counter]['channelname'] = $spacer[1];
								$tree['channels'][$counter]['align'] = 'center';
							} elseif($treffer[1]=="r") { // right spacer
								$spacer = explode($treffer[0], xssSafe($value['channel_name']));
								$tree['channels'][$counter]['channelname'] = $spacer[1];
								$tree['channels'][$counter]['align'] = 'right';
							} else { // normal just with spacer
								$spacer = explode($treffer[0], xssSafe($value['channel_name']));
								$tree['channels'][$counter]['channelname'] = $spacer[1];
								$tree['channels'][$counter]['align'] = 'left';
							};
						} else { // normal channel
							$tree['channels'][$counter]['spacer'] = false;
							$chanmaxclient = ($value['channel_maxclients']=="-1" ? $alldata['server']['virtualserver_maxclients'] : $value['channel_maxclients']);
							
							if($value['channel_icon_id'] != 0) {
								if($value['channel_icon_id'] < 0) {
									$value['channel_icon_id'] = sprintf('%u', $value['channel_icon_id'] & 0xffffffff);
								};
								$tree['channels'][$counter]['channel_icon_id'] = getTeamspeakBaumIcon($ts3_server[$instance]['ip'], "icon_".$value['channel_icon_id'], $alldata['server']['virtualserver_port']);
							} else {
								$tree['channels'][$counter]['channel_icon_id'] = false;
							};
							
							if($chanmaxclient <= $value['total_clients']) {
								$tree['channels'][$counter]['img_before']				=	"images/ts_viewer/channel_red.png";
							} elseif($value['channel_flag_password'] == 1) {
								$tree['channels'][$counter]['img_before']				=	"images/ts_viewer/pwchannel.png";
							} else {
								$tree['channels'][$counter]['img_before']				=	"images/ts_viewer/channel.png";
							};
						};
						
						$counter++;
					} else { // subchannels
						$tree['subChannels'][$counterSubchannels]['pid'] = $value['pid'];
						$tree['subChannels'][$counterSubchannels]['cid'] = $value['cid'];
						
						$tree['subChannels'][$counterSubchannels]['channel_flag_password'] = $value['channel_flag_password'];
						$tree['subChannels'][$counterSubchannels]['channel_flag_default'] = $value['channel_flag_default'];
						$tree['subChannels'][$counterSubchannels]['channel_codec'] = getChannelCodec(intval($value['channel_codec']));
						$tree['subChannels'][$counterSubchannels]['channel_needed_talk_power'] = $value['channel_needed_talk_power'];
						$tree['subChannels'][$counterSubchannels]['channelname'] = xssSafe($value['channel_name']);
						$tree['subChannels'][$counterSubchannels]['channel_flag_permanent'] = $value['channel_flag_permanent'];
						$tree['subChannels'][$counterSubchannels]['channel_topic'] = xssSafe($value['channel_topic']);
						$tree['subChannels'][$counterSubchannels]['channel_type'] = getChannelType($value);
						$tree['subChannels'][$counterSubchannels]['channel_maxclients'] = $value['channel_maxclients'];
						
						$chanmaxclient = ($value['channel_maxclients']=="-1" ? $alldata['server']['virtualserver_maxclients'] : $value['channel_maxclients']);
						
						if($value['channel_icon_id'] != 0) {
							if($value['channel_icon_id'] < 0) {
								$value['channel_icon_id'] = sprintf('%u', $value['channel_icon_id'] & 0xffffffff);
							};
							$tree['subChannels'][$counterSubchannels]['sub_channel_icon_id'] = getTeamspeakBaumIcon($ts3_server[$instance]['ip'], "icon_".$value['channel_icon_id'], $alldata['server']['virtualserver_port']);
						} else {
							$tree['subChannels'][$counterSubchannels]['sub_channel_icon_id'] = false;
						};
						
						if($chanmaxclient <= $value['total_clients']) {
							$tree['subChannels'][$counterSubchannels]['sub_img_before']			=	"images/ts_viewer/channel_red.png";
						} elseif($value['channel_flag_password'] == 1) {
							$tree['subChannels'][$counterSubchannels]['sub_img_before']			=	"images/ts_viewer/pwchannel.png";
						} else {
							$tree['subChannels'][$counterSubchannels]['sub_img_before']			=	"images/ts_viewer/channel.png";
						};
						
						$counterSubchannels++;
					};
					
					if($value['total_clients'] >= 1 && !empty($alldata['clients'])) { // clients
						foreach($alldata['clients'] AS $u_key=>$u_value) {
							if($value['cid'] == $u_value['cid']) { // client is in channel && !$isBlocked) // Ob Client auch im Channel ist
								if($u_value['client_type'] != "1") { // no queryclient
									$tree['clients'][$counterClients]['nick_away_message'] = '';
									
									if($u_value['client_away'] == "1") {
										$tree['clients'][$counterClients]['nick_status'] = 'away';
										if(!empty($u_value['client_away_message'])) {
											$tree['clients'][$counterClients]['nick_away_message'] =	'(' . $u_value['client_away_message'] . ')';
										};
									} elseif($u_value['client_output_hardware'] == "0") {
										$tree['clients'][$counterClients]['nick_status'] = 'hwhead';
									} elseif($u_value['client_input_hardware'] == "0") {
										$tree['clients'][$counterClients]['nick_status'] = 'hwmic';
									} elseif($u_value['client_output_muted'] == "1") {
										$tree['clients'][$counterClients]['nick_status'] = 'head';
									} elseif($u_value['client_input_muted']=="1") {
										$tree['clients'][$counterClients]['nick_status'] = 'mic';
									} elseif($u_value['client_flag_talking'] == "0" AND $u_value['client_is_channel_commander'] == "1") {
										$tree['clients'][$counterClients]['nick_status'] = 'player_command';
									} elseif($u_value['client_flag_talking'] == "1" AND $u_value['client_is_channel_commander'] == "1") {
										$tree['clients'][$counterClients]['nick_status'] = 'player_command_on';
									} elseif($u_value['client_flag_talking']=="1") {
										$tree['clients'][$counterClients]['nick_status'] = 'player_on';
									} else {
										$tree['clients'][$counterClients]['nick_status'] = 'player';
									};
									
									// country image
									$tree['clients'][$counterClients]['nick_country'] = (!empty($u_value['client_country'])) ? strtolower($u_value['client_country']) : '';
									
									// get sgroups
									$anzahlServergruppen = 0;
									$tree['clients'][$counterClients]['sgroup'] = [];
									$getsgroups = explode(',', trim($u_value['client_servergroups']));
									if(!empty($alldata['sgroups'])) {
										foreach($alldata['sgroups'] AS $key=>$sg_value) {
											if(in_array($sg_value['sgid'], $getsgroups)) {
												$iconid = $sg_value['iconid'];
												if($iconid < 0) {
													$iconid								=	sprintf('%u', $iconid & 0xffffffff);
												};
												
												if($iconid != 0) {
													$tree['clients'][$counterClients]['sgroup'][$anzahlServergruppen++] = getTeamspeakBaumIcon($ts3_server[$instance]['ip'], "icon_".$iconid, $alldata['server']['virtualserver_port']);
												};
											};
										};
									};
									
									// get cgroups
									$anzahlChannelgruppen = 0;
									$tree['clients'][$counterClients]['cgroup'] = [];
									if(!empty($alldata['cgroups'])) {
										foreach($alldata['cgroups'] AS $key=>$cg_value) {
											if($cg_value['cgid'] == $u_value['client_channel_group_id']) {
												$iconid = $cg_value['iconid'];
												if($iconid < 0) {
													$iconid								=	sprintf('%u', $iconid & 0xffffffff);
												};
												
												if($iconid != 0) {
													$tree['clients'][$counterClients]['cgroup'][$anzahlChannelgruppen] = getTeamspeakBaumIcon($ts3_server[$instance]['ip'], "icon_".$iconid, $alldata['server']['virtualserver_port']);
												};
											};
										};
									};
									
									$tree['clients'][$counterClients]['nick_cid'] = $u_value['cid'];
									$tree['clients'][$counterClients]['nick_clid'] = $u_value['clid'];
									$tree['clients'][$counterClients]['nick_pid'] = $value['pid'];
									$tree['clients'][$counterClients]['nick_cldbid'] = $u_value['client_database_id'];
									$tree['clients'][$counterClients]['nickname'] = xssSafe($u_value['client_nickname']);
									$tree['clients'][$counterClients]['is_herself'] = ($u_value['connection_client_ip'] === getClientIp()) ? true : false;
									
									$counterClients++;
								};
							};
						};
					};
				};
			};
			
			return generateOutput(true, null, $tree);
		} else {
			return $ts;
		};
	};
	
	/**
		Function to get the teamspeak icon path if it exist
		@param {string} $ip
		@param {int, string} $icon_id
		@param {int, string} $port
		@return {string}
	*/
	function getTeamspeakBaumIcon($ip, $icon_id, $port) {
		$name = str_replace("\\","",$icon_id);
		$name = str_replace("/","",$name);
		
		if(str_replace('icon_', '', $name) == 100 OR str_replace('icon_', '', $name) == 200 OR str_replace('icon_', '', $name) == 300 OR str_replace('icon_', '', $name) == 500 OR str_replace('icon_', '', $name) == 600) {
			$path	=	__dir__.'/../../images/ts_icons/';
		} else {
			$path	=	__dir__.'/../../images/ts_icons/'.$ip.'-'.$port.'/';
		};
		
		return (file_exists($path.$name)) ? base64_encode_image($path.$name, "png") : false;
	};
	
	function base64_encode_image($filename, $filetype) {
		if ($filename) {
			$imgbinary = fread(fopen($filename, "r"), filesize($filename));
			return 'data:image/' . $filetype . ';base64,' . base64_encode($imgbinary);
		};
	};
	
	/**
		Get the Teamspeak Icons and Download them to your Webspace
		@param {object} $ts
		@param {string} $ip
		@param {string} $port
	*/
	function getTeamspeakIcons($ts, $ip, $port) {
		$ft = $ts['data']->ftGetFileList(0, '', '/icons');
		$handler = null;
		
		if(is_dir('../../images/ts_icons/'.$ip.'-'.$port.'/')) {
			$handler = @opendir('../../images/ts_icons/'.$ip.'-'.$port.'/');
		} else {
			if(@mkdir('../../images/ts_icons/'.$ip.'-'.$port.'/', 0777)) {
				$handler = @opendir('../../images/ts_icons/'.$ip.'-'.$port.'/');
			} else {
				writeInLog(2, "getTeamspeakIcons: Could not Create Folder ".$ip."-".$port);
				return false;
			};
		};
		
		if($handler != null) {
			while($datei = readdir($handler)) {
				$icon_arr[] = $datei;
			};
		};
		
		$noIcon = 0;
		if(!empty($ft['data'])) {
			foreach($ft['data'] AS $key2=>$value2) {
				$foundIcons[] = $value2['name'];
			};
		};
		
		if(!empty($icon_arr)) {
			foreach($icon_arr AS $key => $value) {
				if(!empty($ft['data'])) {
					if($value!="." AND $value!=".." AND in_array($value, $foundIcons)) {
						$noIcon = 1;
						break;
					};
					
					if($noIcon == 0) {
						@unlink('../../images/ts_icons/'.$ip.'-'.$port.'/'.$value);
					};
				} else if(strpos($ft['errors'][0], 'ErrorID: 2568 | Message: insufficient client permissions failed_permid') === false) {
					if($value!="." AND $value!="..")
					{
						@unlink('../../images/ts_icons/'.$ip.'-'.$port.'/'.$value);
					};
				};
			};
		};
		
		if(!empty($ft['data'])) {
			foreach($ft['data'] AS $key => $value) {
				if(substr($value['name'], 0, 5) == 'icon_' && !empty($icon_arr)) {
					if(!in_array($value['name'], $icon_arr)) {
						$ft2 = $ts['data']->ftInitDownload("/".$value['name'], 0);
						
						if($ft2['success'] !== false AND !empty($ft2['data']['port'])) {
							$con_ft = @fsockopen($ip, $ft2['data']['port'], $errnum, $errstr, 10);
							if($con_ft) {
								fputs($con_ft, $ft2['data']['ftkey']);
								$data = '';
								
								while (!feof($con_ft)) {
									$data	.= 	fgets($con_ft, 4096);
								};
								
								$handler2 = @fopen('../../images/ts_icons/'.$ip.'-'.$port.'/'.$value['name'], "w+");
								if($handler2 !== false) {
									fwrite($handler2, $data);
									fclose($handler2);
								};
							};
						};
					};
				};
			};
		};
	};
?>