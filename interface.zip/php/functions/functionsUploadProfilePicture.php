<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once("../../config/config.php");
	require_once("./functions.php");
	require_once("./functionsSql.php");
	
	/*
		Get the Modul Keys / Permissionkeys
	*/
	$mysql_keys		=	getKeys();
	
	/*
		Check Session
	*/
	$LoggedIn		=	(checkSession($mysql_keys['login_key'])) ? true : false;
	
	if($LoggedIn)
	{
		$filename	=	$_SESSION['user']['id'];
		
		// $filename: input filename
		// $destination: output filename
		// $mode: 1, quadratic / 2, proportional / 3, cropped
		// $width: output image width
		// $height: optional output image height, only needed for mode 3
		// Code can be found here: https://stackoverflow.com/questions/27362453/how-to-set-widthheight-to-uploaded-image-php
		ResizeImage($_FILES['file']['tmp_name'], __dir__."/../../images/user/".$filename, 3, 100, 100);
		
		echo $filename;
	}
	else
	{
		echo "Client is not logged in!";
	};
	
	// Code can be found here: https://stackoverflow.com/questions/27362453/how-to-set-widthheight-to-uploaded-image-php
function ResizeImage($input, $output, $mode, $w, $h = 0)
{
	switch(GetMimeType($input))
	{
		case "image/png":
			$img = ImageCreateFromPng($input);
			break;
		case "image/gif":
			$img = ImageCreateFromGif($input);
			break;
		case "image/jpeg":
		default:
			$img = ImageCreateFromJPEG($input);
			break;
	};

	$image['sizeX'] = imagesx($img);
	$image['sizeY'] = imagesy($img);
	
	switch ($mode)
	{
		case 1: //Quadratic Image
			$thumb = imagecreatetruecolor($w,$w);
			if($image['sizeX'] > $image['sizeY'])
			{
				imagecopyresampled($thumb, $img, 0,0, ($w / $image['sizeY'] * $image['sizeX'] / 2 - $w / 2),0, $w,$w, $image['sizeY'],$image['sizeY']);
			}
			else
			{
				imagecopyresampled($thumb, $img, 0,0, 0,($w / $image['sizeX'] * $image['sizeY'] / 2 - $w / 2), $w,$w, $image['sizeX'],$image['sizeX']);
			};
			break;
		case 2: //Biggest side given
			if($image['sizeX'] > $image['sizeY'])
			{
				$thumb = imagecreatetruecolor($w, $w / $image['sizeX'] * $image['sizeY']);
				imagecopyresampled($thumb, $img, 0,0, 0,0, imagesx($thumb),imagesy($thumb), $image['sizeX'],$image['sizeY']);
			}
			else
			{
				$thumb = imagecreatetruecolor($w / $image['sizeY'] * $image['sizeX'],$w);
				imagecopyresampled($thumb, $img, 0,0, 0,0, imagesx($thumb),imagesy($thumb), $image['sizeX'],$image['sizeY']);
			};
			break;
		case 3; //Both sides given (cropping)
			$thumb = imagecreatetruecolor($w,$h);
			if($h / $w > $image['sizeY'] / $image['sizeX'])
			{
				imagecopyresampled($thumb, $img, 0,0, ($image['sizeX']-$w / $h * $image['sizeY'])/2,0, $w,$h, $w / $h * $image['sizeY'],$image['sizeY']);
			}
			else
			{
				imagecopyresampled($thumb, $img, 0,0, 0,($image['sizeY']-$h / $w * $image['sizeX'])/2, $w,$h, $image['sizeX'],$h / $w * $image['sizeX']);
			};
			break;
		case 0:
			$thumb = imagecreatetruecolor($w,$w / $image['sizeX']*$image['sizeY']);
			imagecopyresampled($thumb, $img, 0,0, 0,0, $w,$w / $image['sizeX']*$image['sizeY'], $image['sizeX'],$image['sizeY']);
			break;
	};  
	
	imagejpeg($thumb, $output, 90);
};

function GetMimeType($file)
{
	$forbiddenChars = array('?', '*', ':', '|', ';', '<', '>');

	if(strlen(str_replace($forbiddenChars, '', $file)) < strlen($file))
	{
		die("Forbidden characters!");
	};

	$file = escapeshellarg($file);

	ob_start();
	$type = system("file --mime-type -b ".$file);
	ob_clean();

	return $type;
};
?>