<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/instance-bot.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../classes/ts3musicbot.class.php");
	
	/**
		Check a musicbot instance
		@param {int, string} $instance
		@return {Array} generateOutput()
	*/
	function checkBotConnection($instance){
		global $music_server;

		if(!isset($instance)) {
			return generateOutput(false, 'Instance is not given', null);
		};
		
		if($instance > (count($music_server) - 1)) {
			return generateOutput(false, 'Instance cant be found', null);
		};
		
		$tsBot = new ts3musicbot($music_server[$instance]['ip'], $music_server[$instance]['port']);
		$tsBot->setAuthorization($music_server[$instance]['uuid'], $music_server[$instance]['token']);
		$connect = $tsBot->executeCommand('api/version');
		
		if($connect['success']) {
			return generateOutput(true, null, $connect['data']);
		} else {
			return generateOutput(false, $connect['errors'], null);
		};
	};

	/**
		Get Bot connection
		@param {int, string} $instance
		@return {Array} generateOutput()
	 */
	function getBotConnection($instance) {
		global $music_server;

		$tsBot = new ts3musicbot($music_server[$instance]['ip'], $music_server[$instance]['port']);
		$tsBot->setAuthorization($music_server[$instance]['uuid'], $music_server[$instance]['token']);
		$connect = $tsBot->executeCommand('api/version');

		if($connect['success']) {
			return generateOutput(true, null, $tsBot);
		} else {
			return generateOutput(false, $connect['errors'], null);
		};
	};

	/**
		Stop a bot connection
		@param {int, string} $instance
		@param {int} $id
		@return {Array} generateOutput()
	 */
	function stopBotConnection($instance, $id) {
		$bot = getBotConnection($instance);
		if($bot['success']) {
			return generateOutput(true, null, "Works fine");
		} else {
			return $bot;
		};
	};
	
	/**
		Get all Bots of a instance
		@param {int, string} $instance
		@return {Array} generateOutput()
	*/
	function getBotList($instance) {
		global $music_server;
		
		$tsBot = new ts3musicbot($music_server[$instance]['ip'], $music_server[$instance]['port']);
		$tsBot->setAuthorization($music_server[$instance]['uuid'], $music_server[$instance]['token']);
		$connect = $tsBot->executeCommand('api/bot/list');
		//print_r($connect);
		//print_r($tsBot->executeCommand('/api/bot/use/0/(/bot/connect/to/first-coder.de/)'));
		if($connect['success']) {
			return generateOutput(true, null, $connect['data']);
		} else {
			return generateOutput(false, $connect['errors'], null);
		};
	};
	
	/**
		Execute a command to the Bot
		@param {int, string} $instance
		@param {string} $command
		@return {Array} generateOutput()
	*/
	function executeCommand($instance, $command) {
		global $music_server;
		
		$tsBot = new ts3musicbot($music_server[$instance]['ip'], $music_server[$instance]['port']);
		$tsBot->setAuthorization($music_server[$instance]['uuid'], $music_server[$instance]['token']);
		$connect = $tsBot->executeCommand($command);
		
		if($connect['success']) {
			return generateOutput(true, null, $connect['data']);
		} else {
			return generateOutput(false, $connect['errors'], null);
		};
	};
	
	/**
		Execute a bot specific command
		@param {int, string} $instance
		@param {int, string} $bid
		@param {string} $command
		@return {Array} generateOutput()
	*/
	function executeBotCommand($instance, $bid, $command) {
		global $music_server;
		
		$tsBot = new ts3musicbot($music_server[$instance]['ip'], $music_server[$instance]['port']);
		$tsBot->setAuthorization($music_server[$instance]['uuid'], $music_server[$instance]['token']);
		$connect = $tsBot->executeCommand('/api/bot/use/'.$bid.'/('.$command.')');
		
		if($connect['success']) {
			return generateOutput(true, null, $connect['data']);
		} else {
			return generateOutput(false, $connect['errors'], null);
		};
	};
?>