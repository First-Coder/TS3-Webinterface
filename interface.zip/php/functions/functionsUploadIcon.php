<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../../config/config.php");
	require_once(__DIR__."/../../lang/lang.php");
	require_once(__DIR__."/../../php/functions/functions.php");
	require_once(__DIR__."/../../php/functions/functionsSql.php");
	require_once(__DIR__."/../../php/functions/functionsTeamspeak.php");
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	$LinkInformations = getLinkInformations();
	
	if($LinkInformations[3] === false) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Missing link parameters');
	};
	
	if($LinkInformations[2] === false) {
		$LinkInformations[2] = 0;
	};
	
	/**
		Check if user is logged in
	*/
	if(!$LoggedIn) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'You need to be logged in');
	};
	
	/**
		Get Client Permissions
	*/
	$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
	
	/**
		Permissionscheck
	*/
	if(!checkServerPerm(array("perm_ts_server_icons"), $LinkInformations[2], $LinkInformations[3])) {
		redirectSite(REDIRECT_PERMISSION_ERROR, 'Permission perm_ts_server_icons missing');
	};
	
	/**
		Upload Icon
	*/
	$tsAdmin = getTsAdminInstance($LinkInformations[2]);
	$informations = [];
	
	if($tsAdmin['success']) {
		$tsAdmin['data']->selectServer($LinkInformations[3], 'port', true);
		
		if (isset($_FILES['file']) && strpos($_FILES['file']['type'], 'image') !== false) {
			$filename = "icon_".mt_rand(1000000000, 2147483647);
			move_uploaded_file($_FILES['file']['tmp_name'], '../../images/ts_icons/'.$filename);
			
			$informations['status'] = "done";
			$informations['text'] = $filename;
			$informations['size'] = $_FILES['file']['size'];
		} else {
			$informations['status'] = "error";
			$informations['text'] = "Wrong Datatype!";
		};
		
		$ft2 = $tsAdmin['data']->getElement('data', $tsAdmin['data']->ftInitUpload("/".$filename, 0, $_FILES['file']['size']));
		$file = file_get_contents("../../images/ts_icons/".$filename);
		$con_ft = fsockopen($ts3_server[$LinkInformations[2]]['ip'], $ft2['port'], $errnum, $errstr, 10);
		fputs($con_ft, $ft2['ftkey']);
		fputs($con_ft, $file);
		unlink("../../images/ts_icons/".$filename);
		fclose($con_ft);
		
		getTeamspeakIcons($tsAdmin, $ts3_server[$LinkInformations[2]]['ip'], $LinkInformations[3]);
	};
?>