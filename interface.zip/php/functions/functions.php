<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Reload Site defines
	*/
	define("REDIRECT_SERVER_ERROR", 0);
	define("REDIRECT_PERMISSION_ERROR", 1);
	define("RELOAD_THE_SITE", 2);
	
	/**
		Installed Webinterface version
	*/
	define("INTERFACE_VERSION", "2.3.8-OPEN-PRE-ALPHA");
	
	/**
		Logout
		@return generateOutput
	*/
	function logout() {
		if(!isSet($_SESSION)) {
			session_start();
		};
		
		$_SESSION = array();
		
		if (ini_get("session.use_cookies")) {
			$params = session_get_cookie_params();
			setcookie(session_name(), '', time() - 42000, $params["path"],
				$params["domain"], $params["secure"], $params["httponly"]
			);
		};
		
		session_destroy();
		
		return generateOutput(empty($_SESSION), !empty($_SESSION) ? 'Could not delete Session' : null, null);
	};
	
	/**
		Convert timestamp to array
		@param {int, string} $seconds
		@return {Array}
	*/
	function convertSecondsToArrayTime($seconds) {
		$conv_time = array();
		$conv_time['days']=floor($seconds / 86400);
		$conv_time['hours']=floor(($seconds - ($conv_time['days'] * 86400)) / 3600);
		$conv_time['minutes']=floor(($seconds - (($conv_time['days'] * 86400)+($conv_time['hours']*3600))) / 60);
		$conv_time['seconds']=floor(($seconds - (($conv_time['days'] * 86400)+($conv_time['hours']*3600)+($conv_time['minutes'] * 60))));
		return $conv_time;
	};
	
	/**
		Convert timestamp to string
		@param {int} $time
		@param {boolean} $withSeconds
		@return {string}
	*/
	function convertSecondsToStrTime($time, $withSeconds = true) {
		$conv_time = convertSecondsToArrayTime($time);
		if($withSeconds) {
			return $conv_time['days'].'d '.$conv_time['hours'].'h '.$conv_time['minutes'].'m '.$conv_time['seconds'].'s';
		} else {
			return $conv_time['days'].'d '.$conv_time['hours'].'h '.$conv_time['minutes'].'m';
		};
	};

	/**
		Get profile log
		@return generateOutput()
	*/
	function getProfileLog() {
		if(empty($_SESSION['user']['benutzer'])) {
			return generateOutput(false, "Session not found", null);
		};

		$userLogs = file(__DIR__."/../../logs/user.log");
		$data = [];

		if(empty($userLogs)) {
			return generateOutput(true, null, []);
		};

		foreach(array_reverse($userLogs) AS $entry) {
			$entryParts = explode("|", $entry);

			if(trim($entryParts[1]) === $_SESSION['user']['benutzer']) {
				$data[] = array(
					"date" => trim($entryParts[0]),
					"message" => trim($entryParts[2])
				);
			};
		};

		return generateOutput(true, null, $data);
	};
	
	/**
		Get teamspeak backups
		@param {string, int} $instance
		@param {string, int} $port
		@return generateOutput()
	*/
	function getTeamspeakBackups($instance = false, $port = false) {
		$path = __dir__."/../../files/backups/";
		$files = [];
		$need = [];
		
		if(is_dir($path)) {
			if($handle = opendir($path)) {
				while (($file = readdir($handle)) !== false) {
					if(strpos($file, '.fcBackup') !== false) {
						$content = json_decode(file_get_contents($path.$file));
						$files[]	=	$content;
					};
				};
				closedir($handle);
				
				return generateOutput(true, null, $files);
			} else {
				return generateOutput(false, 'Could not get the file handler', null);
			};
		} else {
			return generateOutput(false, 'Folder not found', null);
		};
	};

	/**
		Cut the string to a custom length
		@param {string} $string
		@param {int} $length
		@return {string}
	*/
	function cutString($string, $length) {
  		if(strlen($string)<=$length) {
    		return $string;
  		} else {
    		return substr($string, 0, $length) . '...';
  		};
	};
	
	/**
		Function to get a permission group
		Example Groups are:
		* perm_admin_settings
		* perm_admin_instances
		@param {string} $group
		@return {bool}
	*/
	function hasPermGroup($group) {
		global $mysql_keys;
		global $user_right;
		
		if(!$user_right['success']) {
			return false;
		};
		
		foreach($mysql_keys AS $name=>$key) {
			if(strpos($name, $group) !== false && $user_right['data'][$name] == $mysql_keys[$name]) {
				return true;
			};
		};
		
		return false;
	};

	/**
		Check if client has server permissions
		@param {int, string} $instance
		@param {int, string} $port
		@return {bool}
	*/
	function hasServerPerm($instance = null, $port = null) {
		global $mysql_keys;
		global $mysql_keys_server;
		global $user_right;
		
		if($instance === null || $port === null || empty($mysql_keys_server) || !$user_right['success'] || !isset($user_right['data'])) {
			return false;
		};
		
		if($mysql_keys['perm_teamspeak_access_server'] === $user_right['data']['perm_teamspeak_access_server']) {
			return true;
		};

		foreach($user_right['data'] AS $name => $data) {
			if(!isset($data[$instance]) || !isset($data['key']) || (strpos($data['key'], 'perm_ts_server_') !== false && strpos($data['key'], 'perm_ts_server_edit_') === false) || $mysql_keys_server[$name] !== $data['key']) {
				continue;
			};

			if(!isset($data[$instance])) {
				return false;
			};
			
			if(in_array($port, explode(",", $data[$instance]))) {
				return true;
			};
		};

		return false;
	};

	/**
		Check if server permissions are set
		@param {Array} $perms
		@param {int, string} $instance
		@param {int, string} $port
		@return {bool}
	*/
	function checkServerPerm($perms, $instance = null, $port = null) {
		global $mysql_keys;
		global $mysql_keys_server;
		global $user_right;
		
		if($instance === null || $port === null || empty($mysql_keys_server) || !$user_right['success']) {
			return false;
		};

		if($mysql_keys['perm_teamspeak_access_server'] === $user_right['data']['perm_teamspeak_access_server']) {
			return (strpos($perms[0], "perm_ts_server_edit_") === false || $perms[0] === "perm_ts_server_edit_groups") ? true : false;
		};
		
		if(empty($perms)) {
			return (strpos($perms[0], "perm_ts_server_edit_") === false || $perms[0] === "perm_ts_server_edit_groups");
		};

		foreach($user_right['data'] AS $name => $data) {
			if(!isset($data[$instance]) || !isset($data['key']) || !in_array($name, $perms) || $mysql_keys_server[$name] !== $data['key']) {
				continue;
			};
			return (strpos($data[$instance], $port) !== false);
		};

		return false;
	};
	
	/**
		Get information from the url
		@return {Array}
	*/
	function getLinkInformations() {
		if(!isSet($_SERVER['REQUEST_URI']) && !isSet($_SERVER['HTTP_REFERER'])) {
			return [];
		} else {
			if(isSet($_SERVER['REQUEST_URI'])) {
				if(count(explode("?", $_SERVER['REQUEST_URI'])) >= 2) {
					$url = explode("?", $_SERVER['REQUEST_URI']);
				} else {
					if(!isSet($_SERVER['HTTP_REFERER'])) {
						return [];
					};
					$url = explode("?", $_SERVER['HTTP_REFERER']);
				};
			} else {
				$url = explode("?", $_SERVER['HTTP_REFERER']);
			};
			
			if(count($url) < 2) {
				return [];
			} else {
				$data = [];
				for($i = 1;$i < 5;$i++) {
					switch($i) {
						case 1:
							$data['site'] = $url[$i];
							break;
						default:
							$data[$i] = (!empty($url[$i])) ? $url[$i] : false;
							break;
					};
				};
				return $data;
			};
		};
	};
	
	/**
		Redirect the user to error page we have
		@param {int} $type
		@return void
	*/
	function redirectSite($type, $info = false) {
		global $language;
		
		switch($type) {
			case REDIRECT_SERVER_ERROR:
				include(__dir__.'/../errorcodes/504.php');
				break;
			case REDIRECT_PERMISSION_ERROR:
				include(__dir__.'/../errorcodes/403.php');
				break;
		};

		echo '</div>
		<div id="footer">
			<div class="footer-row">
				<div class="copyright">
					2019 <i class="far fa-copyright"></i> First-Coder by <a href="https://first-coder.de/" target="_blank">L.Gmann</a>
				</div>
				<div class="links">
					<a href="https://github.com/First-Coder/" target="_blank"><i class="fab fa-github mr-2"></i>Github</a>
					<a href="https://forum.first-coder.de/" target="_blank"><i class="fas fa-hands-helping mr-2"></i>Forum</a>
					<a href="#" onClick="changeContent(\'web_main_impressum\');return false;"><i class="far fa-handshake mr-2"></i>Impressum</a>
				</div>
			</div>
		</div>';
		
		exit();
	};
	
	/**
		Default return array of all sql or ajax requests
		@param {boolean} $success
		@param {string} $error
		@param {Array} $data
		@return {Array}
	*/
	function generateOutput($success, $error, $data) {
		return array('success' => $success, 'error' => $error, 'data' => $data);
	};
	
	/**
		Return anti XSS text
		@param {string} $data
		@param {string} $encoding
		@return {string}
	*/
	function xssSafe($data, $encoding = 'UTF-8') {
		return htmlspecialchars($data, ENT_QUOTES | ENT_HTML401, $encoding);
	};
	
	/**
		Write the anti XSS text
		@param {string} $data
		@return {string}
	*/
	function xssEcho($data) {
		echo xssSafe(str_replace("%", " ", $data));
	};
	
	/**
		Get the client ip address
		@return {string}
	*/
	function getClientIp() {
		$ipaddress = '';
		if (isset($_SERVER['HTTP_CLIENT_IP'])) {
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		} elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif(isset($_SERVER['HTTP_X_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		} elseif(isset($_SERVER['HTTP_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		} elseif(isset($_SERVER['HTTP_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		} elseif(isset($_SERVER['REMOTE_ADDR'])) {
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		} else {
			$ipaddress = false;
		};
		return $ipaddress;
	};
	
	/**
		Get link of the userprofile
		@param {string} $pk
		@return {string}
	*/
	function getUserPicture($pk = null) {
		if(isSet($_SESSION['user'])) {
			$id = ($pk == null) ? $_SESSION['user']['id'] : $pk;
		};
		
		if(!isset($id)) {
			return "./images/dummy.jpg";
		} else if(!file_exists(__dir__."/../../images/user/".$id)) {
			return "./images/dummy.jpg";
		} else {
			return "./images/user/".$id;
		};
	};
	
	/**
		Add instance to the config
		@param {Array} $data
		return generateOutput()
	*/
	function addInstance($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		if(!empty($data)) {
			require_once(__dir__.'/../../config/instance.php');
			
			$instanceFile = __dir__."/../../config/instance.php";
			$new_file = file($instanceFile);
			
			$new_zeile = count($new_file) - 1;
			$new_instance = (isset($ts3_server)) ? count($ts3_server) : 0;
			if(isset($ts3_server)) {
				$new_file[$new_zeile] = "\n"; $new_zeile++;
			};
			$new_file[$new_zeile] = "\t\$ts3_server[" . $new_instance . "]['alias'] = '" . urldecode($data->alias) . "';\n"; 		$new_zeile++;
			$new_file[$new_zeile] = "\t\$ts3_server[" . $new_instance . "]['ip'] = '" . $data->ip . "';\n"; 						$new_zeile++;
			$new_file[$new_zeile] = "\t\$ts3_server[" . $new_instance . "]['queryport'] = " . $data->queryport . ";\n"; 			$new_zeile++;
			$new_file[$new_zeile] = "\t\$ts3_server[" . $new_instance . "]['user'] = '" . $data->client . "';\n"; 					$new_zeile++;
			$new_file[$new_zeile] = "\t\$ts3_server[" . $new_instance . "]['pw'] = '" . urldecode($data->password) . "';\n"; 		$new_zeile++;
			$new_file[$new_zeile] = "\t\$ts3_server[" . $new_instance . "]['protocol'] = '" . urldecode($data->protocol) . "';\n"; 	$new_zeile++;
			$new_file[$new_zeile] = "?>";
			
			file_put_contents($instanceFile, "");
			file_put_contents($instanceFile, $new_file);
			
			writeInLog($_SESSION['user']['benutzer'], "Has Added the Instance \"".$data->ip."\"", true);
			
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, 'Data can not be empty!', null);
		};
	};

	/**
		Add bot instance to the config
		@param {Array} $data
		return generateOutput()
	*/
	function addBotInstance($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		if(!empty($data)) {
			require_once(__dir__.'/../../config/instance-bot.php');
			
			$instanceFile = __dir__."/../../config/instance-bot.php";
			$new_file = file($instanceFile);

			$token_parts = explode(":", $data->token);
			
			$new_zeile = count($new_file) - 1;
			$new_instance = (isset($music_server)) ? count($music_server) : 0;
			if(isset($music_server)) {
				$new_file[$new_zeile] = "\n"; $new_zeile++;
			};
			$new_file[$new_zeile] = "\t\$music_server[" . $new_instance . "]['alias'] = '" . urldecode($data->alias) . "';\n"; 		$new_zeile++;
			$new_file[$new_zeile] = "\t\$music_server[" . $new_instance . "]['ip'] = '" . $data->ip . "';\n"; 						$new_zeile++;
			$new_file[$new_zeile] = "\t\$music_server[" . $new_instance . "]['port'] = " . $data->port . ";\n"; 					$new_zeile++;
			$new_file[$new_zeile] = "\t\$music_server[" . $new_instance . "]['uuid'] = '" . $token_parts[0] . "';\n"; 				$new_zeile++;
			$new_file[$new_zeile] = "\t\$music_server[" . $new_instance . "]['token'] = '" . $token_parts[1] . "';\n"; 				$new_zeile++;
			$new_file[$new_zeile] = "?>";
			
			file_put_contents($instanceFile, "");
			file_put_contents($instanceFile, $new_file);
			
			writeInLog($_SESSION['user']['benutzer'], "Has Added the Bot Instance \"".$data->ip."\"", true);
			
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, 'Data can not be empty!', null);
		};
	};
	
	/**
		Update config file
	*/
	function updateConfig($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		if(!empty($data)) {
			$updateFile = __dir__."/../../config/config.php";
			$file = file($updateFile);
			$new_file = [];
			
			for ($i = 0; $i < count($file); $i++) {
				$replaced = false;
				foreach($data AS $key=>$content) {
					if(strpos($file[$i], 'define("'.$key.'"')) {
						$new_file[$i] = "\tdefine(\"".$key."\", \"".urldecode($content)."\");\n";
						$replaced = true;
					};
				};
				
				if(!$replaced) {
					$new_file[$i] = $file[$i];
				};
			};
			
			file_put_contents($updateFile, "");
			file_put_contents($updateFile, $new_file);
			
			writeInLog($_SESSION['user']['benutzer'], "Has updated the config", true);
			
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, 'Data can not be empty!', null);
		};
	};
	
	/**
		Update instance settings
		@param {Array} $data
		return generateOutput()
	*/
	function updateInstance($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		if(!empty($data)) {
			$instanceFile = __dir__."/../../config/instance.php";
			$file = file($instanceFile);
			$new_file = [];
			
			for ($i = 0; $i < count($file); $i++) {
				$replaced = false;
				foreach($data AS $instance=>$content) {
					if(strpos($file[$i], '$ts3_server['.$instance.']')) {
						if(strpos($file[$i], '[\'alias\']')) {
							$new_file[$i] = "\t\$ts3_server[".$instance."]['alias'] = '".urldecode($content->alias)."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'protocol\']')) {
							$new_file[$i] = "\t\$ts3_server[".$instance."]['protocol'] = '".$content->protocol."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'ip\']')) {
							$new_file[$i] = "\t\$ts3_server[".$instance."]['ip'] = '".$content->ip."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'pw\']') && !empty($content->pw)) {
							$new_file[$i] = "\t\$ts3_server[".$instance."]['pw'] = '".urldecode($content->pw)."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'queryport\']')) {
							$new_file[$i] = "\t\$ts3_server[".$instance."]['queryport'] = '".$content->queryport."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'user\']')) {
							$new_file[$i] = "\t\$ts3_server[".$instance."]['user'] = '".$content->user."';\n";
							$replaced = true;
						};
					};
				};
				
				if(!$replaced) {
					$new_file[$i] = $file[$i];
				};
			};
			
			file_put_contents($instanceFile, "");
			file_put_contents($instanceFile, $new_file);
			
			writeInLog($_SESSION['user']['benutzer'], "Has updated the instances", true);
			
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, 'Data can not be empty!', null);
		};
	};
	
	/**
		Update bot instance settings
		@param {Array} $data
		return generateOutput()
	*/
	function updateBotInstance($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		if(!empty($data)) {
			$instanceFile = __dir__."/../../config/instance-bot.php";
			$file = file($instanceFile);
			$new_file = [];
			
			for ($i = 0; $i < count($file); $i++) {
				$replaced = false;
				foreach($data AS $instance=>$content) {
					if(strpos($file[$i], '$music_server['.$instance.']')) {
						if(strpos($file[$i], '[\'alias\']')) {
							$new_file[$i] = "\t\$music_server[".$instance."]['alias'] = '".urldecode($content->alias)."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'ip\']')) {
							$new_file[$i] = "\t\$music_server[".$instance."]['ip'] = '".$content->ip."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'port\']')) {
							$new_file[$i] = "\t\$music_server[".$instance."]['port'] = ".$content->port.";\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'uuid\']')) {
							$new_file[$i] = "\t\$music_server[".$instance."]['uuid'] = '".urldecode($content->uuid)."';\n";
							$replaced = true;
						};
						if(strpos($file[$i], '[\'token\']')) {
							$new_file[$i] = "\t\$music_server[".$instance."]['token'] = '".urldecode($content->token)."';\n";
							$replaced = true;
						};
					};
				};
				
				if(!$replaced) {
					$new_file[$i] = $file[$i];
				};
			};
			
			file_put_contents($instanceFile, "");
			file_put_contents($instanceFile, $new_file);
			
			writeInLog($_SESSION['user']['benutzer'], "Has updated the bot instances", true);
			
			return generateOutput(true, null, null);
		} else {
			return generateOutput(false, 'Data can not be empty!', null);
		};
	};
	
	/**
		Update default template
		@param {Array} $data
		return generateOutput()
	*/
	function updateDefaultTemplate($data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		$filename =  __dir__."/../../config/templates/teamspeak_create_template_default.php";
		$var = '$ts3_server_create_default';
		$file = file($filename);
		$new_file = [];
		
		for ($i = 0; $i < count($file); $i++) {
			$replaced = false;
			foreach($data AS $name=>$output) {
				if(strpos($file[$i], $var."['".$name."']")) {
					$new_file[$i] = "\t".$var."['".xssSafe($name)."'] = '".xssSafe($output)."';\n";
					$replaced = true;
				};
			};
			
			if(!$replaced) {
				$new_file[$i] = $file[$i];
			};
		};
		
		file_put_contents($filename, "");
		file_put_contents($filename, $new_file);
		
		writeInLog($_SESSION['user']['benutzer'], "Has updated the default server create template", true);
		
		return generateOutput(true, null, null);
	};
	
	/**
		Update template
		@param {int} $id
		@param {Array} $data
		return generateOutput()
	*/
	function updateTemplate($id, $data) {
		if(DEMO) {
			return generateOutput(true, null, null);
		};
		
		$id = ($id === 'false') ? false : intval($id);
		$newId = ($id === false) ? false : intval($id);
		$tmp = 0;
		$breakLine = array(
			"templatename",
			"virtualserver_complain_remove_time",
			"virtualserver_hostbutton_url",
			"virtualserver_antiflood_points_needed_ip_block",
			"virtualserver_download_quota"
		);
		while($newId === false) {
			if(file_exists(__dir__."/../../config/templates/teamspeak_create_template_".$tmp.".php")) {
				$tmp++;
			} else {
				$newId = $tmp;
			};
		};
		$filename =  __dir__."/../../config/templates/teamspeak_create_template_".$newId.".php";
		$var = '$ts3_server_create_template';
		$content = [];
		$content[] = "<?php\n";
		$content[] = "\t".$var."['id'] = '".$newId."';\n";
		foreach($data AS $name=>$output) {
			$content[] = "\t".$var."['".xssSafe($name)."'] = '".xssSafe($output)."';\n";
			if(in_array($name, $breakLine)) {
				$content[] = "\n";
			};
		};
		$content[] = "?>";
		
		writeInLog($_SESSION['user']['benutzer'], "Has updated a new templete for create a server", true);
		
		return generateOutput((file_put_contents($filename, $content) === false) ? false : true, 'Could not write templatefile!', $newId);
	};
	
	/**
		Delete a file from the system
		@param {string} $file
		@return {bool}
	*/
	function deleteFile($file) {
		if(DEMO) {
			return true;
		};
		
		writeInLog($_SESSION['user']['benutzer'], "Delete File ".$file."!", true);
		return @unlink(__dir__."/../../".$file);
	};
	
	/**
		Get random string
		@param {int} $length
		@return {string}
	*/
	function randomString($length) {
		$zeichen = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$str = '';
		$anz = strlen($zeichen);
		for ($i=0; $i<$length; $i++) {
			$str .= $zeichen[rand(0,$anz-1)];
		};
		return $str;
	};
	
	/**
		Check if we have a correct session and if the user is logged in
	*/
	function checkSession() {
		if(session_status() != PHP_SESSION_ACTIVE) {
			session_start();
		};
		
		if(isSet($_SESSION['user']['id'])) {
			if(preg_match("/^[A-Z0-9.]{32}$/", $_SESSION['user']['id']) && md5($_SERVER['HTTP_USER_AGENT']) == $_SESSION['agent']) {
				return true;
			} else {
				$_SESSION = array();
				session_destroy();
				return false;
			};
		} else {
			return false;
		};
	};
	
	/**
		Check Windowsserver
		@return {bool}
	*/
	function isWindows() {
		return (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ? true : false;
	};
	
	/**
		Get SOAP News
		@return {string}
	*/
	function getSoapNews() {
		try {
			$client = new SoapClient(null, array(
				'location' => 'http://wiki.first-coder.de/soap/soap_server_version_two.php',
				'uri' => 'https://wiki.first-coder.de/soap/soap_server_version_two.php'
			));
			
			return $client->getImportantInformation();
		} catch(Exception $e) {
			return "";
		};
	};
	
	/**
		Check for a new Version
		@param {bool} $withInfo
		@param {string} $mail
		@return {string}
	*/
	function checkNewVersion($withInfo = true, $mail) {
		try {
			$client = new SoapClient(null, array(
				'location' => 'http://wiki.first-coder.de/soap/soap_server_version_two.php',
				'uri' => 'https://wiki.first-coder.de/soap/soap_server_version_two.php'
			));
			
			return $client->getNewestVersion(INTERFACE_VERSION, $mail);
		} catch(Exception $e) {
			if($withInfo) {
				return "<font class=\"color-danger\">Connection to Updateserver lost!</font>";
			} else {
				return INTERFACE_VERSION;
			};
		};
	};
	
	/**
		Update Informations
		@return {Array}
	*/
	function getUpdateInformations($settings = null)
	{
		if($settings === null) {
			require_once(__dir__.'/functionsSql.php');
			$settings = getSqlHomepagesettings()['data'];
		};

		$returnArray = array();
		try {
			$client = new SoapClient(null, array(
				'location' => 'http://wiki.first-coder.de/soap/soap_server_version_two.php',
				'uri' => 'https://wiki.first-coder.de/soap/soap_server_version_two.php'
			));
			$returnArray['isUpdatePossible'] = $client->isUpdatePossible(INTERFACE_VERSION, $settings['donator']);
			$returnArray['isDonator'] = $client->hasUserDonationStatus($settings['donator']);
			$returnArray['secretInformation'] = $client->getSecretInformation();
			$returnArray['team'] = $client->getTeam();
		} catch(Exception $e) {
			$returnArray['isUpdatePossible'] = false;
			$returnArray['isDonator'] =	false;
			$returnArray['secretInformation'] = false;
			$returnArray['team'] = false;
		};
		
		return $returnArray;
	};
	
	/**
		Write text into the user and system logfile
		@param {string} $loglevel
		@param {string} $logtext
		@param {boolean} $userlog
	*/
	define('L_INFO', 5);
	define('L_NOTICE', 4);
	define('L_WARNING', 3);
	define('L_ERROR', 2);
	define('L_CRITICAL', 1);
	
	function writeInLog($loglevel, $logtext, $userlog = false) {
		if($userlog) {
			$file = '../../logs/user';
		} else {
			$file = '../../logs/system';
		};
		
		if ($loglevel == L_CRITICAL) {
			$loglevel = "\tCRITICAL\t|\t";
		} elseif ($loglevel == L_ERROR) {
			$loglevel = "\tERROR\t\t|\t";
		} elseif ($loglevel == L_WARNING) {
			$loglevel = "\tWARNING\t\t|\t";
		} elseif ($loglevel == L_NOTICE) {
			$loglevel = "\tNOTICE\t\t|\t";
		} elseif ($loglevel == L_INFO) {
			$loglevel = "\tINFO\t\t|\t";
		} else {
			$loglevel = $loglevel."\t|\t";
		};
		
		$date = date("Y-m-d H:i:s");
		$input = $date."\t|\t".$loglevel.$logtext."\n";

		if(file_exists($file.".log")) {
			$loghandle = fopen($file.".log", 'a');
			fwrite($loghandle, $input);
			if (filesize($file.".log") > 10242880) // 10MB
			{
				fwrite($loghandle, $date."\tNOTICE\t\tLogfile filesie of 10 MiB reached.. Rotate logfile.\n");
				
				$zip = new ZipArchive();
				$filename = "./$file.zip";

				if ($zip->open($filename, ZipArchive::CREATE) !== TRUE)
				{
					fwrite($loghandle, $date."\tNOTICE\t\tcannot open <$filename>\n");
					fclose($loghandle);
					exit();
				}
				else
				{
					fclose($loghandle);
				};
				
				$zip->addFromString("log_".date("j_m_Y").".log", file_get_contents($file.".log"));
				$zip->close();
				
				unlink($file.".log");
			};
		};
		
		if(file_exists($file.".zip"))
		{
			if (filesize($file.".zip") > 20485760) // 20 MB
			{
				unlink($file.".zip");
			};
		};
	};
	
	/**
		Get Random Keys
		@return {string}
	*/
	function guid() {
		if (function_exists('com_create_guid')) {
			return com_create_guid();
		} else {
			mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
			$charid = strtoupper(md5(uniqid(rand(), true)));
			$hyphen = chr(45);// "-"
			$uuid = substr($charid, 0, 8).substr($charid, 8, 4).substr($charid,12, 4).substr($charid,16, 4).substr($charid,20,12);
			return $uuid;
		};
	};
	
	/**
		Get the Filesize with prefix
		@param {int} $byte
		@return {int}
	*/
	function getFilesize($byte) {
		if($byte < 1024) {
			$ergebnis = round($byte, 2). ' Byte'; 
		} else if($byte >= 1024 and $byte < pow(1024, 2)) { 
			$ergebnis = round($byte/1024, 2).' KByte'; 
		} else if($byte >= pow(1024, 2) and $byte < pow(1024, 3)) { 
			$ergebnis = round($byte/pow(1024, 2), 2).' MByte'; 
		} else { 
			$ergebnis = round($byte/pow(1024, 3), 2).' GByte'; 
		};
		return $ergebnis; 
	};
	
	/*
		Check permission
	*/
	function checkFolderPermission()
	{
		$permissions				=	true;
		if(!is_writable('config/config.php') || !is_writable('config/instance.php') || !is_writable('files/') || !is_writable('files/backups/') || !is_writable('images/') || !is_writable('images/ts_banner/')
			|| !is_writable('images/ts_icons/') || !is_writable('logs/') || !is_writable('logs/system.log') || !is_writable('logs/user.log') || !is_writable('updater/'))
		{
			$permissions			=	false;
		}
		
		if(file_exists("install") && !is_writable('install/'))
		{
			$permissions			=	false;
		};
		
		return $permissions;
	};
?>