<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("../../config/config.php");
	require_once("../../lang/lang.php");
	require_once("./functions.php");
	require_once("./functionsSql.php");
	require_once("./functionsTeamspeak.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	$mysql_keys_server = getKeys('main_rights_server');
	
	/**
		Get permission
	*/
	$user_right = false;
	if($LoggedIn) {
		$user_right = getUserRights('pk', $_SESSION['user']['id'], 'all');
		if(!$user_right['success']) {
			$user_right = false;
		};
	};
	
	/**
		React to the ajax request with the correct function
	*/
	switch($_POST['action']) {
		case 'getTeamspeakBaum':
			echo json_encode(getTeamspeakBaum($_POST['instanz'], $_POST['port'], $_POST['getIcons']));
			break;
		case 'getClient':
			echo json_encode(getClient($_POST['instance'], $_POST['port'], $_POST['clid']));
			break;
		case 'getInstanceClients':
			if(($user_right === false || $user_right['data']['perm_teamspeak_access_server'] != $mysql_keys['perm_teamspeak_access_server']) && !checkClientHasInstance($_SESSION['user']['id'], $_POST['instance'])) {
				echo json_encode(generateOutput(false, array('permissions missing'), null));
			} else {
				echo json_encode(getInstanceClients($_POST['instance']));
			};
			break;
		case 'getInstanceInfo':
			if(($user_right === false || $user_right['data']['perm_teamspeak_access_server'] != $mysql_keys['perm_teamspeak_access_server']) && !checkClientHasInstance($_SESSION['user']['id'], $_POST['instance'])) {
				echo json_encode(generateOutput(false, array('permissions missing'), null));
			} else {
				echo json_encode(getInstanceInfo($_POST['instance']));
			};
			break;
		
		// Admin Posts
		case 'getTeamspeakPorts':
			if($user_right === false || !hasPermGroup('perm_admin_settings')) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getTeamspeakPorts($_POST['instance']));
			};
			break;
		case 'commandQueryConsole':
			if($user_right === false || $user_right['data']['perm_admin_instances_ts'] != $mysql_keys['perm_admin_instances_ts']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(commandQueryConsole($_POST['instance'], $_POST['command'], (isSet($_POST['server'])) ? $_POST['server'] : -1));
			};
			break;
		
		// Teamspeak Posts
		case 'getTeamspeakInfo':
			if($user_right === false || !hasServerPerm($_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getServerInfo($_POST['instance'], $_POST['port']));
			};
			break;
		case 'getServerList': // Permission check missing(serverview, perm_admin_users_edit)
			echo json_encode(getServerList($_POST['instance']));
			break;
		case 'startTeamspeakServer':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_start_stop"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(startTeamspeakServer($_POST['instance'], $_POST['sid']));
			};
			break;
		case 'stopTeamspeakserver':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_start_stop"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(stopTeamspeakServer($_POST['instance'], $_POST['sid'], (!empty($_POST['message'])) ? $_POST['message'] : null));
			};
			break;
		case 'createServer':
			if($user_right === false || $user_right['data']['perm_teamspeak_create_server'] != $mysql_keys['perm_teamspeak_create_server']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(createServer($_POST['instance'], json_decode($_POST['data']), $_POST['template']));
			};
			break;
		case 'deleteTeamspeakserver':
			if($user_right === false || $user_right['data']['perm_teamspeak_delete_server'] != $mysql_keys['perm_teamspeak_delete_server']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteTeamspeakserver($_POST['instance'], $_POST['sid'], $_POST['port']));
			};
			break;
		case 'instanceMessagePoke':
			if($user_right === false || $user_right['data']['perm_teamspeak_global_msg_poke'] != $mysql_keys['perm_teamspeak_global_msg_poke']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(instanceMessagePoke($_POST['instance'], ($_POST['poke'] === 'true') ? true : false, urldecode($_POST['message'])));
			};
			break;
		
		// Teamspeak Port Posts
		case 'serverMessage':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_message_poke"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(serverMessage($_POST['instance'], $_POST['sid'], ($_POST['poke'] === 'true') ? true : false, urldecode($_POST['message'])));
			};
			break;
		case 'deleteChannel':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_delete_channel"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteChannel($_POST['instance'], $_POST['sid'], $_POST['cid']));
			};
			break;
		case 'createChannel':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_create_channel"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(createChannel($_POST['instance'], $_POST['sid'], json_decode($_POST['data'])));
			};
			break;
		case 'deleteIcon':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_icons"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteIcon($_POST['instance'], $_POST['port'], $_POST['id']));
			};
			break;
		case 'getQueryLog':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_protocol"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getQueryLog($_POST['instance'], $_POST['port']));
			};
			break;
		case 'getServerBans':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_bans"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getServerBans($_POST['instance'], $_POST['port']));
			};
			break;
		case 'deleteBan':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_bans"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteBan($_POST['instance'], $_POST['port'], $_POST['id']));
			};
			break;
		case 'deleteToken':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_token"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteToken($_POST['instance'], $_POST['port'], urldecode($_POST['token'])));
			};
			break;
		case 'createToken':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_token"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(createToken($_POST['instance'], $_POST['port'], json_decode($_POST['data'])));
			};
			break;
		case 'createBan':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_bans"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(createBan($_POST['instance'], $_POST['port'], json_decode($_POST['data'])));
			};
			break;
		case 'getServerToken':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_token"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getServerToken($_POST['instance'], $_POST['port']));
			};
			break;
		case 'createBackup':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_create_backups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(createBackup($_POST['instance'], $_POST['port'], json_decode($_POST['backup'])));
			};
			break;
		case 'resetServer':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_use_backups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(resetServer($_POST['instance'], $_POST['port']));
			};
			break;
		case 'deleteBackup':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_delete_backups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(generateOutput(deleteFile('files/backups/'.$_POST['backup'].'.fcBackup'), null, null));
			};
			break;
		case 'getServerFiles':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_filelist"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getServerFiles($_POST['instance'], $_POST['port']));
			};
			break;
		case 'deleteFile':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_filelist"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteChannelFile($_POST['instance'], $_POST['port'], urldecode($_POST['path']), $_POST['cid']));
			};
			break;
		case 'getPermissionTree':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_edit_groups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getPermissionTree($_POST['instance'], $_POST['port'], $_POST['type'], $_POST['group']));
			};
			break;
		case 'getServerClients':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_clients"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getServerClients($_POST['instance'], $_POST['port']));
			};
			break;
		case 'deleteDBClient':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_delete_clients"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteDBClient($_POST['instance'], $_POST['port'], $_POST['cldbid'], json_decode($_POST['sgroups']), $_POST['time']));
			};
			break;
		case 'setServerSettings':
			$data = json_decode($_POST['data']);
			if($user_right === false || !checkServerPerm(array("perm_ts_server_edit"), $_POST['instance'], $_POST['port']) ||
			(checkServerPerm(array("perm_ts_server_edit_name"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_name", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_port"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_port", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_clients"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_maxclients", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_password"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_password", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_welcome"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_welcomemessage", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_complain"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_complain_autoban_count", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_host"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_hostmessage_mode", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_antiflood"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_antiflood_points_tick_reduce", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_transfer"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_max_upload_total_bandwidth", $data)) ||
			(checkServerPerm(array("perm_ts_server_edit_protocol"), $_POST['instance'], $_POST['port']) && in_array("virtualserver_log_client", $data))) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setServerSettings($_POST['instance'], $_POST['port'], $data));
			};
			break;
		case 'setGroup':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_edit_groups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setGroup($_POST['instance'], $_POST['port'], $_POST['type'], $_POST['gid'], $_POST['name']));
			};
			break;
		case 'setGroupMember':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_client_sgroups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setGroupMember($_POST['instance'], $_POST['port'], $_POST['type'], $_POST['gid'], $_POST['cldbid'], $_POST['cid'], $_POST['value']));
			};
			break;
		case 'setGroupPermissions':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_edit_groups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setGroupPermissions($_POST['instance'], $_POST['port'], $_POST['type'], $_POST['id'], json_decode($_POST['data'])));
			};
			break;
		case 'getGroupMembers':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_edit_groups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getGroupMembers($_POST['instance'], $_POST['port'], $_POST['type'], $_POST['gid']));
			};
			break;
		case 'deleteServerGroupClient':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_edit_groups"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteServerGroupClient($_POST['instance'], $_POST['port'], $_POST['gid'], $_POST['id']));
			};
			break;
		case 'getMassActionMember':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_mass_actions"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getMassActionMember($_POST['instance'], $_POST['port'], $_POST['option'], json_decode($_POST['data'])));
			};
			break;
		case 'setClient':
			if($user_right === false || !checkServerPerm(array("perm_ts_server_mass_actions", "perm_ts_server_client_actions"), $_POST['instance'], $_POST['port'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setClient($_POST['instance'], $_POST['port'], json_decode($_POST['data'])));
			};
			break;
	};