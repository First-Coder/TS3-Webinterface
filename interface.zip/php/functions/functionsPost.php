<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("../../config/config.php");
	require_once("../../lang/lang.php");
	require_once("./functions.php");
	require_once("./functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Get permission
	*/
	$user_right = false;
	if($LoggedIn) {
		$user_right = getUserRights('pk', $_SESSION['user']['id']);
		if(!$user_right['success']) {
			$user_right = false;
		};
	};
	
	/**
		React to the ajax request with the correct function
	*/
	switch($_POST['action']) {
		// Profile
		case 'deleteProfilePicture':
			if(!$LoggedIn) {
				echo json_encode(generateOutput(false, 'You need to logged in!', null));
			} else {
				echo json_encode(generateOutput(deleteFile('images/user/'.$_SESSION['user']['id']), null, null));
			};
			break;
		case 'logout':
			if(!$LoggedIn) {
				echo json_encode(generateOutput(false, 'You need to logged in!', null));
			} else {
				echo json_encode(logout());
			};
			break;
		case 'getProfileLog':
			if(!$LoggedIn) {
				echo json_encode(generateOutput(false, 'You need to logged in!', null));
			} else {
				echo json_encode(getProfileLog());
			};
			break;
		
		// Admin Posts
		case 'updateInstance':
			if($user_right === false || $user_right['data']['perm_admin_instances_ts'] != $mysql_keys['perm_admin_instances_ts']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateInstance(json_decode($_POST['data'])));
			};
			break;
		case 'updateConfig':
			if($user_right === false || 
				($user_right['data']['perm_admin_settings_main'] != $mysql_keys['perm_admin_settings_main'] && $user_right['data']['perm_admin_settings_mail'] != $mysql_keys['perm_admin_settings_mail'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateConfig(json_decode($_POST['data'])));
			};
			break;
		case 'addInstance':
			if($user_right === false || $user_right['data']['perm_admin_instances_ts_add'] != $mysql_keys['perm_admin_instances_ts_add']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(addInstance(json_decode($_POST['data'])));
			};
			break;
		case 'addBotInstance':
			if($user_right === false || $user_right['data']['perm_admin_instances_bot_add'] != $mysql_keys['perm_admin_instances_bot_add']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(addBotInstance(json_decode($_POST['data'])));
			};
			break;
		case 'updateBotInstance':
			if($user_right === false || $user_right['data']['perm_admin_instances_bot'] != $mysql_keys['perm_admin_instances_bot']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateBotInstance(json_decode($_POST['data'])));
			};
			break;
		
		// Teamspeak Posts
		case 'updateTemplate':
			if($user_right === false || $user_right['data']['perm_teamspeak_create_server'] != $mysql_keys['perm_teamspeak_create_server']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateTemplate($_POST['id'], json_decode($_POST['data'])));
			};
			break;
		case 'deleteTemplate':
			if($user_right === false || $user_right['data']['perm_teamspeak_create_server'] != $mysql_keys['perm_teamspeak_create_server']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				$del = deleteFile('config/templates/teamspeak_create_template_'.$_POST['id'].'.php');
				echo json_encode(generateOutput($del, ($del) ? null : 'Could not delete file', null));
			};
			break;
		case 'updateDefaultTemplate':
			if($user_right === false || $user_right['data']['perm_teamspeak_create_server'] != $mysql_keys['perm_teamspeak_create_server']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateDefaultTemplate(json_decode($_POST['data'])));
			};
			break;
		case 'getTeamspeakBackups': // Permission check missing
			echo json_encode(getTeamspeakBackups($_POST['instance'], $_POST['port']));
			break;
	};