<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2018 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once("../../config/config.php");
	require_once("../../lang/lang.php");
	require_once("./functions.php");
	require_once("./functionsSql.php");
	
	/**
		Variables
	*/
	$LoggedIn = (checkSession()) ? true : false;
	
	/**
		Get the Modul Keys
	*/
	$mysql_keys = getKeys();
	
	/**
		Get permission
	*/
	$user_right = false;
	if($LoggedIn) {
		$user_right = getUserRights('pk', $_SESSION['user']['id']);
		if(!$user_right['success']) {
			$user_right = false;
		};
	};
	
	/**
		React to the ajax request with the correct function
	*/
	switch($_POST['action']) {
		// Login Posts
		case 'loginUser':
			echo json_encode(loginUser($_POST['username'], $_POST['password']));
			break;
		case 'forgetAccess':
			echo json_encode(forgetAccess($_POST['username']));
			break;
		case 'getUserPermissions':
			if(!$LoggedIn) {
				echo json_encode(generateOutput(false, 'you need to logged in', null));
			} else {
				echo json_encode(getUserRights('pk', $_SESSION['user']['id']));
			};
			break;
		case 'createUser':
			if($user_right === false || ($user_right['data']['perm_admin_users_add'] != $mysql_keys['perm_admin_users_add']
			&& $user_right['data']['perm_teamspeak_create_server'] != $mysql_keys['perm_teamspeak_create_server'])) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(createUser(urldecode($_POST['username']), urldecode($_POST['password']), urldecode($_POST['firstname']), urldecode($_POST['lastname'])));
			};
			break;
		case 'createUserModul':
			$mysqlModul = getModuls();
			if(!$mysqlModul['success'] || $mysqlModul['data']['support_teamspeak'] != "true") {
				echo json_encode(generateOutput(false, 'module is disabled', null));
			} else {
				echo json_encode(createUserModul(json_decode($_POST['data'])));
			};
			break;
			
		// Profile
		case 'updateUser':
			if(!$LoggedIn) {
				echo json_encode(generateOutput(false, 'you need to logged in', null));
			} else {
				if(isset($_POST['pk']) && ($user_right === false || $user_right['data']['perm_admin_users_edit'] != $mysql_keys['perm_admin_users_edit'])) {
					echo json_encode(generateOutput(false, 'permissions missing', null));
				} else if(isset($_POST['pk'])) {
					echo json_encode(updateUser($_POST['pk'], json_decode($_POST['data'])));
				} else {
					echo json_encode(updateUser(false, json_decode($_POST['data'])));
				};
			};
			break;
		case 'deleteOwnProfile':
			if(!$LoggedIn) {
				echo json_encode(generateOutput(false, 'you need to logged in', null));
			} else {
				echo json_encode(deleteUser($_SESSION['user']['id']));
			};
			break;
		
		// Main Posts
		case 'createNews':
			if($user_right === false || $user_right['data']['perm_main_news_create'] != $mysql_keys['perm_main_news_create']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(createNews(urldecode($_POST['title']), urldecode($_POST['subtitle']), urldecode($_POST['content']), $_POST['time']));
			};
			break;
		case 'deleteNews':
			if($user_right === false || $user_right['data']['perm_main_news_delete'] != $mysql_keys['perm_main_news_delete']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteNews($_POST['id']));
			};
			break;
		case 'editNews':
			if($user_right === false || $user_right['data']['perm_main_news_create'] != $mysql_keys['perm_main_news_create']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(editNews($_POST['id'], urldecode($_POST['text'])));
			};
			break;
		
		// Admin Posts
		case 'getClientPortPermissions':
			if($user_right === false || $user_right['data']['perm_admin_users_edit'] != $mysql_keys['perm_admin_users_edit']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(getUserRights('pk', $_POST['pk'], 'ports'));
			};
			break;
		case 'deleteUser':
			if($user_right === false || $user_right['data']['perm_admin_users_delete'] != $mysql_keys['perm_admin_users_delete']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteUser($_POST['pk']));
			};
			break;
		case 'deleteAllUsers':
			if($user_right === false || $user_right['data']['perm_admin_users_delete'] != $mysql_keys['perm_admin_users_delete']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteAllUsers(urldecode($_POST['username']), urldecode($_POST['password']), urldecode($_POST['firstname']), urldecode($_POST['lastname'])));
			};
			break;
		case 'updateSettings':
			if($user_right === false || $user_right['data']['perm_admin_settings_main'] != $mysql_keys['perm_admin_settings_main']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateSettings(json_decode($_POST['data'])));
			};
			break;
		case 'updateMails':
			if($user_right === false || $user_right['data']['perm_admin_settings_mail'] != $mysql_keys['perm_admin_settings_mail']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateMails(json_decode($_POST['data'])));
			};
			break;
		case 'sendTestmail':
			if($user_right === false || $user_right['data']['perm_admin_settings_mail'] != $mysql_keys['perm_admin_settings_mail']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(writeMail(json_decode($_POST['data'])));
			};
			break;
		case 'updateModules':
			if($user_right === false || $user_right['data']['perm_admin_settings_module'] != $mysql_keys['perm_admin_settings_module']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateModules(json_decode($_POST['data'])));
			};
			break;
		case 'updateOwnSites':
			if($user_right === false || $user_right['data']['perm_admin_settings_sites'] != $mysql_keys['perm_admin_settings_sites']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateOwnSites(json_decode($_POST['data'])));
			};
			break;
		case 'updateLanguage':
			if($user_right === false || $user_right['data']['perm_admin_settings_lang'] != $mysql_keys['perm_admin_settings_lang']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(updateLanguage($_POST['lang']));
			};
			break;
		case 'deleteInstance':
			if($user_right === false || $user_right['data']['perm_admin_instances_ts_delete'] != $mysql_keys['perm_admin_instances_ts_delete']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(deleteInstance($_POST['instance']));
			};
			break;
		case 'setGlobePerm':
			if($user_right === false || $user_right['data']['perm_admin_users_edit'] != $mysql_keys['perm_admin_users_edit']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setGlobePerm($_POST['pk'], json_decode($_POST['data'])));
			};
			break;
		case 'setServerPerm':
			if($user_right === false || $user_right['data']['perm_admin_users_edit'] != $mysql_keys['perm_admin_users_edit']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setServerPerm($_POST['pk'], json_decode($_POST['data'])));
			};
			break;
		case 'setClientBlock':
			if($user_right === false || $user_right['data']['perm_admin_users_edit'] != $mysql_keys['perm_admin_users_edit']) {
				echo json_encode(generateOutput(false, 'permissions missing', null));
			} else {
				echo json_encode(setClientBlock($_POST['pk'], $_POST['blocked']));
			};
			break;
	};