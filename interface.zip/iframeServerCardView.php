<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Includes
	*/
	require_once("./config/config.php");
	require_once("./config/instance.php");
	require_once("./lang/lang.php");
	require_once("./php/functions/functions.php");
	require_once("./php/classes/ts3admin.class.php");
	
	/*
		Teamspeak Function
	*/
	$tsAdmin = new ts3admin($ts3_server[$_GET['instanz']]['ip'], $ts3_server[$_GET['instanz']]['queryport']);
	
	if($tsAdmin->getElement('success', $tsAdmin->connect()))
	{
		$tsAdmin->login($ts3_server[$_GET['instanz']]['user'], $ts3_server[$_GET['instanz']]['pw']);
		$tsAdmin->selectServer($_GET['port'], 'port', true);
		
		$server = $tsAdmin->getElement('data', $tsAdmin->serverInfo());
	};
?>

<html>
	<head>
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Courgette|Kreon">
		
		<link rel="stylesheet" type="text/css" href="./css/other/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="./css/bootstrap/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="./css/style.css" />
	</head>
	<body>
		<div class="card row ml-1 mr-1 lg-shadow serverlist-card" id="globalServerlist">
			<div class="card-block-header">
				<h4 class="card-title">
					<div class="pull-xs-left">
						<?php xssEcho($server['virtualserver_name']); ?>
					</div>
					<div class="pull-xs-right hidden-xs-down">
						<a class="ml-2" href="ts3server://<?php echo $ts3_server[$_GET['instanz']]['ip']; ?>:<?php echo $server['virtualserver_port']; ?>">
							<i data-tooltip="tooltip" data-placement="top" title="<?php echo $language['ts_connect_to_server']; ?>" class="fa fa-sign-in"></i>
						</a>
					</div>
					<div style="clear:both;"></div>
				</h4>
				<h6 class="card-subtitle text-muted">
					<div class="pull-xs-left">
						<i class="fa fa-info"></i> <?php echo $language['server_id'].": ".$server['virtualserver_id']; ?>
					</div>
					<div class="pull-xs-right hidden-xs-down">
						<?php echo $ts3_server[$_GET['instanz']]['ip']; ?>:<?php echo $server['virtualserver_port']; ?>
					</div>
					<div style="clear:both;"></div>
				</h6>
			</div>
			<hr class="hr-headline"/>
			<div class="row">
				<div class="col-xs-12 col-md-6">
					<ul class="list-group">
						<li class="list-group-item">
							<i class="material-icons">info</i>
							<div class="bmd-list-group-col">
								<div iconid="serverstatus-icon-<?php echo $_GET['instanz']; ?>-<?php echo $server['virtualserver_id']; ?>" class="mb-1 serverstatus <?php echo ($server['virtualserver_status'] == 'online') ? "text-success" : "text-danger"; ?>">
									<i id="serverstatus-icon-<?php echo $_GET['instanz']; ?>-<?php echo $server['virtualserver_id']; ?>" class="fa fa-circle-o mr-0" aria-hidden="true"></i> 
									<font id="online-<?php echo $_GET['instanz']; ?>-<?php echo $server['virtualserver_id']; ?>"><?php echo ($server['virtualserver_status'] == 'online') ? $language['online'] : $language['offline']; ?></font>
								</div>
								<p class="list-group-item-text"><?php echo $language['ts3_serverstatus']; ?></p>
							</div>
						</li>
						<li class="list-group-item">
							<i class="material-icons">person</i>
							<div class="bmd-list-group-col">
								<p class="list-group-item-heading" id="clients-<?php echo $_GET['instanz']; ?>-<?php echo $server['virtualserver_id']; ?>"><?php echo $server['virtualserver_clientsonline']; ?>&nbsp;/&nbsp;<?php echo $server['virtualserver_maxclients']; ?></p>
								<p class="list-group-item-text"><?php echo $language['slots']; ?></p>
							</div>
						</li>
						<li class="list-group-item">
							<i class="material-icons">person_outline</i>
							<div class="bmd-list-group-col">
								<p class="list-group-item-heading"><?php echo $server['virtualserver_queryclientsonline']; ?></p>
								<p class="list-group-item-text"><?php echo $language['ts3_query_user']; ?></p>
							</div>
						</li>
					</ul>
				</div>
				<div class="col-xs-12 col-md-6">
					<ul class="list-group">
						<li class="list-group-item">
							<i class="material-icons">sms</i>
							<div class="bmd-list-group-col">
								<div class="mb-1">
									<?php xssEcho($server['virtualserver_welcomemessage']); ?>
								</div>
								<p class="list-group-item-text"><?php echo $language['ts3_welcome_message']; ?></p>
							</div>
						</li>
						<li class="list-group-item">
							<i class="material-icons">input</i>
							<div class="bmd-list-group-col">
								<p class="list-group-item-heading"><?php echo $server['virtualserver_client_connections']; ?></p>
								<p class="list-group-item-text"><?php echo $language['connections']; ?></p>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<hr class="hr-headline"/>
			<div class="hidden-sm-down">
				<div class="pull-xs-left">
					<?php
						echo $language['instance'].": ";
						
						if($ts3_server[$_GET['instanz']]['alias'] != '')
						{
							xssEcho($ts3_server[$_GET['instanz']]['alias']);
						}
						else
						{
							xssEcho($ts3_server[$_GET['instanz']]['ip']);
						};
					?>
				</div>
				<div class="pull-xs-right uptime" id="uptime-<?php echo $_GET['instanz']; ?>-<?php echo $server['virtualserver_id']; ?>" uptime-timestamp="<?php echo $server['virtualserver_uptime']; ?>">
					<?php
						echo $language['online_since'].": ";
						
						if(isset($server['virtualserver_uptime']))
						{
							echo $tsAdmin->convertSecondsToStrTime($server['virtualserver_uptime']);
						}
						else
						{
							echo "-";
						};
					?>
				</div>
				<div style="clear: both;"></div>
			</div>
			<div class="hidden-md-up" style="text-align: center;">
				<?php
					echo $language['instance'].": ";
					
					if($ts3_server[$_GET['instanz']]['alias'] != '')
					{
						xssEcho($ts3_server[$_GET['instanz']]['alias']);
					}
					else
					{
						xssEcho($ts3_server[$_GET['instanz']]['ip']);
					};
				?>
			</div>
		</div>
	</body>
	
	<script language="JavaScript">
		var instanz						=	'<?php echo htmlentities($_GET['instanz']); ?>',
			port 						= 	'<?php echo htmlentities($_GET['port']); ?>',
			jsonLang					=	'<?php echo str_replace('\"', "", json_encode($language)); ?>',
			lang						=	JSON.parse(jsonLang);
	</script>
	<script src="./js/jquery/jquery.min.js"></script>
	<script src="./js/other/functions.js"></script>
	<script>
	var timeElements 	= 	document.getElementsByClassName('uptime'),
		statusElements	=	document.getElementsByClassName('serverstatus');
	
	if(typeof(serverRefresh) != "undefined")
	{
		clearInterval(serverRefresh);
	};
	
	setTimeout(reloadServerInformations, 10000);
	
	var serverRefresh = setInterval(function()
	{
		if(document.getElementById('globalServerlist'))
		{
			for (var i = 0; i < timeElements.length; ++i)
			{
				var timestamp					=	parseInt(timeElements[i].getAttribute('uptime-timestamp'));
				if(timestamp)
				{
					timestamp++;
					
					var newTime					=	convertTime(timestamp);
					
					timeElements[i].innerHTML 	=	lang.online_since+": "+newTime['days']+"d "+newTime['hours']+"h "+newTime['minutes']+"m "+newTime['seconds']+"s";
					timeElements[i].setAttribute('uptime-timestamp', timestamp);
				}
				else
				{
					timeElements[i].innerHTML 	=	lang.online_since+": -";
				};
			};
			
			for (var i = 0; i < statusElements.length; ++i)
			{
				if(statusElements[i].innerHTML.includes(lang.online))
				{
					var statusIcon				=	$('#'+statusElements[i].getAttribute('iconid'));
					
					if(statusIcon.hasClass("fa-circle-o"))
					{
						statusIcon.removeClass("fa-circle-o");
						statusIcon.addClass("fa-dot-circle-o");
					}
					else
					{
						statusIcon.removeClass("fa-dot-circle-o");
						statusIcon.addClass("fa-circle-o");
					};
					
					statusElements[i].classList.remove("text-danger");
					statusElements[i].classList.add("text-success");
				}
				else
				{
					statusElements[i].classList.remove("text-success");
					statusElements[i].classList.add("text-danger");
				};
			};
		}
		else
		{
			clearInterval(serverRefresh);
		};
	}, 1000);
	
	function reloadServerInformations()
	{
		$.ajax({
			type: "POST",
			url: "./php/functions/functionsTeamspeakPost.php",
			data: {
				action:		'getInstanzServerlistInformations'
			},
			success: function(data)
			{
				var informations 	=	JSON.parse(data);
				
				for(var instanz in informations)
				{
					for(var sid in informations[instanz])
					{
						var objectUptime			=	document.getElementById('uptime-'+instanz+'-'+sid),
							objectOnline			=	document.getElementById('online-'+instanz+'-'+sid),
							objectClients			=	document.getElementById('clients-'+instanz+'-'+sid);
							
						if(objectUptime && objectOnline && objectClients)
						{
							if(!informations[instanz][sid].uptime)
							{
								objectUptime.removeAttribute('uptime-timestamp');
								objectUptime.innerHTML			=	lang.online_since+": -";
							}
							else if(informations[instanz][sid].uptime && objectUptime.getAttribute('uptime-timestamp') == null)
							{
								objectUptime.setAttribute('uptime-timestamp', '1');
							};
							
							if(!informations[instanz][sid].online)
							{
								objectOnline.innerHTML			=	lang.offline;
							}
							else
							{
								if(objectOnline.innerHTML != lang.online)
								{
									objectOnline.innerHTML		=	lang.online;
								};
								
								objectClients.innerHTML			=	informations[instanz][sid].clients+" / "+informations[instanz][sid].maxclients;
							};
						};
					};
				};
			}
		});
		
		setTimeout(reloadServerInformations, 10000);
	};
</script>
</html>