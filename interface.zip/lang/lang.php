<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Includes
	*/
	require_once(__DIR__."/../config/config.php");
	require_once(__DIR__."/../php/functions/functions.php");
	require_once(__DIR__."/../php/functions/functionsSql.php");
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/*
		Installed Languages (add here your language if you have a new one)
	*/
	$language												=	array();
	$installedLanguages										=	array(
																	"german" => "First-Coder.de",
																	"english" => "solidus1983"
																);
	/*
		Default language will be load to be sure if the other languages are not complete, we have still english
	*/
	include("en.php");
	
	if($settings['success']) {
		switch($settings['data']['language']) {
			case 'german':
				include("de.php");
				break;
			case 'italian':
				include("it.php");
				break;
			case 'turkish':
				include("tr.php");
				break;
			case 'french':
				include("fr.php");
				break;
		};
	};
?>