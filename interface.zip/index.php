<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2019 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/**
		Check Config
	*/
	if(!@include("./config/config.php"))
	{
		die("Could not load the config/ and/or logs/ subfiles. Please set the permissions for config/* and logs/*!");
	};
	
	/**
		Debug Modus
	*/
	if(DEBUG) {
		error_reporting(E_ALL);
		ini_set("display_errors", 1);
	};
	
	/**
		Includes
	*/
	require_once("./lang/lang.php");
	require_once("./config/instance.php");
	require_once("./config/instance-bot.php");
	require_once("./php/functions/functions.php");
	require_once("./php/functions/functionsSql.php");
	
	/**
		Database check
	*/
	$checkDb = getSqlConnection(true);
	$checkFolder = checkFolderPermission();
	$checkExtensions = extension_loaded("soap") && extension_loaded("PDO") && extension_loaded("zip");
	
	/**
		Variables
	*/
	$LinkInformations = getLinkInformations();
	if($checkDb) {
		$LoggedIn = (checkSession()) ? true : false;
		$mysql_keys = getKeys();
		$mysqlModul = getModuls();
	};
	if(!empty($LinkInformations[3])) {
		require_once("./php/functions/functionsTeamspeak.php");
		
		if(empty($LinkInformations[2])) {
			$LinkInformations[2] = '0';
		};
		
		$server = getServerInfo($LinkInformations[2], $LinkInformations[3]);
		if(!$server['success']) {
			redirectSite(REDIRECT_SERVER_ERROR);
		};
	};
	
	/**
		Badges
	*/
	$badgeSettings = 0;
	
	if($_SERVER['SERVER_SOFTWARE'] === 'Apache' && !isset($_SERVER['HTACCESS'])) {
		$badgeSettings++;
	};
	
	if($checkExtensions) {
		/**
			SOAP
		*/
		$soap = getUpdateInformations();
		
		/**
			Badges
		*/
		if($soap['isUpdatePossible']) { $badgeSettings++; };
		if(!$soap['isDonator']) { $badgeSettings++; };
	};
	
	/**
		Get Sql Homepagesettings
	*/
	$settings = getSqlHomepagesettings();
	
	/**
		User information
	*/
	$userInformations = false;
	if($LoggedIn) {
		$userInformations = getUserInformations($_SESSION['user']['id']);
		$user_right = getUserRights('pk', $_SESSION['user']['id']);
		
		if(!$user_right['success']) {
			redirectSite(REDIRECT_SERVER_ERROR);
		};
	};
	
	/**
		Navigation
	*/
	if(!($checkExtensions && $checkFolder && $checkDb)) {
		$firstBread = "Errorcodes";
		$firstBreadLink = "";
		if(!$checkExtensions) {
			$secondBread = "510";
		} else if(!$checkFolder) {
			$secondBread = "507";
		} else {
			$secondBread = "503";
		};
	} else {
		$firstBread = $language['navigation'];
		$firstBreadLink = "web_main_main";
		$secondBread = $language['news'];
		$subfolder = "main";
		$queryString = explode("?", $_SERVER['QUERY_STRING'])[0];
		
		if(strpos($queryString, "main") !== false) {
			$subfolder = "main";
			$firstBread = $language['navigation'];
			$firstBreadLink = "web_main_main";
			
			switch($queryString) {
				case "web_main_support_teamspeak":
					$secondBread = $language['support_teamspeak'];
					break;
				case "web_main_main":
					$secondBread = $language['news'];
					break;
				case "web_main_apply_server":
					$secondBread = $language['apply_for_server'];
					break;
				case "web_main_register":
					$secondBread = $language['register'];
					break;
				case "web_main_impressum":
					$secondBread = "Impressum";
					break;
			};
		} elseif(strpos($queryString, "profil") !== false) {
			$subfolder = "profile";
			$firstBread = $language['profile'];
			$firstBreadLink = "web_profil_dashboard";
			
			switch($queryString) {
				case "web_profil_dashboard":
					$secondBread = "Dashboard";
					break;
				case "web_profil_edit":
					$secondBread = $language['edit_profile'];
					break;
			};
		} elseif(strpos($queryString, "admin") !== false) {
			$subfolder = "admin";
			$firstBread = $language['global_settings'];
			$firstBreadLink = "web_admin_settings";
			
			switch($queryString) {
				case "web_admin_settings":
					$secondBread = $language['settings'];
					break;
				case "web_admin_instance":
					$secondBread = $language['instances'];
					break;
				case "web_admin_user":
					$secondBread = $language['client'];
					break;
				case "web_admin_logs":
					$secondBread = $language['logs'];
					break;
			};
		} elseif(strpos($queryString, "musicbot") !== false) {
			$subfolder = "musicbot";
			$firstBread = $language['musicbots'];
			$firstBreadLink = "web_musicbot_server";
			
			switch($queryString) {
				case "web_musicbot_server":
					$secondBread = $language['server'];
					break;
			};
		} elseif(strpos($queryString, "teamspeak") !== false) {
			$subfolder				=	"teamspeak";
			$firstBread				=	$language['interface'];
			$firstBreadLink			=	"web_teamspeak_server";
			
			switch($queryString) {
				case "web_teamspeak_serverview":
					$secondBread	=	$language['server_overview'];
					break;
				case "web_teamspeak_server":
					$secondBread	=	$language['server'];
					break;
				case "web_teamspeak_server_create":
					$secondBread	=	$language['create_server'];
					break;
				case "web_teamspeak_server_requests":
					$secondBread	=	$language['server_requests'];
					break;
				case "web_teamspeak_serverbanner":
					$secondBread	=	$language['serverbanner'];
					break;
				case "web_teamspeak_serverprotokol":
					$secondBread	=	$language['protokoll'];
					break;
				case "web_teamspeak_servermassactions":
					$secondBread	=	$language['mass_actions'];
					break;
				case "web_teamspeak_servericons":
					$secondBread	=	$language['icons'];
					break;
				case "web_teamspeak_serverclients":
					$secondBread	=	$language['client'];
					break;
				case "web_teamspeak_serverbans":
					$secondBread	=	$language['bans'];
					break;
				case "web_teamspeak_servertoken":
					$secondBread	=	$language['token'];
					break;
				case "web_teamspeak_serverfilelist":
					$secondBread	=	$language['filelist'];
					break;
				case "web_teamspeak_serverbackups":
					$secondBread	=	$language['backups'];
					break;
			};
		} elseif(strpos($queryString, "ticket") !== false) {
			$subfolder = "ticket";
			$firstBread = $language['ticket_system'];
			$secondBread = $language['tickets'];
			$firstBreadLink = "web_ticket";
		};
	};
	
	/**
		Get custom navigation
	*/
	$ownSites = getSqlOwnSites();
?>

<!doctype html>
<html lang="en">
	<head>
		<title><?php echo xssSafe($settings['data']['title'])." -- Teamspeak3 Control Panel -- ".$secondBread; ?></title>
		
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=0.6, minimum-scale=0.6, maximum-scale=0.6, shrink-to-fit=no" />
		<meta name="theme-color" content="#2f7207" />
		<meta name="author" content="First Coder: L.Gmann" />
		
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" />
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Courgette|Kreon|Poppins|Roboto" />
		
		<link rel="stylesheet" type="text/css" href="css/other/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="css/other/dropzone.css" />
		<link rel="stylesheet" type="text/css" href="css/chart/chartist.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-table.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-material-datetimepicker.css" />
		<link rel="stylesheet" type="text/css" href="css/editor/summernote-bs4.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		
		<script>
			var jsonLang = '<?php echo str_replace('\"', "", json_encode($language)); ?>';
			var lang = JSON.parse(jsonLang);
		</script>
		
		<script src="js/jquery/jquery.min.js"></script>
		<script src="js/jquery/jquery.bootstrap.js"></script>
		<script src="js/other/tether.js"></script>
		<script src="js/other/popper.js"></script>
		<script src="js/other/functions.js"></script>
		<script src="js/other/navigation.js"></script>
		<script src="js/other/arrive.js"></script>
		<script src="js/other/approve.js"></script>
		<script src="js/other/sweetalert2.js"></script>
		<script src="js/bootstrap/bootstrap-material-design.iife.js"></script>
		<script src="js/bootstrap/bootstrap-table.js"></script>
		<script src="https://apis.google.com/js/api:client.js"></script>
	</head>
	
	<body>
		<!-- Demo -->
		<div id="demo" style="display: <?php echo (!DEMO) ? 'none' : 'initial'; ?>;">
			Demo-Modus
		</div>
		
		<!-- Header -->
		<nav class="navbar">
			<span class="navbar-brand nav-title"><?php xssEcho($settings['data']['title']); ?></span>
			<?php if($checkExtensions && $checkFolder && $checkDb) { ?>
				<div class="dropdown">
					<button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<span><?php echo $language['navigation']; ?></span>
					</button>
					<div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						<a class="dropdown-item" href="#" onClick="changeContent('web_main_main');return false;"><i class="far fa-newspaper"></i><?php echo $language['news']; ?></a>
						
						<?php
							if($ownSites['success']) {
								foreach($ownSites['data'] AS $id=>$content) {
									if(empty($content['name'])) {
										continue;
									};
									
									switch($id) {
										case 'custom_01':
											echo '<a class="dropdown-item" href="#" onClick="changeContent(\''.$content['value'].'\', false, \''.$content['name'].'\');return false;"><i class="'.$content['icon'].'"></i>'.$content['name'].'</a>';
											break;
										case 'custom_02':
											echo '<a class="dropdown-item" href="#" onClick="changeContent(\''.$content['value'].'\', false, \''.$content['name'].'\');return false;"><i class="'.$content['icon'].'"></i>'.$content['name'].'</a>';
											break;
										case 'custom_03':
											echo '<a class="dropdown-item" href="#" onClick="changeContent(\''.$content['value'].'\', false, \''.$content['name'].'\');return false;"><i class="'.$content['icon'].'"></i>'.$content['name'].'</a>';
											break;
										case 'custom_04':
											echo '<a class="dropdown-item" href="#" onClick="changeContent(\''.$content['value'].'\', false, \''.$content['name'].'\');return false;"><i class="'.$content['icon'].'"></i>'.$content['name'].'</a>';
											break;
									};
								};
							};
						?>
						<div class="dropdown-divider"></div>
						<?php if($mysqlModul['data']['support_teamspeak'] == "true" && $mysqlModul['data']['support_teamspeak_instance'] !== false && $mysqlModul['data']['support_teamspeak_port'] !== false && isset($ts3_server[$mysqlModul['data']['support_teamspeak_instance']])) { ?>
							<a class="dropdown-item" href="#" onClick="changeContent('web_main_support_teamspeak');return false;"><i class="far fa-eye"></i><?php echo $language['support_teamspeak']; ?></a>
						<?php }; ?>
						<?php if($mysqlModul['data']['free_ts3_server_application'] == "true") { ?>
							<a class="dropdown-item d-none" href="#" onClick="changeContent('web_main_apply_server');return false;"><i class="far fa-edit"></i><?php echo $language['apply_for_server']; ?></a>
						<?php }; ?>
					</div>
				</div>
				
				<div class="nav"></div>
				<li class="nav-item dropdown dropdown-flags showOnUnlogged" style="<?php echo (!$LoggedIn) ? "display: inline;" : "display: none;" ?>">
					<a class="nav-link dropdown-toggle no-after" data-toggle="dropdown" href="#">
						<i class="fas fa-sign-in-alt"></i>
					</a>
					<div class="dropdown-menu dropdown-menu-right from-right dropdown-menu-lg dropdown-no-event">
						<div class="header">
							<div>
								<div class="picture">
									<div>
										<i class="fab fa-keycdn"></i>
									</div>
								</div>
								<div class="details">
									<span class="name"><?php echo $language['login']; ?></span>
									<span class="mail">Teamspeak 3 Interface</span>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label><?php echo $language['mail']; ?></label>
							<input id="loginUser" type="email" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
						<div class="form-group">
							<label><?php echo $language['password']; ?></label>
							<input id="loginPw" type="password" class="form-control">
							<small class="form-control-feedback"></small>
						</div>
						<button onClick="loginUser();" id="loginBtn" class="btn btn-success mt-3 w-100-percent"><i class="fa fa-paper-plane"></i> <?php echo $language['login']; ?></button>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" id="forget-access" href="#">
							<i class="fas fa-question"></i><span class="title"><?php echo $language['forgot_access']; ?></span>
						</a>
						<?php if($mysqlModul['success'] && $mysqlModul['data']['free_register'] == "true") { ?>
							<a class="dropdown-item" onClick="changeContent('web_main_register');return false;" href="#">
								<i class="fas fa-user-plus"></i></i><span class="title"><?php echo $language['register']; ?></span>
							</a>
						<?php }; ?>
					</div>
				</li>
				<div class="dropdown user-dropdown showOnLogged" style="<?php echo ($LoggedIn) ? "display: inline;" : "display: none;" ?>">
					<a class="dropdown-toggle no-after" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<div class="badge badge-40">
							<img src="<?php echo getUserPicture(); ?>" class="max-w-40 profile-image" alt="badge" />
						</div>
					</a>
					<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right from-right">
						<div class="header">
							<div>
								<div class="picture">
									<img class="profile-image" src="<?php echo getUserPicture(); ?>" />
								</div>
								<div class="details">
									<span class="name"><?php xssEcho((empty($userInformations['data']['firstname'])) ? "Mr. Unknown" : $userInformations['data']['firstname'][0].'. '.$userInformations['data']['lastname']); ?></span>
									<span class="mail profile-mail"><?php xssEcho((isset($_SESSION['user']['benutzer'])) ? $_SESSION['user']['benutzer'] : ""); ?></span>
								</div>
							</div>
						</div>
						<a class="dropdown-item" href="#" onClick="changeContent('web_profil_dashboard');return false;">
							<i class="fas fa-tachometer-alt"></i><span class="title">Dashboard</span>
						</a>
						<a class="dropdown-item" href="#" onClick="changeContent('web_profil_edit');return false;">
							<i class="fas fa-user"></i><span class="title"><?php echo $language['profile']; ?></span>
						</a>
						<a class="dropdown-item" href="#" onClick="changeContent('web_ticket');return false;">
							<i class="fas fa-headset"></i><span class="title"><?php echo $language['tickets']; ?></span>
						</a>
						<div class="dropdown-divider"></div>
						<a class="dropdown-item" onClick="ausloggenInit();return false;" href="#">
							<i class="fas fa-sign-out-alt"></i><span class="title"><?php echo $language['logout']; ?></span>
						</a>
					</div>
				</div>
			<?php } else { ?>
				<div class="nav"></div>
			<?php }; ?>
		</nav>
		
		<div class="jumbotron-main">
			<div class="jumbotron-content">
				<ul class="showOnLogged" data-display="table-cell" style="<?php echo (!$LoggedIn) ? "display: none;" : "display: table-cell;" ?>">
					<li class="perm_admin <?php echo (hasPermGroup('perm_admin')) ? "" : "d-none" ?>">
						<a href="#" data-toggle="dropdown" class="dropdown-toggle no-after"><i class="fas fa-cogs mr-2"></i><?php echo $language['global_settings']; ?> <i class="fas fa-angle-down"></i></a>
						<div class="dropdown-menu no-margin-left">
							<a href="#" class="dropdown-item perm_admin_settings <?php echo (!hasPermGroup('perm_admin_settings')) ? 'd-none' : ''; ?>" onClick="changeContent('web_admin_settings');return false;">
								<span class="dropdown-text">
									<i class="fas fa-cog"></i>
									<span class="dropdown-title"><?php echo $language['settings']; ?></span>
									<span class="dropdown-badge">
										<div class="badge badge-20 badge-<?php echo ($badgeSettings > 0) ? 'danger' : 'success'; ?>"><?php echo $badgeSettings; ?></div>
									</span>
								</span>
							</a>
							<a href="#" class="dropdown-item perm_admin_instance <?php echo (!hasPermGroup('perm_admin_instances')) ? 'd-none' : ''; ?>" onClick="changeContent('web_admin_instance');return false;">
								<span class="dropdown-text">
									<i class="fas fa-globe"></i>
									<span class="dropdown-title"><?php echo $language['instances']; ?></span>
									<span class="dropdown-badge">
										<?php
											$countTs = (isset($ts3_server)) ? count($ts3_server) : 0;
											$countMusic = (isset($music_server)) ? count($music_server) : 0;
										?>
										<div class="badge badge-20 badge-<?php echo ($countTs > 0 || $countMusic > 0) ? 'success' : 'danger'; ?>"><?php echo ($mysqlModul['data']['splamy_musicbot'] == "true") ? $countTs + $countMusic : $countTs; ?></div>
									</span>
								</span>
							</a>
							<a href="#" class="dropdown-item perm_admin_user <?php echo (!hasPermGroup('perm_admin_users')) ? 'd-none' : ''; ?>" onClick="changeContent('web_admin_user');return false;">
								<span class="dropdown-text">
									<i class="fas fa-users"></i>
									<span class="dropdown-title"><?php echo $language['client']; ?></span>
								</span>
							</a>
							<a href="#" class="dropdown-item perm_admin_logs <?php echo (!hasPermGroup('perm_admin_logs')) ? 'd-none' : ''; ?>" onClick="changeContent('web_admin_logs');return false;">
								<span class="dropdown-text">
									<i class="fas fa-archive"></i>
									<span class="dropdown-title"><?php echo $language['logs']; ?></span>
								</span>
							</a>
						</div>
					</li>
					<li>
						<a href="#" data-toggle="dropdown" class="dropdown-toggle no-after"><i class="fas fa-server mr-2"></i><?php echo $language['server']; ?> <i class="fas fa-angle-down"></i></a>
						<div class="dropdown-menu no-margin-left">
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_server');return false;"><i class="fab fa-teamspeak"></i>Teamspeak</a>
							<a href="#" class="dropdown-item perm_teamspeak_create_server <?php echo (!hasPermGroup('perm_teamspeak_create_server')) ? 'd-none' : ''; ?>" onClick="changeContent('web_teamspeak_server_create');return false;"><i class="far fa-edit"></i></i><?php echo $language['create_teamspeak']; ?></a>
							<div class="dropdown-divider <?php echo ($mysqlModul['data']['splamy_musicbot'] == "true") ? '' : 'd-none'; ?>"></div>
							<a href="#" class="dropdown-item <?php echo ($mysqlModul['data']['splamy_musicbot'] == "true") ? '' : 'd-none'; ?>" onClick="changeContent('web_musicbot_server');return false;"><i class="fas fa-music"></i></i><?php echo $language['musicbots']; ?></a>
							<a href="#" class="dropdown-item perm_bot_create_bot <?php echo ($mysqlModul['data']['splamy_musicbot'] == "true" && hasPermGroup('perm_bot_create_bot')) ? '' : 'd-none'; ?>" onClick="changeContent('web_musicbot_server_create');return false;"><i class="far fa-edit"></i></i><?php echo $language['create_bot']; ?></a>
							<?php if($mysqlModul['data']['free_ts3_server_application'] == "true") { ?>
								<div class="dropdown-divider perm_teamspeak_create_serve d-none <?php echo (!hasPermGroup('perm_teamspeak_create_server')) ? 'd-none' : ''; ?>"></div>
								<a href="#" class="dropdown-item perm_teamspeak_create_serve d-none <?php echo (!hasPermGroup('perm_teamspeak_create_server')) ? 'd-none' : ''; ?>" onClick="changeContent('web_teamspeak_server_requests');return false;"><i class="far fa-edit"></i></i><?php echo $language['server_requests']; ?></a>
							<?php }; ?>
						</div>
					</li>
					<li id="navTsServerName" class="<?php echo (empty($LinkInformations[3])) ? 'd-none' : ''; ?>" data-instance="<?php echo empty($LinkInformations[2]) ? "" : $LinkInformations[2]; ?>" data-port="<?php echo empty($LinkInformations[3]) ? "" : $LinkInformations[3]; ?>">
						<a href="#" data-toggle="dropdown" class="dropdown-toggle no-after"><i class="fab fa-teamspeak mr-2"></i><span><?php echo (isset($server)) ? $server['data']['virtualserver_name'] : ''; ?></span> <i class="fas fa-angle-down"></i></a>
						<div class="dropdown-menu no-margin-left">
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_serverview', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-eye"></i><?php echo $language['server_overview']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_serveredit', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-pencil-alt"></i><?php echo $language['server_edit']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_servergroups', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fab fa-trello"></i><?php echo $language['server_groups']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_serverclients', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-users"></i><?php echo $language['server_clients']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_servermassactions', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-boxes"></i><?php echo $language['server_mass_actions']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_serverprotokol', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-atlas"></i><?php echo $language['server_protokoll']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_servertoken', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-key"></i><?php echo $language['server_token']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_serverbans', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-user-times"></i><?php echo $language['server_bans']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_servericons', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-images"></i><?php echo $language['server_icons']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_serverfilelist', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-file"></i><?php echo $language['server_filelist']; ?></a>
							<a href="#" class="dropdown-item" onClick="changeContent('web_teamspeak_serverbackups', true, false, ':navTsServerName', ':navTsServerName');return false;"><i class="fas fa-cloud-upload-alt"></i><?php echo $language['server_backups']; ?></a>
						</div>
					</li>
				</ul>
				<ol class="breadcrumb icon-home icon-angle-right no-bg breadline">
					<li id="secondBread"><?php echo $secondBread; ?></li>
					<li><a id="firstBread" href="#" onClick="changeContent('<?php echo $firstBreadLink; ?>');return false;"><?php echo $firstBread; ?></a></li>
				</ol>
			</div>
		</div>
		
		<!-- Spinner -->
		<span class="spinner">
			<span class="spinner-bar"></span>
		</span>
		
		<!-- Content -->
		<div id="myContent">
			<?php
				if(!$checkDb) {
					include_once("./php/errorcodes/503.php");
				} else if(!$checkFolder) {
					include_once("./php/errorcodes/507.php");
				} else if(!$checkExtensions) {
					include_once("./php/errorcodes/510.php");
				} else {
					if(!empty($LinkInformations) && file_exists("./php/".$subfolder."/".$LinkInformations['site'].".php")) {
						include_once("./php/".$subfolder."/".$LinkInformations['site'].".php");
					} else {
						include_once("./php/main/web_main_main.php");
					};
				};
			?>
		</div>
		
		<!-- Do not change the footer. It´s part of the copyright! -->
		<div id="footer">
			<div class="footer-row">
				<div class="copyright">
					2019 <i class="far fa-copyright"></i> First-Coder by <a href="https://first-coder.de/" target="_blank">L.Gmann</a>
				</div>
				<div class="links">
					<a href="https://github.com/First-Coder/" target="_blank"><i class="fab fa-github mr-2"></i>Github</a>
					<a href="https://forum.first-coder.de/" target="_blank"><i class="fas fa-hands-helping mr-2"></i>Forum</a>
					<a href="#" onClick="changeContent('web_main_impressum');return false;"><i class="far fa-handshake mr-2"></i>Impressum</a>
				</div>
			</div>
		</div>
		
		<script>
			/**
				Meterial init
			*/
			$('body').bootstrapMaterialDesign();
			
			/**
				Dropwdown events for the login area
			*/
			$('.dropdown-menu.dropdown-no-event').on('click', function(event){
				// The event won't be propagated up to the document NODE and 
				// therefore delegated events won't be fired
				event.stopPropagation();
			});

			/**
			 * Forget access
			 */
			$('.navbar .dropdown-menu').on("click", "#forget-access", function(e) {
				e.preventDefault();
				
				if($(this).attr("data-focused") === "true") {
					$(this).attr("data-focused", "true");
					$("span", this).html(lang.forgot_access);
					$('#loginPw').closest("div").slideDown("fast");
					$('#loginBtn').removeClass("btn-warning").addClass("btn-success").html('<i class="fa fa-paper-plane"></i> '+lang.login);
					$(this).attr("data-focused", "false");
				} else {
					$(this).attr("data-focused", "true");
					$("span", this).html(lang.back);
					$('#loginPw').closest("div").slideUp("fast");
					$('#loginBtn').removeClass("btn-success").addClass("btn-warning").html('<i class="fas fa-question"></i> '+lang.forgot_access);
				};
			});
		</script>
		<script src="./js/bootstrap/bootstrap-tooltip.js"></script>
	</body>
</html>