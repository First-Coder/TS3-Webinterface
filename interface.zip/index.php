<?php
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann

		This program is free software: you can redistribute it and/or modify
		it under the terms of the GNU General Public License as published by
		the Free Software Foundation, either version 3 of the License, or
		any later version.

		This program is distributed in the hope that it will be useful,
		but WITHOUT ANY WARRANTY; without even the implied warranty of
		MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
		GNU General Public License for more details.

		You should have received a copy of the GNU General Public License
		along with this program.  If not, see <http://www.gnu.org/licenses/>.
		
		for help look http://first-coder.de/
	*/
	
	/*
		Check Config
	*/
	if(!@include("./config/config.php"))
	{
		die("Could not load the config/ and/or logs/ subfiles. Please set the permissions for config/* and logs/*!");
	};
	
	/*
		Includes
	*/
	require_once("./lang/lang.php");
	require_once("./php/functions/functions.php");
	require_once("./php/functions/functionsSql.php");
	
	/*
		Variables
	*/
	$LoggedIn			=	(checkSession()) ? true : false;
	$LinkInformations	=	getLinkInformations();
	$mysql_modul		=	getModuls();
	$mysql_keys			=	getKeys();
	
	/*
		Get Client Permissions
	*/
	$user_right			=	getUserRights('pk', $_SESSION['user']['id']);
	
	/*
		Masterserver abfragen
	*/
	if($mysql_modul['masterserver'] == "true" && MASTERSERVER_INSTANZ != "" && MASTERSERVER_PORT != "")
	{
		require_once("./config/instance.php");
		require_once("./php/classes/ts3admin.class.php");
		
		$tsAdmin = new ts3admin($ts3_server[MASTERSERVER_INSTANZ]['ip'], $ts3_server[MASTERSERVER_INSTANZ]['queryport']);
	
		if($tsAdmin->getElement('success', $tsAdmin->connect()))
		{
			$tsAdmin->login($ts3_server[MASTERSERVER_INSTANZ]['user'], $ts3_server[MASTERSERVER_INSTANZ]['pw']);
			$tsAdmin->selectServer(MASTERSERVER_PORT, 'port', true);
			
			$indexServer		= 	$tsAdmin->serverInfo();
		};
	};
	
	/*
		Database check
	*/
	$dbError 					=	getSqlConnection(true);
	$folderPermission			=	checkFolderPermission();
	$soap						=	extension_loaded("soap");
	
	/*
		Navigation
	*/
	$firstBread					=	$language['profile'];
	$firstBreadLink				=	"web_main_main";
	$secondBread				=	"";
	$subfolder					=	"login";
	$queryString				=	explode("?", $_SERVER['QUERY_STRING'])[0];
	
	if(strpos($queryString, "main") !== false)
	{
		$subfolder				=	"main";
	};
	if(strpos($queryString, "profil") !== false)
	{
		$subfolder				=	"profile";
		$firstBread				=	$language['profile'];
		$firstBreadLink			=	"web_profil_dashboard";
		
		switch($queryString)
		{
			case "web_profil_dashboard":
				$secondBread	=	"Dashboard";
				break;
			case "web_profil_edit":
				$secondBread	=	$language['edit_profile'];
				break;
		};
	};
	if(strpos($queryString, "admin") !== false)
	{
		$subfolder				=	"admin";
		$firstBread				=	$language['global_settings'];
		$firstBreadLink			=	"web_admin_settings";
		
		switch($queryString)
		{
			case "web_admin_settings":
				$secondBread	=	$language['settings'];
				break;
			case "web_admin_instanz":
				$secondBread	=	$language['instances'];
				break;
			case "web_admin_user":
				$secondBread	=	$language['client'];
				break;
			case "web_admin_mail":
				$secondBread	=	$language['mail_settings'];
				break;
			case "web_admin_logs":
				$secondBread	=	$language['logs'];
				break;
		};
	};
	if(strpos($queryString, "teamspeak") !== false)
	{
		$subfolder				=	"teamspeak";
		$firstBread				=	$language['interface'];
		$firstBreadLink			=	"web_teamspeak_server";
		
		switch($queryString)
		{
			case "web_teamspeak_serverview":
				$secondBread	=	$language['server_overview'];
				break;
			case "web_teamspeak_server":
				$secondBread	=	$language['server'];
				break;
			case "web_teamspeak_server_create":
				$secondBread	=	$language['create_server'];
				break;
			case "web_teamspeak_server_requests":
				$secondBread	=	$language['server_requests'];
				break;
			case "web_teamspeak_serverbanner":
				$secondBread	=	$language['serverbanner'];
				break;
			case "web_teamspeak_serverprotokol":
				$secondBread	=	$language['protokoll'];
				break;
			case "web_teamspeak_servermassactions":
				$secondBread	=	$language['mass_actions'];
				break;
			case "web_teamspeak_servericons":
				$secondBread	=	$language['icons'];
				break;
			case "web_teamspeak_serverclients":
				$secondBread	=	$language['client'];
				break;
			case "web_teamspeak_serverbans":
				$secondBread	=	$language['bans'];
				break;
			case "web_teamspeak_servertoken":
				$secondBread	=	$language['token'];
				break;
			case "web_teamspeak_serverfilelist":
				$secondBread	=	$language['filelist'];
				break;
			case "web_teamspeak_serverbackups":
				$secondBread	=	$language['backups'];
				break;
		};
	};
	if(strpos($queryString, "bot") !== false)
	{
		$subfolder				=	"bot";
		$firstBread				=	$language['botinterface'];
		$secondBread			=	$language['tickets'];
		$firstBreadLink			=	"web_bot_query";
	};
	if(strpos($queryString, "ticket") !== false)
	{
		$subfolder				=	"ticket";
		$firstBread				=	$language['ticket_system'];
		$secondBread			=	$language['tickets'];
		$firstBreadLink			=	"web_ticket";
	};
?>

<!doctype html>
<html lang="en" class="custom-bg">
	<head>
		<title><?php echo xssSafe(HEADING)." -- Teamspeak3 Control Panel -- Version 2 CLOSED-ALPHA"; ?></title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=0.8, minimum-scale=0.8, maximum-scale=0.8, shrink-to-fit=no">
		<meta name="author" content="First Coder: L.Gmann">
		
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Courgette|Kreon">
		
		<link rel="stylesheet" type="text/css" href="css/other/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="css/other/toastr.css" />
		<link rel="stylesheet" type="text/css" href="css/other/sweetalert2.css" />
		<link rel="stylesheet" type="text/css" href="css/other/dropzone.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-table.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-material-datetimepicker.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-colorpicker.css" />
		<link rel="stylesheet" type="text/css" href="css/bootstrap/bootstrap-editable.css" />
		<link rel="stylesheet" type="text/css" href="css/mail/codemirror.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<?php if(STYLE !== "") { ?>
			<link rel="stylesheet" type="text/css" href="css/themes/<?php echo STYLE; ?>.css" />
		<?php }; ?>
		
		<script>
			var ts3_server_create_default 	= 	<?php echo json_encode($ts3_server_create_default); ?>,
				jsonLang					=	'<?php echo str_replace('\"', "", json_encode($language)); ?>',
				lang						=	JSON.parse(jsonLang),
				logged 						=	'<?php echo ($LoggedIn) ? "true" : "false"; ?>',
				wantServer 					= 	new Array(),
				checkClientInterval			= 	<?php echo CHECK_CLIENT_PERMS; ?>,
				updateAvalible				=	"<?php echo (checkNewVersion(false) != INTERFACE_VERSION) ? "true" : "false"; ?>",
				hasPermission				=	"<?php echo $hasPermission; ?>",
				timer						=	10,
				emailRegex					=	/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;;
		</script>
		
		<script src="js/jquery/jquery.min.js"></script>
		<script src="js/jquery/jquery.bootstrap.js"></script>
		<script src="js/other/tether.js"></script>
		<script src="js/other/functions.js"></script>
		<script src="js/other/navigation.js"></script>
		<script src="js/other/arrive.js"></script>
		<script src="js/other/approve.js"></script>
		<script src="js/other/toastr.js"></script>
		<script src="js/other/sweetalert2.js"></script>
		<script src="js/other/draggabilly.pkgd.js"></script>
		<script src="js/bootstrap/bootstrap-material-design.iife.js"></script>
		<script src="js/bootstrap/bootstrap-table.js"></script>
		<script src="https://apis.google.com/js/api:client.js"></script>
		
		<script>
			toastr.options = {
				positionClass: 'toast-bottom-right',
				progressBar: true
			};
			var OverlayButton = new OverlayButton();
		</script>
	</head>
	
	<body>
		<!-- Header -->
		<nav class="navbar">
			<span class="navbar-brand nav-title"><?php xssEcho(HEADING); ?></span>
			<ul class="nav nav-inline navbar-left" style="text-align: right;">
				<?php if($soap && $dbError == "done" && $folderPermission) { ?>
					<li class="nav-item mainNaviServerview" style="<?php echo (empty($LinkInformations)) ? "display: none;" : "display: inline"; ?>">
						<a class="nav-link" onClick="changeNavigation();changeContent('web_teamspeak_server');return false;" href="#">
							<i class="material-icons">list</i> <span class="hidden-sm-down nav-linktext"><?php echo $language['serverlist']; ?></span>
						</a>
					</li>
					<li class="nav-item mainNaviLogged" style="<?php echo (empty($LinkInformations)) ? "display: inline;" : "display: none"; ?>">
						<a class="nav-link" onClick="changeContent('web_main_main');return false;" href="#">
							<i class="material-icons">home</i> <span class="hidden-sm-down nav-linktext"><?php echo $language['main_site']; ?></span>
						</a>
					</li>
					<li class="nav-item mainNaviLogged hidden-415-down mainApplyForServer <?php if($mysql_modul['free_ts3_server_application'] != "true") { echo "no-display"; }; ?>" style="<?php if(!empty($LinkInformations)) { echo "display:none;"; }; ?>">
						<a class="nav-link" onClick="changeContent('web_main_apply_server');return false;" href="#">
							<i class="material-icons">mode_edit</i> <span class="hidden-sm-down nav-linktext"><?php echo $language['apply_for_server']; ?></span>
						</a>
					</li>
					<li class="nav-item mainNaviLogged mainMasterserver <?php if($mysql_modul['masterserver'] != "true" || MASTERSERVER_INSTANZ == "" || MASTERSERVER_PORT == "") { echo "no-display"; }; ?>" style="<?php if(!empty($LinkInformations)) { echo "display:none;"; }; ?>">
						<a class="nav-link" onClick="changeContent('web_main_masterserver');return false;" href="#">
							<div class="badge badge-20">
								<i class="material-icons">remove_red_eye</i>
								<span class="tag tag-rounded tag-primary"><?php echo ($indexServer['data']['virtualserver_clientsonline'] - $indexServer['data']['virtualserver_queryclientsonline']); ?></span>
							</div>
						</a>
					</li>
					<?php if($mysql_modul['free_register'] == "true") { ?>
						<li class="nav-item dropdown dropdown-flags showOnUnlogged" style="<?php echo (!$LoggedIn) ? "display: inline;" : "display: none;" ?>">
							<a class="nav-link dropdown-toggle no-after" data-toggle="dropdown" href="#">
								<i class="material-icons">input</i>
							</a>
							<div class="dropdown-menu dropdown-menu-right from-right">
								<div class="dropdown-item" onClick="changeContent('web_login');return false;">
									<a href="#"><?php echo $language['login']; ?></a>
								</div>
								<div class="dropdown-item" onClick="changeContent('web_login_register');return false;">
									<a href="#"><?php echo $language['register']; ?></a>
								</div>
							</div>
						</li>
					<?php } else { ?>
						<li class="nav-item showOnUnlogged" style="<?php echo (!$LoggedIn) ? "display: inline;" : "display: none;" ?>">
							<a class="nav-link" onClick="changeContent('web_login');return false;" href="#">
								<i class="material-icons">input</i>
							</a>
						</li>
					<?php };
				}; ?>
			</ul>
			<div class="dropdown user-dropdown showOnLogged" style="<?php echo ($LoggedIn) ? "display: inline;" : "display: none;" ?>">
				<?php if($soap && $dbError == "done" && $folderPermission) { ?>
					<a class="dropdown-toggle no-after" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<div class="badge badge-40">
							<img src="<?php echo getUserPicture(); ?>" class="max-w-40 img-circle" alt="badge" />
						</div>
					</a>
					<div class="dropdown-menu dropdown-menu-right from-right">
						<a class="dropdown-item" href="#" onClick="changeNavigation();changeContent('web_profil_dashboard');return false;">
							<i class="material-icons icon">dashboard</i>
							<span class="title">Dashboard</span>
						</a>
						<a class="dropdown-item" href="#" onClick="changeNavigation();changeContent('web_profil_edit');return false;">
							<i class="material-icons icon">person</i>
							<span class="title"><?php echo $language['profile']; ?></span>
						</a>
						<a class="dropdown-item" onClick="changeNavigation();ausloggenInit();return false;" href="#">
							<i class="material-icons icon">power_settings_new</i>
							<span class="title"><?php echo $language['logout']; ?></span>
						</a>
					</div>
				<?php }; ?>
			</div>
			<a class="navbar-right btn btn-flat showOnLogged" href="#" style="<?php echo ($LoggedIn) ? "display: inline;" : "display: none;" ?>">
				<?php if($soap && $dbError == "done" && $folderPermission) { ?>
					<li class="nav-item no-liststyle showOnLogged" style="<?php echo ($LoggedIn) ? "display: inline;" : "display: none;" ?>">
						<a class="nav-link toggle-layout" href="#">
							<i class="material-icons menu">menu</i>
						</a>
					</li>
				<?php }; ?>
			</a>
		</nav>
		
		<div class="jumbotron-main">
			<div class="jumbotron jumbotron-fluid">
				<div class="container-fluid">
					<ol class="breadcrumb icon-home icon-angle-right no-bg showOnLogged breadline" style="<?php echo ($LoggedIn && $subfolder != "main" && !empty($queryString)) ? "display: inline;" : "display: none;" ?>">
						<li><a id="firstBread" href="#" onClick="changeNavigation();changeContent('<?php echo $firstBreadLink; ?>');return false;"><?php echo $firstBread; ?></a></li>
						<li id="secondBread"><?php echo $secondBread; ?></li>
					</ol>
					<?php
						$SOAP_NEWS = getSoapNews();
						if(!empty($SOAP_NEWS)) { ?>
							<div class="marquee"><?php echo $SOAP_NEWS ?></div>
					<?php }; ?>
				</div>
			</div>
		</div>
		
		<div class="container-fluid">
			<div class="row">
				<div class="left-sidebar">
					<div class="wrapper">
						<div class="content">
							<div class="content-bottom">
								<div class="left-sidebar-section" id="naviContent">
									<?php include_once((count(explode("?", $_SERVER['QUERY_STRING'])) > 1) ? "./php/login/web_logged_serverview.php" : "./php/login/web_logged.php"); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Hidden Boxes -->
		<div class="backdrop">
			<i class="fa fa-spinner fa-spin" aria-hidden="true"></i>
		</div>
		
		<div id="OverlayButton" class="btn bmd-btn-fab bmd-fixed" style="display: none;" data-toggle="tooltip" data-placement="left">
			<i class="fa" aria-hidden="true"></i>
		</div>
		
		<!-- Content -->
		<div id="myContent">
			<?php
				if($dbError != "done")
				{
					include_once("./php/verify/verify_sql_failed.php");
				}
				else if(!$folderPermission)
				{
					include_once("./php/verify/verify_permissions.php");
				}
				else if(!$soap)
				{
					include_once("./php/verify/verify_soap.php");
				}
				else
				{
					if(!empty($queryString) && file_exists("./php/".$subfolder."/".$queryString.".php"))
					{
						include_once("./php/".$subfolder."/".$queryString.".php");
					}
					else
					{
						include_once("./php/main/web_main_main.php");
					};
				};
			?>
		</div>
		
		<div id="footer" class="jumbotron-main">
			<div class="jumbotron jumbotron-fluid">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-4">
							<div class="footer-background">
								<ul class="list-group footer-color-light">
									<li class="list-group-item">
										<p class="list-group-item-heading footer-headline"><i class="fa fa-thumbs-up" aria-hidden="true"></i> <?php echo "Speziellen Dank"; ?></p>
									</li>
									<div class="footer-border ml-2 mr-2"></div>
									<li class="list-group-item">
										SoulofSorrow
										<span class="tag tag-secondary tag-pill pull-xs-right">Projektmanager</span>
									</li>
									<li class="list-group-item">
										L. Gmann
										<span class="tag tag-secondary tag-pill pull-xs-right">Entwickler</span>
									</li>
									<li class="list-group-item">
										angeloccrr
										<span class="tag tag-secondary tag-pill pull-xs-right">Designer</span>
									</li>
									<li class="list-group-item">
										Splamy
										<span class="tag tag-secondary tag-pill pull-xs-right">Bot Entwickler</span>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-md-4">
							<?php if($mysql_modul['masterserver'] == "true" && MASTERSERVER_INSTANZ != "" && MASTERSERVER_PORT != "") { ?>
								<div class="footer-background">
									<ul class="list-group footer-color-dark">
										<li class="list-group-item">
											<p class="list-group-item-heading footer-headline"><i class="fa fa-eye" aria-hidden="true"></i> <?php xssEcho($indexServer['data']['virtualserver_name']); ?></p>
										</li>
										<div class="footer-border ml-2 mr-2"></div>
										<li class="list-group-item">
											<?php echo $language['ts3_serverstatus']; ?>
											<span class="tag tag-<?php echo($indexServer['data']['virtualserver_status'] == "online") ? "success" : "danger"; ?> tag-pill pull-xs-right"><?php echo $indexServer['data']['virtualserver_status']; ?></span>
										</li>
										<li class="list-group-item">
											<?php echo $language['online_since']; ?>
											<span class="tag tag-secondary tag-pill pull-xs-right">
												<?php 
													$Tage			= 	$indexServer['data']['virtualserver_uptime'] / 86400;
													$Stunden		=	($indexServer['data']['virtualserver_uptime'] - (floor($Tage) * 86400)) / 3600;
													$Minuten		=	($indexServer['data']['virtualserver_uptime'] - (floor($Tage) * 86400) - (floor($Stunden) * 3600)) / 60;

													echo floor($Tage) . "d " . floor($Stunden) . "h " . floor($Minuten) . "m";
												?>
											</span>
										</li>
										<li class="list-group-item">
											<?php echo $language['client']; ?>
											<span class="tag tag-secondary tag-pill pull-xs-right"><?php echo ($indexServer['data']['virtualserver_clientsonline'] - $indexServer['data']['virtualserver_queryclientsonline'])." / ".$indexServer['data']['virtualserver_maxclients']; ?></span>
										</li>
										<li class="list-group-item">
											<?php echo $language['connections']; ?>
											<span class="tag tag-secondary tag-pill pull-xs-right"><?php echo $indexServer['data']['virtualserver_client_connections']; ?></span>
										</li>
									</ul>
								</div>
							<?php }; ?>
						</div>
						<!-- Copyright! Do not remove this lines! -->
						<div class="col-md-4">
							<div id="copyright" class="footer-logo">
								<img style="width:300px;" src="https://first-coder.de/images/fcLogo.png"/>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
			$('body').bootstrapMaterialDesign();
		</script>
		<script src="./js/bootstrap/bootstrap-tooltip.js"></script>
	</body>
</html>